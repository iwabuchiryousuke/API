"""Fiscal-share legal dates are independent of exchange ex-rights dates."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import gzip,json
from pathlib import Path

import pytest

from zaimu10.market_cap import extract_fiscal_shares,assemble_market_caps
from zaimu10.models import Filing,Period
from zaimu10.split_basis import align_fiscal_share_basis

FIXTURE=Path(__file__).parent/'fixtures/furuya_2024_share_split.json.gz'


def reference():
    obj=json.loads(gzip.decompress(FIXTURE.read_bytes()))
    raw=obj['filing'];raw['start']=date.fromisoformat(raw['start']);raw['end']=date.fromisoformat(raw['end'])
    filing=Filing(**raw);period=Period(filing.start,filing.end)
    pages=[tuple(item)for item in obj['pages']]
    shares=extract_fiscal_shares(pages,filing,filing.end,filing.code)
    quote={'available':True,'nominal_close_jpy':'4370','historical_close_jpy':'4370',
           'trading_date':'2024-06-28','stock_split_events':[
               {'date':'2024-06-27','numerator':'3','denominator':'1','ratio':'3:1'}]}
    return pages,filing,period,shares,quote


def rewritten(pages,old,new):
    assert any(old in markup for _,markup in pages),old
    return [(name,markup.replace(old,new))for name,markup in pages]


def with_new_pages(original,new_pages):
    _,filing,period,_,quote=original
    shares=extract_fiscal_shares(new_pages,filing,filing.end,filing.code)
    return new_pages,filing,period,shares,quote


def test_actual_furuya_ex_rights_precedes_fiscal_end_and_legal_date_follows():
    inputs=reference();result=align_fiscal_share_basis(*inputs)
    assert result['available'] is True
    assert result['historical_close_jpy']=='13110'
    assert result['basis_price_factor']=='3'
    assert result['basis_alignment_status']=='aligned'
    proof=result['basis_adjustments'][0]
    assert proof['legal_effective_date']=='2024-07-01'
    assert proof['exchange_ex_date']=='2024-06-27'
    assert proof['quote_is_post_split'] is True
    assert proof['fiscal_shares_are_post_split'] is False
    assert '１株を３株に分割' in proof['quoted_paragraph']
    assert proof['textblock_qname'].endswith('}IssuedSharesTotalNumberOfSharesEtcTextBlock')
    assert inputs[-1]['historical_close_jpy']=='4370'
    assert inputs[3]['value_shares']=='8463212'
    caps=assemble_market_caps([inputs[2]],{'shares':{inputs[2].key:inputs[3]}},{'prices':{inputs[2].end.isoformat():result}})
    assert Decimal(caps[inputs[2].key]['value_jpy'])==Decimal(8463212)*Decimal(13110)


def test_reapplying_uses_original_nominal_quote_and_does_not_double_adjust():
    pages,filing,period,shares,quote=reference()
    first=align_fiscal_share_basis(pages,filing,period,shares,quote)
    second=align_fiscal_share_basis(pages,filing,period,shares,first)
    assert second['historical_close_jpy']=='13110'
    assert len(second['basis_adjustments'])==1


@pytest.mark.parametrize('kind', ['no_event','wrong_ratio','conflicting_event','no_nominal','bad_count','wrong_source_hash'])
def test_ambiguous_or_inconsistent_transition_stays_unavailable(kind):
    pages,filing,period,shares,quote=reference()
    if kind=='no_event':quote['stock_split_events']=[]
    elif kind=='wrong_ratio':quote['stock_split_events'][0]['numerator']='2'
    elif kind=='conflicting_event':quote['stock_split_events'].append(dict(date='2024-06-27',numerator='2',denominator='1'))
    elif kind=='no_nominal':quote.pop('nominal_close_jpy')
    elif kind=='bad_count':shares['value_shares']='8463213'
    elif kind=='wrong_source_hash':shares['sha256']='0'*64
    result=align_fiscal_share_basis(pages,filing,period,shares,quote)
    assert result['available'] is False
    assert result['basis_alignment_status']=='unverified'
    assert result['reason']
    assert assemble_market_caps([period],{'shares':{period.key:shares}},{'prices':{period.end.isoformat():result}})=={}


def test_unknown_or_unparsed_official_ratio_cannot_borrow_exchange_ratio():
    original=reference()
    changed=rewritten(original[0],'１株を３株に分割','１株を数株に分割')
    inputs=with_new_pages(original,changed)
    assert align_fiscal_share_basis(*inputs)['available'] is False


def test_legal_note_uses_calendar_date_not_a_board_resolution_date():
    pages,filing,period,shares,quote=reference()
    result=align_fiscal_share_basis(pages,filing,period,shares,quote)
    assert result['basis_adjustments'][0]['legal_effective_date']=='2024-07-01'
    assert result['basis_adjustments'][0]['legal_effective_date']!='2024-05-10'


def test_mismatched_filing_share_count_does_not_guess_a_capital_change():
    original=reference()
    changed=rewritten(original[0],'25,389,636','25,389,637')
    inputs=with_new_pages(original,changed)
    result=align_fiscal_share_basis(*inputs)
    assert result['available'] is False
    assert result['reason']


def test_future_legal_date_not_yet_effective_at_filing_is_not_confirmation():
    original=reference()
    changed=rewritten(original[0],'2024年７月１日','2024年10月１日')
    result=align_fiscal_share_basis(*with_new_pages(original,changed))
    assert result['available'] is False


def test_wrong_company_dei_never_uses_matching_looking_split_note():
    pages,filing,period,shares,quote=reference()
    filing.code='6947'
    assert align_fiscal_share_basis(pages,filing,period,shares,quote)['available'] is False


def test_no_cross_boundary_event_does_not_reverse_a_future_split():
    pages,filing,period,shares,quote=reference()
    # An ordinary fiscal year with no event near its boundary needs no price
    # conversion; all past/future exchange actions are already in the nominal
    # historical quote's source basis. Remove this fixture's actual split note.
    pages=rewritten(pages,'2024年７月１日','2023年７月１日')
    shares=extract_fiscal_shares(pages,filing,filing.end,filing.code)
    quote['stock_split_events']=[dict(date='2023-06-28',numerator='3',denominator='1'),
                                dict(date='2025-06-27',numerator='2',denominator='1')]
    result=align_fiscal_share_basis(pages,filing,period,shares,quote)
    assert result['available'] is True
    assert result['historical_close_jpy']=='4370'
    assert result['basis_alignment_status']=='not_needed'


def test_legal_effective_on_fiscal_date_with_pre_ex_quote_uses_inverse_ratio():
    original=reference()
    pages=rewritten(original[0],'2024年７月１日','2024年６月30日')
    pages=rewritten(pages,'8,463,212','25,389,636')
    pages,filing,period,shares,quote=with_new_pages(original,pages)
    quote['nominal_close_jpy']='13110';quote['historical_close_jpy']='13110'
    quote['stock_split_events'][0]['date']='2024-06-30'
    result=align_fiscal_share_basis(pages,filing,period,shares,quote)
    assert result['available'] is True
    assert Decimal(result['historical_close_jpy'])==4370
    assert Decimal(result['basis_price_factor'])==Decimal(1)/3


def torichem():
    obj=json.loads(gzip.decompress((FIXTURE.parent/'torichem_2021_share_split.json.gz').read_bytes()))
    raw=obj['filing'];raw['start']=date.fromisoformat(raw['start']);raw['end']=date.fromisoformat(raw['end'])
    filing=Filing(**raw);period=Period(filing.start,filing.end)
    pages=[tuple(item)for item in obj['pages']]
    shares=extract_fiscal_shares(pages,filing,filing.end,filing.code)
    quote={'available':True,'nominal_close_jpy':'100','historical_close_jpy':'100',
           'trading_date':'2021-01-29','stock_split_events':[
               {'date':'2021-01-28','numerator':'4','denominator':'1'}]}
    return pages,filing,period,shares,quote


def test_actual_split_then_separate_new_issuance_reconciles_filing_count():
    result=align_fiscal_share_basis(*torichem())
    assert result['available'] is True
    assert result['historical_close_jpy']=='400'
    proof=result['basis_adjustments'][0]['additional_issuance_reconciliation']
    assert proof['opening_fiscal_shares']=='7812160'
    assert proof['closing_filing_shares']=='32498640'
    assert [item['delta_shares']for item in proof['movements']]==['23436480','1250000']
    assert [item['closing_shares']for item in proof['movements']]==['31248640','32498640']
    assert proof['textblock_qname'].endswith('}ChangesInNumberOfIssuedSharesStatedCapitalEtcTextBlock')


@pytest.mark.parametrize('kind',['missing_issuance','changed_issuance','changed_payment_date','changed_split_delta','unknown_cause'])
def test_extra_issuance_requires_actual_date_delta_and_cause(kind):
    pages,filing,period,shares,quote=torichem()
    from bs4 import BeautifulSoup
    changed=[]
    for filename,markup in pages:
        if '0104010'not in filename:changed.append((filename,markup));continue
        soup=BeautifulSoup(markup,'html.parser')
        block=next(node for node in soup.find_all()if(node.get('name')or'').endswith(':ChangesInNumberOfIssuedSharesStatedCapitalEtcTextBlock'))
        target=next(node for node in block.find_all('p')if'2021年２月24日' in node.get_text())
        if kind=='missing_issuance':target.decompose()
        elif kind=='changed_issuance':
            for text in list(target.strings):
                if '1,250,000'in text:text.replace_with(str(text).replace('1,250,000','1,250,001'))
        elif kind=='changed_payment_date':
            for text in list(target.strings):
                if '2021年２月24日'in text:text.replace_with(str(text).replace('2021年２月24日','2021年１月24日'))
        elif kind=='unknown_cause':
            for text in list(target.strings):
                if '公募による新株式の発行'in text:text.replace_with(str(text).replace('公募による新株式の発行','不明な処理'))
        elif kind=='changed_split_delta':
            target=next(node for node in block.find_all('p')if'23,436,480'in node.get_text())
            for text in list(target.strings):
                if '23,436,480'in text:text.replace_with(str(text).replace('23,436,480','23,436,481'))
        changed.append((filename,str(soup)))
    shares=extract_fiscal_shares(changed,filing,filing.end,filing.code)
    result=align_fiscal_share_basis(changed,filing,period,shares,quote)
    assert result['available'] is False
    assert result['reason']


def test_actual_dawn_ordinary_share_words_between_split_units_are_supported():
    obj=json.loads(gzip.decompress((FIXTURE.parent/'dawn_2026_share_split.json.gz').read_bytes()))
    raw=obj['filing'];raw['start']=date.fromisoformat(raw['start']);raw['end']=date.fromisoformat(raw['end'])
    filing=Filing(**raw);period=Period(filing.start,filing.end);pages=[tuple(item)for item in obj['pages']]
    shares=extract_fiscal_shares(pages,filing,filing.end,filing.code)
    quote={'available':True,'nominal_close_jpy':'100','historical_close_jpy':'100','trading_date':'2026-05-29',
           'stock_split_events':[dict(date='2026-05-28',numerator='2',denominator='1')]}
    result=align_fiscal_share_basis(pages,filing,period,shares,quote)
    assert result['available'] is True
    assert result['historical_close_jpy']=='200'
    proof=result['basis_adjustments'][0]
    assert proof['legal_effective_date']=='2026-06-01'
    assert proof['fiscal_issued_shares']=='3300000'
    assert proof['filing_issued_shares']=='6600000'


def test_missing_genuine_stock_block_cannot_be_called_no_adjustment_needed():
    original=reference()
    pages=rewritten(original[0],'IssuedSharesTotalNumberOfSharesEtcTextBlock','UnknownStockTextBlock')
    # Numeric fiscal-share facts still exist, but this does not prove a
    # complete legal-action notice or its absence.
    shares=extract_fiscal_shares(pages,original[1],original[1].end,original[1].code)
    quote=deepcopy(original[-1]);quote['stock_split_events']=[]
    result=align_fiscal_share_basis(pages,original[1],original[2],shares,quote)
    assert result['available'] is False
