"""Install only into this application's .venv; never change system packages."""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
import subprocess
import sys
import venv

BASE = Path(__file__).resolve().parent


def environment_python(base=BASE):
    return Path(base) / '.venv' / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')


def validate_environment(base=BASE):
    base = Path(base).resolve()
    expected = base / '.venv'
    if expected.resolve() != expected or not (expected / 'pyvenv.cfg').is_file():
        return '専用環境を確認できません。.venvを共有・リンクせず、新しいフォルダーでセットアップしてください。'
    probe = ('import json,sys,sysconfig; print(json.dumps({"prefix":sys.prefix,'
             '"base_prefix":sys.base_prefix,"version":list(sys.version_info[:3]),'
             '"paths":{k:v for k,v in sysconfig.get_paths().items() '
             'if k in ("purelib","platlib","scripts","data")}}))')
    try:
        result = subprocess.run([str(environment_python(base)), '-c', probe],
                                cwd=base, capture_output=True, text=True,
                                encoding='utf-8', timeout=30, check=False)
        data = json.loads(result.stdout)
        if result.returncode or Path(data['prefix']).resolve() != expected or data['prefix'] == data['base_prefix']:
            return '.venv内のPythonがこのアプリ専用ではありません。インストールを中止しました。'
        if tuple(data['version']) < (3, 10):
            return '専用環境のPythonが3.10未満です。新版を別フォルダーへ展開してやり直してください。'
        for key in ('purelib', 'platlib', 'scripts', 'data'):
            if not Path(data['paths'][key]).resolve().is_relative_to(expected):
                return '専用環境の保存先が別のフォルダーへ接続されています。インストールを中止しました。'
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        return '専用Python環境の確認に失敗しました。新しいフォルダーでセットアップしてください。'
    return None


def check_environment(base=BASE, report=None):
    executable = environment_python(base)
    if not executable.is_file():
        return 1
    problem = validate_environment(base)
    if problem:
        (report or print)(problem)
        return 1
    try:
        result = subprocess.run([str(executable), str(Path(base) / 'app.py'), '--self-check'],
                                cwd=base, timeout=60, check=False, capture_output=True,
                                text=True, encoding='utf-8', errors='replace')
        if result.stdout:
            (report or print)(result.stdout.rstrip())
        if result.stderr:
            (report or print)(result.stderr.rstrip())
        return result.returncode
    except (OSError, subprocess.TimeoutExpired):
        return 1


def install(base=BASE):
    base = Path(base).resolve()
    if sys.version_info < (3, 10):
        print('Python 3.10以上が必要です。python.orgの公式Pythonをインストールしてください。', file=sys.stderr)
        return 1
    try:
        import tkinter  # Presence only: do not require a display during setup.
    except ImportError:
        print('Tkinterがありません。Tcl/Tk付きの公式Pythonをご使用ください。', file=sys.stderr)
        return 1
    try:
        log_path = base / 'logs' / 'setup.log'
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open('a', encoding='utf-8') as log:
            def say(message):
                print(message, flush=True)
                log.write(message + '\n')
                log.flush()
            say('\nセットアップ開始 ' + datetime.now().isoformat(timespec='seconds'))
            executable = environment_python(base)
            if not executable.is_file():
                say('このアプリ専用のPython環境を作成しています。')
                # Match `python -m venv`: POSIX uses interpreter symlinks so
                # bundled runtime libraries keep their original lookup path.
                # Windows uses its normal redirector executables instead.
                venv.EnvBuilder(with_pip=True, symlinks=sys.platform != 'win32').create(base / '.venv')
            problem = validate_environment(base)
            if problem:
                say(problem)
                return 1
            pip_check = subprocess.run([str(executable), '-m', 'pip', '--version'],
                                       cwd=base, capture_output=True, check=False)
            if pip_check.returncode:
                say('専用環境のpipを準備し直しています。')
                subprocess.run([str(executable), '-m', 'ensurepip', '--upgrade'], cwd=base, check=True)
            say('必要なライブラリをインストールします。初回はインターネット接続が必要です。')
            with subprocess.Popen(
                [str(executable), '-m', 'pip', 'install', '--disable-pip-version-check',
                 '-r', str(base / 'requirements.txt')], cwd=base,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                encoding='utf-8', errors='replace', env=_child_environment()) as proc:
                for line in proc.stdout:
                    say(line.rstrip())
                status = proc.wait()
            if status:
                say('インストールに失敗しました。接続状況とログを確認して再実行してください。')
                return 1
            if check_environment(base, report=say):
                say('起動準備の確認に失敗しました。logs/setup.logを確認してください。')
                return 1
            say('準備ができました。start_windows.bat または start.command で起動できます。')
        return 0
    except (OSError, subprocess.SubprocessError) as exc:
        print(f'セットアップできませんでした：{exc}\n書き込みできるフォルダーへZIPを展開してください。',file=sys.stderr)
        return 1


def _child_environment():
    import os
    env = os.environ.copy()
    # Disable install destinations supplied by a surrounding shell or pip
    # configuration, while retaining network proxy, index and CA settings.
    for key in ('PIP_TARGET', 'PIP_PREFIX', 'PIP_USER', 'PIP_ROOT'):
        env.pop(key, None)
    env['PIP_CONFIG_FILE'] = os.devnull
    env['PYTHONIOENCODING'] = 'utf-8'
    return env


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='インストールせず専用環境を確認')
    args = parser.parse_args(argv)
    return check_environment() if args.check else install()


if __name__ == '__main__':
    raise SystemExit(main())
