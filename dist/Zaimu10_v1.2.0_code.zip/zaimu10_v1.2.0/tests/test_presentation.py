"""Presentation semantics, using real EDINET facts and scoped edge cases."""
from copy import deepcopy
from dataclasses import asdict,fields
from datetime import date
from decimal import Decimal
import gzip,json
from pathlib import Path
import pytest
from zaimu10.models import Cell,Dataset,Filing,Period,Row,Source
from zaimu10.parser import parse_filing
from zaimu10.presentation import PresentationError,detect_display_unit,local_name,metric_cell,pl_metrics,prepare_dataset,template_rows
F=Path(__file__).parent/'fixtures'
P=Period(date(2024,4,1),date(2025,3,31));O=Period(date(2023,4,1),date(2024,3,31))
STD='http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'
EXT='http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E01966-000/2024-03-31/01/2024-06-20'
NEW=EXT.replace('2024-03-31','2025-03-31').replace('2024-06-20','2025-06-20')
def r(local,value,*,p=P,ns=STD,st='CF',section=('営業活動によるキャッシュ・フロー',),basis='consolidated',unit='JPY',dims=(),role=None,label=None,submitted='2025-06-20',scale=3,decimals='0',nil=False):
 role=role or ('end'if st.startswith('BS')else'duration')
 s=Source('S100W07I','statements.xhtml','https://disclosure2.edinet-fsa.go.jp/',submitted=submitted,concept=f'{{{ns}}}{local}',unit=unit,decimals=decimals,original_label=label or local,scale=scale,basis=basis)
 return Row(json.dumps([st,local,list(dims),role,unit,basis]),label or local,st,section,values={p.key:Cell(None if value is None else Decimal(str(value)),s,nil=nil)},label_period=p.key)
def ds(*rows):
 d=Dataset('6947','図研','consolidated',[O,P],accounting_standard='J-GAAP',period_bases={O.key:'consolidated',P.key:'consolidated'},period_standards={O.key:'J-GAAP',P.key:'J-GAAP'})
 for row in rows:d.rows[row.statement].append(row)
 return d
def actual(name='zuken_2025',code='6947'):
 return parse_filing(Filing('S100W07I',code=code),json.load(gzip.open(F/f'{name}_ixbrl.json.gz','rt',encoding='utf-8')))
def loaded(obj):
 def cell(c):return Cell(None if c['value']is None else Decimal(c['value']),Source(**c['source']),nil=c.get('nil',False),note=c.get('note',''))
 d=Dataset(**{f.name:deepcopy(obj[f.name])for f in fields(Dataset)if f.name in obj and f.name not in{'rows','periods'}},periods=[Period(date.fromisoformat(p['start']),date.fromisoformat(p['end']))for p in obj['periods']])
 d.rows={s:[Row(**{k:deepcopy(v)for k,v in rr.items()if k!='values'},values={k:cell(c)for k,c in rr['values'].items()})for rr in rows]for s,rows in obj['rows'].items()}
 return d
def slot(d,n):return next(row for row in template_rows(d)if row.key==f'template:CF:{n}')
def test_actual_ten_year_zuken_retirement_is_one_series_with_unchanged_sources():
 raw=loaded(json.loads((F/'zuken_retirement_series.json').read_text()));before=asdict(raw);out=prepare_dataset(raw)
 assert len(raw.rows['CF'])==10 and len(out.rows['CF'])==1
 [row]=out.rows['CF'];assert len(row.values)==10
 assert row.label=='退職給付に係る負債の増減額（△は減少）'
 key=next(p.key for p in raw.periods if p.end.year==2024)
 assert row.values[key].value==Decimal('-252821000')
 expected={}
 for rr in raw.rows['CF']:
  for key,c in rr.values.items():
   if key not in expected or c.source.submitted>expected[key].source.submitted:expected[key]=c
 assert {k:c.value for k,c in row.values.items()}=={k:c.value for k,c in expected.items()}
 assert len(slot(out,8).values)==10 and asdict(raw)==before

def test_latest_same_issuer_version_replaces_value_instead_of_adding():
 out=prepare_dataset(ds(r('RightsTransferIncome',100,ns=EXT,submitted='2024-06-20',label='旧'),r('RightsTransferIncome',120,ns=NEW,label='新')))
 [row]=out.rows['CF'];assert row.values[P.key].value==120 and row.label=='新'
 assert 'より新しい'in row.values[P.key].note
@pytest.mark.parametrize('namespace',[NEW.replace('E01966','E00001'),NEW.replace('-000/','-001/'),NEW.replace('/asr/','/qrr/'),'https://unrelated.example/E01966-000/2025'])
def test_issuer_branch_form_unknown_uri_do_not_merge(namespace):
 assert len(prepare_dataset(ds(r('OtherIncome',10,ns=EXT),r('OtherIncome',20,ns=namespace))).rows['CF'])==2

def test_other_sections_and_dimension_role_unit_basis_are_separate():
 assert len(prepare_dataset(ds(r('Other',10,ns=EXT,st='PL',section=('営業外収益',)),r('Other',20,ns=NEW,st='PL',section=('特別利益',)))).rows['PL'])==2
 records=[r('Stable',1,ns=NEW),r('Stable',2,ns=NEW,dims=(('axis','member'),)),r('Stable',3,ns=NEW,role='begin'),r('Stable',4,ns=NEW,unit='USD'),r('Stable',5,ns=NEW,basis='standalone')]
 assert len(prepare_dataset(ds(*records)).rows['CF'])==5
 d=ds(r('Stable',1,ns=EXT,p=O),r('Stable',2,ns=NEW));d.period_standards[O.key]='IFRS'
 assert len(prepare_dataset(d).rows['CF'])==2

def test_reversed_direction_words_are_not_unproven_aliases():
 assert len(prepare_dataset(ds(r('DecreaseIncreaseInInventoriesOpeCF',20),r('IncreaseDecreaseInInventoriesOpeCF',-20))).rows['CF'])==2

def test_net_pension_asset_liability_alias_is_zuken_only():
 ns=NEW.replace('E01966','E00001');out=prepare_dataset(ds(r('IncreaseDecreaseInNetDefinedBenefitAssetOrLiabilityOpeCF',100,ns=ns),r('IncreaseDecreaseInRetirementBenefitLiabilityOpeCF',40,ns=ns)))
 assert len(out.rows['CF'])==2 and slot(out,8).values[P.key].value==40
 assert any(local_name(row)=='IncreaseDecreaseInNetDefinedBenefitAssetOrLiabilityOpeCF'for row in template_rows(out))

def test_no_value_rows_removed_but_reported_zero_kept():
 out=prepare_dataset(ds(r('Never',None,nil=True),r('ExplicitZero',0)))
 assert [local_name(x)for x in out.rows['CF']]==['ExplicitZero']

def test_prepare_is_idempotent_and_original_not_mutated():
 raw=actual();before=asdict(raw);a=prepare_dataset(raw);b=prepare_dataset(a)
 assert asdict(a)==asdict(b) and asdict(raw)==before
 assert len(a.source_notes)==len(set(a.source_notes))

def test_actual_bs_receivables_component_sum_with_provenance():
 out=prepare_dataset(actual());[group]=[x for x in out.rows['BS_A']if x.label=='売掛金及び受取手形'];c=group.values[out.periods[-1].key]
 assert c.value==Decimal('7235145000')and c.operation=='sum'
 assert sorted(x.value for x in c.components)==[Decimal('274733000'),Decimal('6960412000')]
 assert all(x.source.concept.startswith('{http://disclosure.edinet-fsa.go.jp/')for x in c.components)
 assert not any(local_name(x)in{'NotesReceivableTrade','AccountsReceivableTrade'}for x in out.rows['BS_A'])

def test_combined_receivables_not_added_again_and_conflict_fails():
 parts=[r('NotesReceivableTrade',40,st='BS_A'),r('AccountsReceivableTrade',60,st='BS_A')]
 [group]=prepare_dataset(ds(r('NotesAndAccountsReceivableTrade',100,st='BS_A'),*parts)).rows['BS_A']
 assert group.values[P.key].value==100 and group.values[P.key].operation=='reported_total'
 parts[1].values[P.key].value=70
 with pytest.raises(PresentationError):prepare_dataset(ds(r('NotesAndAccountsReceivableTrade',100,st='BS_A'),*parts))

def test_known_missing_receivable_component_is_not_guessed_zero():
 notes=r('NotesReceivableTrade',40,st='BS_A',p=O);notes.values[P.key]=Cell(None,deepcopy(notes.values[O.key].source),nil=True)
 accounts=r('AccountsReceivableTrade',60,st='BS_A',p=O);accounts.values[P.key]=Cell(Decimal(70),deepcopy(accounts.values[O.key].source))
 [group]=prepare_dataset(ds(notes,accounts)).rows['BS_A']
 assert group.values[O.key].value==100 and group.values[P.key].value is None
 assert group.values[P.key].operation=='incomplete_group'

def test_inventory_parts_are_three_groups_directly_below_receivables():
 values={'CashAndDeposits':500,'NotesReceivableTrade':40,'AccountsReceivableTrade':60,'Merchandise':10,'FinishedGoods':20,'WorkInProcess':30,'RawMaterials':40,'Supplies':50}
 out=prepare_dataset(ds(*(r(n,v,st='BS_A')for n,v in reversed(list(values.items())))))
 assert [x.label for x in out.rows['BS_A']][1:5]==['売掛金及び受取手形','商品及び製品','WorkInProcess','原材料及び貯蔵品']
 vals={x.label:x.values[P.key].value for x in out.rows['BS_A']}
 assert vals['商品及び製品']==30 and vals['原材料及び貯蔵品']==90

def test_pl_net_income_is_total_and_not_parent_only():
 out=prepare_dataset(actual());key=out.periods[-1].key;m=pl_metrics(out)
 assert m['net_profit'].values[key].value==Decimal('5247956000')
 assert m['net_profit_parent'].values[key].value==Decimal('5226214000')
 parent=r('ProfitLossAttributableToOwnersOfParent',80,st='PL')
 assert metric_cell(ds(parent),'net_profit',P)is None
 minority=r('ProfitLossAttributableToNonControllingInterests',20,st='PL')
 assert metric_cell(ds(parent,minority),'net_profit',P).value==100

def test_pl_fallback_does_not_sum_reported_subtotal_and_its_children():
 parts=[r('CustomIncomeA',70,st='PL',section=('営業外収益',)),r('CustomIncomeB',30,st='PL',section=('営業外収益',)),r('CustomIncomeTotal',100,st='PL',section=('営業外収益',),label='営業外収益合計')];parts[-1].is_total=True
 assert metric_cell(ds(*parts),'nonoperating_income',P).value==100

def test_ifrs_finance_metrics_keep_posted_sga():
 out=prepare_dataset(actual('nitori_2026','9843'));key=out.periods[0].key;m=pl_metrics(out)
 assert m['sga'].values[key].value==Decimal('348576000000')
 assert m['nonoperating_income'].values[key].value==Decimal('3019000000')
 assert m['nonoperating_expense'].values[key].value==Decimal('3236000000')
 assert m['ordinary_profit'].values[key].value==Decimal('117448000000')

def test_auto_unit_latest_scale_precision_and_fallback():
 assert detect_display_unit(ds(r('Old',100,p=O,scale=3),r('New',100,scale=6),r('EPS',20,scale=0,unit='JPY/shares')))=='million'
 assert detect_display_unit(actual())=='thousand'
 assert detect_display_unit(actual('nitori_2026','9843'))=='million'
 assert detect_display_unit(ds(r('Amount',100,scale=0,decimals='-6')))=='million'
 assert detect_display_unit(ds(r('Amount',100,scale=0,decimals='INF')))=='thousand'

def test_cf_component_group_keeps_original_cash_signs():
 out=prepare_dataset(ds(r('IncreaseDecreaseInAllowanceForDoubtfulAccountsOpeCF',-10),r('IncreaseDecreaseInProvisionForBonusesOpeCF',30)));c=slot(out,7).values[P.key]
 assert c.value==20 and [x.value for x in c.components]==[Decimal(-10),Decimal(30)]

def test_cf_reported_net_never_added_to_its_components():
 sec=('財務活動によるキャッシュ・フロー',)
 out=prepare_dataset(ds(r('NetIncreaseDecreaseInShortTermLoansPayableFinCF',100,section=sec),r('IncreaseInShortTermLoansPayableFinCF',150,section=sec),r('DecreaseInShortTermLoansPayableFinCF',-50,section=sec)))
 assert slot(out,56).values[P.key].value==100
 assert slot(out,56).values[P.key].operation=='reported_total'

def test_unmatched_cf_rows_keep_working_and_payment_placement():
 rows=[Row('head','営業活動によるキャッシュ・フロー','CF',('営業活動によるキャッシュ・フロー',),is_heading=True),r('UnknownNoncash',10),r('DecreaseIncreaseInInventoriesOpeCF',-20),r('UnknownWorking',5),r('SubtotalOpeCF',100,section=()),r('UnknownPayment',-3,section=()),r('NetCashProvidedByUsedInOperatingActivities',97,section=())]
 result=template_rows(prepare_dataset(ds(*rows)))
 groups={local_name(x):getattr(x,'display_group',None)for x in result if not x.key.startswith('template:')}
 assert groups=={'UnknownNoncash':'operating_adjustments','UnknownWorking':'operating_working','UnknownPayment':'operating_payments'}
 assert len([x for x in result if x.key=='template:CF:33'])==1

def test_actual_ifrs_interest_payments_stay_between_subtotal_and_cfo():
 out=prepare_dataset(actual('nitori_2026','9843'));rows=template_rows(out);mapped={x.key:x for x in rows if x.key.startswith('template:')}
 for p in out.periods:
  start=mapped['template:CF:33'].values[p.key].value
  payments=sum((mapped[f'template:CF:{n}'].values[p.key].value for n in range(34,40)if f'template:CF:{n}'in mapped and p.key in mapped[f'template:CF:{n}'].values),Decimal(0))
  extra=sum((x.values[p.key].value for x in rows if getattr(x,'display_group','')=='operating_payments'and p.key in x.values),Decimal(0))
  assert abs(start+payments+extra-mapped['template:CF:40'].values[p.key].value)<=Decimal('5000000')
 assert not any(local_name(x)in{'InterestPaidOpeCFIFRS','InterestReceivedOpeCFIFRS','DividendsReceivedOpeCFIFRS'}and getattr(x,'display_group','')=='cash_bridge'for x in rows)

def test_dimensional_cf_item_is_not_folded_into_undimensioned_template_slot():
 out=template_rows(prepare_dataset(ds(r('DepreciationAndAmortizationOpeCF',10,dims=(('axis','member'),)))))
 assert not any(x.key=='template:CF:4'for x in out)
 assert any(local_name(x)=='DepreciationAndAmortizationOpeCF'for x in out)

def test_original_filing_phase_annotation_survives_different_basis_blocks():
 from zaimu10.presentation import annotate_filing
 old=annotate_filing(actual('furuya_2017','7826'))
 new=annotate_filing(actual('furuya_2026','7826'))
 transfer_names={'TransferFromInventoriesToFixedAssetsOpeCF','TransferFromFixedAssetsToInventoriesOpeCF'}
 transfers=[x for x in new.rows['CF']if local_name(x)in transfer_names]
 assert len(transfers)==2
 assert all(x.display_group=='operating_working'for x in transfers)
 assert all(c.display_group=='operating_working'for x in transfers for c in x.values.values())
 target_periods=[old.periods[-1],new.periods[-1]]
 combined=Dataset('7826','フルヤ金属','mixed',target_periods,accounting_standard='J-GAAP',
    period_bases={old.periods[-1].key:old.basis,new.periods[-1].key:new.basis},
    period_standards={p.key:'J-GAAP'for p in target_periods})
 for filing in [old,new]:
  for source in filing.rows['CF']:
   row=deepcopy(source);row.values={k:c for k,c in row.values.items()if k in {p.key for p in target_periods}}
   combined.rows['CF'].append(row)
 display=template_rows(prepare_dataset(combined))
 kept=[x for x in display if local_name(x)in transfer_names]
 assert len(kept)==2 and all(x.display_group=='operating_working'for x in kept)
 for period in target_periods:
  subtotal=slot(prepare_dataset(combined),33).values[period.key]
  assert subtotal.value is not None

def test_same_unknown_concept_in_different_cashflow_phases_keeps_each_source_phase():
 from zaimu10.presentation import annotate_filing
 def source(period,namespace,before):
  unknown=r('UnknownCashFlow',10 if before else 20,p=period,ns=namespace)
  heading=Row('heading','営業活動によるキャッシュ・フロー','CF',('営業活動によるキャッシュ・フロー',),is_heading=True)
  subtotal=r('SubtotalOpeCF',100,p=period,section=())
  total=r('NetCashProvidedByUsedInOperatingActivities',100,p=period,section=())
  items=[heading,unknown,subtotal,total]if before else[heading,subtotal,unknown,total]
  if not before:unknown.section=()
  return annotate_filing(ds(*items))
 old=source(O,EXT,True);new=source(P,NEW,False)
 combined=ds(*(old.rows['CF']+new.rows['CF']))
 prepared=prepare_dataset(combined)
 rows=[x for x in template_rows(prepared)if local_name(x)=='UnknownCashFlow']
 assert len(rows)==2
 assert {x.display_group for x in rows}=={'operating_adjustments','operating_payments'}

def test_bs_display_stitches_disjoint_year_profiles_without_sum_or_basis_loss():
 old=r('CashAndDeposits',100,p=O,st='BS_A',basis='standalone')
 new=r('CashAndDeposits',200,p=P,st='BS_A')
 raw=ds(old,new);raw.basis='mixed';raw.period_bases[O.key]='standalone'
 before=asdict(raw);out=prepare_dataset(raw)
 [cash]=out.rows['BS_A'];assert cash.values[O.key].value==100 and cash.values[P.key].value==200
 assert cash.values[O.key].source.basis=='standalone'
 assert cash.values[P.key].source.basis=='consolidated'
 assert out.period_bases==raw.period_bases and asdict(raw)==before

def test_bs_display_never_stitches_overlapping_year_profiles_or_different_standards():
 out=prepare_dataset(ds(r('CashAndDeposits',100,st='BS_A',basis='standalone'),r('CashAndDeposits',200,st='BS_A')))
 assert len(out.rows['BS_A'])==2
 raw=ds(r('CashAndDeposits',100,p=O,st='BS_A',basis='standalone'),r('CashAndDeposits',200,p=P,st='BS_A'))
 raw.period_standards[O.key]='IFRS'
 assert len(prepare_dataset(raw).rows['BS_A'])==2

def test_actual_furuya_mixed_basis_has_one_receivable_and_three_inventory_rows():
 from zaimu10.presentation import annotate_filing
 old=annotate_filing(actual('furuya_2017','7826'));new=annotate_filing(actual('furuya_2026','7826'))
 periods=[old.periods[-1],new.periods[-1]];keys={p.key for p in periods}
 combined=Dataset('7826','フルヤ金属','mixed',periods,accounting_standard='J-GAAP',
    period_bases={periods[0].key:old.basis,periods[1].key:new.basis},period_standards={p.key:'J-GAAP'for p in periods})
 for filing in [old,new]:
  for statement in combined.rows:
   for original in filing.rows[statement]:
    item=deepcopy(original);item.values={k:c for k,c in item.values.items()if k in keys}
    combined.rows[statement].append(item)
 out=prepare_dataset(combined)
 labels=[x.label for x in out.rows['BS_A']if not x.is_heading]
 for name in ['売掛金及び受取手形','商品及び製品','仕掛品','原材料及び貯蔵品']:assert labels.count(name)==1
 assert labels[:5]==['現金及び預金','売掛金及び受取手形','商品及び製品','仕掛品','原材料及び貯蔵品']
 for name in ['CashAndDeposits','CurrentAssets','Assets']:
  assert len([x for x in out.rows['BS_A']if local_name(x)==name])==1

def test_bs_original_cell_section_and_order_survive_display_stitch():
 from zaimu10.presentation import annotate_filing
 old_section=('資産の部','流動資産');new_section=('資産','流動資産の部')
 old=ds(Row('oldhead','資産の部','BS_A',old_section,is_heading=True),
        r('CashAndDeposits',100,p=O,st='BS_A',basis='standalone',section=old_section))
 new=ds(Row('newhead','資産','BS_A',new_section,is_heading=True),
        r('UnrelatedItem',5,st='BS_A',section=new_section),
        r('CashAndDeposits',200,st='BS_A',section=new_section))
 a=annotate_filing(old);b=annotate_filing(new)
 merged=ds(*(a.rows['BS_A']+b.rows['BS_A']));merged.basis='mixed';merged.period_bases[O.key]='standalone'
 out=prepare_dataset(merged);[cash]=[x for x in out.rows['BS_A']if local_name(x)=='CashAndDeposits']
 assert cash.values[O.key].source_section==old_section and cash.values[O.key].source_order==1
 assert cash.values[P.key].source_section==new_section and cash.values[P.key].source_order==2
 assert old.rows['BS_A'][1].values[O.key].source_section is None
 serialized=asdict(out)
 [saved]=[x for x in serialized['rows']['BS_A']if x['key']==cash.key]
 assert saved['values'][O.key]['source_section']==old_section
 assert saved['values'][P.key]['source_order']==2

def test_derived_receivables_inherit_common_original_section_and_first_component_order():
 from zaimu10.presentation import annotate_filing
 section=('資産の部','流動資産')
 raw=ds(Row('head','資産の部','BS_A',section,is_heading=True),
        r('CashAndDeposits',10,st='BS_A',section=section),
        r('NotesReceivableTrade',40,st='BS_A',section=section),
        r('AccountsReceivableTrade',60,st='BS_A',section=section))
 out=prepare_dataset(annotate_filing(raw));[group]=[x for x in out.rows['BS_A']if x.label=='売掛金及び受取手形']
 cell=group.values[P.key]
 assert cell.source_section==section and cell.source_order==2
 assert [c.source_order for c in cell.components]==[2,3]
 assert all(c.source_section==section for c in cell.components)

def test_bs_components_from_conflicting_original_sections_are_not_guessed_into_one_group():
 from zaimu10.presentation import annotate_filing
 raw=ds(r('NotesReceivableTrade',40,st='BS_A',section=('資産','流動資産')),
        r('AccountsReceivableTrade',60,st='BS_A',section=('資産','固定資産')))
 with pytest.raises(PresentationError,match='異なるBS区分'):prepare_dataset(annotate_filing(raw))

def test_pl_unknown_category_total_needs_no_border_flag_to_avoid_double_count():
 section=('営業外収益',)
 items=[r('CustomIncomeA',70,st='PL',section=section),r('CustomIncomeB',30,st='PL',section=section),
        r('IssuerCustomIncomeTotal',100,st='PL',section=section,label='営業外収益合計')]
 assert not items[-1].is_total
 assert metric_cell(ds(*items),'nonoperating_income',P).value==100

def test_cf_extra_same_concept_stitches_disjoint_profiles_but_preserves_cash_roles():
 from zaimu10.presentation import annotate_filing
 sec=('財務活動によるキャッシュ・フロー',)
 rows=[r('RepaymentsOfLeaseObligationsFinCF',-10,p=O,basis='standalone',section=sec),
       r('RepaymentsOfLeaseObligationsFinCF',-20,p=P,section=sec),
       r('CashAndCashEquivalents',100,p=O,basis='standalone',role='begin',section=()),
       r('CashAndCashEquivalents',200,p=P,role='begin',section=()),
       r('CashAndCashEquivalents',110,p=O,basis='standalone',role='end',section=()),
       r('CashAndCashEquivalents',220,p=P,role='end',section=())]
 raw=annotate_filing(ds(*rows));raw.basis='mixed';raw.period_bases[O.key]='standalone'
 # Cash records are explicitly the post-financing bridge, not lease details.
 for row in raw.rows['CF']:
  if local_name(row)=='CashAndCashEquivalents':
   row.display_group='cash_bridge'
   for cell in row.values.values():cell.display_group='cash_bridge'
 before=asdict(raw);out=prepare_dataset(raw);display=template_rows(out)
 lease=[x for x in display if local_name(x)=='RepaymentsOfLeaseObligationsFinCF']
 assert len(lease)==1 and lease[0].display_group=='financing'
 assert lease[0].values[O.key].value==-10 and lease[0].values[P.key].value==-20
 assert slot(out,67).values[O.key].value==100 and slot(out,67).values[P.key].value==200
 assert slot(out,68).values[O.key].value==110 and slot(out,68).values[P.key].value==220
 assert asdict(raw)==before

def test_cf_display_refuses_overlap_or_different_cashflow_context():
 sec=('財務活動によるキャッシュ・フロー',)
 overlapping=prepare_dataset(ds(r('RepaymentsOfLeaseObligationsFinCF',-10,basis='standalone',section=sec),
                               r('RepaymentsOfLeaseObligationsFinCF',-20,section=sec)))
 assert len(overlapping.rows['CF'])==2
 contexts=prepare_dataset(ds(r('RepaymentsOfLeaseObligationsFinCF',-10,p=O,basis='standalone',section=sec),
                            r('RepaymentsOfLeaseObligationsFinCF',-20,p=P,section=('営業活動によるキャッシュ・フロー',))))
 assert len(contexts.rows['CF'])==2

def test_cf_stitched_component_uses_actual_year_basis_when_grouped_with_other_components():
 sec=('営業活動によるキャッシュ・フロー',)
 raw=ds(r('IncreaseDecreaseInProvisionForBonusesOpeCF',10,p=O,basis='standalone',section=sec),
        r('IncreaseDecreaseInProvisionForBonusesOpeCF',20,p=P,section=sec),
        r('IncreaseDecreaseInAllowanceForDoubtfulAccountsOpeCF',30,p=P,section=sec))
 raw.basis='mixed';raw.period_bases[O.key]='standalone'
 out=prepare_dataset(raw)
 assert slot(out,7).values[O.key].value==10 and slot(out,7).values[P.key].value==50

@pytest.mark.parametrize('old_name,new_name,statement,section',[
 ('DeferredTaxAssetsIOA','DeferredTaxAssets','BS_A',('資産の部','固定資産','投資その他の資産')),
 ('DeferredTaxLiabilitiesNCL','DeferredTaxLiabilities','BS_LE',('負債の部','固定負債'))])
def test_noncurrent_jgaap_tax_renames_unify_only_disjoint_amount_periods(old_name,new_name,statement,section):
 raw=ds(r(old_name,100,p=O,st=statement,section=section,basis='standalone'),
        r(new_name,200,p=P,st=statement,section=section))
 raw.basis='mixed';raw.period_bases[O.key]='standalone';before=asdict(raw)
 out=prepare_dataset(raw);[tax]=out.rows[statement]
 assert tax.values[O.key].value==100 and tax.values[P.key].value==200
 assert tax.values[O.key].source.concept.endswith('}'+old_name)
 assert tax.values[P.key].source.concept.endswith('}'+new_name)
 assert asdict(raw)==before
 # Simultaneous amount-bearing concepts are not merged or added by this rule.
 overlap=prepare_dataset(ds(r(old_name,100,p=P,st=statement,section=section),r(new_name,200,p=P,st=statement,section=section)))
 assert len(overlap.rows[statement])==2

def test_noncurrent_tax_alias_never_absorbs_current_or_other_accounting_standard():
 nca=('資産の部','固定資産','投資その他の資産');ca=('資産の部','流動資産')
 raw=ds(r('DeferredTaxAssetsCA',10,p=O,st='BS_A',section=ca),
        r('DeferredTaxAssetsIOA',100,p=O,st='BS_A',section=nca),
        r('DeferredTaxAssets',200,p=P,st='BS_A',section=nca))
 out=prepare_dataset(raw)
 assert len(out.rows['BS_A'])==2
 current=next(x for x in out.rows['BS_A']if local_name(x)=='DeferredTaxAssetsCA')
 assert current.values[O.key].value==10 and P.key not in current.values
 generic_current=prepare_dataset(ds(r('DeferredTaxAssetsIOA',100,p=O,st='BS_A',section=nca),
                                   r('DeferredTaxAssets',200,p=P,st='BS_A',section=ca)))
 assert len(generic_current.rows['BS_A'])==2
 raw=ds(r('DeferredTaxAssetsIOA',100,p=O,st='BS_A',section=nca),r('DeferredTaxAssets',200,p=P,st='BS_A',section=nca))
 raw.period_standards[P.key]='IFRS'
 assert len(prepare_dataset(raw).rows['BS_A'])==2

def test_noncurrent_tax_alias_refuses_nil_period_overlap_without_filling():
 section=('資産の部','固定資産','投資その他の資産')
 old=r('DeferredTaxAssetsIOA',100,p=O,st='BS_A',section=section)
 old.values[P.key]=Cell(None,deepcopy(old.values[O.key].source),nil=True)
 current=r('DeferredTaxAssets',200,p=P,st='BS_A',section=section)
 out=prepare_dataset(ds(old,current))
 assert len(out.rows['BS_A'])==2
 old_result=next(x for x in out.rows['BS_A']if local_name(x)=='DeferredTaxAssetsIOA')
 assert old_result.values[P.key].value is None and old_result.values[P.key].nil
 assert next(x for x in out.rows['BS_A']if local_name(x)=='DeferredTaxAssets').values[P.key].value==200
