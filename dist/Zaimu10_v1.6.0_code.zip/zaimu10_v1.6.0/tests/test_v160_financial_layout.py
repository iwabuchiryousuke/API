"""Latest reference financial layout and independently retained net inputs."""
from copy import deepcopy,copy
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
import pytest

from zaimu10.excel import Writer,_pl,_bs,_cf,_bs_source_plans,_collapse_net_assets,TEMPLATE_PATH
from zaimu10.layout import build_balance_layout
from zaimu10.models import Cell,Dataset,Period,Row,Source

P=Period(date(2025,4,1),date(2026,3,31))
OLD=Period(date(2024,4,1),date(2025,3,31))
NS='http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2025-11-01/jppfs_cor'
SEC=('資産の部','固定資産','有形固定資産')


def item(local,label,value,order,*,period=P,section=SEC,nil=False,namespace=NS):
    source=Source('S100TEST','statement.xhtml','https://example.jp/source',
        context_id='CurrentYearInstant',concept='{'+namespace+'}'+local,
        unit='JPY',decimals='0',original_label=label,basis='consolidated',raw_value=str(value))
    fact=Cell(Decimal(value)if value is not None else None,source,nil=nil,
              source_section=section,source_order=order)
    return Row(local,label,'BS_A',section,values={period.key:fact})


def assets(*,net=70,contra=-30):
    return [item('BuildingsAndStructures','建物及び構築物',100,1),
        item('AccumulatedDepreciationBuildingsAndStructures','減価償却累計額',contra,2),
        item('BuildingsAndStructuresNet','建物及び構築物（純額）',net,3,nil=net is None),
        item('Land','土地',20,4),
        item('PropertyPlantAndEquipment','有形固定資産合計',90,5)]


def test_disclosed_net_is_one_visible_literal_with_reference_net_font_and_source_aliases():
    d=Dataset('6947','図研株式会社','consolidated',[P]);d.rows['BS_A']=assets()
    w=Writer(d,'yen');_bs(w,d,'BS_A');ws=w.book['BS-A']
    labels=[c[0].value for c in ws]
    assert labels.count('建物及び構築物')==1
    assert not any('純額'in str(label)or label=='減価償却累計額'for label in labels)
    number=labels.index('建物及び構築物')+1
    assert ws.cell(number,2).value==70 and ws.cell(number,2).data_type=='n'
    assert copy(ws.cell(number,1).font)==copy(w.template['BS-A']['A16'].font)
    alias=w.source_addresses['BuildingsAndStructures'][P.key]
    assert alias['net_display']is True and alias['original_value_jpy']==Decimal(100)
    assert alias['display_value_jpy']==Decimal(70)
    evidence=w.layout_metadata['BS-A']['net_asset_presentation']['periods'][0]
    assert evidence['disclosed_net']is True
    assert {p['original_cell']['value']for p in evidence['original_inputs']}=={Decimal(100),Decimal(-30)}
    assert not any(c.get('ok')is False for c in w.checks)


@pytest.mark.parametrize('contra',[-30,30])
def test_positive_and_signed_contra_are_each_deducted_once(contra):
    rows=assets(contra=contra);plans,coverage=_bs_source_plans(rows,[P])
    result,plans,coverage,aliases,evidence=_collapse_net_assets(rows,[P],plans,coverage)
    assert [r.key for r in result]==['BuildingsAndStructuresNet','Land','PropertyPlantAndEquipment']
    assert result[0].values[P.key].value==70
    assert plans[P.key][2]==[0,1]
    assert 'BuildingsAndStructuresNet'not in aliases


def test_explicit_nil_net_is_never_reconstructed_and_published_total_stays_literal():
    d=Dataset('6947','図研','consolidated',[P]);d.rows['BS_A']=assets(net=None)
    w=Writer(d,'yen');_bs(w,d,'BS_A');ws=w.book['BS-A']
    line=next(r[0].row for r in ws if r[0].value=='建物及び構築物')
    assert ws.cell(line,2).value is None
    total=next(r[0].row for r in ws if r[0].value=='有形固定資産計')
    assert ws.cell(total,2).value==90 and ws.cell(total,2).data_type=='n'
    assert not any(c.get('ok')is False for c in w.checks)
    assert w.layout_metadata['BS-A']['net_asset_presentation']['periods'][0]['nil_preserved']is True


def test_missing_net_can_use_complete_standard_inputs_with_full_calculation_lineage():
    rows=assets();del rows[2]
    plans,coverage=_bs_source_plans(rows,[P])
    result,_,_,_,proof=_collapse_net_assets(rows,[P],plans,coverage)
    calculated=next(r for r in result if r.key.startswith('net_asset:'))
    fact=calculated.values[P.key]
    assert fact.value==70 and fact.operation=='asset_net'
    assert [c.value for c in fact.components]==[100,-30]
    assert fact.source.concept=='{urn:zaimu10:calculation}NetAsset'
    assert proof[0]['disclosed_net']is False


def test_issuer_extension_spelling_is_not_authority_for_asset_net_membership():
    rows=assets()
    for row in rows:
        row.values[P.key].source.concept=row.values[P.key].source.concept.replace(NS,'http://issuer.example/taxonomy')
    plans,coverage=_bs_source_plans(rows,[P])
    result,_,_,aliases,proof=_collapse_net_assets(rows,[P],plans,coverage)
    assert len(result)==5 and not aliases and not proof


def test_contradictory_disclosed_net_is_rejected_before_display():
    rows=assets(net=80);plans,coverage=_bs_source_plans(rows,[P])
    with pytest.raises(ValueError,match='開示純額'):
        _collapse_net_assets(rows,[P],plans,coverage)


def test_latest_original_order_overrides_cash_first_and_old_only_stays_inside_parent():
    section=('資産の部','流動資産')
    cash=item('CashAndDeposits','現金及び預金',20,20,section=section)
    inventory=item('Inventories','棚卸資産',10,10,section=section)
    old_only=item('OtherCA','旧年度のみの項目',5,15,section=section,period=OLD)
    current=item('CurrentAssets','流動資産合計',30,30,section=section)
    current.values[OLD.key]=deepcopy(current.values[P.key]);current.values[OLD.key].value=5
    rows=[cash,inventory,old_only,current]
    plans={P.key:{3:[0,1]},OLD.key:{3:[2]}}
    layout=build_balance_layout(rows,[OLD,P],plans,{P.key:{},OLD.key:{}})
    assert [layout.rows[i].label for i in layout.order]==['棚卸資産','現金及び預金','旧年度のみの項目','流動資産計']


def test_pl_24_rows_parent_profit_and_semantic_rules():
    from test_exporter import dataset
    d=dataset();w=Writer(d,'thousand');_pl(w,d);ws=w.book['PL']
    assert ws.max_row==24 and ws['A22'].value=='親会社帰属当期純利益'and ws['A24'].value=='実効税率'
    assert ws['B22'].value==21000 and ws['C22'].value==26000
    assert ws['B24'].value=='=B18/B17'
    for number in range(2,25):
        for cell in ws[number]:
            assert bool(cell.border.top.style)==(number in {5,9,14,17,19})
            assert bool(cell.border.bottom.style)==(number in {5,9,14,17,19})
    assert ws['A24'].fill.fgColor.type=='theme'and ws['A24'].fill.fgColor.theme==0
    assert ws['A24'].font.color is None


def test_cf_small_subtotal_and_working_subtotal_have_both_rules():
    from test_exporter import dataset
    d=dataset();w=Writer(d,'thousand');_cf(w,d);ws=w.book['CF'];roles=w.layout_metadata['CF']['roles']
    totals={roles[str(s)]for s in [22,26,33,40,54,64,68]}
    for number in range(2,w.layout_metadata['CF']['main_end_row']+1):
        for cell in ws[number]:
            assert bool(cell.border.top.style)==(number in totals)
            assert bool(cell.border.bottom.style)==(number in totals)
    assert set(roles)>={'4','22','23','24','25','26','40','44','54','64','68'}


def test_financial_template_is_sanitized_and_carries_new_reference_theme():
    wb=load_workbook(TEMPLATE_PATH)
    assert wb['PL'].max_row==24
    assert wb['BS-A']['A16'].font.name=='ＭＳ ゴシック'
    assert not any(c.comment or c.hyperlink or c.data_type=='f' or(c.column>1 and c.value is not None)
                   for ws in wb for row in ws for c in row)
    assert wb.loaded_theme and b'Office 2007'in wb.loaded_theme
    wb.close()


def test_actual_nitori_extension_rou_trio_and_later_standard_contra_are_one_net_line():
    import gzip,json
    from dataclasses import fields
    with gzip.open(Path(__file__).parent/'fixtures/nitori_rou_2019_2023.json.gz','rt',encoding='utf-8')as stream:
        raw=json.load(stream)
    periods=[Period(date.fromisoformat(p.split('/')[0]),date.fromisoformat(p.split('/')[1]))for p in raw['periods']]
    rows=[]
    for item in raw['rows']:
        row=Row(item['key'],item['label'],'BS_A',tuple(item['section']))
        for key,cell in item['values'].items():
            data={k:v for k,v in cell.items()if k not in {'value','source','components','source_section'}}
            row.values[key]=Cell(Decimal(cell['value'])if cell['value']is not None else None,
                Source(**cell['source']),source_section=tuple(cell['source_section']),**data)
        rows.append(row)
    plans,coverage=_bs_source_plans(rows,periods)
    collapsed,_,_,aliases,proof=_collapse_net_assets(rows,periods,plans,coverage)
    assert len(collapsed)==1 and collapsed[0].label=='使用権資産（純額）'
    assert len(proof)==5 and all(p['disclosed_net']for p in proof)
    values=[collapsed[0].values[p.key].value for p in periods]
    assert values==[None,Decimal('4529000000'),Decimal('3673000000'),Decimal('3841000000'),Decimal('11129000000')]
    # Genuine issuer QNames remain issuer QNames. No numeric XBRL tag is invented.
    assert all('/E03144-000/'in c.source.concept for c in collapsed[0].values.values())
    originals=[p['original_cell']['source']['concept']for annual in proof for p in annual['original_inputs']]
    assert any('AccumulatedDepreclationRightOfUseAssets'in c for c in originals)
    assert any('/taxonomy/jppfs/'in c and c.endswith('}AccumulatedDepreciationRightOfUseAssets')for c in originals)
    assert len(aliases)==3  # gross, legacy contra and standard contra


def test_generic_liability_and_noncontrolling_labels_do_not_inherit_payable_input_color():
    from test_exporter import dataset,row
    d=dataset();d.rows['BS_LE'].append(row('BS_LE','LongTermAccountsPayable','長期未払金',1,2,('負債の部','固定負債')))
    d.rows['BS_LE'].append(row('BS_LE','NonControllingInterests','非支配株主持分',1,2,('純資産の部',)))
    w=Writer(d,'thousand');_bs(w,d,'BS_LE');ws=w.book['BS-L,E']
    for label in ['長期未払金','Ⅲ 非支配株主持分']:
        n=next(r[0].row for r in ws if r[0].value==label)
        assert ws.cell(n,1).fill.patternType is None
    payable=next(r[0].row for r in ws if r[0].value=='買掛金')
    assert copy(ws.cell(payable,1).fill)==copy(w.template['BS-L&E']['A3'].fill)
    w.book.close();w.template.close()


def test_outdented_ifrs_totals_own_only_their_named_section_and_explicit_subtotal_once():
    base=('資産',);current=base+('流動資産',);noncurrent=base+('非流動資産',)
    rows=[item('CashAndCashEquivalentsIFRS','現金及び現金同等物',10,1,section=current),
        item('CurrentAssetsOtherThanAssetsHeldForSaleCAIFRS','小計',10,2,section=current),
        item('AssetsHeldForSaleIFRS','売却目的保有資産',5,3,section=current),
        item('CurrentAssetsIFRS','流動資産合計',15,4,section=base),
        item('PropertyPlantAndEquipmentIFRS','有形固定資産',20,6,section=noncurrent),
        item('IntangibleAssetsIFRS','無形資産',3,7,section=noncurrent),
        item('NonCurrentAssetsIFRS','非流動資産合計',23,8,section=base),
        item('AssetsIFRS','資産合計',38,9,section=())]
    for row in rows:
        row.values[P.key].source.concept=row.values[P.key].source.concept.replace('/jppfs/','/jpigp/').replace('/jppfs_cor','/jpigp_cor')
    plans,coverage=_bs_source_plans(rows,[P])
    assert plans[P.key][3]==[1,2]
    assert plans[P.key][6]==[4,5]
    assert plans[P.key][7]==[3,6]
    d=Dataset('2802','味の素','consolidated',[P]);d.rows['BS_A']=rows
    w=Writer(d,'yen');_bs(w,d,'BS_A')
    total=next(r[0].row for r in w.book['BS-A']if r[0].value=='資産合計')
    assert w.values['BS-A',f'B{total}']==38
    assert not any(c.get('ok')is False for c in w.checks)
    w.book.close();w.template.close()
