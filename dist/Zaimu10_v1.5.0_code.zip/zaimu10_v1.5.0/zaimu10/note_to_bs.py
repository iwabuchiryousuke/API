"""Display adopted debt-note components inside the upper liability table.

The source Dataset is never changed.  A note is a primary-table component only
when a same-filing, same-scope containing Other balance is proved.  Otherwise
it is an explicitly labelled memorandum amount, outside all primary sums.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal
import json

from .analysis import analyze_dataset, debt_category, metric_terms
from .layout import classification, role
from .models import Cell, Dataset, Row
from .presentation import _concept


_SCOPE = {
    'short_term_borrowings': 'current', 'current_long_term_borrowings': 'current',
    'current_borrowings': 'current', 'current_lease': 'current',
    'current_bonds': 'current', 'commercial_paper': 'current',
    'long_term_borrowings': 'noncurrent', 'noncurrent_lease': 'noncurrent',
    'bonds': 'noncurrent',
}
_OTHERS = {
    'current': {'OtherCL', 'OtherCurrentLiabilitiesCLIFRS',
                'OtherFinancialLiabilitiesCLIFRS', 'OtherFinancialLiabilitiesCurrentIFRS'},
    'noncurrent': {'OtherNCL', 'OtherNonCurrentLiabilitiesNCLIFRS',
                   'OtherFinancialLiabilitiesNCLIFRS', 'OtherFinancialLiabilitiesNonCurrentIFRS'},
}
_LEASE_LABELS = {'current_lease': 'リース債務', 'noncurrent_lease': 'リース債務'}
_NONLEASE_PREFIXES = (
    'AccountsPayableTrade', 'NotesPayableTrade', 'NotesAndAccountsPayableTrade',
    'IncomeTaxesPayable', 'AccruedConsumptionTaxes', 'ConsumptionTaxesPayable',
    'DeferredTaxLiabilities', 'ProvisionFor', 'OtherProvision',
    'NetDefinedBenefitLiability', 'RetirementBenefitLiability',
    'AssetRetirementObligations', 'AdvancesReceived', 'LongTermAdvancesReceived',
    'UnearnedRevenue', 'LongTermUnearnedRevenue', 'ContractLiabilities',
)


@dataclass
class DebtPresentation:
    rows: list[Row]
    plans: dict
    coverage: dict
    aliases: dict[str, dict[str, str]] = field(default_factory=dict)
    adjustments: list[dict] = field(default_factory=list)
    memoranda: list[Row] = field(default_factory=list)
    omitted_zero: dict[str, list[str]] = field(default_factory=dict)


def _local(cell):
    return cell.source.account_concept.rsplit('}', 1)[-1].rsplit(':', 1)[-1]


def _scope(row, cell):
    return classification(cell.source_section if cell.source_section is not None else row.section)


def _tolerance(cells):
    amount = Decimal(0)
    for cell in cells:
        try:
            amount += Decimal(10) ** -int(cell.source.decimals)
        except (ValueError, TypeError):
            pass
    return max(Decimal(1), amount)


def _evidence(cell):
    for line in cell.note.splitlines():
        if line.startswith('debt_note_evidence:'):
            try:
                return json.loads(line.split(':', 1)[1])
            except (ValueError, TypeError):
                return {}
    return {}


def _excludes_lease(row, cell):
    if _concept(cell.source.account_concept)[0] not in {'jppfs_cor', 'jpigp_cor'}:
        return False
    category=debt_category(row, cell)
    return (category in {'short_term_borrowings','current_long_term_borrowings',
                         'long_term_borrowings','bonds','current_bonds','commercial_paper'}
            or _local(cell).startswith(_NONLEASE_PREFIXES))


def project_debt_notes(dataset: Dataset, rows: list[Row], plans: dict,
                       coverage: dict) -> DebtPresentation:
    """Return a liability display projection, never changing raw source rows.

    A complete primary decomposition and exactly one Other component make a
    Japanese borrowing-schedule lease's containing balance unique.  IFRS note
    tables additionally identify their exact containing concept.  Merely being
    smaller than an Other balance never establishes containment.
    """
    out = DebtPresentation(deepcopy(rows), deepcopy(plans), deepcopy(coverage))
    analysis = analyze_dataset(dataset)
    by_key = {row.key: row for row in dataset.analysis_inputs}
    adopted = {}
    for period in dataset.periods:
        for _, key, cell in metric_terms(analysis.metrics['interest_bearing_debt'].values[period.key]):
            if key in by_key and cell.value is not None and not cell.nil:
                adopted.setdefault(key, {})[period.key] = cell
    active = {key for key, values in adopted.items() if any(c.value != 0 for c in values.values())}
    for key, values in adopted.items():
        if key not in active:
            out.omitted_zero[key] = list(values)
    # Existing main rows are preferred as a display slot when their fact is
    # absent/nil in the exact year.  This avoids two same-meaning lease rows.
    created = {}
    insert_before = {}
    pending = {}
    for key in sorted(active):
        original = by_key[key]
        category = debt_category(original)
        scope = _SCOPE.get(category)
        for period in dataset.periods:
            fact = adopted[key].get(period.key)
            if fact is None:
                continue
            expected_role = scope + '_liabilities' if scope else None
            parents = [i for i, row in enumerate(rows) if role(row) == expected_role
                       and period.key in row.values and row.values[period.key].value is not None]
            parent = parents[0] if len(parents) == 1 else None
            parts = plans.get(period.key, {}).get(parent, []) if parent is not None else []
            evidence = _evidence(fact)
            candidates = []
            for i in parts:
                host = rows[i].values.get(period.key)
                if host is None or host.nil or host.value is None or host.value < 0:
                    continue
                if _local(host) not in _OTHERS.get(scope, set()):
                    continue
                if _concept(host.source.account_concept)[0] not in {'jppfs_cor','jpigp_cor'}:
                    continue
                explicit = evidence.get('parent_local')
                # Some IFRS original tables have flat, shared "負債" section
                # metadata.  The proven direct-parent plan and the note's
                # exact CL/NCL parent QName establish scope in that case.
                if not explicit and _scope(rows[i], host) != 'liabilities/' + scope:
                    continue
                if (host.source.doc_id != fact.source.doc_id or
                    host.source.basis != fact.source.basis or
                    host.source.unit != 'JPY' or fact.source.unit != 'JPY'):
                    continue
                if explicit and explicit != _local(host):
                    continue
                # Without an exact parent in the IFRS note, only a recognised
                # balance-sheet lease from the borrowing schedule is admitted.
                if not explicit and not (category in _LEASE_LABELS and
                        evidence.get('kind') == 'borrowings_schedule'):
                    continue
                if not explicit and any(not _excludes_lease(rows[j], rows[j].values[period.key])
                        for j in parts if j!=i and period.key in rows[j].values):
                    # An unclassified payable or extension can also contain a
                    # lease: a unique line literally called Other is then not
                    # a unique possible container.
                    continue
                numeric = [rows[j].values.get(period.key) for j in parts]
                numeric = [c for c in numeric if c is not None and c.value is not None and not c.nil]
                total = rows[parent].values[period.key]
                if abs(sum((c.value for c in numeric), Decimal(0)) - total.value) > _tolerance([total] + numeric):
                    continue
                candidates.append(i)
            host_index = candidates[0] if len(candidates) == 1 else None
            reason = ''
            if fact.value < 0:
                reason = '注記残高が負数のためOtherを自動分解しません。'
            elif parent is None:
                reason = '流動・非流動の区分又は対応する本表小計を一意に確定できません。'
            elif host_index is None and fact.value != 0:
                reason = '同じ原文・区分の包含先Otherを一意に立証できません。'
            elif host_index is not None:
                used = pending.get((host_index, period.key), [])
                total_note = sum((c.value for _, c, _ in used), Decimal(0)) + fact.value
                if total_note > rows[host_index].values[period.key].value:
                    reason = '採用注記の合計が包含先Otherの残高を超えるため自動分解しません。'
            if reason:
                memo_key = 'presentation:debt-memorandum:' + key
                memo = created.get(memo_key)
                if memo is None:
                    label = ('有利子預り金' if category == 'other_interest_bearing_debt'
                             and evidence.get('interest_rate_positive_required') is True else original.label)
                    memo = deepcopy(original);memo.key = memo_key
                    memo.label = '（負債合計の内数）' + label
                    memo.section = ('負債の部', '内数・注記');memo.values = {}
                    out.memoranda.append(memo);created[memo_key] = memo
                copied = deepcopy(fact)
                copied.note += '\n表示: 負債合計に既に含まれる注記の内数。主表の合計へ再加算しません。' + reason
                memo.values[period.key] = copied
                out.aliases.setdefault(key, {})[period.key] = memo_key
                continue
            # A known zero needs no allocation.  Keep it only in a category
            # that has a non-zero disclosure in another displayed year.
            matches = []
            for i, row in enumerate(rows):
                sample = row.values.get(period.key) or next(iter(row.values.values()), None)
                if sample is not None and debt_category(row, sample) == category and _scope(row, sample) == 'liabilities/' + scope:
                    present = row.values.get(period.key)
                    if present is None or present.value is None or present.nil:
                        matches.append(i)
            target = matches[0] if len(matches) == 1 else None
            if target is None:
                display_key = 'presentation:debt-component:' + key
                target_row = created.get(display_key)
                if target_row is None:
                    target_row = deepcopy(original);target_row.key = display_key
                    target_row.label = _LEASE_LABELS.get(category, original.label)
                    target_row.section = ('負債の部', '流動負債' if scope=='current' else '固定負債')
                    target_row.values = {};created[display_key] = target_row
                    target = len(out.rows);out.rows.append(target_row)
                    insert_before[target] = host_index if host_index is not None else parent
                else:
                    target = out.rows.index(target_row)
            target_row = out.rows[target]
            copied = deepcopy(fact)
            copied.source_section = ('負債の部', '流動負債' if scope=='current' else '固定負債')
            copied.note += '\n表示: 開示注記から本表の同じ流動・非流動区分へ展開。原文の注記項目名・単位・残高は保持。'
            target_row.values[period.key] = copied
            out.aliases.setdefault(key, {})[period.key] = target_row.key
            current = out.plans.setdefault(period.key, {}).setdefault(parent, [])
            if target not in current:
                current.append(target)
            if host_index is not None and fact.value != 0:
                pending.setdefault((host_index, period.key), []).append((key, fact, target))
    for (host_index, period_key), members in pending.items():
        raw = rows[host_index].values[period_key]
        value = raw.value - sum((c.value for _, c, _ in members), Decimal(0))
        residual = deepcopy(raw)
        residual.value = value;residual.nil = False
        residual.components = [deepcopy(raw)] + [deepcopy(c) for _, c, _ in members]
        residual.operation = 'subtract'
        residual.component_keys = [rows[host_index].key] + [key for key, _, _ in members]
        residual.note += '\n表示上の組替: 原文Other残高から、上に別掲した同じ区分の注記残高だけを控除。負債小計は不変。'
        out.rows[host_index].values[period_key] = residual
        out.adjustments.append({'host_key': rows[host_index].key, 'period': period_key,
            'original_value_jpy': str(raw.value), 'residual_value_jpy': str(value),
            'note_keys': [key for key, _, _ in members],
            'note_values_jpy': [str(c.value) for _, c, _ in members],
            'method': ('explicit_note_parent' if all(_evidence(c).get('parent_local') for _,c,_ in members)
                       else 'same_filing_scope_unique_other'),
            'original_source': {'doc_id': raw.source.doc_id, 'concept': raw.source.concept,
                                'basis': raw.source.basis},
            'reason': '同じ原文・流動/非流動区分の直接内訳が公表小計に一致し、包含先Otherが一意。'})
    # Source indices, rather than source physical-order provenance, determine
    # display tie-breaks.  Never invent a physical table position for a note.
    order = []
    for i in range(len(rows)):
        order.extend(j for j, anchor in insert_before.items() if anchor == i)
        order.append(i)
    order.extend(i for i in range(len(rows), len(out.rows)) if i not in order)
    indices = {old: new for new, old in enumerate(order)}
    out.rows = [out.rows[i] for i in order]
    out.plans = {period: {indices[parent]: [indices[i] for i in children] for parent, children in values.items()}
                 for period, values in out.plans.items()}
    out.coverage = {period: {indices[parent]: [indices[i] for i in children] for parent, children in values.items()}
                    for period, values in out.coverage.items()}
    return out
