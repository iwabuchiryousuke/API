from datetime import datetime, timezone, timedelta, date
from copy import deepcopy

from zaimu10 import gui


def test_japan_date_works_without_an_iana_database(monkeypatch):
    class Clock:
        @staticmethod
        def now(tz):
            return datetime(2026,11,19,18,0,tzinfo=timezone.utc).astimezone(tz)
    def unavailable(*args):
        raise RuntimeError('No IANA data, as on standard Windows Python')
    monkeypatch.setattr(gui,'datetime',Clock)
    monkeypatch.setattr(gui,'ZoneInfo',unavailable,raising=False)
    assert gui.japan_today()==date(2026,11,20)


def event(period=None,end=None,kind='scheduled'):
    return dict(code='3038',date='2026-12-14',kind=kind,fiscal_period=period,
                fiscal_end=end,source_url='https://www.jpx.co.jp/')


def test_registered_unspecified_schedule_and_market_exact_period_show_once():
    registered=[event('通期本決算（対象期の詳細は出典を参照）')]
    market=[event('2026年10月期','2026-10-31')]
    before=deepcopy((registered,market))
    result=gui.combined_calendar_events(registered,market)
    assert len(result)==1 and result[0]['fiscal_end']=='2026-10-31'
    assert (registered,market)==before


def test_distinct_known_periods_remain_separate_and_actual_has_priority():
    one=event('2026年10月期','2026-10-31')
    two=event('2025年10月期','2025-10-31')
    assert len(gui.combined_calendar_events([one],[two]))==2
    actual=event('2026年10月期','2026-10-31',kind='actual')
    assert gui.combined_calendar_events([actual],[one])==[actual]


def test_actual_for_a_different_known_period_does_not_hide_a_schedule():
    actual=event('2025年10月期','2025-10-31',kind='actual')
    scheduled=event('2026年10月期','2026-10-31')
    assert gui.combined_calendar_events([actual],[scheduled])==[actual,scheduled]
