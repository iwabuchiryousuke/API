"""Service invariants: conservative identity, provenance and honest coverage."""

from datetime import date
from decimal import Decimal
import json

import pytest

from zaimu10.models import Cell, Dataset, Period, Row, SHEETS, Source
from zaimu10.service import (AcquisitionError, Options, merge_datasets,
                             save_audit, validate_code, verify_dataset)


OLD = Period(date(2023, 4, 1), date(2024, 3, 31))
NEW = Period(date(2024, 4, 1), date(2025, 3, 31))
FUTURE = Period(date(2025, 4, 1), date(2026, 3, 31))
NS = "http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor"


def fact(value, *, doc="S100NEW", label="売上高", local="NetSales",
         namespace=NS, decimals="-3", nil=False):
    return Cell(None if value is None else Decimal(str(value)),
                Source(doc_id=doc, filename=f"{doc}.xbrl",
                       url=f"https://disclosure2dl.edinet-fsa.go.jp/searchdocument/pdf/{doc}.pdf",
                       concept=f"{{{namespace}}}{local}",
                       original_label=label, decimals=decimals,
                       raw_value="" if value is None else str(value),
                       basis="consolidated"), nil=nil)


def dataset(*, code="6947", basis="consolidated", periods=None):
    return Dataset(code, "図研", basis, periods or [OLD, NEW])


def complete_dataset():
    ds = dataset()
    for statement in SHEETS:
        local = {"PL": "NetSales", "BS_A": "Assets",
                 "BS_LE": "LiabilitiesAndNetAssets", "CF": "NetCashProvidedByUsedInOperatingActivities"}[statement]
        ds.rows[statement] = [Row(key=statement, label=local, statement=statement,
                                 is_total=True,
                                 values={p.key: fact(1000000000, local=local)
                                         for p in [OLD, NEW]})]
    return ds


def test_changed_label_same_identity_uses_latest_label_and_keeps_old_names():
    latest, older = dataset(), dataset()
    latest.rows["PL"] = [Row("standard:Revenue", "最新の名称", "PL",
                              values={NEW.key: fact(200, label="最新の名称")},
                              label_period=NEW.key)]
    older.rows["PL"] = [Row("standard:Revenue", "以前の名称", "PL",
                             values={OLD.key: fact(100, doc="S100OLD", label="以前の名称")})]
    merged = merge_datasets([latest, older], [NEW, OLD], code="6947", basis="consolidated")
    assert merged.periods == [OLD, NEW]
    assert len(merged.rows["PL"]) == 1
    row = merged.rows["PL"][0]
    assert row.label == "最新の名称"
    assert row.values[OLD.key].source.original_label == "以前の名称"
    assert row.values[NEW.key].source.original_label == "最新の名称"
    row.values[OLD.key].value = Decimal("999")
    assert older.rows["PL"][0].values[OLD.key].value == Decimal("100")


def test_newer_comparative_restatement_replaces_original_and_keeps_source():
    latest, older = dataset(), dataset()
    latest.rows["PL"] = [Row("sales", "売上高", "PL",
                              values={OLD.key: fact(95, doc="S100RESTATED"),
                                      NEW.key: fact(120)})]
    older.rows["PL"] = [Row("sales", "売上高", "PL",
                             values={OLD.key: fact(100, doc="S100ORIGINAL")}),
                        Row("retired", "旧項目", "PL",
                            values={OLD.key: fact(3, doc="S100ORIGINAL", label="旧項目")})]
    merged = merge_datasets([latest, older], [OLD, NEW], code="6947", basis="consolidated")
    rows = {row.key: row for row in merged.rows["PL"]}
    assert rows["sales"].values[OLD.key].value == Decimal("95")
    assert rows["sales"].values[OLD.key].source.doc_id == "S100RESTATED"
    assert rows["retired"].values[OLD.key].value == Decimal("3")
    assert NEW.key not in rows["retired"].values


def test_identical_japanese_labels_do_not_merge_unknown_extension_identities():
    latest, older = dataset(), dataset()
    key1 = "{https://issuer.example/2025/company}OtherIncome"
    key2 = "{https://issuer.example/2024/company}OtherIncome"
    latest.rows["PL"] = [Row(key1, "その他", "PL", values={NEW.key: fact(20)})]
    older.rows["PL"] = [Row(key2, "その他", "PL", values={OLD.key: fact(10)})]
    merged = merge_datasets([latest, older], [OLD, NEW], code="6947", basis="consolidated")
    assert len(merged.rows["PL"]) == 2
    assert {row.key for row in merged.rows["PL"]} == {key1, key2}
    assert all(len(row.values) == 1 for row in merged.rows["PL"])


def test_explicit_nil_is_blank_and_never_replaced_with_zero_or_old_value():
    latest, older = dataset(), dataset()
    latest.rows["PL"] = [Row("sales", "売上高", "PL",
                              values={OLD.key: fact(None, nil=True), NEW.key: fact(0)})]
    older.rows["PL"] = [Row("sales", "売上高", "PL", values={OLD.key: fact(100)})]
    row = merge_datasets([latest, older], [OLD, NEW], code="6947", basis="consolidated").rows["PL"][0]
    assert row.values[OLD.key].nil is True
    assert row.values[OLD.key].value is None
    assert row.values[NEW.key].value == Decimal("0")


def test_period_filter_excludes_future_and_out_of_range_values():
    ds = dataset(periods=[OLD, NEW, FUTURE])
    ds.rows["PL"] = [Row("sales", "売上高", "PL",
                          values={OLD.key: fact(100), NEW.key: fact(120), FUTURE.key: fact(150)}),
                     Row("forecast-only", "将来だけの項目", "PL", values={FUTURE.key: fact(180)})]
    merged = merge_datasets([ds], [OLD, NEW], code="6947", basis="consolidated")
    assert len(merged.rows["PL"]) == 1
    assert set(merged.rows["PL"][0].values) == {OLD.key, NEW.key}


def test_mixed_basis_is_rejected():
    with pytest.raises(AcquisitionError, match="連結と個別"):
        merge_datasets([dataset(), dataset(basis="standalone")], [OLD, NEW],
                       code="6947", basis="consolidated")


def test_explicit_yearly_basis_map_keeps_basis_separate_and_complete():
    consolidated, standalone = complete_dataset(), complete_dataset()
    standalone.basis = "standalone"
    for statement in SHEETS:
        consolidated.rows[statement][0].key += ":consolidated"
        standalone.rows[statement][0].key += ":standalone"
        prior_fact = standalone.rows[statement][0].values[OLD.key]
        prior_fact.value = Decimal("2000000000")
        standalone.rows[statement][0].values = {OLD.key: prior_fact}
        standalone.rows[statement][0].values[OLD.key].source.basis = "standalone"
    mapping = {OLD.key: "standalone", NEW.key: "consolidated"}
    merged = merge_datasets([consolidated, standalone], [OLD, NEW], code="6947",
                            basis="mixed", period_bases=mapping)
    assert merged.period_bases == mapping
    assert merged.complete
    for records in merged.rows.values():
        assert len(records) == 2
        old_row = next(row for row in records if row.key.endswith(":standalone"))
        new_row = next(row for row in records if row.key.endswith(":consolidated"))
        assert set(old_row.values) == {OLD.key}
        assert set(new_row.values) == {NEW.key}
        assert old_row.values[OLD.key].value == Decimal("2000000000")
        assert new_row.values[NEW.key].value == Decimal("1000000000")
    checks = verify_dataset(merged, 2)
    assert all(check["ok"] is True for check in checks
               if check["check"] not in {"cash_flow_components", "cash_balance_rollforward"})
    assert all(check["ok"] is None for check in checks
               if check["check"] in {"cash_flow_components", "cash_balance_rollforward"})


def test_mixed_company_codes_are_rejected():
    with pytest.raises(AcquisitionError):
        merge_datasets([dataset(), dataset(code="7309")], [OLD, NEW],
                       code="6947", basis="consolidated")


def test_empty_heading_is_removed_before_next_populated_section():
    ds = dataset()
    ds.rows["BS_A"] = [Row("empty", "空の区分", "BS_A", is_heading=True),
                       Row("populated", "値のある区分", "BS_A", is_heading=True),
                       Row("assets", "資産", "BS_A", values={OLD.key: fact(100)})]
    merged = merge_datasets([ds], [OLD], code="6947", basis="consolidated")
    assert [row.key for row in merged.rows["BS_A"]] == ["populated", "assets"]


def test_parent_heading_with_populated_child_section_is_preserved():
    ds = dataset()
    ds.rows["BS_A"] = [Row("parent", "資産", "BS_A", indent=0, is_heading=True),
                       Row("child", "流動資産", "BS_A", indent=1, is_heading=True),
                       Row("cash", "現金", "BS_A", indent=2,
                           values={OLD.key: fact(100)})]
    merged = merge_datasets([ds], [OLD], code="6947", basis="consolidated")
    assert [row.key for row in merged.rows["BS_A"]] == ["parent", "child", "cash"]


def test_coverage_counts_actual_values_in_each_sheet_and_period():
    ds = complete_dataset()
    checks = verify_dataset(ds, 2)
    assert all(check["ok"] is True for check in checks
               if check["check"] not in {"cash_flow_components", "cash_balance_rollforward"})
    assert all(check["ok"] is None for check in checks
               if check["check"] in {"cash_flow_components", "cash_balance_rollforward"})
    ds.rows["CF"][0].values[OLD.key] = fact(None, nil=True)
    checks = verify_dataset(ds, 3)
    failures = [check for check in checks if check["ok"] is False]
    assert len(failures) == 2
    assert any(check["check"] == "period_count" for check in failures)
    assert any(check["check"] == "statement_coverage" and check["statement"] == "CF"
               and check["period"] == OLD.key for check in failures)


def test_balance_comparison_accepts_rounding_but_rejects_material_difference():
    ds = complete_dataset()
    ds.rows["BS_LE"][0].values[OLD.key].value = Decimal("1000000999")
    ds.rows["BS_LE"][0].values[NEW.key].value = Decimal("1000010000")
    checks = verify_dataset(ds, 2)
    balance = {check["period"]: check for check in checks
               if check["check"] == "balance_sheet_equation"}
    assert balance[OLD.key]["ok"] is True
    assert balance[NEW.key]["ok"] is False
    assert Decimal(balance[NEW.key]["difference_jpy"]) == Decimal("-10000")


def test_company_extension_named_assets_is_not_a_standard_balance_total():
    ds = complete_dataset()
    for statement in ["BS_A", "BS_LE"]:
        for cell in ds.rows[statement][0].values.values():
            local = cell.source.concept.rsplit("}", 1)[1]
            cell.source.concept = f"{{https://issuer.example/extension}}{local}"
    checks = verify_dataset(ds, 2)
    balance = [check for check in checks if check["check"] == "balance_sheet_equation"]
    assert all(check["ok"] is None for check in balance)


def test_missing_standard_totals_is_unverifiable_not_a_pass():
    ds = complete_dataset()
    ds.rows["BS_LE"][0].values = {}
    checks = verify_dataset(ds, 2)
    assert all(check["ok"] is None for check in checks
               if check["check"] == "balance_sheet_equation")


def test_nonconsecutive_periods_are_detected():
    ds = complete_dataset()
    ds.periods[1] = Period(date(2024, 4, 2), date(2025, 3, 31))
    checks = verify_dataset(ds, 2)
    assert any(check["check"] == "consecutive_periods" and check["ok"] is False
               for check in checks)


@pytest.mark.parametrize("raw, expected", [("６９４７", "6947"),
                                           (" 285a ", "285A"),
                                           ("7309", "7309")])
def test_stock_code_normalization(raw, expected):
    assert validate_code(raw) == expected


@pytest.mark.parametrize("raw", ["69470", "6947.T", "", "ABCD", "../../x", None])
def test_invalid_stock_code_is_rejected(raw):
    with pytest.raises(ValueError):
        validate_code(raw)


def test_audit_serializes_decimal_values_and_full_provenance(tmp_path):
    ds = complete_dataset()
    ds.rows["PL"][0].values[NEW.key].value = Decimal("1234567890123.45")
    path = tmp_path / "audit.json"
    save_audit(ds, path, Options("6947", tmp_path))
    audit = json.loads(path.read_text(encoding="utf-8"))
    fact_obj = audit["dataset"]["rows"]["PL"][0]["values"][NEW.key]
    assert fact_obj["value"] == "1234567890123.45"
    assert fact_obj["source"]["doc_id"] == "S100NEW"
    assert fact_obj["source"]["concept"] == f"{{{NS}}}NetSales"
    assert audit["dataset"]["periods"][0]["start"] == "2023-04-01"
    assert audit["identity_policy"]


def test_merged_workbook_has_only_selected_periods_and_no_derived_values(tmp_path):
    from openpyxl import load_workbook
    from zaimu10.excel import export_workbook

    latest, older = complete_dataset(), complete_dataset()
    latest.rows["PL"][0].label = "最新表示名"
    latest.rows["PL"][0].values[OLD.key] = fact(None, nil=True)
    latest.rows["PL"][0].values[FUTURE.key] = fact(9999999)
    latest.rows["PL"].append(Row("future-only", "将来の項目", "PL",
                                 values={FUTURE.key: fact(1)}))
    older.rows["PL"][0].label = "旧表示名"
    merged = merge_datasets([latest, older], [OLD, NEW], code="6947", basis="consolidated")
    path = export_workbook(merged, tmp_path / "merged.xlsx")
    wb = load_workbook(path)
    assert wb.sheetnames == list(SHEETS.values())
    ws = wb["損益計算書"]
    assert ws["A7"].value == "最新表示名"
    assert ws["B7"].value is None
    assert ws["C7"].value == 1000000
    assert "2024/03/31" in ws["B6"].value
    assert "2025/03/31" in ws["C6"].value
    assert ws.max_column == 3
    assert all(cell.value != "将来の項目" for row in ws for cell in row)
    assert not any(cell.data_type == "f" for sheet in wb for row in sheet for cell in row)
    wb.close()


def test_late_historical_amendment_keeps_latest_fiscal_label_and_newest_old_value():
    amendment, current = dataset(), dataset()
    amendment.rows['PL'] = [Row('sales', '古い年度の名称', 'PL',
                               values={OLD.key: fact(95, doc='S100AMEND',label='古い年度の名称')},
                               label_period=OLD.key)]
    current.rows['PL'] = [Row('sales', '最新年度の名称', 'PL',
                             values={OLD.key: fact(100), NEW.key: fact(120)},
                             label_period=NEW.key)]
    # The amendment was filed later, so its numeric value has first priority.
    merged=merge_datasets([amendment,current],[OLD,NEW],code='6947',basis='consolidated')
    row=merged.rows['PL'][0]
    assert row.label=='最新年度の名称'
    assert row.values[OLD.key].value==Decimal('95')
    assert row.values[OLD.key].source.original_label=='古い年度の名称'
    assert row.values[OLD.key].source.doc_id=='S100AMEND'
