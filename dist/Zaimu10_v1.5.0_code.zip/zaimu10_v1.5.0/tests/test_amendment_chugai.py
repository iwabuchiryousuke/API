"""Real split-body corrections plus hostile changes to the scope proof."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

from bs4 import BeautifulSoup
import pytest

from zaimu10.amendment import inspect_amendment

ROOT = Path(__file__).parent / 'fixtures' / 'chugai_corrections'
MANIFEST = json.loads((ROOT / 'manifest.json').read_text())
CASES = {item['doc_id']: item for item in MANIFEST}
NOTES = ['S100U3VS', 'S100QD4U', 'S100QD54', 'S100QD58', 'S100QD5C', 'S100QD5F']
NONFINANCIAL = ['S100TB9F', 'S100NSNY', 'S100DP2Y']
SAFE = {'nonfinancial_only', 'unchanged_financial_values', 'financial_notes_only'}


def pages(doc='S100QD4U'):
    return [(item['filename'], (ROOT / item['path']).read_bytes().decode('utf-8')) for item in CASES[doc]['files']]


def edit_body(edit, doc='S100QD4U'):
    original = pages(doc)
    name, markup = original[-1]
    soup = BeautifulSoup(markup, 'html.parser')
    edit(soup)
    original[-1] = name, str(soup)
    return original


def append_fragment(soup, fragment):
    soup.body.append(BeautifulSoup(fragment, 'html.parser'))


@pytest.mark.parametrize('doc', NOTES)
def test_real_notes_corrections_retain_changed_cells_with_explicit_scope(doc):
    result = inspect_amendment(pages(doc))
    assert result['status'] == 'financial_notes_only', result
    assert result['proof_complete'] is True
    assert result['changed_tables'] and result['changed_row_labels']
    assert result['notes_scopes']
    assert result['outside_table_prose_equal'] is True
    assert result['analysis_inputs_affected'] is False
    assert result['affected_periods'] is None
    assert result['evidence'] == [dict(filename=item['filename'], sha256=item['sha256']) for item in CASES[doc]['files']]
    # Financial-note changes must not be mislabeled as numeric invariance.
    assert 'invariant' not in result


@pytest.mark.parametrize('doc', NONFINANCIAL)
def test_real_attachment_or_compensation_scopes_have_positive_proof(doc):
    result = inspect_amendment(pages(doc))
    assert result['status'] == 'nonfinancial_only', result
    assert result.get('attachment_only') or result.get('remuneration_table_schemas')


def test_actual_numeric_reclassification_is_kept_in_audit():
    result = inspect_amendment(pages())
    assert any(change['before'] == '344,380' and change['after'] == '329,740'
               for table in result['changed_tables'] for change in table['changed_cells'])
    assert '顧客との契約から生じた債権' in result['changed_row_labels']


@pytest.mark.parametrize('fragment', [
    '<div>【連結貸借対照表】資産合計999</div>',
    '<p>【連結損益計算書】</p>',
    '<table><tr><td>【連結キャッシュ・フロー計算書】</td><td>999</td></tr></table>',
    '<span>売上高を999に訂正</span>',
    '<p>表外の訂正額999</p>',
    '<table><tr><td>売上高</td><td>999</td></tr></table>',
])
def test_extra_financial_or_unclassified_content_cannot_borrow_notes_scope(fragment):
    result = inspect_amendment(edit_body(lambda soup: append_fragment(soup, fragment)))
    assert result['status'] not in SAFE, result


def test_numerically_tagged_note_requires_normal_strict_parser():
    result = inspect_amendment(edit_body(lambda soup: append_fragment(soup,
        '<p><ix:nonFraction name="jppfs_cor:Assets" contextRef="CurrentYearInstant">999</ix:nonFraction></p>')))
    assert result['status'] == 'financial'


def test_missing_after_marker_cannot_be_used():
    def edit(soup):
        marker = next(node for node in soup.find_all('p') if node.get_text(strip=True) == '（訂正後）')
        marker.string = '後半'
    assert inspect_amendment(edit_body(edit))['status'] not in SAFE


def test_extra_separate_unclassified_chapter_is_rejected():
    original = pages()
    original.append(('other.htm', '<html><body><p>売上高999</p></body></html>'))
    assert inspect_amendment(original)['status'] not in SAFE


def test_note_unit_change_is_not_a_proven_numeric_reclassification():
    def edit(soup):
        tables = soup.find_all('table')
        value = tables[2].find(string=lambda text: text and '百万円' in text)
        assert value
        value.replace_with(str(value).replace('百万円', '千円'))
    assert inspect_amendment(edit_body(edit))['status'] not in SAFE


def test_table_shape_change_is_not_proven():
    def edit(soup):
        soup.find_all('table')[2].find('td')['colspan'] = '99'
    assert inspect_amendment(edit_body(edit))['status'] not in SAFE


def test_debt_dependency_in_changed_table_is_explicitly_flagged():
    def edit(soup):
        for table in soup.find_all('table'):
            for cell in table.find_all(['td', 'th']):
                if cell.get_text(strip=True) == '顧客との契約から生じた債権':
                    cell.clear(); cell.append('リース負債')
    result = inspect_amendment(edit_body(edit))
    assert result['status'] == 'financial_notes_only'
    assert result['analysis_inputs_affected'] is True
    assert 'リース負債' in result['changed_row_labels']


def test_compensation_scope_cannot_hide_an_extra_statement_table():
    result = inspect_amendment(edit_body(lambda soup: append_fragment(soup,
        '<table><tr><td>資産合計</td><td>999</td></tr></table>'), 'S100TB9F'))
    assert result['status'] not in SAFE


def test_compensation_prose_allows_only_tsr_rank_and_release_percentage_change():
    def edit(soup):
        paragraphs = [node for node in soup.find_all('p') if '３～５年間' in node.get_text()]
        assert len(paragraphs) == 2
        target = paragraphs[-1].find(string=lambda text: text and '３～５年間' in text)
        target.replace_with(str(target).replace('３～５年間', '３～６年間'))
    assert inspect_amendment(edit_body(edit, 'S100TB9F'))['status'] not in SAFE


def test_articles_attachment_cannot_hide_numeric_change():
    result = inspect_amendment(edit_body(lambda soup: append_fragment(soup,
        '<p>売上高100を101に訂正</p>'), 'S100NSNY'))
    assert result['status'] not in SAFE


def test_fixtures_are_original_public_markup_with_document_hashes():
    for item in MANIFEST:
        for source in item['files']:
            assert sha256((ROOT/source['path']).read_bytes()).hexdigest() == source['sha256']
