"""CF arithmetic is checked only for fully explicit source bridges."""
from copy import deepcopy
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest

from zaimu10.models import Cell, Filing, Row, Source
from zaimu10.parser import parse_filing
from zaimu10.service import cash_flow_checks

FIXTURES = Path(__file__).parent / 'fixtures'


def parsed(name='zuken_2025'):
    with gzip.open(FIXTURES / f'{name}_ixbrl.json.gz', 'rt', encoding='utf-8') as stream:
        return parse_filing(Filing('S100W07I'), json.load(stream))


def local(row):
    return next(iter(row.values.values())).source.concept.rsplit('}',1)[-1]


def record(ds, name, role=None):
    rows = [row for row in ds.rows['CF'] if not row.is_heading and row.values and local(row)==name
            and (role is None or json.loads(row.key)[3]==role)]
    assert len(rows)==1
    return rows[0]


def checks(ds, period=None):
    period = period or ds.periods[-1]
    return {item['check']:item for item in cash_flow_checks(ds, period)}


def adjustment(ds, value, *, insert_after):
    period=ds.periods[-1]
    row=Row(json.dumps(['CF','{https://issuer.example/extension}CashAdjustment',[],
                       'duration','JPY',ds.basis]), 'その他の現金調整', 'CF')
    row.values[period.key]=Cell(Decimal(value),Source(
        'S100W07I','statements.xhtml','https://disclosure2.edinet-fsa.go.jp/',
        concept='{https://issuer.example/extension}CashAdjustment',unit='JPY',
        decimals='-3',basis=ds.basis))
    position=ds.rows['CF'].index(insert_after)
    ds.rows['CF'].insert(position+1,row)
    return row


def test_real_zuken_negative_cash_changes_with_source_rounding():
    ds=parsed()
    increase=record(ds,'NetIncreaseDecreaseInCashAndCashEquivalents')
    assert increase.values[ds.periods[0].key].value<0
    assert increase.values[ds.periods[1].key].value<0
    for period in ds.periods:
        result=checks(ds,period)
        assert all(c['ok'] is True for c in result.values())
    prior=checks(ds,ds.periods[0])
    assert prior['cash_flow_components']['difference_jpy']=='-1000'
    assert prior['cash_balance_rollforward']['difference_jpy']=='-1000'
    assert prior['cash_flow_components']['rounding_tolerance_jpy']=='5000'
    assert prior['cash_balance_rollforward']['rounding_tolerance_jpy']=='3000'


def test_consistent_positive_net_cash_change_passes_both_source_bridges():
    ds=parsed();period=ds.periods[-1]
    increase=record(ds,'NetIncreaseDecreaseInCashAndCashEquivalents').values[period.key]
    operations=record(ds,'NetCashProvidedByUsedInOperatingActivities').values[period.key]
    beginning=record(ds,'CashAndCashEquivalents','begin').values[period.key]
    ending=record(ds,'CashAndCashEquivalents','end').values[period.key]
    positive_change=Decimal('1000000')
    operations.value+=positive_change-increase.value
    increase.value=positive_change
    ending.value=beginning.value+positive_change
    assert all(c['ok'] is True and c['difference_jpy']=='0' for c in checks(ds).values())


def test_real_ifrs_cashflow_uses_reported_million_yen_precision():
    ds=parsed('nitori_2026')
    for period in ds.periods:
        result=checks(ds,period)
        assert result['cash_flow_components']['ok'] is True
        assert result['cash_balance_rollforward']['ok'] is True
        assert result['cash_balance_rollforward']['difference_jpy']=='1000000'
        assert result['cash_balance_rollforward']['rounding_tolerance_jpy']=='3000000'


@pytest.mark.parametrize('difference',['1000','-1000'])
def test_rounding_precision_accepts_small_positive_and_negative_differences(difference):
    ds=parsed();period=ds.periods[-1]
    record(ds,'NetCashProvidedByUsedInOperatingActivities').values[period.key].value+=Decimal(difference)
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is True
    assert Decimal(result['cash_flow_components']['difference_jpy'])==Decimal(difference)
    assert result['cash_balance_rollforward']['ok'] is True


def test_material_error_in_disclosed_flow_is_not_hidden_by_source_totals():
    ds=parsed();period=ds.periods[-1]
    record(ds,'NetCashProvidedByUsedInOperatingActivities').values[period.key].value+=Decimal('1000000')
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is False
    assert result['cash_flow_components']['difference_jpy']=='1000000'
    assert result['cash_balance_rollforward']['ok'] is True


def test_material_cash_balance_error_fails_the_begin_end_bridge():
    ds=parsed();period=ds.periods[-1]
    record(ds,'CashAndCashEquivalents','end').values[period.key].value+=Decimal('1000000')
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is True
    assert result['cash_balance_rollforward']['ok'] is False
    assert result['cash_balance_rollforward']['difference_jpy']=='1000000'


@pytest.mark.parametrize('missing_value',[False,True])
def test_missing_or_nil_fx_is_unverified_instead_of_an_assumed_zero(missing_value):
    ds=parsed();period=ds.periods[-1]
    row=record(ds,'EffectOfExchangeRateChangeOnCashAndCashEquivalents')
    if missing_value:
        row.values[period.key].value=None;row.values[period.key].nil=True
    else:
        ds.rows['CF'].remove(row)
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is None
    assert 'reason' in result['cash_flow_components']
    assert result['cash_balance_rollforward']['ok'] is True


def test_unknown_adjustment_in_net_flow_bridge_makes_it_unverified():
    ds=parsed()
    finance=record(ds,'NetCashProvidedByUsedInFinancingActivities')
    adjustment(ds,'1000000',insert_after=finance)
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is None
    assert result['cash_balance_rollforward']['ok'] is True


def test_unknown_cash_scope_change_makes_cash_bridge_unverified():
    ds=parsed();period=ds.periods[-1]
    increase=record(ds,'NetIncreaseDecreaseInCashAndCashEquivalents')
    adjustment(ds,'1000000',insert_after=increase)
    record(ds,'CashAndCashEquivalents','end').values[period.key].value+=Decimal('1000000')
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is True
    assert result['cash_balance_rollforward']['ok'] is None
    assert 'reason' in result['cash_balance_rollforward']


def test_extension_named_like_standard_increase_never_establishes_the_bridge():
    ds=parsed()
    row=record(ds,'NetIncreaseDecreaseInCashAndCashEquivalents')
    for cell in row.values.values():
        cell.source.concept='{https://issuer.example/extension}NetIncreaseDecreaseInCashAndCashEquivalents'
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is None
    assert result['cash_balance_rollforward']['ok'] is None


def test_missing_explicit_begin_end_roles_cannot_pass_a_cash_bridge():
    ds=parsed()
    beginning=record(ds,'CashAndCashEquivalents','begin')
    key=json.loads(beginning.key);key[3]='end';beginning.key=json.dumps(key)
    result=checks(ds)
    assert result['cash_flow_components']['ok'] is True
    assert result['cash_balance_rollforward']['ok'] is None
