"""Discover filings using EDINET's public search interface; no API key.

The requests reproduce the public screen's pagination action. Only public
metadata is cached, never the short-lived GeneXus session authentication state.
"""
from __future__ import annotations

import csv
import io
import json
import re
import time
import unicodedata
import zipfile
from datetime import date, datetime, timezone, timedelta
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

import requests
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from . import edinet
from .models import Filing

CODE_URL = 'https://disclosure2dl.edinet-fsa.go.jp/searchdocument/codelist/Edinetcode.zip'
SEARCH_URL = 'https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx'
USER_AGENT = 'Mozilla/5.0 (compatible; Zaimu10/1.0; personal financial research)'
PUBLIC_FIELDS = (
    'TEISHUTSU_NICHIJI', 'SHORUI_NAME', 'SYORUI_SB_CD_ID',
    'SHORUI_KANRI_NO', 'EDINET_CD', 'TEISYUTUSYA_NAME',
    'STATUS', 'ALERT_KUBUN', 'BIKOU', 'XBRLKBN', 'JURAN_KUBUN',
)


class DiscoveryError(RuntimeError):
    pass


def normalize_code(code: str) -> str:
    value = unicodedata.normalize('NFKC', str(code)).strip().upper()
    for suffix in ('.T', '.JP'):
        if value.endswith(suffix):
            value = value[:-len(suffix)]
            break
    if len(value) == 5 and value.endswith('0'):
        value = value[:-1]
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}', value):
        raise ValueError('銘柄コードは半角4文字で入力してください（例: 6947、285A）。')
    return value


class _StateParser(HTMLParser):
    state: dict | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == 'input' and attributes.get('name') == 'GXState':
            self.state = json.loads(attributes.get('value') or '{}')


def _state_from_html(html: str) -> dict:
    parser = _StateParser()
    parser.feed(html)
    state = parser.state or {}
    required = ('GX_AJAX_KEY', 'GX_AJAX_IV', 'GX_AUTH_WEEE0030', 'vW_PAGEMAX')
    if not all(k in state for k in required):
        raise DiscoveryError('EDINET検索画面の形式が変わったか、利用できません。')
    return state


def _marker(state: dict) -> str:
    iv = bytes.fromhex(state['GX_AJAX_IV'])
    encryptor = Cipher(algorithms.AES(bytes.fromhex(state['GX_AJAX_KEY'])), modes.CBC(iv)).encryptor()
    return (iv + encryptor.update(b'gxajaxEvt' + b'\0' * 7) + encryptor.finalize()).hex()


def _cancelled(cancel) -> None:
    edinet._check_cancel(cancel)


def _request(session, method: str, url: str, *, cancel=None, **kwargs):
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname not in {
            'disclosure2.edinet-fsa.go.jp', 'disclosure2dl.edinet-fsa.go.jp'}:
        raise DiscoveryError('取得先がEDINETの公式公開ホストではありません。')
    for attempt in range(3):
        _cancelled(cancel)
        # The reader and discovery share one process-wide courtesy interval.
        with edinet._request_lock:
            edinet._pause(max(0, edinet._MIN_INTERVAL -
                              (time.monotonic() - edinet._last_request)), cancel)
            edinet._last_request = time.monotonic()
        try:
            response = session.request(method, url, timeout=(15, 60),
                                       allow_redirects=False, **kwargs)
            if response.status_code in edinet._RETRY_STATUSES:
                wait = edinet._retry_after(response.headers.get('Retry-After'))
                if wait is not None and wait > 300:
                    raise DiscoveryError(f'EDINETから待機が指定されました（{wait:.0f}秒）。時間を置いて再実行してください。')
                if attempt < 2:
                    edinet._pause(max(wait or 0, 2 ** (attempt+1)), cancel)
                    continue
            if response.status_code != 200:
                raise DiscoveryError(f'EDINETへの接続に失敗しました（HTTP {response.status_code}）。')
            _cancelled(cancel)
            return response
        except requests.RequestException as exc:
            if attempt == 2:
                # Avoid including public screen session headers/URLs in errors.
                raise DiscoveryError(f'EDINETへの接続に失敗しました（{type(exc).__name__}）。') from None
            edinet._pause(2 ** (attempt+1), cancel)
    raise DiscoveryError('EDINETから応答を取得できません。')


def _write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


def _parse_code_archive(content: bytes) -> list[dict]:
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        members = [name for name in archive.namelist() if name.lower().endswith('edinetcodedlinfo.csv')]
        if len(members) != 1:
            raise DiscoveryError('EDINETコード一覧ZIPの内容を確認できません。')
        text = archive.read(members[0]).decode('cp932')
    rows = list(csv.reader(io.StringIO(text)))
    if len(rows) < 3 or '証券コード' not in rows[1]:
        raise DiscoveryError('EDINETコード一覧CSVの形式が変わっています。')
    header = rows[1]
    return [dict(zip(header, row)) for row in rows[2:] if row]


def resolve_company(code: str, *, cache_dir: Path, offline=False, session=None, cancel=None) -> dict:
    code = normalize_code(code)
    cache_dir = Path(cache_dir)
    archive_path = cache_dir / 'discovery' / 'Edinetcode.zip'
    owns_session = session is None
    session = session or requests.Session()
    session.headers.update({'User-Agent': USER_AGENT})
    try:
        fresh = archive_path.exists() and time.time() - archive_path.stat().st_mtime < 86400
        if not offline and not fresh:
            content = _request(session, 'GET', CODE_URL, cancel=cancel).content
            _parse_code_archive(content)  # Validate before replacing a usable cache.
            archive_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = archive_path.with_suffix('.zip.tmp')
            temporary.write_bytes(content)
            temporary.replace(archive_path)
        if not archive_path.exists():
            raise DiscoveryError('オフライン用のEDINETコード一覧がありません。先にオンラインで取得してください。')
        rows = _parse_code_archive(archive_path.read_bytes())
        matches = [r for r in rows if r.get('証券コード') == code + '0']
        if not matches:
            raise DiscoveryError(f'銘柄コード {code} はEDINETの現行コード一覧にありません。')
        if len(matches) != 1:
            raise DiscoveryError(f'銘柄コード {code} に複数の提出者が該当しました。自動選択しません。')
        row = matches[0]
        return {'code': code, 'company': row['提出者名'], 'edinet_code': row['ＥＤＩＮＥＴコード'],
                'consolidated': row.get('連結の有無') == '有', 'fiscal_year_end': row.get('決算日', '')}
    finally:
        if owns_session:
            session.close()


def _query_rows(edinet_code: str, session, *, cancel=None, log=print) -> list[dict]:
    """Run exactly the search/pager action available on the public screen."""
    page_response = _request(session, 'GET', SEARCH_URL, cancel=cancel)
    state = _state_from_html(page_response.content.decode('utf-8-sig'))
    today = datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d')
    criteria = {
        'SEARCH_KEY_WORD': edinet_code, 'CONTAIN_FUND': False,
        'SYORUI_SYUBETU': '120,130,140,150,160,170,',
        'KESSAN_NEN': '', 'KESSAN_TUKI': '',
        'TEISYUTU_FROM': '19000101', 'TEISYUTU_TO': today,
        'FLS': True, 'LPR': False, 'RPR': False, 'OTH': False,
        'TEISYUTU_KIKAN': 7,
    }
    result: list[dict] = []
    seen: set[str] = set()
    total_count = 0
    for number in range(1, 101):
        _cancelled(cancel)
        payload = {
            'MPage': False, 'cmpCtx': '',
            'parms': [state['vPGMNAME'], state['vPGMDESC'], criteria, 2, number,
                      int(state['vW_PAGEMAX']), state['vW_SDTCOMMONSESSION'],
                      state['vW_LANGUAGE'], False, [], '', total_count],
            'hsh': [{'hsh': state['gxhash_' + key], 'row': ''} for key in
                    ('vPGMNAME', 'vPGMDESC', 'vW_PAGEMAX', 'vW_LANGUAGE')],
            'objClass': 'weee0030', 'pkgName': 'GeneXus.Programs',
            'events': ["'DOBTN_PAGER'"], 'grids': {},
        }
        headers = {
            'GxAjaxRequest': '1', 'Content-Type': 'application/json',
            'AJAX_SECURITY_TOKEN': state['AJAX_SECURITY_TOKEN'],
            'X-GXAUTH-TOKEN': state['GX_AUTH_WEEE0030'], 'Referer': SEARCH_URL,
        }
        url = f'{SEARCH_URL}?{_marker(state)},gx-no-cache={int(time.time()*1000)}'
        response = _request(session, 'POST', url, cancel=cancel, json=payload, headers=headers)
        try:
            data = response.json()
            values = next(x for x in data.get('gxValues', []) if 'AV125W_RESULT_LIST_JSON' in x)
            rows = json.loads(values['AV125W_RESULT_LIST_JSON'])
            total_count = int(values['AV79W_TotalCount'])
        except (ValueError, TypeError, KeyError, StopIteration):
            raise DiscoveryError('EDINET公開検索の応答形式を確認できません。') from None
        if not isinstance(rows, list):
            raise DiscoveryError('EDINET公開検索の書類一覧が不正です。')
        if total_count == 0:
            return []
        added = 0
        for row in rows:
            doc_id = row.get('SHORUI_KANRI_NO') or ''
            if doc_id and doc_id not in seen:
                seen.add(doc_id)
                result.append({k: row.get(k) for k in PUBLIC_FIELDS})
                added += 1
        if len(result) >= total_count:
            return result
        if added == 0:
            raise DiscoveryError('EDINET書類一覧のページ送りが進みません。途中の一覧は使用しません。')
        log(f'書類一覧を取得中: {len(result)}/{total_count}件')
        state.update(data.get('gxHiddens', {}))
        if values.get('AV74W_SdtCommonSession'):
            state['vW_SDTCOMMONSESSION'] = values['AV74W_SdtCommonSession']
        if cancel is not None:
            if cancel.wait(1.2):
                _cancelled(cancel)
        else:
            time.sleep(1.2)
    raise DiscoveryError('EDINET書類一覧が100ページを超えたため取得を中止しました。')


def _filings_from_rows(rows: list[dict], company: dict, log=print) -> list[Filing]:
    filings: list[Filing] = []
    seen = set()
    for row in rows:
        description = str(row.get('SHORUI_NAME') or '')
        kind = str(row.get('SYORUI_SB_CD_ID') or '')
        if not (kind.startswith(('120', '130')) and '有価証券報告書' in description):
            continue
        if row.get('EDINET_CD') != company['edinet_code']:
            # Do not include a similarly named company's statements.
            continue
        doc_id = str(row.get('SHORUI_KANRI_NO') or '')
        if not re.fullmatch(r'S[0-9A-Z]{7}', doc_id) or doc_id in seen:
            continue
        # 31 is the public, viewable status emitted by the current screen.
        # Unknown/withdrawn/non-disclosed statuses must never become financial
        # data merely because a historical ID remains in the search response.
        # Treat unknown values conservatively instead of guessing their codes.
        if str(row.get('STATUS') or '') != '31' or re.search(
                r'取下|取り下げ|不開示', str(row.get('BIKOU') or '')):
            log(f'公開状態を確認できない書類を除外: {doc_id}（STATUS={row.get("STATUS")}）')
            continue
        normalized = unicodedata.normalize('NFKC', description)
        dates = re.findall(r'(\d{4})/(\d{1,2})/(\d{1,2})', normalized)
        if len(dates) < 2:
            raise DiscoveryError(f'{doc_id}: 有価証券報告書の対象期間を確認できません。')
        start, end = [date(*(int(part) for part in value)) for value in dates[:2]]
        if end < start:
            raise DiscoveryError(f'{doc_id}: 対象期間の開始日と終了日が逆転しています。')
        submitted = str(row.get('TEISHUTSU_NICHIJI') or '').replace('/', '-')
        if row.get('ALERT_KUBUN') not in (None, '', '0'):
            log(f'注意付き書類: {doc_id} {description}（EDINET画面で確認してください）')
        filings.append(Filing(doc_id=doc_id, code=company['code'],
                              company=str(row.get('TEISYUTUSYA_NAME') or company['company']),
                              edinet_code=company['edinet_code'], start=start, end=end,
                              submitted=submitted, description=description,
                              amended=kind.startswith('130') or '訂正' in description))
        seen.add(doc_id)
    filings.sort(key=lambda x: (x.end or date.min, x.submitted, x.doc_id), reverse=True)
    return filings


def discover_filings(code: str, *, cache_dir: Path, years: int = 10,
                     log: Callable[[str], None] = print, cancel=None,
                     offline: bool = False) -> list[Filing]:
    """Return all available annual reports and amendments, newest period first.

    ``years`` describes the requested export horizon; filtering is the service's
    responsibility, since an older report can provide a comparative year.
    Online discovery always refreshes the list. Offline mode requires the cache.
    """
    if not 1 <= years <= 30:
        raise ValueError('取得年数は1〜30の範囲で指定してください。')
    _cancelled(cancel)
    code = normalize_code(code)
    cache_dir = Path(cache_dir)
    with requests.Session() as session:
        session.headers.update({'User-Agent': USER_AGENT})
        company = resolve_company(code, cache_dir=cache_dir, offline=offline,
                                  session=session, cancel=cancel)
        log(f"{company['company']}（{code} / {company['edinet_code']}）の有価証券報告書を検索します。")
        cache_path = cache_dir / 'discovery' / f"{company['edinet_code']}.json"
        if offline:
            if not cache_path.exists():
                raise DiscoveryError('この銘柄のオフライン用書類一覧がありません。')
            saved = json.loads(cache_path.read_text(encoding='utf-8'))
            if (saved.get('schema') != 1 or saved.get('edinet_code') != company['edinet_code']
                    or not isinstance(saved.get('rows'), list)
                    or any(not isinstance(r, dict) or r.get('EDINET_CD') != company['edinet_code']
                           for r in saved['rows'])):
                raise DiscoveryError('保存済み書類一覧の形式または提出者が一致しません。オンラインで取り直してください。')
            rows = saved['rows']
            log(f"保存済み一覧を使用: {saved.get('queried_at', '')}")
        else:
            rows = _query_rows(company['edinet_code'], session, cancel=cancel, log=log)
            _write_json(cache_path, {'schema': 1, 'source_url': SEARCH_URL,
                                    'queried_at': datetime.now(timezone.utc).isoformat(),
                                    'edinet_code': company['edinet_code'], 'rows': rows})
        filings = _filings_from_rows(rows, company, log)
    if not filings:
        raise DiscoveryError('公開検索に有価証券報告書がありません。銘柄コードや提出履歴を確認してください。')
    periods = len({(f.start, f.end) for f in filings})
    log(f'有価証券報告書 {periods}期・{len(filings)}書類（訂正を含む）を確認しました。')
    if periods < years:
        log(f'取得可能な年次報告書は{periods}期です。比較情報を含む収録期間は読み取り後に確認します。')
    return filings
