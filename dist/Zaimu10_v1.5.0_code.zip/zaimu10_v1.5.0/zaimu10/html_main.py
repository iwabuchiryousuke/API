"""Read explicitly dated IFRS main tables without account-level numeric tags.

The TextBlock QName is kept as the source. Caption roles below are separate
issuer-scoped HTML identities, never fabricated numeric XBRL QNames.
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal
import hashlib
import json
import re
import unicodedata

from .models import Cell, Row, Source

BS = {
    '有形固定資産':'PropertyPlantAndEquipmentIFRS', '無形資産':'IntangibleAssetsIFRS',
    '繰延税金資産':'DeferredTaxAssetsIFRS', '非流動資産合計':'NonCurrentAssetsIFRS',
    '棚卸資産':'InventoriesIFRS', '流動資産合計':'CurrentAssetsIFRS',
    '資産合計':'AssetsIFRS', '現金及び現金同等物':'CashAndCashEquivalentsIFRS',
    '非流動負債合計':'NonCurrentLabilitiesIFRS','流動負債合計':'CurrentLiabilitiesIFRS',
    '負債合計':'LiabilitiesIFRS','資本合計':'EquityIFRS',
    '純資産合計':'HtmlNetAssetsIFRS','当社の株主持分':'EquityAttributableToOwnersOfParentIFRS',
    '非支配持分':'NonControllingInterestsIFRS',
    '長期有利子負債':'BorrowingsNCLIFRS','短期有利子負債':'BorrowingsCLIFRS',
    '長期引当金':'ProvisionsNCLIFRS','短期引当金':'ProvisionsCLIFRS',
    '繰延税金負債':'DeferredTaxLiabilitiesIFRS',
}
PL = {'売上収益':'RevenueIFRS','売上原価':'CostOfSalesIFRS',
      '売上総利益':'GrossProfitIFRS','営業利益':'OperatingProfitLossIFRS',
      '税引前当期利益':'ProfitLossBeforeTaxIFRS','法人所得税':'IncomeTaxExpenseIFRS',
      '当期利益':'ProfitLossIFRS','金融費用':'FinanceCostsIFRS',
      'その他の金融収入(支出)':'FinanceIncomeIFRS',
      '当社の株主持分':'ProfitLossAttributableToOwnersOfParentIFRS',
      '非支配持分':'ProfitLossAttributableToNonControllingInterestsIFRS'}
CF = {'営業活動によるキャッシュ・フロー':'NetCashProvidedByUsedInOperatingActivitiesIFRS',
      '投資活動によるキャッシュ・フロー':'NetCashProvidedByUsedInInvestingActivitiesIFRS',
      '財務活動によるキャッシュ・フロー':'NetCashProvidedByUsedInFinancingActivitiesIFRS',
      '現金及び現金同等物に係る換算差額':'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS',
      '現金及び現金同等物の増減額':'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS',
      '現金及び現金同等物の期首残高':'CashAndCashEquivalentsIFRS',
      '現金及び現金同等物の期末残高':'CashAndCashEquivalentsIFRS',
      '法人所得税の支払':'IncomeTaxesPaidOpeCFIFRS',
      '有形固定資産の取得':'PurchaseOfPropertyPlantAndEquipmentInvCFIFRS',
      '無形資産の取得':'PurchaseOfIntangibleAssetsInvCFIFRS'}


def compact(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or '')).rstrip('：:')


def read_html_block(filing, page, block, statement, dataset, contexts):
    from .parser import (_cells,_text,_grid,_table_rows,_expanded,_total,_indent,
                         ParseError)
    if 'IFRS' not in block.get('name',''):
        raise ParseError('タグのない本表は、明示されたIFRS本表以外では解釈しません。')
    block_context=contexts.get(block.get('contextref',''))
    if block_context is None or block_context.dimensions or block.get('continuedat'):
        raise ParseError('HTML本表のコンテキストまたは継続参照を確定できません。')
    units=set(re.findall(r'単位\s*[:：]\s*(百万円|千円|円)',_text(block)))
    if len(units)!=1:
        raise ParseError('HTML本表の単位を一意に確定できません。')
    scale={'円':0,'千円':3,'百万円':6}[units.pop()]
    source_qname=_expanded(block.get('name',''),page.namespaces)
    issuer=filing.edinet_code
    if not re.fullmatch(r'E\d{5}',issuer or ''):
        raise ParseError('HTML本表の提出者を確定できません。')
    namespace='urn:zaimu10:html-table:'+issuer+':'+block.get('name','').rsplit(':',1)[-1]
    side='BS_A';section=();count=0
    by_end={p.end:p for p in dataset.periods}
    for table_index,(table,rows) in enumerate(_table_rows(block)):
        grid=_grid(rows); columns={}
        for tr in rows:
            for col,cell in grid[tr]:
                text=unicodedata.normalize('NFKC',_text(cell))
                dates=[date(int(y),int(m),int(d)) for y,m,d in
                       re.findall(r'(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日',text)]
                if not dates:continue
                end=dates[-1]
                if end not in by_end:
                    raise ParseError('HTML本表に対象期間と対応しない日付列があります。')
                if end in by_end:
                    if len(dates)>1 and dates[0]!=by_end[end].start:
                        raise ParseError('HTML本表の開始日と年度が一致しません。')
                    if col in columns and columns[col]!=by_end[end]:
                        raise ParseError('HTML本表の年度列が重複しています。')
                    columns[col]=by_end[end]
        if not columns:
            if any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',compact(_text(c)))
                   for tr in rows for c in _cells(tr)[1:]):
                raise ParseError('HTML本表の数値表に明示的な年度列がありません。')
            continue
        if len(set(columns.values()))!=len(columns):
            raise ParseError('HTML本表の同年度に複数の金額列があります。')
        for row_index,tr in enumerate(rows):
            positions=grid[tr];lookup=dict(positions)
            label_cell=next((c for col,c in positions if col<min(columns) and _text(c)),None)
            if label_cell is None:continue
            label=_text(label_cell).strip();caption=compact(label)
            if re.search(r'単位|会計年度|事業年度|注記',caption) or re.search(r'\d{4}年',caption):continue
            raw_values={col:compact(_text(lookup[col])) if col in lookup else '' for col in columns}
            numeric=any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',v)
                        for v in raw_values.values() if v)
            if not numeric:
                if not any(raw_values.values()):
                    if statement=='BS':
                        if caption in {'資産','負債','資本','資本の帰属'}:
                            side='BS_A' if caption=='資産' else 'BS_LE';section=(label,)
                        elif caption in {'非流動資産','流動資産','非流動負債','流動負債'}:section=(label,)
                    elif statement=='CF' and '活動' in caption:section=(label,)
                    elif statement=='PL' and '帰属' in caption:section=(label,)
                continue
            target=side if statement=='BS' else statement
            mapping={'BS':BS,'PL':PL,'CF':CF}[statement]
            local=mapping.get(caption,'HtmlRow_'+hashlib.sha256((caption+'|'+str(section)).encode()).hexdigest()[:18])
            role='begin' if statement=='CF' and caption=='現金及び現金同等物の期首残高' else 'end' if statement=='BS' or (statement=='CF' and caption=='現金及び現金同等物の期末残高') else 'duration'
            unit='JPY/shares' if '1株当たり' in caption else 'JPY'
            key=json.dumps([target,namespace,local,[],role,unit,dataset.basis,dataset.accounting_standard,list(section)],ensure_ascii=False)
            row=Row(key,label,target,section,_indent(label_cell),_total(label,tr))
            for col,period in columns.items():
                raw=raw_values[col];nil=raw in {'','-','－','—','―','–','−','ー'}
                if nil:value=None
                else:
                    if not re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',raw):
                        raise ParseError(f'HTML本表の数値を解釈できません: {label}: {raw}')
                    negative=raw.startswith(('△','▲','−','-','('))
                    value=Decimal(raw.lstrip('△▲−-+(').rstrip(')').replace(',',''))
                    if negative:value=-value
                    value*=Decimal(10)**(scale if unit=='JPY' else 0)
                path=json.dumps({'table':table_index,'row':row_index,'column':col},sort_keys=True)
                source=Source(filing.doc_id,page.filename,
                    f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}',
                    filing.submitted,block.get('contextref',''),source_qname,unit,
                    str(-scale if unit=='JPY' else -2),label,raw,scale if unit=='JPY' else 0,
                    dataset.basis,'{'+namespace+'}'+local,path)
                row.values[period.key]=Cell(value,source,nil,
                    note='勘定別数値タグのないIFRS本表。元TextBlock内の明示された年度列・科目名・単位から取得。HTML役割はXBRL QNameと区別。',
                    source_section=section,source_order=len(dataset.rows[target]))
            row.label_period=max(row.values)
            dataset.rows[target].append(row);count+=1
    if not count:
        raise ParseError('HTML本表の数値を取得できません。')
    dataset.source_notes.append(f'{filing.doc_id} {page.filename}: {statement}は勘定別数値タグのないIFRS本表。明示的な年度・単位と物理セル位置を検証して取得。合成した表示役割を実在の数値QNameとして扱いません。')
