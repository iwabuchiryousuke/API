"""The supplied CAPM model, with visible prices and original LINEST formulas.

Monthly prices are split-adjusted price closes (dividends excluded), truncated
in Python to whole yen/index points as in the reference. Rf and the premium are
explicit editable reference assumptions, not fetched current market rates.
"""
from __future__ import annotations

from copy import copy
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from importlib.resources import files
from math import fsum, isfinite
import json
import re

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.formula import ArrayFormula

TEMPLATE_PATH = files('zaimu10').joinpath('assets').joinpath('capm_template.xlsx')
RISK_FREE_RATE = Decimal('0.0103')
MARKET_RISK_PREMIUM = Decimal('0.0563')
PROFILES = {
    'furuya': dict(data_header=15, data_start=16, date_col=11, beta_header=20,
                   beta_start=21, beta_year_col=7, risk_free_col=13, premium_col=15),
    'zuken': dict(data_header=16, data_start=17, date_col=12, beta_header=16,
                  beta_start=17, beta_year_col=8, risk_free_col=14, premium_col=16),
}


def _month(value: str) -> tuple[int, int]:
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}', value):
        raise ValueError('市場データの年月形式が不正です。')
    year, month = map(int, value.split('-'))
    date(year, month, 1)
    return year, month


def _months(first: str, last: str) -> list[str]:
    y, m = _month(first); ey, em = _month(last)
    if (y, m) > (ey, em):
        return []
    result = []
    while (y, m) <= (ey, em):
        result.append(f'{y:04d}-{m:02d}')
        y, m = (y+1, 1) if m == 12 else (y, m+1)
    return result


def market_horizon(periods, *, today: date | None = None) -> tuple[str, str]:
    """Enough preceding December prices for every historical five-year window."""
    if not periods:
        raise ValueError('CAPMの対象年度がありません。')
    today = today or datetime.now(timezone(timedelta(hours=9))).date()
    previous = date(today.year-1, 12, 1) if today.month == 1 else date(today.year, today.month-1, 1)
    return f'{min(period.end.year for period in periods)-5:04d}-12', previous.strftime('%Y-%m')


def calibration_window(year: int, latest_year: int, end_month: str) -> tuple[str, str]:
    """Reference calendar-five-year window; the newest year may be partial."""
    _month(end_month)
    end = end_month if year == latest_year else f'{year:04d}-12'
    return f'{int(end[:4])-4:04d}-01', end


def linest(stock_returns, index_returns) -> tuple[Decimal, Decimal]:
    """Independent scalar cache for Excel LINEST(y,x,,FALSE), const=True."""
    ys, xs = list(map(float, stock_returns)), list(map(float, index_returns))
    if len(xs) != len(ys) or len(xs) < 2 or not all(map(isfinite, xs+ys)):
        raise ValueError('LINESTに必要な同月の収益率がありません。')
    xm, ym = fsum(xs)/len(xs), fsum(ys)/len(ys)
    variance = fsum((x-xm)**2 for x in xs)
    if variance == 0:
        raise ValueError('市場収益率の分散がゼロのためβを計算できません。')
    slope = fsum((x-xm)*(y-ym) for x, y in zip(xs, ys))/variance
    return Decimal(str(slope)), Decimal(str(ym-slope*xm))


def _decimal(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def _style(source, target):
    for attribute in ('font', 'fill', 'border', 'alignment', 'protection'):
        setattr(target, attribute, copy(getattr(source, attribute)))
    target.number_format = source.number_format


def _new_sheet(writer, profile):
    book = load_workbook(TEMPLATE_PATH)
    source = book[profile]
    if 'CAPM' in writer.book:
        raise ValueError('CAPMシートが既にあります。')
    target = writer.book.create_sheet('CAPM')
    for row in source:
        for cell in row:
            if cell.has_style or cell.value is not None:
                copied = target.cell(cell.row, cell.column)
                _style(cell, copied)
                copied.value = cell.value
    for key, value in source.column_dimensions.items():
        copied = copy(value)
        copied.parent = target
        copied._style = None
        target.column_dimensions[key] = copied
    for key, value in source.row_dimensions.items():
        copied = copy(value)
        copied.parent = target
        copied._style = None
        target.row_dimensions[key] = copied
    target.sheet_format = copy(source.sheet_format)
    target.sheet_properties = copy(source.sheet_properties)
    target.page_setup = copy(source.page_setup)
    target.page_margins = copy(source.page_margins)
    target.print_options = copy(source.print_options)
    target.freeze_panes = source.freeze_panes
    target.sheet_view.zoomScale = source.sheet_view.zoomScale
    # Keep the styles source alive until write_capm has styled dynamic rows.
    return target, source, book


def _put(writer, sheet, row, column, value=None, *, expression=None, expected=None,
         period=None, note='', kind='ratio_or_text', array_ref=None):
    cell = sheet.cell(row, column)
    key = ('CAPM', cell.coordinate)
    if expression is not None:
        cell.value = ArrayFormula(ref=array_ref, text=expression) if array_ref else expression
        writer.cached[key] = expected
        writer.values[key] = expected
    else:
        cell.value = float(value) if isinstance(value, Decimal) else value
        if isinstance(value, str):
            cell.data_type = 's'
        writer.values[key] = value
    if note:
        cell.comment = Comment(note, 'Zaimu10')
    record = {'sheet': 'CAPM', 'address': cell.coordinate,
              'row_key': 'CAPM:model', 'period': period.key if period else None,
              'formula': expression, 'display_value': str(expected if expression is not None else value)
              if (expected if expression is not None else value) is not None else None,
              'unit': kind, 'note': note}
    if expression is not None:
        record['expected'] = str(expected) if expected is not None else None
    if array_ref:
        record['array_ref'] = array_ref
    writer.cells.append(record)
    return cell


def _series(rows, kind):
    result = {}; errors = []
    for row in rows or []:
        if not isinstance(row, dict):
            errors.append(f'{kind}の価格レコード形式が不正です。'); continue
        month = row.get('month')
        try:
            _month(month)
            observed = date.fromisoformat(row.get('last_trading_date') or row.get('date') or '')
            if observed.strftime('%Y-%m') != month:
                raise ValueError
        except (ValueError, TypeError):
            errors.append(f'{kind}の実際の取引日を確認できません: {month}'); continue
        raw = _decimal(row.get('close'))
        if raw is None or raw <= 0 or int(raw) <= 0:
            errors.append(f'{kind}の正の終値を確認できません: {month}'); continue
        value = dict(row, close_decimal=raw, input=Decimal(int(raw)), observed=observed)
        if month in result and (result[month]['input'], result[month]['observed']) != (value['input'], value['observed']):
            raise ValueError(f'{kind}の同じ月に異なる価格があります: {month}')
        result[month] = value
    return result, errors


def write_capm(writer, dataset, market_data=None, refs=None):
    """Add CAPM, returning its assumptions, calibration, and missing-input audit.

    FinancialRefs supplies final visible financial addresses and display-unit
    Decimal values. Market caps are verified JPY values keyed by fiscal period.
    This function never fetches data or copies financial/pricing sample values.
    """
    if refs is None:
        from .supplemental import FinancialRefs
        refs = FinancialRefs(writer, dataset)
    periods = sorted(writer.periods, key=lambda period: (period.end, period.start))
    if not periods:
        raise ValueError('CAPMの対象年度がありません。')
    profile = 'zuken' if dataset.code == '6947' else 'furuya'
    config = PROFILES[profile]
    ws, template, template_book = _new_sheet(writer, profile)
    market = dict(market_data) if isinstance(market_data, dict) else {}
    identity_errors = []
    if market:
        if str(market.get('code') or '') != dataset.code:
            identity_errors.append('市場データの銘柄が対象企業と一致しません。')
        if market.get('benchmark') != '^N225':
            identity_errors.append('市場データのベンチマークが日経平均（^N225）と一致しません。')
        if market.get('stock_symbol') not in (None, dataset.code+'.T'):
            identity_errors.append('市場データの価格系列の銘柄が一致しません。')
    if identity_errors:
        # Preserve the financial sheets, but never put another stock/index's
        # prices or market caps into this CAPM calculation.
        market.update(stock_rows=[], index_rows=[], market_caps={})
    stock, errors = _series(market.get('stock_rows'), '個別株')
    index, index_errors = _series(market.get('index_rows'), '日経平均')
    errors += index_errors + identity_errors
    months_available = sorted(set(stock) | set(index))
    end_month = market.get('end_month') or market.get('requested_end_month') or (months_available[-1] if months_available else market_horizon(periods)[1])
    _month(end_month)
    first_month = f'{min(period.end.year for period in periods)-5:04d}-12'
    month_list = list(reversed(_months(first_month, end_month))) if months_available else []
    latest_year = periods[-1].end.year
    rf_col, premium_col = config['risk_free_col'], config['premium_col']
    rf_ref, premium_ref = f'{get_column_letter(rf_col)}9', f'{get_column_letter(premium_col)}9'
    metadata = {'profile': profile, 'formula_policy': 'reference_CAPM_LINEST_no_conditional_guards',
        'benchmark': '^N225', 'benchmark_name': '日経平均株価', 'input_price_policy': 'TRUNC(split-adjusted price close,0); dividends excluded',
        'assumptions': {'risk_free_rate': str(RISK_FREE_RATE), 'equity_risk_premium': str(MARKET_RISK_PREMIUM),
                        'source': '両方の提供見本にある編集可能な固定仮定。現在の金利・市場予想の取得値ではありません。'},
        'source_provenance': market.get('source_provenance', {}), 'checked_at': market.get('checked_at'),
        'stale': bool(market.get('stale')), 'warnings': list(market.get('warnings', []))+errors,
        'monthly_inputs': [], 'calibrations': [], 'periods': {}}
    title = f'{dataset.company.replace("株式会社", "").strip()} /{writer.unit_label}'
    _put(writer, ws, 1, 1, title, note='提供見本のCAPM式を使用。指数名・日付の誤記は訂正し、元データと対象期間を記録。\n'+metadata['assumptions']['source'])
    _put(writer, ws, 9, rf_col, RISK_FREE_RATE, note=metadata['assumptions']['source'])
    _put(writer, ws, 9, premium_col, MARKET_RISK_PREMIUM, note=metadata['assumptions']['source'])
    _style(template['A4'], ws['A14'])
    _put(writer, ws, 14, 1, '親会社帰属当期純利益（ROE用）',
         note='見本のROE分子は親会社帰属の当期純利益。非支配株主損益を含む総利益と区別し、原文の親会社帰属額又は証明された内訳を表示。')
    alignment = copy(ws['A14'].alignment)
    alignment.wrap_text = True
    alignment.shrink_to_fit = False
    ws['A14'].alignment = alignment
    ws.row_dimensions[14].height = 26
    date_col = config['date_col']; stock_col = date_col+1; index_col = date_col+2
    sr_col, ir_col = date_col+3, date_col+4
    for offset, label in enumerate(['日付', f'{dataset.company.replace("株式会社", "").strip()}終値', '日経平均終値',
                                     '個別株前月比', '日経平均前月比']):
        _put(writer, ws, config['data_header'], date_col+offset, label)
    row_by_month = {}
    returns = {}
    for offset, month in enumerate(month_list):
        row = config['data_start']+offset; row_by_month[month] = row
        a, b = stock.get(month), index.get(month)
        for column in range(date_col, date_col+5):
            _style(template.cell(config['data_start'], column), ws.cell(row, column))
        observed = b['observed'] if b else a['observed'] if a else None
        _put(writer, ws, row, date_col, observed, note=f'暦月: {month}。実際の最終取引日。' if observed else f'{month}の価格未取得。日付は推定していません。')
        for column, value, kind in [(stock_col, a, 'stock'), (index_col, b, 'index')]:
            note = f'対象月: {month}\n'
            if value:
                note += f'実取引日: {value["observed"]}\n取得終値（元精度）: {value["close"]}\nCAPM入力: TRUNC終値={value["input"]}\n配当調整後AdjCloseは使用しません。\n'
                note += json.dumps(market.get('source_provenance', {}).get(kind, {}), ensure_ascii=False, default=str)
            else:
                note += '正の終値を確認できません。'
            _put(writer, ws, row, column, value['input'] if value else None, note=note, kind='JPY_per_share' if kind=='stock' else 'index_points')
        metadata['monthly_inputs'].append({'month': month, 'row': row, 'stock_date': str(a['observed']) if a else None,
            'index_date': str(b['observed']) if b else None, 'stock_close_raw': str(a['close_decimal']) if a else None,
            'index_close_raw': str(b['close_decimal']) if b else None,
            'stock_input': str(a['input']) if a else None, 'index_input': str(b['input']) if b else None})
    for offset, month in enumerate(month_list[:-1]):
        previous = month_list[offset+1]; row = row_by_month[month]
        a, ap, b, bp = stock.get(month), stock.get(previous), index.get(month), index.get(previous)
        values = []
        for column, price_col, current, prior in [(sr_col, stock_col, a, ap), (ir_col, index_col, b, bp)]:
            if current and prior:
                expected = current['input']/prior['input']-1
                letter = get_column_letter(price_col)
                _put(writer, ws, row, column, expression=f'={letter}{row}/{letter}{row+1}-1', expected=expected,
                     note=f'{month} / {previous} − 1。提供見本と同じ単純月次価格収益率。')
                values.append(expected)
            else:
                _put(writer, ws, row, column, note='同じ月と前月の終値がそろわないため収益率未算出。')
                values.append(None)
        returns[month] = tuple(values)
    beta_values = {}
    for reverse_index, period in enumerate(reversed(periods)):
        row = config['beta_start']+reverse_index; year_col = config['beta_year_col']; beta_col = year_col+1
        for column in range(year_col, beta_col+2):
            _style(template.cell(config['beta_start'], column), ws.cell(row, column))
        first, last = calibration_window(period.end.year, latest_year, end_month)
        needed = _months(first, last)
        missing = [month for month in needed if month not in returns or any(v is None for v in returns[month])]
        note = f'会計期間: {period.key}\nβの校正期間: {first}〜{last}（月次{len(needed)}件）。\nLINEST(個別株収益率,日経平均収益率,,FALSE)、切片あり。'
        _put(writer, ws, row, year_col, period.end.year, note=note, period=period)
        detail = {'period': period.key, 'first_month': first, 'last_month': last, 'observations': len(needed),
                  'missing_months': missing, 'beta_address': f'{get_column_letter(beta_col)}{row}'}
        if needed and not missing:
            try:
                beta, intercept = linest([returns[month][0] for month in needed], [returns[month][1] for month in needed])
                start_row, end_row = row_by_month[last], row_by_month[first]
                sy, sx = get_column_letter(sr_col), get_column_letter(ir_col)
                expression = f'=LINEST({sy}{start_row}:{sy}{end_row},{sx}{start_row}:{sx}{end_row},,FALSE)'
                array_ref = f'{get_column_letter(beta_col)}{row}:{get_column_letter(beta_col+1)}{row}'
                _put(writer, ws, row, beta_col, expression=expression, expected=beta, period=period, note=note, array_ref=array_ref)
                # LINEST's second cell is the array-result intercept, not an
                # unrelated copied number. Cache it for readers before recalc.
                _put(writer, ws, row, beta_col+1, note=note, period=period)
                writer.values[('CAPM', f'{get_column_letter(beta_col+1)}{row}')] = intercept
                writer.cached[('CAPM', f'{get_column_letter(beta_col+1)}{row}')] = intercept
                writer.cells[-1].update(display_value=str(intercept), expected=str(intercept), array_result_of=detail['beta_address'])
                beta_values[period.key] = (detail['beta_address'], beta)
                detail.update(formula=expression, array_ref=array_ref, beta=str(beta), intercept=str(intercept), complete=True)
            except ValueError as exc:
                detail.update(complete=False, reason=str(exc))
        else:
            detail.update(complete=False, reason='同月の個別株・指数・前月価格が不足しています。')
        if not detail['complete']:
            ws.cell(row, beta_col).comment = Comment(note+'\n未算出: '+detail['reason']+'\n不足: '+','.join(missing), 'Zaimu10')
        metadata['calibrations'].append(detail)
    cap_data = market.get('market_caps') or {}
    for column, period in enumerate(periods, 2):
        letter = get_column_letter(column); detail = {'missing_inputs': []}
        for row in [1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13]:
            _style(template.cell(row, min(column, 15)), ws.cell(row, column))
        _style(template.cell(4, min(column, 15)), ws.cell(14, column))
        _put(writer, ws, 1, column, period.end.year, period=period, note=f'会計期間: {period.key}')
        def financial(name, target):
            fact = refs.get(name, period)
            value = _decimal(getattr(fact, 'value', None)) if fact else None
            if value is not None:
                _put(writer, ws, target, column, expression='='+fact.excel, expected=value, period=period,
                     note=f'見える原表の{fact.excel}を参照。', kind=writer.unit)
                return value
            detail['missing_inputs'].append(name)
            _put(writer, ws, target, column, period=period, note=f'{name}の根拠付き入力がないため未算出。', kind=writer.unit)
            return None
        debt = financial('interest_bearing_debt', 2)
        interest = refs.get('interest_paid', period)
        interest_value = _decimal(getattr(interest, 'value', None)) if interest else None
        if debt is not None and debt != 0 and interest_value is not None:
            _put(writer, ws, 3, column, expression=f'=-{interest.excel}/{letter}2', expected=-interest_value/debt,
                 period=period, note='提供見本: 負債コスト = −利息支払額 / 有利子負債。')
        else:
            _put(writer, ws, 3, column, period=period, note='有利子負債がゼロ、又は利息支払額・負債残高が不足。条件式で補いません。')
        cap = cap_data.get(period.key, cap_data.get(str(period.end.year)))
        cap_value = _decimal(cap.get('value_jpy')) if isinstance(cap, dict) else None
        if cap_value is not None and cap_value > 0:
            _put(writer, ws, 4, column, cap_value/writer.factor, period=period, note=json.dumps(cap,ensure_ascii=False,default=str), kind=writer.unit)
        else:
            detail['missing_inputs'].append('market_cap')
            _put(writer, ws, 4, column, period=period, note='年度末の発行済株式数・株価に基づく時価総額を確認できません。手入力可能です。', kind=writer.unit)
        current_cap = writer.values.get(('CAPM', f'{letter}4'))
        previous_cap = writer.values.get(('CAPM', f'{get_column_letter(column-1)}4')) if column>2 else None
        if current_cap is not None and (column==2 or previous_cap is not None):
            expression = f'={letter}4' if column==2 else f'=({get_column_letter(column-1)}4+{letter}4)/2'
            expected = current_cap if column==2 else (previous_cap+current_cap)/2
            _put(writer, ws, 5, column, expression=expression, expected=expected, period=period, kind=writer.unit,
                 note='提供見本: 初年度は当年時価総額、その後は期首・期末の単純平均。')
        else:
            _put(writer, ws, 5, column, period=period, kind=writer.unit,
                 note='平均に必要な当年・前年の時価総額が不足しています。')
        beta_info = beta_values.get(period.key)
        if beta_info:
            _put(writer, ws, 6, column, expression='='+beta_info[0], expected=beta_info[1], period=period,
                 note='校正表のβを参照。校正期間は参照先セルのメモに記録。')
            beta_reference = beta_info[0] if column==len(periods)+1 else f'{letter}6'
            _put(writer, ws, 7, column, expression=f'={rf_ref}+{beta_reference}*{premium_ref}',
                 expected=RISK_FREE_RATE+beta_info[1]*MARKET_RISK_PREMIUM, period=period,
                 note='提供見本: E(Rx)=Rf+β×(E(Rm)−Rf)。Rf・プレミアムは見える編集可能な参照仮定。')
        else:
            detail['missing_inputs'].append('beta:校正期間の同月価格が不足、又は指数の分散がゼロ')
            for row in (6, 7):
                _put(writer, ws, row, column, period=period,
                     note='βの校正に必要な月次価格・収益率がそろわないため未算出。下の校正表のメモを参照。')
        parent = refs.parent_profit_input(period)
        parent_value = _decimal(parent.fact.value) if parent and not parent.fact.nil else None
        if parent_value is not None:
            if parent.visible is not None:
                if hasattr(writer, 'formula'):
                    writer.formula('CAPM', 14, column, '='+parent.visible.excel, parent_value,
                                   row=parent.row, source=parent.fact, note=parent.reason)
                else:
                    _put(writer, ws, 14, column, expression='='+parent.visible.excel,
                         expected=parent_value/writer.factor, period=period, note=parent.reason, kind=writer.unit)
            elif hasattr(writer, 'source'):
                writer.source('CAPM', 14, column, parent.row, parent.fact, period)
            else:
                _put(writer, ws, 14, column, parent_value/writer.factor, period=period,
                     note=parent.reason, kind=writer.unit)
            refs.register_parent_profit(period, f'{letter}14')
        else:
            _put(writer, ws, 14, column, period=period, kind=writer.unit,
                 note='親会社帰属の当期純利益を確認できません。総利益で推測代用しません。')
        profit = refs.get('net_profit_parent', period); equity = refs.get('shareholders_equity', period)
        pv = _decimal(getattr(profit, 'value', None)) if profit else None
        ev = _decimal(getattr(equity, 'value', None)) if equity else None
        if pv is not None and ev is not None and ev != 0:
            _put(writer, ws, 11, column, expression=f'={profit.excel}/{equity.excel}', expected=pv/ev,
                 period=period, note='提供見本: 親会社帰属当期純利益 / 株主資本計（総利益・純資産合計への置換はしません）。')
            _put(writer, ws, 12, column, expression=f'={letter}11*30%', expected=pv/ev*Decimal('0.30'),
                 period=period, note='提供見本のCE=ROE×30%。')
        else:
            detail['missing_inputs'].append('ROE:net_profit_parent/shareholders_equity')
            for row in (11, 12):
                _put(writer, ws, row, column, period=period,
                     note='親会社帰属当期純利益・株主資本計が未確認、又は株主資本計がゼロのため未算出。総利益・純資産合計で代用しません。')
        debt_cost = writer.values.get(('CAPM', f'{letter}3'))
        equity_cap = writer.values.get(('CAPM', f'{letter}5'))
        tax = writer.values.get(('DCF', f'{letter}13'))
        for row, cost_row in [(10, 7), (13, 12)]:
            equity_cost = writer.values.get(('CAPM', f'{letter}{cost_row}'))
            if (debt is not None and equity_cap is not None and debt+equity_cap != 0 and tax is not None
                    and equity_cost is not None and (debt_cost is not None or debt==0)):
                expected = ((debt_cost or Decimal(0))*(1-tax)*debt+equity_cost*equity_cap)/(debt+equity_cap)
                _put(writer, ws, row, column,
                     expression=f'=({letter}3*(1-\'DCF\'!{letter}13)*{letter}2+{letter}{cost_row}*{letter}5)/({letter}2+{letter}5)',
                     expected=expected, period=period, note='提供見本のWACC式。実効税率はDCF13行、株主資本時価は前後平均。')
            else:
                _put(writer, ws, row, column, period=period, note='WACCに必要な負債・負債コスト・時価総額・実効税率・株主資本コストがそろっていません。')
        metadata['periods'][period.key] = detail
    # Source summaries: all years, final five WACC(C), final eight WACC(R).
    for row, tail in [(10, 5), (13, 8)]:
        for summary_col, start in [(len(periods)+2, 2), (len(periods)+3, max(2,len(periods)+2-tail))]:
            last_col = len(periods)+1
            values = [writer.values.get(('CAPM',f'{get_column_letter(c)}{row}')) for c in range(start,last_col+1)]
            _style(template.cell(row,16 if profile=='furuya' else 17),ws.cell(row,summary_col))
            known = [value for value in values if isinstance(value, Decimal) and value.is_finite()]
            if known:
                ordered=sorted(known);n=len(ordered)
                expected=ordered[n//2] if n%2 else (ordered[n//2-1]+ordered[n//2])/2
                _put(writer,ws,row,summary_col,expression=f'=MEDIAN({get_column_letter(start)}{row}:{get_column_letter(last_col)}{row})',
                     expected=expected,note=f'提供見本と同じMEDIAN。範囲内の数値{n}期を使用し、空欄{len(values)-n}期はExcel標準の動作で除外します。')
            else:
                _put(writer,ws,row,summary_col,note=f'対象範囲にWACCの数値がなく、{len(values)}期すべて空欄のため中央値は未算出です。')
    ws.print_options.horizontalCentered=False
    ws.page_setup.orientation='landscape'
    ws.page_setup.paperSize=ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth=1
    ws.page_setup.fitToHeight=0
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    last_row = max(config['beta_start']+len(periods)-1, config['data_start']+len(month_list)-1, config['data_header'])
    last_column = max(len(periods)+3, date_col+4)
    if ws.max_row > last_row:
        ws.delete_rows(last_row+1, ws.max_row-last_row)
    for key in list(ws.row_dimensions):
        if key > last_row:
            del ws.row_dimensions[key]
    if ws.max_column > last_column:
        ws.delete_cols(last_column+1, ws.max_column-last_column)
    ws.print_area=f'A1:{get_column_letter(last_column)}{last_row}'
    writer.layout_metadata['CAPM'] = metadata
    template_book.close()
    return metadata
