"""Native desktop UI. Network work never runs on the Tk event loop."""
from __future__ import annotations

from datetime import date, datetime, timezone, timedelta
from dataclasses import dataclass, field
from pathlib import Path
import os
import calendar
import webbrowser
from urllib.parse import urlparse
import re
import queue
import subprocess
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

from . import __version__
from .discovery import discover_filings, search_companies, display_company_name
from .registry import CompanyRegistry, RegistryError
from .service import Options, Result, run, validate_code
from .charts import FinancialCharts

APP_DIR = Path(__file__).resolve().parent.parent
UNIT_OPTIONS = {'自動（取得元の表示単位）': 'auto', '千円': 'thousand', '百万円': 'million', '円': 'yen'}
BASIS_OPTIONS = {'自動（連結を優先）': 'auto', '連結': 'consolidated', '個別': 'standalone'}


def initial_window_size(screen_width: int, screen_height: int) -> tuple[int, int]:
    """Fit ordinary laptop screens while retaining a resizable working area."""
    return max(640, min(screen_width-80, 1040)), max(480, min(screen_height-100, 820))


def scheduled_announcement_text(record: dict) -> str:
    """Display only the registry's verified upcoming schedule and target year."""
    announced=record.get('next_announcement_date')
    status=record.get('next_announcement_status') or 'not_fetched'
    if announced:
        text=str(announced)
        if record.get('next_announcement_stale') or status=='stale_schedule':
            text+='（要更新）'
        period=record.get('next_announcement_fiscal_period')
        if period and '対象期の詳細は出典を参照' in period:period='通期（対象期は出典参照）'
        return text+('\n'+str(period)if period else'')
    return {'past_unconfirmed':'日程経過・未確認',
            'partial_fetch_failure':'取得未完了',
            'stale_no_schedule':'要更新・予定未確認',
            'not_in_checked_sources':'未確認'}.get(status,'未取得')


def calendar_values(record: dict) -> tuple[str, ...]:
    """Keep actual dates separate from official upcoming annual schedules."""
    return (str(record.get('code') or ''),
            str(record.get('display_name') or display_company_name(record.get('company') or '')),
            str(record.get('latest_period_end') or record.get('latest_period_label') or '未取得'),
            str(record.get('announcement_date') or '未取得'),
            scheduled_announcement_text(record))


def japan_today() -> date:
    # Windows Python need not have an IANA timezone database installed.
    return datetime.now(timezone(timedelta(hours=9))).date()


def month_dates(year: int, month: int) -> list[date]:
    weeks=calendar.Calendar(firstweekday=6).monthdatescalendar(year,month)
    days=[day for week in weeks for day in week]
    from datetime import timedelta
    while len(days)<42:days.append(days[-1]+timedelta(days=1))
    return days


def calendar_event_view(events: list[dict], *, scope: str, today: date,
                        year: int, month: int, selected_date: date | None = None) -> list[dict]:
    result=[]
    for event in events:
        try:day=date.fromisoformat(event.get('date',''))
        except (ValueError,TypeError):continue
        kind=event.get('kind')
        if kind not in {'actual','scheduled'}:continue
        if selected_date is not None:
            if day!=selected_date:continue
        elif scope=='今後の予定':
            if kind!='scheduled' or day<today:continue
        elif scope=='過去の発表':
            if kind!='actual' or day>today:continue
        elif scope=='表示中の月' and (day.year!=year or day.month!=month):continue
        result.append(event)
    return sorted(result,key=lambda e:(e['date'],e.get('time')or'',e.get('code')or''),reverse=scope not in {'今後の予定','表示中の月'})


def combined_calendar_events(registered: list[dict], market: list[dict]) -> list[dict]:
    """Reconcile providers without collapsing different known fiscal periods."""
    def period_month(event):
        month=event.get('fiscal_month') or (event.get('fiscal_end') or '')[:7]
        if not month:
            match=re.search(r'(\d{4})年\s*(\d{1,2})月期',event.get('fiscal_period') or '')
            if match:month=f'{int(match[1]):04}-{int(match[2]):02}'
        return month
    all_events=registered+market
    actual={}
    for event in all_events:
        if event.get('kind')=='actual':
            actual.setdefault((event.get('code'),event.get('date')),set()).add(period_month(event))
    groups={}
    for event in all_events:
        actual_periods=actual.get((event.get('code'),event.get('date')),set())
        month=period_month(event)
        if event.get('kind')=='scheduled' and actual_periods and (
                not month or month in actual_periods or '' in actual_periods):continue
        key=(event.get('code'),event.get('date'),event.get('kind'))
        groups.setdefault(key,[]).append(event)
    result=[]
    for events in groups.values():
        known={};unknown=[]
        for event in events:
            month=period_month(event)
            if not month:unknown.append(event);continue
            previous=known.get(month)
            if previous is None or (event.get('fiscal_end') and not previous.get('fiscal_end')):
                known[month]=event
        result.extend(known.values() if known else unknown[:1])
    return result


@dataclass
class GuiJob:
    """One independently cancellable worker. Only the UI changes busy state.

    Every run owns a fresh cancellation event and generation. Logs and terminal
    values go to this job's private queue, so late messages cannot finish a
    different job or a later run. Worker callbacks never call Tk.
    """
    name: str
    busy: bool = False
    generation: int = 0
    cancel_event: threading.Event = field(default_factory=threading.Event)
    events: queue.Queue = field(default_factory=queue.Queue)
    thread: threading.Thread | None = None
    message: str = ''

    def start(self, call, done_kind: str) -> bool:
        if self.busy:
            return False
        self.generation += 1
        generation = self.generation
        cancel = threading.Event()
        self.cancel_event = cancel
        self.busy = True

        def emit(kind, value):
            self.events.put((generation, kind, value))

        def work():
            try:
                value = call(cancel, lambda text: emit('log', text))
                emit(done_kind, value)
            except InterruptedError as exc:
                emit('cancelled', str(exc))
            except Exception as exc:
                emit('error', str(exc))
                emit('trace', traceback.format_exc())

        self.thread = threading.Thread(target=work, name='zaimu10-'+self.name,
                                       daemon=True)
        self.thread.start()
        return True

    def pending(self, limit: int = 100):
        for _ in range(limit):
            try:
                generation, kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if generation == self.generation:
                yield kind, value

    def finish(self):
        self.busy = False

    def cancel(self):
        self.cancel_event.set()


class App:
    def __init__(self, root: tk.Tk, initial_code: str = '6947', *,
                 data_dir: Path | None = None, cache_dir: Path | None = None):
        self.root = root
        self.root.title(f'Zaimu10 v{__version__} — 財務諸表を10期まとめてExcelへ')
        width, height = initial_window_size(root.winfo_screenwidth(), root.winfo_screenheight())
        self.root.geometry(f'{width}x{height}')
        self.root.minsize(min(860, width), min(620, height))
        self.root.configure(bg='#f5f7fa')
        self.cache_dir = Path(cache_dir) if cache_dir is not None else APP_DIR/'.cache'/'zaimu10'
        self.registry = CompanyRegistry((Path(data_dir) if data_dir is not None else APP_DIR/'data')/'companies.json')
        self.jobs = {name: GuiJob(name) for name in ('financial', 'earnings', 'search')}
        self.closing = False
        self.result: Result | None = None
        self.selected_company: dict | None = None
        self.search_results: dict[str, dict] = {}
        self.registered: dict[str, dict] = {}
        self.market_events: list[dict] = []
        self.calendar_events: list[dict] = []
        self.calendar_event_rows: dict[str,dict] = {}
        today=japan_today()
        self.calendar_year,self.calendar_month=today.year,today.month
        self.calendar_list_year,self.calendar_list_month=today.year,today.month
        self.calendar_selected_date: date | None = None
        self.calendar_list_expanded=False
        self.calendar_days: list[date] = []
        self.pending_search_action = 'show'
        self.loading_company = False
        self.code = tk.StringVar(value=initial_code)
        self.years = tk.IntVar(value=10)
        self.basis = tk.StringVar(value=next(iter(BASIS_OPTIONS)))
        self.unit = tk.StringVar(value=next(iter(UNIT_OPTIONS)))
        self.output = tk.StringVar(value=str(APP_DIR/'results'))
        self.until = tk.StringVar()
        self.partial = tk.BooleanVar(value=False)
        self.offline = tk.BooleanVar(value=False)
        self.show_advanced = tk.BooleanVar(value=False)
        self.selected_text = tk.StringVar(value='銘柄コード、または会社名を入力してください。')
        self.registry_text = tk.StringVar(value='登録した企業の最新決算期末と本決算発表日を表示します。')
        self.calendar_scope=tk.StringVar(value='すべて')
        self.calendar_month_text=tk.StringVar()
        self.calendar_note=tk.StringVar(value='企業を登録して「発表日を更新」を押してください。')
        self.calendar_detail=tk.StringVar(value='発表済みと、公式に公表された今後の予定を表示します。')
        self.market_schedule=tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='会社を検索するか、銘柄コードを入力して「Excelを作成」を押してください。')
        self.financial_state=tk.StringVar(value='待機中')
        self.earnings_state=tk.StringVar(value='待機中')
        self.result_notice=tk.StringVar(value='公表値・原項目名を使用。欠落は空白、同一性を確認できない科目は別行に残します。')
        self._styles()
        self._build()
        self.code.trace_add('write', self._query_changed)
        self._refresh_registry()
        self._sync_controls()
        self.root.protocol('WM_DELETE_WINDOW', self._close)
        self.root.bind('<Destroy>',self._root_destroyed,add='+')
        self._poll_after_id=self.root.after(100,self._poll)

    def _styles(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=('Yu Gothic UI', 10), background='#f5f7fa', foreground='#203047')
        style.configure('TFrame', background='#f5f7fa')
        style.configure('Card.TFrame', background='#ffffff')
        style.configure('Card.TLabel', background='#ffffff')
        style.configure('Title.TLabel', font=('Yu Gothic UI', 21, 'bold'), foreground='#172c48')
        style.configure('Sub.TLabel', foreground='#526276', font=('Yu Gothic UI', 9))
        style.configure('TButton', padding=(12, 7), font=('Yu Gothic UI', 10))
        style.configure('Primary.TButton', background='#174a7b', foreground='white', font=('Yu Gothic UI', 10, 'bold'))
        style.map('Primary.TButton', background=[('active', '#246296'), ('disabled', '#b4c2d0')])
        style.configure('TEntry', padding=5)
        style.configure('TCombobox', padding=5)
        style.configure('TLabelframe', padding=10, background='white')
        style.configure('TLabelframe.Label', background='#f5f7fa', font=('Yu Gothic UI', 10, 'bold'))
        style.configure('TCheckbutton', background='white')
        style.configure('Treeview', background='white', fieldbackground='white', rowheight=27, font=('Yu Gothic UI', 9))
        style.configure('Treeview.Heading', font=('Yu Gothic UI', 9, 'bold'))
        style.configure('Registry.Treeview', rowheight=34)
        style.configure('TNotebook.Tab', padding=(14, 7))

    @staticmethod
    def _tree(parent, columns, headings, widths, height):
        frame = ttk.Frame(parent)
        tree = ttk.Treeview(frame, columns=columns, show='headings', selectmode='browse', height=height)
        for key, label, width in zip(columns, headings, widths):
            tree.heading(key, text=label)
            tree.column(key, width=width, minwidth=65, stretch=key == 'company')
        scroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.grid(row=0, column=0, sticky='nsew')
        scroll.grid(row=0, column=1, sticky='ns')
        horizontal = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(xscrollcommand=horizontal.set)
        horizontal.grid(row=1, column=0, sticky='ew')
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return frame, tree

    def _build(self):
        main = ttk.Frame(self.root, padding=(22, 16))
        main.pack(fill='both', expand=True)
        ttk.Label(main, text='財務諸表を、10期まとめて。', style='Title.TLabel').pack(anchor='w')
        ttk.Label(main, text='会社名でも検索。財務諸表4表とDCF・FR・CAPMの7シートを作成します。', style='Sub.TLabel').pack(anchor='w', pady=(3, 10))
        # Reserve the footer before the flexible notebook so progress/status
        # remain visible even on a 1366x768 laptop with advanced options open.
        footer = ttk.Frame(main)
        footer.pack(side='bottom', fill='x', pady=(8, 0))
        activity=ttk.Frame(footer);activity.pack(fill='x')
        activity.columnconfigure(1,weight=1);activity.columnconfigure(4,weight=1)
        ttk.Label(activity,text='Excel',style='Sub.TLabel').grid(row=0,column=0,padx=(0,7))
        self.progress=ttk.Progressbar(activity,mode='indeterminate')
        self.progress.grid(row=0,column=1,sticky='ew')
        ttk.Label(activity,textvariable=self.financial_state,style='Sub.TLabel',width=15).grid(row=0,column=2,padx=(7,15))
        ttk.Label(activity,text='決算発表日',style='Sub.TLabel').grid(row=0,column=3,padx=(0,7))
        self.earnings_progress=ttk.Progressbar(activity,mode='indeterminate')
        self.earnings_progress.grid(row=0,column=4,sticky='ew')
        ttk.Label(activity,textvariable=self.earnings_state,style='Sub.TLabel',width=9).grid(row=0,column=5,padx=(7,0))
        ttk.Label(footer, textvariable=self.status, style='Sub.TLabel', wraplength=950).pack(anchor='w', pady=(5, 0))
        self.notebook = ttk.Notebook(main)
        self.notebook.pack(fill='both', expand=True)
        self.create_tab = ttk.Frame(self.notebook, padding=(12, 10))
        self.registry_tab = ttk.Frame(self.notebook, padding=(12, 12))
        self.calendar_tab = ttk.Frame(self.notebook, padding=(12, 10))
        self.charts_tab = ttk.Frame(self.notebook, padding=(12, 10))
        self.notebook.add(self.create_tab, text='Excelを作成')
        self.notebook.add(self.charts_tab, text='財務グラフ')
        self.notebook.add(self.calendar_tab, text='決算カレンダー')
        self.notebook.add(self.registry_tab, text='登録企業')
        self._build_create_tab()
        self._build_registry_tab()
        self._build_calendar_tab()
        self.financial_charts=FinancialCharts(self.charts_tab,open_callback=self._open_saved_chart,source_callback=self._open_url)
        self.financial_charts.pack(fill='both',expand=True)
        self.root.bind('<Control-Return>', lambda _: self._start())
        self.code_entry.focus_set()

    def _build_create_tab(self):
        main = self.create_tab
        main.columnconfigure(0, weight=1)
        main.rowconfigure(4, weight=1, minsize=70)
        card = ttk.Frame(main, style='Card.TFrame', padding=12)
        card.grid(row=0, column=0, sticky='ew')
        card.columnconfigure(1, weight=1)
        ttk.Label(card, text='コード・会社名', style='Card.TLabel').grid(row=0, column=0, sticky='w', padx=(0, 10))
        self.code_entry = ttk.Entry(card, textvariable=self.code, font=('Yu Gothic UI', 12))
        self.code_entry.grid(row=0, column=1, sticky='ew')
        self.code_entry.bind('<Return>', lambda _: self._search())
        self.search_button = ttk.Button(card, text='検索', command=self._search_button_clicked)
        self.search_button.grid(row=0, column=2, padx=8)
        self.register_button = ttk.Button(card, text='企業を登録', command=self._register_company)
        self.register_button.grid(row=0, column=3)
        ttk.Label(card, textvariable=self.selected_text, style='Card.TLabel', wraplength=840).grid(row=1, column=0, columnspan=4, sticky='w', pady=(7, 8))
        # Ambiguous matches use their own selection window. A results table
        # embedded above the options would hide logs on small laptop screens.
        self.search_dialog = tk.Toplevel(self.root)
        self.search_dialog.withdraw()
        self.search_dialog.title('検索結果から企業を選択')
        self.search_dialog.transient(self.root)
        self.search_dialog.minsize(620, 300)
        self.search_dialog.geometry(f'{min(900,self.root.winfo_screenwidth()-100)}x{min(470,self.root.winfo_screenheight()-130)}')
        self.search_dialog.protocol('WM_DELETE_WINDOW', self._dismiss_search)
        self.search_dialog.bind('<Escape>', lambda _: self._dismiss_search())
        dialog_main = ttk.Frame(self.search_dialog, padding=16)
        dialog_main.pack(fill='both', expand=True)
        self.search_caption = tk.StringVar(value='対象の企業を選んでください。')
        ttk.Label(dialog_main, textvariable=self.search_caption, wraplength=820).pack(anchor='w', pady=(0, 10))
        self.search_frame, self.search_tree = self._tree(dialog_main,
            ('code', 'company'), ('銘柄コード', '会社名'),
            (100, 660), 10)
        self.search_frame.pack(fill='both', expand=True)
        self.search_tree.bind('<Double-1>', lambda _: self._use_search_result())
        self.search_tree.bind('<Return>', lambda _: self._use_search_result())
        dialog_actions = ttk.Frame(dialog_main)
        dialog_actions.pack(fill='x', pady=(12, 0))
        self.use_search_button = ttk.Button(dialog_actions, text='選択した企業を入力', command=self._use_search_result, style='Primary.TButton')
        self.use_search_button.pack(side='left')
        ttk.Button(dialog_actions, text='閉じる', command=self._dismiss_search).pack(side='right')

        opts = ttk.Frame(main, style='Card.TFrame', padding=10)
        opts.grid(row=1, column=0, sticky='ew', pady=(8, 0))
        opts.columnconfigure(1, weight=1)
        opts.columnconfigure(5, weight=1)
        ttk.Label(opts, text='対象', style='Card.TLabel').grid(row=0, column=0, sticky='w', padx=(0, 8))
        self.basis_box = ttk.Combobox(opts, textvariable=self.basis, values=list(BASIS_OPTIONS), state='readonly', width=21)
        self.basis_box.grid(row=0, column=1, sticky='ew')
        ttk.Label(opts, text='期数', style='Card.TLabel').grid(row=0, column=2, sticky='w', padx=(12, 6))
        self.years_box = ttk.Combobox(opts, textvariable=self.years, values=list(range(1, 11)), width=4, state='readonly')
        self.years_box.grid(row=0, column=3, sticky='w')
        ttk.Label(opts, text='表示単位', style='Card.TLabel').grid(row=0, column=4, sticky='w', padx=(12, 7))
        self.unit_box = ttk.Combobox(opts, textvariable=self.unit, values=list(UNIT_OPTIONS), state='readonly', width=25)
        self.unit_box.grid(row=0, column=5, columnspan=2, sticky='ew')
        ttk.Label(opts, text='出力先', style='Card.TLabel').grid(row=1, column=0, sticky='w', pady=(8, 0))
        self.output_entry = ttk.Entry(opts, textvariable=self.output)
        self.output_entry.grid(row=1, column=1, columnspan=5, sticky='ew', pady=(8, 0))
        self.folder_button = ttk.Button(opts, text='選択…', command=self._choose_folder)
        self.folder_button.grid(row=1, column=6, padx=(8, 0), pady=(8, 0))
        self.advanced_check = ttk.Checkbutton(opts, text='詳細設定', variable=self.show_advanced, command=self._toggle_advanced)
        self.advanced_check.grid(row=2, column=0, columnspan=2, sticky='w', pady=(7, 0))
        ttk.Label(opts, text='自動単位は、取得した決算書の表示に合わせます。', style='Card.TLabel').grid(row=2, column=2, columnspan=5, sticky='e', pady=(7, 0))
        self.advanced_frame = ttk.Frame(opts, style='Card.TFrame')
        self.advanced_frame.grid(row=3, column=0, columnspan=7, sticky='ew', pady=(7, 0))
        ttk.Label(self.advanced_frame, text='最終決算日', style='Card.TLabel').grid(row=0, column=0, sticky='w')
        self.until_entry = ttk.Entry(self.advanced_frame, textvariable=self.until, width=17)
        self.until_entry.grid(row=0, column=1, sticky='w', padx=(8, 10))
        ttk.Label(self.advanced_frame, text='空欄＝最新 ／ 例：2025-03-31', style='Card.TLabel').grid(row=0, column=2, sticky='w')
        self.offline_check = ttk.Checkbutton(self.advanced_frame, text='取得済みデータのみ使用（オフライン）', variable=self.offline)
        self.offline_check.grid(row=1, column=0, columnspan=2, sticky='w', pady=(5, 0))
        self.partial_check = ttk.Checkbutton(self.advanced_frame, text='不足・警告があっても「要確認」で出力', variable=self.partial)
        self.partial_check.grid(row=1, column=2, sticky='w', padx=(12, 0), pady=(5, 0))
        self.advanced_frame.grid_remove()

        actions = ttk.Frame(main)
        actions.grid(row=2, column=0, sticky='ew', pady=(10, 7))
        self.start_button = ttk.Button(actions, text='Excelを作成', style='Primary.TButton', command=self._start)
        self.start_button.pack(side='left')
        self.cancel_button = ttk.Button(actions, text='Excelを中止', command=self._cancel_financial, state='disabled')
        self.cancel_button.pack(side='left', padx=8)
        self.open_button = ttk.Button(actions, text='Excelを開く', command=self._open_file, state='disabled')
        self.open_button.pack(side='right')
        self.open_folder_button = ttk.Button(actions, text='出力先を開く', command=self._open_folder)
        self.open_folder_button.pack(side='right', padx=8)
        ttk.Label(main, textvariable=self.result_notice, style='Sub.TLabel', wraplength=930).grid(row=3, column=0, sticky='w', pady=(0, 5))
        self.logs = ScrolledText(main, height=4, wrap='word', font=('Yu Gothic UI', 9), bg='white', fg='#28384d', relief='flat', padx=10, pady=7, state='disabled')
        self.logs.grid(row=4, column=0, sticky='nsew')
        self.inputs = [self.code_entry, self.search_button, self.register_button, self.use_search_button,
                       self.years_box, self.basis_box, self.unit_box, self.output_entry,
                       self.folder_button, self.until_entry, self.offline_check, self.partial_check, self.advanced_check]

    def _build_registry_tab(self):
        main=self.registry_tab
        main.columnconfigure(0,weight=1);main.rowconfigure(2,weight=1)
        heading=ttk.Frame(main);heading.grid(row=0,column=0,sticky='ew',pady=(0,4))
        ttk.Label(heading,text='登録企業',font=('Yu Gothic UI',15,'bold')).pack(side='left')
        ttk.Label(heading,text='最新決算期末順。発表済みと公式予定を分けて表示します。',style='Sub.TLabel').pack(side='left',padx=(14,0))
        frame,self.registry_tree=self._tree(main,
            ('code','company','period','announcement','scheduled'),
            ('コード','会社名','最新決算期末 ▼','本決算発表日（実績）','次回本決算発表予定'),
            (70,270,150,170,230),7)
        self.registry_tree.configure(style='Registry.Treeview')
        frame.grid(row=2,column=0,sticky='nsew')
        self.registry_tree.bind('<Double-1>',lambda _:self._use_registered())
        self.registry_tree.bind('<Return>',lambda _:self._use_registered())
        actions=ttk.Frame(main);actions.grid(row=3,column=0,sticky='ew',pady=(10,8))
        self.use_registered_button=ttk.Button(actions,text='選択した企業を入力',command=self._use_registered)
        self.use_registered_button.pack(side='left')
        self.calendar_button=ttk.Button(actions,text='選択企業の発表日を更新',command=self._update_calendar)
        self.calendar_button.pack(side='left',padx=8)
        self.all_calendar_button=ttk.Button(actions,text='登録企業すべての発表日を更新',command=self._update_all_calendars)
        self.all_calendar_button.pack(side='left',padx=(0,8))
        self.calendar_cancel_button=ttk.Button(actions,text='発表日を中止',command=self._cancel_earnings,state='disabled',width=8)
        self.calendar_cancel_button.pack(side='left')
        self.remove_registered_button=ttk.Button(actions,text='登録を解除',command=self._remove_registered)
        self.remove_registered_button.pack(side='right')
        ttk.Label(main,textvariable=self.registry_text,style='Sub.TLabel',wraplength=900).grid(row=4,column=0,sticky='w',pady=(4,0))
        ttk.Label(main,text='発表日は有価証券報告書の提出日とは別の日付です。次回予定は公式発表済みの通期決算だけを表示します。\n未確認の日付を推測せず、更新が必要な予定は「要更新」と表示します。履歴・出典は「決算カレンダー」で確認できます。',style='Sub.TLabel',wraplength=900).grid(row=5,column=0,sticky='w',pady=(10,0))
        self.inputs.extend([self.use_registered_button,self.calendar_button,self.all_calendar_button,self.remove_registered_button])

    def _build_calendar_tab(self):
        main=self.calendar_tab
        main.columnconfigure(0,weight=1)
        main.rowconfigure(2,weight=1,minsize=190);main.rowconfigure(4,weight=2,minsize=90)
        controls=ttk.Frame(main);controls.grid(row=0,column=0,sticky='ew',pady=(0,5));controls.columnconfigure(3,weight=1)
        ttk.Button(controls,text='‹ 前月',command=lambda:self._move_calendar(-1)).grid(row=0,column=0)
        ttk.Label(controls,textvariable=self.calendar_month_text,font=('Yu Gothic UI',14,'bold'),width=13,anchor='center').grid(row=0,column=1,padx=8)
        ttk.Button(controls,text='翌月 ›',command=lambda:self._move_calendar(1)).grid(row=0,column=2)
        ttk.Button(controls,text='今月',command=self._calendar_today).grid(row=0,column=3,sticky='w',padx=8)
        self.calendar_refresh_button=ttk.Button(controls,text='発表日を更新',command=self._update_earnings)
        self.calendar_refresh_button.grid(row=0,column=4,padx=(4,6))
        self.calendar_stop_button=ttk.Button(controls,text='中止',command=self._cancel_earnings,state='disabled',width=5)
        self.calendar_stop_button.grid(row=0,column=5)
        options=ttk.Frame(main);options.grid(row=1,column=0,sticky='ew',pady=(0,5));options.columnconfigure(0,weight=1)
        self.market_check=ttk.Checkbutton(options,text='公開予定も表示（全銘柄・JPX公式）',variable=self.market_schedule,command=self._market_changed)
        self.market_check.grid(row=0,column=0,sticky='w')
        self.calendar_scope_box=ttk.Combobox(options,textvariable=self.calendar_scope,values=['表示中の月','今後の予定','過去の発表','すべて'],state='readonly',width=14)
        legend=ttk.Frame(options);legend.grid(row=0,column=1,padx=(4,12))
        ttk.Label(legend,text='● 発表済み',foreground='#16816a',font=('Yu Gothic UI',8)).pack(side='left',padx=(0,8))
        ttk.Label(legend,text='● 公式予定',foreground='#4467a2',font=('Yu Gothic UI',8)).pack(side='left')
        self.calendar_scope_box.grid(row=0,column=2,sticky='e');self.calendar_scope_box.bind('<<ComboboxSelected>>',lambda _:self._calendar_filter_changed())
        self.month_canvas=tk.Canvas(main,bg='white',highlightthickness=0,height=190)
        self.month_canvas.grid(row=2,column=0,sticky='nsew')
        self.month_canvas.bind('<Configure>',lambda _:self._draw_calendar())
        self.month_canvas.bind('<Button-1>',self._calendar_click)
        self.month_canvas.bind('<Motion>',self._calendar_hover)
        self.month_canvas.bind('<Leave>',lambda _:self.month_canvas.delete('calendar_hover'))
        list_header=ttk.Frame(main);list_header.grid(row=3,column=0,sticky='ew',pady=(5,4));list_header.columnconfigure(0,weight=1)
        ttk.Label(list_header,textvariable=self.calendar_note,style='Sub.TLabel',wraplength=460).grid(row=0,column=0,sticky='w')
        self.apply_month_button=ttk.Button(list_header,text='この月の一覧',command=self._apply_calendar_month)
        self.apply_month_button.grid(row=0,column=1,sticky='e',padx=(8,0))
        self.clear_calendar_date_button=ttk.Button(list_header,text='日付解除',command=self._clear_calendar_date,state='disabled')
        self.clear_calendar_date_button.grid(row=0,column=2,sticky='e',padx=(8,0))
        self.list_expand_button=ttk.Button(list_header,text='一覧を広く表示',command=self._toggle_calendar_list)
        self.list_expand_button.grid(row=0,column=3,sticky='e',padx=(8,0))
        frame,self.events_tree=self._tree(main,('date','kind','code','company','period'),
            ('決算発表日','区分','コード','会社名','対象決算期'),(120,95,75,310,220),3)
        frame.grid(row=4,column=0,sticky='nsew')
        self.events_tree.bind('<<TreeviewSelect>>',lambda _:self._calendar_event_selected())
        self.events_tree.bind('<Double-1>',lambda _:self._open_event_source())
        footer=ttk.Frame(main);footer.grid(row=5,column=0,sticky='ew',pady=(6,0));footer.columnconfigure(0,weight=1)
        ttk.Label(footer,textvariable=self.calendar_detail,style='Sub.TLabel',wraplength=735).grid(row=0,column=0,sticky='w')
        self.event_source_button=ttk.Button(footer,text='出典を開く',command=self._open_event_source,state='disabled')
        self.event_source_button.grid(row=0,column=1,sticky='e')
        self.inputs.extend([self.calendar_refresh_button,self.market_check])
        self._render_calendar()

    def _toggle_calendar_list(self):
        self.calendar_list_expanded=not self.calendar_list_expanded
        if self.calendar_list_expanded:
            self.month_canvas.grid_remove()
            self.calendar_tab.rowconfigure(2,weight=0,minsize=0)
            self.calendar_tab.rowconfigure(4,weight=1,minsize=180)
            self.list_expand_button.configure(text='月表示に戻す')
        else:
            self.month_canvas.grid()
            self.calendar_tab.rowconfigure(2,weight=1,minsize=190)
            self.calendar_tab.rowconfigure(4,weight=2,minsize=90)
            self.list_expand_button.configure(text='一覧を広く表示')

    def _refresh_calendar_grid(self):
        self.calendar_month_text.set(f'{self.calendar_year}年 {self.calendar_month}月')
        self._draw_calendar()

    def _move_calendar(self,amount):
        month=self.calendar_year*12+self.calendar_month-1+amount
        self.calendar_year,self.calendar_month=month//12,month%12+1
        # Top-month navigation never changes the lower list's condition, date
        # filter, selected source row or scroll position.
        self._refresh_calendar_grid()

    def _calendar_today(self):
        today=japan_today();self.calendar_year,self.calendar_month=today.year,today.month
        self._refresh_calendar_grid()

    def _calendar_filter_changed(self):
        self.calendar_selected_date=None
        if self.calendar_scope.get()=='表示中の月':
            self.calendar_list_year,self.calendar_list_month=self.calendar_year,self.calendar_month
        self._render_calendar()

    def _apply_calendar_month(self):
        self.calendar_scope.set('表示中の月')
        self.calendar_list_year,self.calendar_list_month=self.calendar_year,self.calendar_month
        self.calendar_selected_date=None
        self._render_calendar()

    def _clear_calendar_date(self):
        self.calendar_selected_date=None
        self._render_calendar()

    def _market_changed(self):
        self._render_calendar()
        if self.market_schedule.get() and not self.market_events and not self._job_busy('earnings'):
            self._update_earnings(market_only=True)

    def _render_calendar(self):
        registered=[event for record in self.registered.values()for event in record.get('earnings_events',[])]
        self.calendar_events=combined_calendar_events(registered,self.market_events if self.market_schedule.get()else[])
        self.calendar_month_text.set(f'{self.calendar_year}年 {self.calendar_month}月')
        if not hasattr(self,'events_tree'):return
        selected=self.events_tree.selection()
        previous=self.calendar_event_rows.get(selected[0])if selected else None
        def identity(event):
            return (event.get('code'),event.get('date'),event.get('kind'),event.get('fiscal_month')or event.get('fiscal_period'))
        previous_key=identity(previous)if previous else None
        events=calendar_event_view(self.calendar_events,scope=self.calendar_scope.get(),today=japan_today(),
            year=self.calendar_list_year,month=self.calendar_list_month,selected_date=self.calendar_selected_date)
        self.events_tree.delete(*self.events_tree.get_children());self.calendar_event_rows={}
        restore=None
        for i,event in enumerate(events):
            key=str(i);self.calendar_event_rows[key]=event
            self.events_tree.insert('','end',iid=key,values=(event['date']+(' '+event['time'] if event.get('time')else''),
                '発表済み'if event['kind']=='actual'else'公式予定',event.get('code',''),
                display_company_name(event.get('company','')),event.get('fiscal_period')or''))
            if previous_key is not None and identity(event)==previous_key:restore=key
        if self.calendar_selected_date:
            label=self.calendar_selected_date.isoformat()+'（日付指定）'
        elif self.calendar_scope.get()=='表示中の月':
            label=f'{self.calendar_list_year}年{self.calendar_list_month}月の一覧'
        else:label=self.calendar_scope.get()
        actual=sum(e['kind']=='actual'for e in events);planned=sum(e['kind']=='scheduled'for e in events)
        self.calendar_note.set(f'{label}：発表済み {actual}件 ／ 公式予定 {planned}件')
        self.calendar_detail.set('月送りは上のカレンダーだけ切り替えます。一覧は条件・日付を選んで変更できます。予定は出典でご確認ください。')
        if hasattr(self,'clear_calendar_date_button'):
            self.clear_calendar_date_button.configure(state='normal'if self.calendar_selected_date else'disabled')
        if hasattr(self,'event_source_button'):self.event_source_button.configure(state='disabled')
        if restore is not None:
            self.events_tree.selection_set(restore)
            if hasattr(self.events_tree,'see'):self.events_tree.see(restore)
            self._calendar_event_selected()
        self._draw_calendar()

    def _draw_calendar(self):
        if not hasattr(self,'month_canvas'):return
        canvas=self.month_canvas;canvas.delete('all')
        width,height=max(100,canvas.winfo_width()),max(150,canvas.winfo_height())
        header=23;cw=width/7;ch=(height-header)/6
        self.calendar_days=month_dates(self.calendar_year,self.calendar_month)
        grouped={}
        for event in self.calendar_events:
            grouped.setdefault(event.get('date'),[]).append(event)
        weekdays=('日','月','火','水','木','金','土')
        for i,label in enumerate(weekdays):
            canvas.create_text((i+.5)*cw,11,text=label,fill='#b56262'if i==0 else'#5c78a0'if i==6 else'#64748b',font=('Yu Gothic UI',9,'bold'))
        today=japan_today()
        for i,day in enumerate(self.calendar_days):
            col,row=i%7,i//7;x0,y0=col*cw,header+row*ch;x1,y1=x0+cw,y0+ch
            other=day.month!=self.calendar_month
            color='#f4f6f9'if other else'#ffffff'
            if day==today:color='#edf4fd'
            selected=day==self.calendar_selected_date
            canvas.create_rectangle(x0,y0,x1,y1,fill=color,outline='#6a91c5'if selected else'#e1e7ef',width=2 if selected else 1)
            canvas.create_text(x0+7,y0+3,text=str(day.day),anchor='nw',fill='#b4bdc8'if other else'#b56262'if col==0 else'#5c78a0'if col==6 else'#263b56',font=('Yu Gothic UI',9,'bold'if day==today else'normal'))
            items=grouped.get(day.isoformat(),[])
            if items:
                canvas.create_text(x1-5,y0+3,text=f'{len(items)}件',anchor='ne',fill='#667b92',font=('Yu Gothic UI',8))
                room=max(0,int((ch-15)/11))
                for j,event in enumerate(items[:room]):
                    name=display_company_name(event.get('company',''))
                    label=f"{event.get('code','')} {name}"
                    maximum=max(4,int((cw-12)/10));label=label if len(label)<=maximum else label[:maximum-1]+'…'
                    canvas.create_text(x0+6,y0+15+j*11,text=label,anchor='nw',fill='#16816a'if event['kind']=='actual'else'#4467a2',font=('Yu Gothic UI',8))

    def _calendar_day_at(self,event):
        width=max(1,self.month_canvas.winfo_width());height=max(150,self.month_canvas.winfo_height())
        if event.y<23:return None
        col=int(event.x/(width/7));row=int((event.y-23)/((height-23)/6))
        index=row*7+col
        return self.calendar_days[index]if 0<=col<7 and 0<=row<6 and index<len(self.calendar_days)else None

    def _calendar_click(self,event):
        day=self._calendar_day_at(event)
        if day is None:return
        self.calendar_year,self.calendar_month=day.year,day.month
        self.calendar_selected_date=day;self._render_calendar()

    def _calendar_hover(self,event):
        canvas=self.month_canvas;canvas.delete('calendar_hover')
        day=self._calendar_day_at(event)
        if day is None:return
        items=[e for e in self.calendar_events if e.get('date')==day.isoformat()]
        if not items:return
        lines=[day.isoformat()]
        for item in items[:7]:lines.append(f"{'発表済み'if item['kind']=='actual'else'公式予定'}　{item.get('code','')} {display_company_name(item.get('company',''))}")
        if len(items)>7:lines.append(f'ほか{len(items)-7}件。クリックして一覧を表示。')
        text=canvas.create_text(0,0,text='\n'.join(lines),anchor='nw',font=('Yu Gothic UI',9),fill='#263b56',tags='calendar_hover')
        box=canvas.bbox(text);bw,bh=box[2]-box[0]+18,box[3]-box[1]+14
        x=min(max(4,event.x+12),max(4,canvas.winfo_width()-bw-4));y=min(max(4,event.y+12),max(4,canvas.winfo_height()-bh-4))
        canvas.coords(text,x+9,y+7);rect=canvas.create_rectangle(x,y,x+bw,y+bh,fill='#f4f8fd',outline='#bbcbdc',tags='calendar_hover');canvas.tag_raise(text,rect)

    def _calendar_event_selected(self):
        selection=self.events_tree.selection()
        event=self.calendar_event_rows.get(selection[0])if selection else None
        self.event_source_button.configure(state='normal'if event and event.get('source_url')else'disabled')
        if event:self.calendar_detail.set(f"{event.get('title','')}　／　{event.get('source_title')or event.get('publisher')or'公式開示'}　／　確認：{(event.get('verified_at')or'')[:10]}")

    def _open_event_source(self):
        selection=self.events_tree.selection()
        event=self.calendar_event_rows.get(selection[0])if selection else None
        if event and event.get('source_url'):self._open_url(event['source_url'])

    def _open_url(self,url):
        parsed=urlparse(url)
        if parsed.scheme in {'https','http'} and parsed.hostname:webbrowser.open(url)

    def _open_saved_chart(self):
        if self.closing:return
        path=filedialog.askopenfilename(title='保存済みの財務データを開く',initialdir=self.output.get()if Path(self.output.get()).is_dir()else str(APP_DIR),filetypes=[('Zaimu10の監査データ','*.audit.json'),('JSON','*.json')])
        if not path:return
        try:
            from .audit import load_result
            result=load_result(Path(path))
            self.financial_charts.set_dataset(result.dataset)
            self.result=result
            self.notebook.select(self.charts_tab)
            self.open_button.configure(state='normal'if result.workbook.is_file()else'disabled')
            self.status.set(f'{result.dataset.code} {result.dataset.company} の保存済みグラフを表示しています。')
        except (ValueError,OSError,KeyError)as exc:messagebox.showerror('データを開けませんでした',str(exc),parent=self.root)

    def _toggle_advanced(self):
        if self.show_advanced.get():
            self.advanced_frame.grid()
        else:
            self.advanced_frame.grid_remove()

    def _show_search_results(self, count: int):
        if count > 1:
            self.search_caption.set(f'「{self.code.get()}」に一致する企業は{count}件です。対象企業を選んで入力してください。')
            self.search_dialog.deiconify()
            self.search_dialog.lift()
            self.search_dialog.grab_set()
        else:
            if self.search_dialog.grab_current() is self.search_dialog:
                self.search_dialog.grab_release()
            self.search_dialog.withdraw()

    def _dismiss_search(self):
        self.pending_search_action = 'show'
        self._show_search_results(0)
        self.status.set('企業選択を閉じました。検索語を変えて再検索できます。')

    def _query_changed(self, *_):
        if not self.loading_company:
            self.selected_company = None
            self.pending_search_action = 'show'
            self._show_search_results(0)
            self.search_tree.delete(*self.search_tree.get_children())
            self.search_results = {}
            self.selected_text.set('会社名の検索結果が複数ある場合は、対象企業を選んで入力してください。')

    def _set_company(self, company: dict):
        self.loading_company = True
        try:
            self.code.set(company['code'])
        finally:
            self.loading_company = False
        self.selected_company = dict(company)
        record=self.registered.get(company['code'],company)
        detail=[]
        if record.get('latest_period_end')or record.get('latest_period_label'):detail.append('最新決算期末：'+(record.get('latest_period_end')or record['latest_period_label']))
        if record.get('announcement_date'):detail.append('本決算発表：'+record['announcement_date'])
        self.selected_text.set(f"{company['code']}　{company.get('display_name') or display_company_name(company.get('company',''))}"+('　／　'+'　'.join(detail)if detail else''))

    def _choose_folder(self):
        path = filedialog.askdirectory(title='Excelの出力先を選択', initialdir=self.output.get() if Path(self.output.get()).is_dir() else str(APP_DIR))
        if path:
            self.output.set(path)

    def _append(self, text: str):
        self.logs.configure(state='normal')
        self.logs.insert('end', text+'\n')
        self.logs.see('end')
        self.logs.configure(state='disabled')

    @property
    def busy(self):
        """Aggregate observation for callers waiting for all activity to finish."""
        return any(job.busy for job in self.jobs.values())

    def _job_busy(self, name):
        return self.jobs[name].busy

    def _sync_controls(self):
        financial=self._job_busy('financial');earnings=self._job_busy('earnings');search=self._job_busy('search')
        closing=self.closing
        # Settings are snapshots when a worker starts. Editing another company
        # or preparing the next export cannot change an active export's options.
        for widget in self.inputs:
            widget.configure(state='disabled'if closing else('readonly'if isinstance(widget,ttk.Combobox)else'normal'))
        self.code_entry.configure(state='disabled'if search or closing else'normal')
        self.register_button.configure(state='disabled'if search or closing else'normal')
        self.use_search_button.configure(state='disabled'if search or closing else'normal')
        self.use_registered_button.configure(state='disabled'if search or closing else'normal')
        self.search_button.configure(text='検索中止'if search else'検索',state='disabled'if closing else'normal')
        self.start_button.configure(state='disabled'if financial or search or closing else'normal')
        for button in (self.calendar_button,self.all_calendar_button,self.calendar_refresh_button,self.market_check):
            button.configure(state='disabled'if earnings or closing else'normal')
        self.cancel_button.configure(state='normal'if financial and not self.jobs['financial'].cancel_event.is_set()and not closing else'disabled')
        for button in (self.calendar_cancel_button,self.calendar_stop_button):
            button.configure(state='normal'if earnings and not self.jobs['earnings'].cancel_event.is_set()and not closing else'disabled')
        self.open_button.configure(state='normal'if self.result and not closing else'disabled')
        for name,bar in (('financial',self.progress),('earnings',self.earnings_progress)):
            if self._job_busy(name):bar.start(12)
            else:bar.stop()

    def _job_status(self, name, text, state=None):
        self.jobs[name].message=text
        if state is not None:
            if name=='financial':self.financial_state.set(state)
            elif name=='earnings':self.earnings_state.set(state)
        labels={'financial':'Excel','earnings':'決算発表日','search':'企業検索'}
        active=[key for key in ('financial','earnings')if self._job_busy(key)]
        if name not in active:active.append(name)
        self.status.set('\n'.join(labels[key]+'：'+self.jobs[key].message for key in active if self.jobs[key].message))

    def _worker(self, name: str, call, done_kind: str):
        expected={'financial':'done','earnings':'earnings_done','search':'search_done'}
        if name not in expected or done_kind!=expected[name]:
            raise ValueError('バックグラウンド処理の結果種別が一致しません。')
        if self.closing:return False
        started=self.jobs[name].start(call,done_kind)
        if started:
            if name=='financial':self.financial_state.set('取得中')
            elif name=='earnings':self.earnings_state.set('更新中')
            self._sync_controls()
        return started

    def _search_button_clicked(self):
        if self._job_busy('search'):self._cancel_search()
        else:self._search()

    def _search(self, purpose: str = 'show'):
        if self._job_busy('search') or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showinfo('企業の検索', '銘柄コード、または会社名を入力してください。', parent=self.root)
            return
        self.pending_search_action = purpose
        offline = self.offline.get()
        self._job_status('search',f'「{query}」に一致する企業を検索しています。')
        self._worker('search', lambda cancel,log: (search_companies(query, cache_dir=self.cache_dir,
            offline=offline, cancel=cancel, log=log), purpose), 'search_done')

    def _search_done(self, results: list[dict], purpose: str):
        self.search_tree.delete(*self.search_tree.get_children())
        self.search_results = {}
        for i, company in enumerate(results):
            item = str(i)
            self.search_results[item] = dict(company)
            self.search_tree.insert('', 'end', iid=item, values=(company['code'], company.get('display_name') or display_company_name(company.get('company',''))))
        self.pending_search_action = purpose
        self._show_search_results(len(results))
        if not results:
            self.selected_company = None
            self.selected_text.set('一致する企業がありません。会社名の一部、または4文字の銘柄コードで再検索してください。')
            self.status.set('企業が見つかりませんでした。')
        elif len(results) == 1:
            self.search_tree.selection_set('0')
            self._set_company(results[0])
            self.status.set(f"{results[0]['code']} の企業情報を入力しました。")
            self._complete_search_action(purpose)
        else:
            self.selected_company = None
            self.selected_text.set(f'{len(results)}件見つかりました。検索結果をダブルクリックするか「選択した企業を入力」を押してください。')
            self.status.set('同じ名前を含む企業が複数あります。対象企業を選んでください。')
            self.search_tree.focus_set()

    def _complete_search_action(self, purpose):
        self.pending_search_action = 'show'
        if purpose == 'register':
            self._register_company()
        elif purpose == 'start':
            self._start()

    def _use_search_result(self):
        if self._job_busy('search') or self.closing:
            return
        selected = self.search_tree.selection()
        if not selected:
            self.status.set('検索結果から企業を選択してください。')
            return
        company = self.search_results[selected[0]]
        purpose = self.pending_search_action
        self._set_company(company)
        self._show_search_results(0)
        self.status.set(f"{company['code']} の企業情報を入力しました。")
        self._complete_search_action(purpose)

    def _register_company(self):
        if self._job_busy('search') or self.closing:
            return
        if self.selected_company is None:
            self._search('register')
            return
        try:
            company = self.registry.register(self.selected_company)
            self._refresh_registry()
            self.status.set(f"{company['code']} {display_company_name(company.get('company',''))} を登録しました。")
            self.registry_text.set('登録しました。「発表日を更新」で最新決算期末と本決算発表日を確認できます。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録できませんでした', str(exc), parent=self.root)

    def _refresh_registry(self):
        try:
            records = self.registry.calendar_rows()
        except (RegistryError, OSError, ValueError) as exc:
            self.registry_text.set(f'登録情報を読み込めませんでした：{exc}')
            self._append(f'登録情報：{exc}')
            return
        selected = self.registry_tree.selection()
        self.registry_tree.delete(*self.registry_tree.get_children())
        self.registered = {record['code']: record for record in records}
        if self.selected_company is not None and self.code.get()==self.selected_company.get('code'):
            self._set_company(self.selected_company)
        for record in records:
            self.registry_tree.insert('', 'end', iid=record['code'], values=calendar_values(record))
        if selected and selected[0] in self.registered:
            self.registry_tree.selection_set(selected[0])
        elif records:
            self.registry_tree.selection_set(records[0]['code'])
        self.registry_text.set(f'登録企業：{len(records)}社。最新決算期末の新しい順（未取得は下段）。')
        if hasattr(self,'month_canvas'):self._render_calendar()

    def _use_registered(self):
        if self._job_busy('search') or self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('登録企業から対象を選択してください。')
            return
        self._set_company(self.registered[selected[0]])
        self.notebook.select(self.create_tab)
        self.status.set('登録企業を入力しました。「Excelを作成」で取得できます。')
        self.code_entry.focus_set()

    def _remove_registered(self):
        if self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('解除する登録企業を選択してください。')
            return
        code = selected[0]
        try:
            self.registry.remove(code)
            self._refresh_registry()
            self.status.set(f'{code} の登録を解除しました。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録を解除できませんでした', str(exc), parent=self.root)

    def _update_calendar(self):
        if self._job_busy('earnings') or self.closing:return
        selected=self.registry_tree.selection()
        if not selected:self.status.set('発表日を更新する登録企業を選択してください。');return
        self._update_earnings(codes=[selected[0]])

    def _update_all_calendars(self):
        if self._job_busy('earnings') or self.closing:return
        codes=list(self.registered)
        if not codes:
            self.status.set('登録企業がありません。企業を登録してから全社更新を実行してください。')
            return
        self._update_earnings(codes=codes)

    def _update_earnings(self,codes=None,market_only=False):
        if self._job_busy('earnings') or self.closing:return
        chosen=[]if market_only else(list(self.registered)if codes is None else list(codes))
        include_market=self.market_schedule.get()
        if not chosen and not include_market:
            self.status.set('企業を登録するか「公開予定も表示」を選んでください。');return
        offline=self.offline.get()
        self._job_status('earnings',(f'登録企業{len(chosen)}社の'if chosen else'公開予定の')+'本決算発表日・公式予定を確認しています。')
        def work(cancel,log):
            from .earnings import load_calendar,load_market_schedule
            warnings=[];count=0;market=None
            for code in chosen:
                if cancel.is_set():raise InterruptedError('発表日の更新を中止しました。')
                try:
                    calendar=load_calendar(code,cache_dir=self.cache_dir,offline=offline,refresh=not offline,cancel=cancel,log=log)
                    self.registry.update_earnings(code,calendar);count+=len(calendar.get('events',[]));warnings.extend(calendar.get('warnings',[]))
                except InterruptedError:raise
                except Exception as exc:warnings.append(f'{code}：{exc}')
            if include_market:
                try:
                    market=load_market_schedule(cache_dir=self.cache_dir,offline=offline,refresh=not offline,cancel=cancel,log=log)
                    warnings.extend(market.get('warnings',[]));count+=len(market.get('events',[]))
                except InterruptedError:raise
                except Exception as exc:warnings.append(f'公開予定：{exc}')
            if cancel.is_set():raise InterruptedError('発表日の更新を中止しました。')
            return {'market':market,'count':count,'warnings':warnings}
        self._worker('earnings',work,'earnings_done')

    def _make_options(self, code: str) -> Options:
        until = date.fromisoformat(self.until.get().strip()) if self.until.get().strip() else None
        years = int(self.years.get())
        if not 1 <= years <= 10:
            raise ValueError('取得期数は1～10を指定してください。')
        if not self.output.get().strip():
            raise ValueError('出力先を指定してください。')
        return Options(code=code, output_dir=Path(self.output.get()), cache_dir=self.cache_dir,
            years=years, basis=BASIS_OPTIONS[self.basis.get()], unit=UNIT_OPTIONS[self.unit.get()],
            until=until, offline=self.offline.get(), allow_partial=self.partial.get())

    def _start(self):
        if self._job_busy('financial') or self._job_busy('search') or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showerror('入力を確認してください', '会社名、または銘柄コードを入力してください。', parent=self.root)
            return
        try:
            opts = self._make_options(query)
        except (ValueError, KeyError, tk.TclError) as exc:
            messagebox.showerror('入力を確認してください', str(exc), parent=self.root)
            return
        try:
            opts.code = validate_code(query)
        except ValueError:
            self._search('start')
            return
        code = opts.code
        self.result = None
        self.logs.configure(state='normal')
        self.logs.delete('1.0', 'end')
        self.logs.configure(state='disabled')
        self.result_notice.set('公表値・原項目名を使用。欠落は空白、同一性を確認できない科目は別行に残します。')
        self._job_status('financial',f'{code} の財務諸表を取得しています。初回は数分かかる場合があります。')
        self._worker('financial',lambda cancel,log:run(opts,log=log,cancel=cancel),'done')

    def _handle_event(self, kind, value, *, job_name=None):
        name=job_name or {'earnings_done':'earnings','search_done':'search'}.get(kind,'financial')
        expected={'financial':'done','earnings':'earnings_done','search':'search_done'}
        if name not in expected or kind not in {'log','error','cancelled','trace',expected[name]}:
            return
        job=self.jobs[name]
        prefix={'financial':'Excel','earnings':'決算発表日','search':'企業検索'}[name]
        if kind=='log':
            self._append(f'[{prefix}] {value}')
            self._job_status(name,value)
            return
        if kind=='trace':return
        # Finishing one slot never changes another slot's busy/cancel state.
        job.finish()
        self._sync_controls()
        if kind=='search_done':
            if job.cancel_event.is_set()or self.closing:
                self.pending_search_action='show'
                self._job_status(name,'企業の検索を中止しました。')
            else:
                results,purpose=value
                self._search_done(results,purpose)
        elif kind=='earnings_done':
            if value.get('market')is not None:self.market_events=value['market'].get('events',[])
            self._refresh_registry()
            for warning in value.get('warnings',[]):self._append(f'[決算発表日] {warning}')
            self._job_status(name,f"本決算発表日・公式予定を{value.get('count',0)}件確認しました。"+
                (' 一部の予定は未公表・取得できません。詳細はログをご確認ください。'if value.get('warnings')else''),'完了')
        elif kind=='done':
            self.result=value
            try:self.financial_charts.set_dataset(value.dataset)
            except Exception as exc:self._append(f'[Excel] Excelは作成済みです。グラフを表示できませんでした：{exc}')
            notice=getattr(value,'basis_notice','')or''
            capm=getattr(value.dataset,'export_metadata',{}).get('supplemental',{}).get('CAPM',{})
            missing=set(period for period,details in capm.get('periods',{}).items()
                        if details.get('missing_inputs'))
            missing.update(item.get('period') for item in capm.get('calibrations',[])
                           if not item.get('complete'))
            market_notice=(f'CAPM：{len(missing)}期に未算出の指標があります。理由は該当セルのメモに記載しています。'
                           if missing else '')
            tag='要確認の出力'if value.dataset.warnings else'作成完了'
            if notice or market_notice:
                self.result_notice.set(' '.join(text for text in (notice,market_notice) if text))
                self._append('[Excel] '+self.result_notice.get())
            summary='完了（個別CF未掲載のため取得区分を切替）'if notice else tag
            self._job_status(name,f'{summary}：{value.workbook.name}',
                             '完了・区分切替'if notice else'完了・CAPM一部未算出'if market_notice else'完了')
            self._append(f'[Excel] Excel：{value.workbook}\n監査記録：{value.audit}')
            try:
                record=self.registry.update_result(value.dataset)
                if record is not None:self._refresh_registry()
            except (RegistryError,OSError,ValueError)as exc:
                self._append(f'[Excel] Excelは作成済みです。登録情報の更新に失敗しました：{exc}')
            self._sync_controls()
        elif kind=='error':
            if name=='earnings':self._refresh_registry()
            self._append(f'[{prefix}] {value}')
            self._job_status(name,'処理を完了できませんでした。詳細はログをご確認ください。','エラー')
        elif kind=='cancelled':
            if name=='earnings':self._refresh_registry()
            self._append(f'[{prefix}] {value}')
            self._job_status(name,str(value),'中止')

    def _drain_jobs(self):
        # A chatty financial worker cannot starve an earnings completion event.
        for name,job in self.jobs.items():
            for kind,value in job.pending():
                self._handle_event(kind,value,job_name=name)

    def _poll(self):
        self._poll_after_id=None
        self._drain_jobs()
        if self.closing and all(job.thread is None or not job.thread.is_alive()for job in self.jobs.values()):
            self._stop_ui_poll()
            self.root.destroy()
            return
        self._poll_after_id=self.root.after(100,self._poll)

    def _stop_ui_poll(self):
        timer=getattr(self,'_poll_after_id',None)
        if timer is not None:
            self.root.after_cancel(timer)
            self._poll_after_id=None

    def _root_destroyed(self,event):
        if event.widget is self.root:
            self.closing=True
            for job in self.jobs.values():job.cancel()
            self._stop_ui_poll()

    def _cancel_job(self,name):
        job=self.jobs[name]
        if not job.busy:return
        job.cancel()
        self._job_status(name,'中止しています。実行中の通信が終了するまでお待ちください。','中止中')
        self._sync_controls()

    def _cancel_financial(self):self._cancel_job('financial')
    def _cancel_earnings(self):self._cancel_job('earnings')
    def _cancel_search(self):self._cancel_job('search')

    def _cancel(self):
        """Compatibility for the financial cancel action; never cancels earnings."""
        self._cancel_financial()

    def _close(self):
        if self.busy:
            self.closing=True
            for name in self.jobs:self._cancel_job(name)
            self._sync_controls()
        else:
            self._stop_ui_poll()
            self.root.destroy()

    def _open_path(self, path: Path):
        try:
            if sys.platform == 'win32':
                os.startfile(str(path))
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', str(path)])
            else:
                subprocess.Popen(['xdg-open', str(path)])
        except OSError as exc:
            messagebox.showerror('開けませんでした', str(exc), parent=self.root)

    def _open_file(self):
        if self.result:
            self._open_path(self.result.workbook)

    def _open_folder(self):
        path = Path(self.output.get()).expanduser()
        if path.is_dir():
            self._open_path(path)
        else:
            messagebox.showinfo('出力先', 'Excelの作成後にフォルダーを開けます。', parent=self.root)


def launch(initial_code: str = '6947'):
    root = tk.Tk()
    App(root, initial_code)
    root.mainloop()
