"""Real public author datasets and semantic/cache failure regressions."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
from io import BytesIO
import json
from pathlib import Path
import threading
import zipfile

import pytest

from zaimu10 import damodaran as risk

FIXTURES = Path(__file__).parent / 'fixtures' / 'damodaran'


def raw(name):
    return (FIXTURES / name).read_bytes()


@pytest.fixture(autouse=True)
def today(monkeypatch):
    monkeypatch.setattr(risk, '_today', lambda: date(2026, 11, 26))


def rewrite_xlsx(content, member, before, after):
    out = BytesIO()
    with zipfile.ZipFile(BytesIO(content)) as source, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == member:
                assert before in data
                data = data.replace(before, after)
            target.writestr(info, data)
    return out.getvalue()


def seed(monkeypatch, tmp_path):
    blobs = {
        risk.COUNTRY_URL: raw('country_japan.html'),
        risk.DISCOVERY_URL: raw('author_feed_selected.json'),
        'https://pages.stern.nyu.edu/~adamodar/pc/datasets/ctrypremJuly26.xlsx': raw('ctrypremJuly26.xlsx'),
        'https://pages.stern.nyu.edu/~adamodar/pc/blog/DiffInflationRiskfree26.xlsx': raw('DiffInflationRiskfree26.xlsx'),
    }
    monkeypatch.setattr(risk, '_request', lambda session, url, **kwargs: blobs[url])
    return risk.load_risk_inputs(tmp_path, refresh=True, log=lambda _: None)


def test_requested_country_page_total_erp_is_neither_crp_nor_cds_alternative():
    data = risk.parse_country_page(raw('country_japan.html'))
    assert data['country'] == 'Japan' and data['as_of'] == '2026-01-05'
    assert data['equity_risk_premium'] == '0.0514'
    assert data['country_premium'] == '0.0091'
    assert Decimal(data['default_spread']) == Decimal('0.006')
    assert data['risk_free_rate_present'] is False
    assert '4.69%' in data['raw_row']  # Explicitly NOT the selected rating-based ERP.


@pytest.mark.parametrize('before,after', [
    (b'5.14%', b'5.14'),
    (b'Equity Risk\n                Premium</td>', b'Riskfree Rate</td>'),
    (b'<td>Japan</td>', b'<td>Japanese Yen</td>'),
    (b'January 5, 2026', b'January 5, 2027'),
])
def test_country_identity_units_headers_dates_must_be_explicit(before, after):
    with pytest.raises(risk.RiskInputError):
        risk.parse_country_page(raw('country_japan.html').replace(before, after))


def test_duplicate_japan_not_merged_or_guessed():
    body = raw('country_japan.html')
    row = body[body.index(b'<tr><td>Japan'):body.index(b'</tr>', body.index(b'<tr><td>Japan')) + 5]
    with pytest.raises(risk.RiskInputError):
        risk.parse_country_page(body.replace(b'</table>', row + b'</table>'))


def test_real_latest_country_workbook_exact_japan_total_erp_and_components():
    data = risk.parse_country_workbook(raw('ctrypremJuly26.xlsx'))
    assert data['as_of'] == '2026-07-01'
    assert data['equity_risk_premium'] == '0.05072785839763368'
    assert data['country_premium'] == '0.008727858397633674'
    assert data['default_spread'] == '0.005614592162023261'
    assert data['cells']['Total Equity Risk Premium'] == 'E81'
    assert data['cells']['Country Risk Premium'] == 'F81'
    assert 'July 9, 2026' in data['update_notes']
    assert abs(Decimal(data['equity_risk_premium']) - Decimal(data['country_premium']) - Decimal(data['mature_market_erp'])) < Decimal('1e-12')


def test_country_cached_value_arithmetic_contradiction_fails():
    body = rewrite_xlsx(raw('ctrypremJuly26.xlsx'), 'xl/worksheets/sheet4.xml',
                        b'5.0727858397633677E-2', b'6.0727858397633677E-2')
    with pytest.raises(risk.RiskInputError, match='成熟市場'):
        risk.parse_country_workbook(body)


def test_real_jpy_riskfree_currency_method_is_independently_verified_not_crp():
    data = risk.parse_currency_riskfree_workbook(raw('DiffInflationRiskfree26.xlsx'))
    assert data['country'] == 'Japan' and data['currency'] == 'JPY'
    assert data['value'] == '0.03958435108288527'
    assert data['cell'] == 'D89' and data['country_cell'] == 'A89'
    assert data['method'] == 'inflation_based_currency_default_free_rate'
    assert data['formula'].startswith('=IF(C89=')
    inputs = data['formula_inputs']
    independently = ((1 + Decimal(inputs['usd_risk_free_rate'])) *
        (1 + Decimal(inputs['japan_expected_inflation'])) /
        (1 + Decimal(inputs['usd_expected_inflation'])) - 1)
    assert abs(Decimal(data['value']) - independently) < Decimal('1e-12')
    assert Decimal(data['value']) != Decimal('0.0091')


@pytest.mark.parametrize('before,after,pattern', [
    (b'3.9584351082885272E-2', b'0.0091', '保存値'),
    (b'$B$2', b'$B$1', '公開計算式'),
    (b'Japan', b'Japax', 'Japan'),
    (b'Expected Inflation in US $', b'Government Bond Yield', '一意'),
])
def test_riskfree_currency_formula_and_cached_values_are_not_assumed(before, after, pattern):
    member = 'xl/sharedStrings.xml' if before in (b'Japan', b'Expected Inflation in US $') else 'xl/worksheets/sheet1.xml'
    body = rewrite_xlsx(raw('DiffInflationRiskfree26.xlsx'), member, before, after)
    with pytest.raises(risk.RiskInputError, match=pattern):
        risk.parse_currency_riskfree_workbook(body)


def test_formula_strings_are_never_evaluated():
    body = rewrite_xlsx(raw('DiffInflationRiskfree26.xlsx'), 'xl/worksheets/sheet1.xml',
        b'<c r="D89" s="6"><f t="shared" si="1"/>',
        b'<c r="D89" s="6"><f>HYPERLINK("https://example.invalid/","0.01")</f>')
    with pytest.raises(risk.RiskInputError, match='公開計算式'):
        risk.parse_currency_riskfree_workbook(body)


def test_author_feed_uses_actual_dates_urls_and_does_not_hardcode_2026():
    body = json.loads(raw('author_feed_selected.json'))
    current = risk.discover_author_workbooks(body)
    assert len(current) == 2
    assert {e['kind'] for e in current} == {'risk_free_rate', 'equity_risk_premium'}
    assert all(e['as_of'] == '2026-07' and e['publication_date'] == '2026-07-15' for e in current)
    future = deepcopy(body['feed']['entry'][0])
    future['published']['$t'] = '2027-07-15T17:40:00-04:00'
    future['content']['$t'] = future['content']['$t'].replace('2026', '2027').replace('July26.xlsx', 'July27.xlsx').replace('Riskfree26.xlsx', 'Riskfree27.xlsx')
    body['feed']['entry'].append(future)
    assert len(risk.discover_author_workbooks(body)) == 2  # Future data cannot be used early.
    # Once actually published, the future author URL can be discovered without a code change.
    # Caller/date is injected, no permanent filename/year assumption.


def test_old_htm_external_and_unlabelled_links_cannot_replace_country_source():
    body = json.loads(raw('author_feed_selected.json'))
    body['feed']['entry'][0]['content']['$t'] += '<a href="https://evil.invalid/ctrypremJuly26.xlsx">Equity Risk Premiums, by country - July 2026</a><a href="https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/ctryprem.htm">Equity Risk Premiums, by country - July 2026</a>'
    assert len(risk.discover_author_workbooks(body)) == 2


def test_live_contract_selects_newer_erp_retains_requested_page_and_correct_rf(monkeypatch, tmp_path):
    result = seed(monkeypatch, tmp_path)
    assert result['risk_free_rate']['value'] == '0.03958435108288527'
    assert result['risk_free_rate']['semantic'] == 'jpy_default_free_rate'
    assert result['risk_free_rate']['as_of'] == '2026-07'
    assert result['risk_free_rate']['date_precision'] == 'month'
    assert result['equity_risk_premium']['value'] == '0.05072785839763368'
    assert result['equity_risk_premium']['semantic'] == 'total_equity_risk_premium'
    assert result['equity_risk_premium']['as_of'] == '2026-07-01'
    assert result['country_premium']['value'] == '0.008727858397633674'
    assert result['errors'] == [] and not result['stale']
    assert len(result['sources']) == 4
    assert {p['equity_risk_premium']:p['selected'] for p in result['comparison_sources']} == {
        '0.0514': False, '0.05072785839763368': True}
    assert all('sha256' in s and 'raw_path' in s for s in result['sources'])


def test_offline_reads_and_reparses_verified_raw_without_network(monkeypatch, tmp_path):
    saved = seed(monkeypatch, tmp_path)
    def no_network(*a, **k):
        raise AssertionError('Offline must never request a document')
    monkeypatch.setattr(risk, '_request', no_network)
    result = risk.load_risk_inputs(tmp_path, offline=True, log=lambda _: None)
    assert result['equity_risk_premium'] == saved['equity_risk_premium']
    assert result['risk_free_rate'] == saved['risk_free_rate']


def test_source_refresh_failure_retains_verified_cache_and_explicit_stale_reason(monkeypatch, tmp_path):
    saved = seed(monkeypatch, tmp_path)
    def fail(*a, **k):
        raise risk.RiskInputError('server unavailable')
    monkeypatch.setattr(risk, '_request', fail)
    result = risk.load_risk_inputs(tmp_path, refresh=True, log=lambda _: None)
    assert result['stale']
    assert result['risk_free_rate']['value'] == saved['risk_free_rate']['value']
    assert result['equity_risk_premium']['value'] == saved['equity_risk_premium']['value']
    assert len(result['warnings']) >= 4 and all(s['stale'] for s in result['sources'])


def test_unavailable_inputs_do_not_reuse_reference_constants_or_crp(monkeypatch, tmp_path):
    monkeypatch.setattr(risk, '_request', lambda *a, **k: (_ for _ in ()).throw(risk.RiskInputError('unavailable')))
    result = risk.load_risk_inputs(tmp_path, log=lambda _: None)
    assert not result['risk_free_rate']['available'] and result['risk_free_rate']['value'] is None
    assert not result['equity_risk_premium']['available'] and result['equity_risk_premium']['value'] is None
    assert result['errors'] and not (tmp_path/'market/risk_inputs/risk_inputs.json').exists()


def test_missing_currency_workbook_keeps_japan_erp_but_rf_unavailable(monkeypatch, tmp_path):
    seed(monkeypatch, tmp_path)
    base = tmp_path/'market/risk_inputs'
    (base/'currency_riskfree_diffinflationriskfree26_xlsx.json').unlink()
    result = risk.load_risk_inputs(tmp_path, offline=True, log=lambda _: None)
    assert result['equity_risk_premium']['available']
    assert not result['risk_free_rate']['available'] and result['risk_free_rate']['value'] is None
    assert result['errors']


def test_corrupt_raw_cache_is_preserved_and_not_silently_refetched(monkeypatch, tmp_path):
    result = seed(monkeypatch, tmp_path)
    source = result['risk_free_rate']['source']
    p = tmp_path/'market/risk_inputs'/source['raw_path']
    p.write_bytes(b'corrupt original')
    monkeypatch.setattr(risk, '_request', lambda *a, **k: (_ for _ in ()).throw(AssertionError('must preserve evidence')))
    result = risk.load_risk_inputs(tmp_path, offline=True, log=lambda _: None)
    assert not result['risk_free_rate']['available']
    assert p.read_bytes() == b'corrupt original'
    assert '保存データ' in result['risk_free_rate']['reason']


def test_cancel_is_not_converted_to_missing_risk_inputs(monkeypatch, tmp_path):
    event = threading.Event(); event.set()
    with pytest.raises(InterruptedError):
        risk.load_risk_inputs(tmp_path, cancel=event, log=lambda _: None)


def test_redirect_and_http_failure_are_explicit_not_followed(monkeypatch):
    class Response:
        status_code = 302
        content = b''
        headers = {'Location':'https://example.invalid/'}
    class Session:
        def get(self, url, **kwargs):
            assert kwargs['allow_redirects'] is False
            return Response()
    monkeypatch.setattr(risk.edinet, '_pause', lambda *a, **k: None)
    with pytest.raises(risk.RiskInputError, match='302'):
        risk._request(Session(), risk.COUNTRY_URL)


def test_long_retry_after_is_not_ignored_or_waited_unbounded(monkeypatch):
    class Response:
        status_code = 429
        content = b''
        headers = {'Retry-After':'180'}
    class Session:
        def get(self, url, **kwargs): return Response()
    monkeypatch.setattr(risk.edinet, '_pause', lambda *a, **k: None)
    with pytest.raises(risk.RiskInputError, match='長時間'):
        risk._request(Session(), risk.COUNTRY_URL)


def test_later_author_dataset_year_is_discovered_without_source_edits(monkeypatch):
    body = json.loads(raw('author_feed_selected.json'))
    entry = deepcopy(body['feed']['entry'][0])
    entry['published']['$t'] = '2027-07-15T17:40:00-04:00'
    entry['content']['$t'] = entry['content']['$t'].replace('2026', '2027').replace('July26.xlsx', 'July27.xlsx').replace('Riskfree26.xlsx', 'Riskfree27.xlsx')
    body['feed']['entry'].append(entry)
    monkeypatch.setattr(risk, '_today', lambda: date(2027, 11, 26))
    candidates = risk.discover_author_workbooks(body)
    assert candidates[0]['as_of'] == candidates[1]['as_of'] == '2027-07'
    assert {c['url'].rsplit('/', 1)[-1] for c in candidates[:2]} == {'ctrypremJuly27.xlsx', 'DiffInflationRiskfree27.xlsx'}


def test_newer_source_failure_keeps_dated_previous_snapshot_and_never_calls_it_latest(monkeypatch, tmp_path):
    saved = seed(monkeypatch, tmp_path)
    feed = json.loads(raw('author_feed_selected.json'))
    future = deepcopy(feed['feed']['entry'][0])
    future['published']['$t'] = '2027-07-15T17:40:00-04:00'
    future['content']['$t'] = future['content']['$t'].replace('2026', '2027').replace('July26.xlsx', 'July27.xlsx').replace('Riskfree26.xlsx', 'Riskfree27.xlsx')
    feed['feed']['entry'].append(future)
    monkeypatch.setattr(risk, '_today', lambda: date(2027, 11, 26))
    blobs = {
        risk.COUNTRY_URL: raw('country_japan.html'), risk.DISCOVERY_URL: json.dumps(feed).encode(),
        'https://pages.stern.nyu.edu/~adamodar/pc/datasets/ctrypremJuly26.xlsx': raw('ctrypremJuly26.xlsx'),
        'https://pages.stern.nyu.edu/~adamodar/pc/blog/DiffInflationRiskfree26.xlsx': raw('DiffInflationRiskfree26.xlsx'),
    }
    def fetch(session, url, **kwargs):
        if url not in blobs: raise risk.RiskInputError('Newer published file is temporarily unavailable')
        return blobs[url]
    monkeypatch.setattr(risk, '_request', fetch)
    result = risk.load_risk_inputs(tmp_path, refresh=True, log=lambda _: None)
    assert result['stale'] and not result['latest_publication_check_complete']
    assert result['risk_free_rate']['value'] == saved['risk_free_rate']['value']
    assert result['equity_risk_premium']['value'] == saved['equity_risk_premium']['value']
    assert result['risk_free_rate']['stale'] and result['equity_risk_premium']['stale']
    assert result['risk_free_rate']['as_of'] == '2026-07'
    assert len(result['source_errors']) == 2


def test_same_origin_source_url_must_match_saved_manifest_identity(monkeypatch, tmp_path):
    seed(monkeypatch, tmp_path)
    p = tmp_path/'market/risk_inputs/currency_riskfree_diffinflationriskfree26_xlsx.json'
    body = json.loads(p.read_text()); body.pop('payload_sha256')
    body['source']['source_url'] = risk.COUNTRY_URL
    body['payload_sha256'] = risk._hash(body)
    p.write_text(json.dumps(body))
    result = risk.load_risk_inputs(tmp_path, offline=True, log=lambda _: None)
    assert not result['risk_free_rate']['available']
    assert '保存データ' in result['risk_free_rate']['reason']


def test_missing_offline_cache_is_unavailable_and_creates_no_false_snapshot(tmp_path):
    result = risk.load_risk_inputs(tmp_path, offline=True, log=lambda _: None)
    assert result['errors'] and result['stale']
    assert not result['latest_publication_check_complete']
    assert not list(tmp_path.rglob('*.json'))
