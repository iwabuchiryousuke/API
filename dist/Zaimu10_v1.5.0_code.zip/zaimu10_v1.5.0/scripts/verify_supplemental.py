"""Read-only DCF/FR verification independent of application calculations.

The two original workbooks define the row mathematics. Inputs are resolved
again from the emitted financial cells and their original audit identities;
neither supplemental.py nor financial_refs.py is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import unicodedata

from openpyxl import load_workbook
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils.cell import range_boundaries,get_column_letter

ORIGINALS=[Path('/workspace/attachments/92ba0a29-b023-4009-8bc1-17c27d72d40f/6947図研.xlsx'),
           Path('/workspace/attachments/0b61b82f-e6db-472f-a60f-8953778882df/7826フルヤ金属.xlsx')]
DCF_LABELS={2:'売上高',3:'G R',4:'±',5:'売上原価',6:'/Sales',7:'売上総利益',8:'販管費',9:'/Sales',
            10:'営業利益',11:'G R',12:'/Sales',13:'実効税率',14:'ＮＯＰＡＴ',15:'非現金支出',16:'/Sales',
            17:'売上債権',18:'/Sales',19:'在庫',20:'/Sales',21:'支払債務',22:'/COGS',23:'運転資本',24:'±',25:'設備投資',26:'FCF',27:'GR'}
FR_LABELS={2:'ROIC',3:'投下資本回転率',4:'AROIC',5:'WACC(C)',6:'WACC(R)',7:'Spread',8:'投下資本',9:'EVA',
           10:'＜バリュードライバー＞',11:'税引前ROIC',12:'営業利益率',13:'売上高成長率',14:'EBITDAマージン',15:'原価率',16:'販管費率',
           17:'＜安全性指標＞',18:'手元流動性',19:'流動比率',20:'当座比率',21:'＜生産性指標＞',22:'有形固定資産回転率',
           23:'売上債権回転日数',24:'棚卸資産回転日数',25:'買入債務回転日数',26:'Cash Conversion Cycle'}


def compact(text):return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(text or'')))
def decimal(value):
    if value in (None,''):return None
    assert not isinstance(value,bool)
    return Decimal(str(value))
def close(actual,expected,where):
    a=decimal(actual)
    if expected is None:assert a is None,(where,'must remain blank',actual);return
    assert a is not None and abs(a-expected)<=max(Decimal('1e-9'),abs(expected)*Decimal('1e-12')),(where,a,expected)
def plus(*values):return None if any(v is None for v in values)else sum(values,Decimal(0))
def minus(a,b):return None if a is None or b is None else a-b
def times(a,b):return None if a is None or b is None else a*b
def divide(a,b):return None if a is None or b in (None,Decimal(0))else a/b


class Formula:
    """Small Excel arithmetic/SUM interpreter, without Python eval."""
    def __init__(self,expression,sheet,values):
        self.tokens=[t for t in Tokenizer(expression).items if t.type!='WHITE-SPACE']
        self.pos=0;self.sheet=sheet;self.values=values;self.refs=set();self.blanks=set()
    def peek(self):return self.tokens[self.pos]if self.pos<len(self.tokens)else None
    def take(self):t=self.peek();assert t is not None,'Incomplete formula';self.pos+=1;return t
    def atom(self):
        token=self.take()
        if token.type=='OPERATOR-PREFIX':
            assert token.value in {'+','-'};v=self.atom();return v if token.value=='+'else-v
        if token.type=='PAREN'and token.subtype=='OPEN':
            v=self.expr();end=self.take();assert end.type=='PAREN'and end.subtype=='CLOSE';return v
        if token.type=='FUNC'and token.subtype=='OPEN':
            assert token.value.upper()=='SUM(',('Forbidden function',token.value)
            result=Decimal(0)
            while not(self.peek().type=='FUNC'and self.peek().subtype=='CLOSE'):
                value=self.expr();result+=sum(value,Decimal(0))if isinstance(value,list)else value
                if self.peek().type=='SEP':assert self.take().subtype=='ARG'
                else:break
            end=self.take();assert end.type=='FUNC'and end.subtype=='CLOSE';return result
        assert token.type=='OPERAND',('Unsupported formula token',token)
        if token.subtype=='NUMBER':return Decimal(token.value)
        assert token.subtype=='RANGE',('Unsupported formula operand',token.value)
        target=token.value
        if '!'in target:
            sheet,area=target.rsplit('!',1);sheet=sheet.strip("'").replace("''", "'")
        else:sheet,area=self.sheet,target
        assert '['not in sheet and ']'not in sheet,'External workbook reference'
        bounds=range_boundaries(area.replace('$',''));numbers=[]
        for row in range(bounds[1],bounds[3]+1):
            for column in range(bounds[0],bounds[2]+1):
                address=f'{get_column_letter(column)}{row}';self.refs.add((sheet,address))
                value=decimal(self.values[sheet][address].value)
                if value is None:self.blanks.add((sheet,address));value=Decimal(0)
                numbers.append(value)
        return numbers if len(numbers)>1 else numbers[0]
    def expr(self,minimum=0):
        left=self.atom()
        priorities={'+':1,'-':1,'*':2,'/':2,'^':3}
        while self.peek()is not None:
            token=self.peek()
            if token.type=='OPERATOR-POSTFIX':
                assert self.take().value=='%';left/=100;continue
            if token.type!='OPERATOR-INFIX' or token.value not in priorities or priorities[token.value]<minimum:break
            op=self.take().value;right=self.expr(priorities[op]+(0 if op=='^'else 1))
            assert not isinstance(left,list)and not isinstance(right,list),'A range is only allowed inside SUM'
            left={'+':lambda:left+right,'-':lambda:left-right,'*':lambda:left*right,'/':lambda:left/right,'^':lambda:left**right}[op]()
        return left
    def run(self):
        value=self.expr();assert self.pos==len(self.tokens),'Unconsumed formula tokens';return value


def leaves(cell):
    if cell.get('components'):
        for child in cell['components']:yield from leaves(child)
    else:yield cell
def signature(cell):
    source=cell['source']
    return tuple(source.get(k,'')for k in ('doc_id','filename','concept','context_id','raw_value'))
def local(cell):return cell['source'].get('semantic_concept')or cell['source'].get('concept','')
def typename(cell):return local(cell).rsplit('}',1)[-1].rsplit(':',1)[-1]
def standard(cell):return bool(re.match(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(?:jppfs|jpigp)/\d{4}-\d{2}-\d{2}/',cell['source'].get('concept','')))


def source_role(cell,role):
    """Independent explicit accounting scopes, derived from the originals."""
    if cell['source'].get('unit')!='JPY':return False
    name=typename(cell);caption=compact(cell['source'].get('original_label',''));known=standard(cell)
    if role=='noncash':
        if known and (name in {'DepreciationAndAmortizationOpeCF','DepreciationAndAmortizationOpeCFIFRS','AmortizationOfGoodwillOpeCF','AmortizationOfGoodwillOpeCFIFRS','ImpairmentLossOpeCF','ImpairmentLossesOpeCFIFRS'}or(name.startswith(('IncreaseDecreaseInProvision','IncreaseDecreaseInAllowance'))and 'OpeCF'in name and 'Retirement'not in name and 'Pension'not in name)):return True
        return (caption in {'減価償却費','減価償却費及び償却費','減価償却費及び無形資産償却費','減価償却費及び償却額','のれん償却額','のれんの償却額','減損損失','減損損失及び減損損失戻入(△は益)'}
                or ('引当金'in caption and any(w in caption for w in ('増減','繰入','戻入'))and '退職'not in caption and '支払'not in caption))
    if role=='capex':
        if not any(x in name for x in ('InvCF','html-table'))and not cell['source'].get('semantic_concept'):return False
        if cell['source'].get('semantic_concept'):
            assert cell['source']['concept'].endswith('}ConsolidatedStatementOfCashFlowsIFRSTextBlock')
            if not any('投資活動'in section for section in cell.get('source_section')or()):return False
        if any(w in name for w in ('InvestmentSecurities','Bonds','Loans'))or any(w in caption for w in ('投資有価証券','社債','貸付')):return False
        property_asset=('PropertyPlantAndEquipment'in name or 'IntangibleAssets'in name or '有形固定資産'in caption or '無形固定資産'in caption or '無形資産'in caption)
        dealing=(name.startswith(('Purchase','PaymentsForPurchase','ProceedsFromSale','ProceedsFromDisposal','Acquisition'))or any(w in caption for w in ('取得','売却','処分')))
        related_company=(any(w in name for w in ('Subsidiaries','Subsidiary','Affiliates','Associates'))or any(w in caption for w in ('子会社','関係会社')))
        equity=(any(w in name for w in ('Stocks','Shares','InvestmentsInSubsidiaries','AcquisitionOfSubsidiaries','SalesOfSubsidiaries','SaleOfSubsidiaries'))or '株式'in caption
                or caption in {'子会社の取得による支出','子会社の売却による収入','子会社の取得','子会社の売却'})
        shares=related_company and equity
        shares_dealing=(any(w in name for w in ('Purchase','Sale','Acquisition','Disposal'))or any(w in caption for w in ('取得','売却','処分')))
        return (property_asset and dealing)or(shares and shares_dealing)
    sets={
      'receivables_aggregate':{'NotesAndAccountsReceivableTrade','TradeReceivablesCAIFRS','TradeReceivablesIFRS'},
      'receivables_parts':{'NotesReceivableTrade','AccountsReceivableTrade','ElectronicallyRecordedMonetaryClaimsOperating'},
      'payables_aggregate':{'NotesAndAccountsPayableTrade','TradePayablesCLIFRS','TradePayablesIFRS'},
      'payables_parts':{'NotesPayableTrade','AccountsPayableTrade','ElectronicallyRecordedObligationsOperating'},
      'inventory_aggregate':{'Inventories','InventoriesIFRS','InventoriesCAIFRS'},
      'inventory_parts':{'MerchandiseAndFinishedGoods','Merchandise','FinishedGoods','WorkInProcess','RawMaterialsAndSupplies','RawMaterials','Supplies'},
      'cash':{'CashAndDeposits','CashAndCashEquivalents','CashAndCashEquivalentsIFRS'},
      'securities':{'Securities','ShortTermInvestmentSecurities','SecuritiesCAIFRS','MarketableSecuritiesCAIFRS'},
      'ppe':{'PropertyPlantAndEquipment','PropertyPlantAndEquipmentIFRS'},
      'construction':{'ConstructionInProgress','ConstructionInProgressIFRS'},
    }
    if known and name in sets.get(role,set()):return True
    if cell['source'].get('semantic_concept','').startswith('{urn:zaimu10:html-table:'):
        # The separate raw-source verifier checks the genuine TextBlock and
        # physical table proof. Here only exact captions establish a role.
        assert cell['source']['concept'].endswith('}ConsolidatedStatementOfFinancialPositionIFRSTextBlock')
        html_captions={'inventory_aggregate':{'棚卸資産'},'cash':{'現金及び現金同等物'},'securities':{'有価証券'},
                       'ppe':{'有形固定資産'},'construction':{'建設仮勘定'},
                       'receivables_aggregate':{'営業債権','売上債権','受取手形及び売掛金'},
                       'payables_aggregate':{'営業債務','仕入債務','支払債務','買掛金'}}
        if role=='securities':
            section=' '.join(cell.get('source_section')or())
            return caption=='有価証券'and '流動資産'in section and '非流動資産'not in section
        return caption in html_captions.get(role,set())
    return False


class Ledger:
    def __init__(self,payload,book,values):
        self.payload=payload;self.ds=payload['dataset'];self.raw=payload.get('raw_dataset')or self.ds
        self.book=book;self.values=values
        self.emitted={(c['sheet'],c['address']):c for c in self.ds['export_metadata']['cells']}
        self.periods=sorted(self.ds['periods'],key=lambda p:(p['end'],p['start']))
    def number(self,sheet,address):return decimal(self.values[sheet][address].value)
    def row(self,sheet,labels,column):
        labels={compact(label)for label in labels}
        candidates=[i for i in range(2,self.book[sheet].max_row+1)if compact(self.book[sheet].cell(i,1).value)in labels]
        assert len(candidates)<=1,(sheet,labels,candidates)
        if not candidates:return None,set()
        address=f'{get_column_letter(column)}{candidates[0]}'
        value=self.number(sheet,address)
        return (value,{(sheet,address)})if value is not None else(None,set())
    def optional_status(self,role,period):
        """Absence permits the original optional term; an explicit nil does not."""
        assert role in {'securities','construction'}
        found=[]
        for row in self.raw['rows']['BS_A']:
            cell=row['values'].get(period)
            if cell is None:continue
            for leaf in leaves(cell):
                if not source_role(leaf,role):continue
                if role=='securities'and typename(leaf)=='Securities':
                    section=' '.join(leaf.get('source_section')or row.get('section')or[])
                    if '流動資産'not in section or '非流動資産'in section:continue
                found.append(leaf)
        if not found:return 'absent'
        return 'disclosed_blank'if any(c['value']is None or c['nil']for c in found)else'available'
    def resolve(self,role,period,column):
        statement='CF'if role in {'noncash','capex'}else'BS_LE'if role=='payables'else'BS_A'
        sheet={'CF':'CF','BS_LE':'BS-L,E','BS_A':'BS-A'}[statement]
        categories=({role}if role in {'noncash','capex','cash','securities','ppe','construction'}else
                    {role+'_aggregate',role+'_parts'}if role in {'receivables','payables'}else{'inventory_aggregate','inventory_parts'})
        def qualifies(cell):return any(source_role(cell,r)for r in categories)
        raw=[];unknown_posted_aggregate=False
        for row in self.raw['rows'][statement]:
            cell=row['values'].get(period)
            if role=='securities'and cell is not None and typename(cell)=='Securities':
                section=' '.join(cell.get('source_section')or row.get('section')or[])
                if '流動資産'not in section or '非流動資産'in section:continue
            if cell is not None and any(qualifies(leaf)for leaf in leaves(cell)):
                if role in {'receivables','payables','inventory'}and any(source_role(leaf,role+'_aggregate')and(leaf['value']is None or leaf['nil'])for leaf in leaves(cell)):
                    unknown_posted_aggregate=True
                raw.extend(leaf for leaf in leaves(cell)if qualifies(leaf)and leaf['value']is not None and not leaf['nil'])
        if unknown_posted_aggregate:return None,set()
        if role in {'receivables','payables','inventory'}:
            aggregate=role+'_aggregate'
            if any(source_role(c,aggregate)for c in raw):raw=[c for c in raw if source_role(c,aggregate)]
            elif role=='inventory':
                if any(typename(c)=='MerchandiseAndFinishedGoods'for c in raw):raw=[c for c in raw if typename(c)not in {'Merchandise','FinishedGoods'}]
                if any(typename(c)=='RawMaterialsAndSupplies'for c in raw):raw=[c for c in raw if typename(c)not in {'RawMaterials','Supplies'}]
        wanted={signature(c)for c in raw}
        if not wanted:return None,set()
        candidates=[]
        for address in [f'{get_column_letter(column)}{i}'for i in range(2,self.book[sheet].max_row+1)]:
            item=self.emitted.get((sheet,address));cell=item.get('source')if item else None
            if not cell or self.number(sheet,address)is None:continue
            original=[c for c in leaves(cell)if c['value']is not None and not c['nil']]
            keys={signature(c)for c in original}
            if keys and keys<=wanted:candidates.append((address,keys,self.number(sheet,address)))
        selected=[];covered=set()
        for address,keys,value in sorted(candidates,key=lambda item:-len(item[1])):
            if keys&covered:continue
            selected.append((address,value));covered|=keys
        assert covered==wanted,('Eligible original source is not represented by an independently scoped visible cell',self.ds['code'],role,period,wanted-covered)
        return sum((v for _,v in selected),Decimal(0)),{(sheet,a)for a,_ in selected}


def original_contracts(paths):
    result=[]
    for path in paths:
        book=load_workbook(path,data_only=False)
        dcf=book['DCF 2024'];fr=book['FR']
        assert compact(dcf['A15'].value)=='非現金支出'and '4:'in dcf['B15'].value and '7)'in dcf['B15'].value
        assert dcf['B26'].value=='=B14+B15-B24+B25'and dcf['B24'].value is None
        assert dcf['C24'].value=='=C23-B23'and dcf['B14'].value=='=B10-B10*B13'
        assert dcf['B10'].value=='=B7-B8'
        labels={compact(fr.cell(r,1).value):r for r in range(2,fr.max_row+1)if fr.cell(r,1).value}
        inventory=fr.cell(labels['棚卸資産回転日数'],2).value
        assert '*365'in inventory and ('/PL!B2'in inventory or "/'PL 10-24'!B6"in inventory)
        def referenced_labels(formula):
            found=[]
            for token in Tokenizer(formula).items:
                if token.type!='OPERAND'or token.subtype!='RANGE':continue
                target,area=token.value.rsplit('!',1);target=target.strip("'")
                left,top,right,bottom=range_boundaries(area)
                assert left==right==2
                found.extend({'sheet':target,'row':row,'label':book[target].cell(row,1).value}for row in range(top,bottom+1))
            return found
        noncash_scope=referenced_labels(dcf['B15'].value);capex_scope=referenced_labels(dcf['B25'].value)
        assert [row['row']for row in noncash_scope]==[4,5,6,7]
        assert len(capex_scope)==6 and not any('投資有価証券'in row['label']for row in capex_scope)
        result.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'original_noncash_scope':noncash_scope,'original_signed_capex_scope':capex_scope,
            'historical_manual_tax_values':[{'address':dcf.cell(13,column).coordinate,'year':str(dcf.cell(1,column).value),'value':str(dcf.cell(13,column).value)}
                for column in range(2,dcf.max_column+1)if re.fullmatch(r'\d{4}',str(dcf.cell(1,column).value or''))and isinstance(dcf.cell(13,column).value,(int,float))],
            'dcf_rows':{str(r):{'label':dcf.cell(r,1).value,'first_formula':dcf.cell(r,2).value,'next_formula':dcf.cell(r,3).value}for r in range(2,28)},
            'fr_rows':{str(r):{'label':fr.cell(r,1).value,'first_formula':fr.cell(r,2).value}for r in range(2,fr.max_row+1)if fr.cell(r,1).value}})
        book.close()
    return result


def verify_one(audit):
    payload=json.loads(audit.read_text(encoding='utf-8'));path=audit.with_name(audit.name.removesuffix('.audit.json')+'.xlsx')
    book=load_workbook(path,data_only=False);values=load_workbook(path,data_only=True);ledger=Ledger(payload,book,values)
    assert all(s in book.sheetnames for s in ('DCF','FR','CAPM'))
    counts=Counter();details=[];previous={};metadata=ledger.ds['export_metadata']['supplemental']
    for sheet,maximum,labels in [('DCF',27,DCF_LABELS),('FR',26,FR_LABELS)]:
        ws=book[sheet];assert ws.max_row==maximum and ws.max_column==len(ledger.periods)+1
        assert ws.sheet_state=='visible'and not any(d.hidden for d in ws.row_dimensions.values())and not any(d.hidden for d in ws.column_dimensions.values())
        assert metadata[sheet]['historical_only']is True and metadata[sheet]['forecast_generated']is False
        for row,label in labels.items():assert compact(ws.cell(row,1).value)==compact(label),(sheet,row,ws.cell(row,1).value,label)
        for column in range(2,len(ledger.periods)+2):
            assert ws.cell(1,column).value==book['PL'].cell(1,column).value,(sheet,'fiscal header differs from financial statements')
        if sheet=='FR':
            assert all(ws.cell(row,column).value is None and values[sheet].cell(row,column).value is None
                       for row in (10,17,21)for column in range(2,len(ledger.periods)+2))
    for column,period in enumerate(ledger.periods,2):
        key=period['start']+'/'+period['end'];letter=get_column_letter(column);prior=get_column_letter(column-1)
        pl=lambda row:ledger.number('PL',f'{letter}{row}')
        direct=lambda row:(pl(row),{('PL',f'{letter}{row}')})if pl(row)is not None else(None,set())
        resolved={role:ledger.resolve(role,key,column)for role in ['noncash','capex','receivables','inventory','payables','cash','securities','ppe','construction']}
        d={2:pl(2),5:pl(4),8:pl(8),13:pl(22),15:resolved['noncash'][0],17:resolved['receivables'][0],19:resolved['inventory'][0],21:resolved['payables'][0],25:resolved['capex'][0]}
        d[3]=minus(divide(d[2],previous.get('revenue')),Decimal(1))if column>2 else None
        d[4]=minus(d[2],previous.get('revenue'))if column>2 else None
        d[6]=divide(d[5],d[2]);d[7]=minus(d[2],d[5]);d[9]=divide(d[8],d[2]);d[10]=minus(d[7],d[8])
        d[11]=minus(divide(d[10],previous.get('model_op')),Decimal(1))if column>2 else None
        d[12]=divide(d[10],d[2]);d[14]=minus(d[10],times(d[10],d[13]));d[16]=divide(d[15],d[2]);d[18]=divide(d[17],d[2]);d[20]=divide(d[19],d[2]);d[22]=divide(d[21],d[5])
        d[23]=minus(plus(d[17],d[19]),d[21]);d[24]=minus(d[23],previous.get('wc'))if column>2 else None
        d[26]=plus(d[14],d[15],d[25])if column==2 else minus(plus(d[14],d[15],d[25]),d[24])
        d[27]=minus(divide(d[26],previous.get('fcf')),Decimal(1))if column>2 else None
        drefs={2:direct(2)[1],5:direct(4)[1],8:direct(8)[1],13:direct(22)[1],15:resolved['noncash'][1],17:resolved['receivables'][1],19:resolved['inventory'][1],21:resolved['payables'][1],25:resolved['capex'][1]}
        local_refs={3:[(letter,2),(prior,2)],4:[(letter,2),(prior,2)],6:[(letter,5),(letter,2)],7:[(letter,2),(letter,5)],9:[(letter,8),(letter,2)],10:[(letter,7),(letter,8)],11:[(letter,10),(prior,10)],12:[(letter,10),(letter,2)],14:[(letter,10),(letter,13)],16:[(letter,15),(letter,2)],18:[(letter,17),(letter,2)],20:[(letter,19),(letter,2)],22:[(letter,21),(letter,5)],23:[(letter,17),(letter,19),(letter,21)],24:[(letter,23),(prior,23)],26:[(letter,14),(letter,15),(letter,24),(letter,25)],27:[(letter,26),(prior,26)]}
        drefs.update({row:{('DCF',f'{col}{r}')for col,r in refs}for row,refs in local_refs.items()})
        capital,capital_refs=ledger.row('BS-A',{'投下資本'},column)
        ca,ca_refs=ledger.row('BS-A',{'流動資産合計','流動資産計'},column)
        cl,cl_refs=ledger.row('BS-L,E',{'流動負債合計','Ⅰ流動負債計','流動負債計'},column)
        cash,cash_refs=resolved['cash'];securities,securities_refs=resolved['securities'];ppe,ppe_refs=resolved['ppe'];construction,construction_refs=resolved['construction']
        liquid=None if cash is None or ledger.optional_status('securities',key)=='disclosed_blank'else cash+(securities or Decimal(0));liquid_refs=cash_refs|securities_refs
        ppe_base=None if ppe is None or ledger.optional_status('construction',key)=='disclosed_blank'else ppe-(construction or Decimal(0))
        wacc_c=ledger.number('CAPM',f'{letter}10');wacc_r=ledger.number('CAPM',f'{letter}13')
        fr={2:divide(d[14],capital),3:divide(pl(2),capital),5:wacc_c,6:wacc_r,8:capital,
            11:divide(pl(9),capital),12:divide(pl(9),pl(2)),13:None if column==2 else pl(3),
            14:divide(plus(pl(9),d[15]),pl(2)),15:divide(pl(4),pl(2)),16:divide(pl(8),pl(2)),
            18:divide(liquid,divide(pl(2),Decimal(12))),19:divide(ca,cl),20:divide(plus(liquid,d[17]),cl),
            22:divide(pl(2),ppe_base),23:times(divide(d[17],pl(2)),Decimal(365)),24:times(divide(d[19],pl(2)),Decimal(365)),25:times(divide(d[21],pl(4)),Decimal(365))}
        fr[4]=times(fr[2],fr[3]);fr[7]=minus(fr[2],fr[5]);fr[9]=times(fr[7],fr[8]);fr[26]=minus(plus(fr[23],fr[24]),fr[25])
        frefs={2:{('DCF',f'{letter}14')}|capital_refs,3:direct(2)[1]|capital_refs,4:{('FR',f'{letter}2'),('FR',f'{letter}3')},
            5:{('CAPM',f'{letter}10')},6:{('CAPM',f'{letter}13')},7:{('FR',f'{letter}2'),('FR',f'{letter}5')},8:capital_refs,
            9:{('FR',f'{letter}7'),('FR',f'{letter}8')},11:direct(9)[1]|capital_refs,12:direct(9)[1]|direct(2)[1],
            13:direct(3)[1],14:direct(9)[1]|resolved['noncash'][1]|direct(2)[1],15:direct(4)[1]|direct(2)[1],16:direct(8)[1]|direct(2)[1],
            18:liquid_refs|direct(2)[1],19:ca_refs|cl_refs,20:liquid_refs|resolved['receivables'][1]|cl_refs,
            22:direct(2)[1]|ppe_refs|construction_refs,23:resolved['receivables'][1]|direct(2)[1],24:resolved['inventory'][1]|direct(2)[1],25:resolved['payables'][1]|direct(4)[1],
            26:{('FR',f'{letter}23'),('FR',f'{letter}24'),('FR',f'{letter}25')}}
        for sheet,expected,refs in [('DCF',d,drefs),('FR',fr,frefs)]:
            for row,value in expected.items():
                address=f'{letter}{row}';cell=book[sheet][address];where=f'{path.name} {sheet}!{address}'
                close(values[sheet][address].value,value,where)
                records=[item for item in metadata[sheet]['periods'][key].values()if item['address']==address]
                assert len(records)==1,(where,'missing audit record')
                record=records[0];close(record.get('display_value'),value,where+' audit')
                assert record.get('formula')==cell.value if cell.data_type=='f'else record.get('formula')is None,(where,'formula audit differs')
                if value is None:
                    assert cell.value is None and record['missing'],(where,'unknown input not kept blank')
                    counts['blank_metric_cells']+=1
                else:
                    assert cell.data_type=='f',(where,'expected a visible formula')
                    oracle=Formula(cell.value,sheet,values);computed=oracle.run();close(computed,value,where+' formula arithmetic')
                    assert oracle.refs==refs[row],(where,'wrong formula addresses',oracle.refs,refs[row])
                    allowed_blank={('DCF',f'{letter}24')}if sheet=='DCF'and row==26 and column==2 else set()
                    assert oracle.blanks<=allowed_blank,(where,'blank required operand silently became zero',oracle.blanks)
                    if allowed_blank:assert cell.comment and '初年度'in cell.comment.text and '0として'in cell.comment.text
                    counts['numeric_metric_cells']+=1;counts['formula_addresses_verified']+=len(oracle.refs)
        if d[10]is not None and pl(9)is not None and d[10]!=pl(9):
            assert book['DCF'][f'{letter}10'].comment and 'モデルとの差'in book['DCF'][f'{letter}10'].comment.text
            details.append({'period':key,'model_operating_profit':str(d[10]),'reported_operating_profit':str(pl(9))})
            counts['model_profit_differences_disclosed']+=1
        previous={'revenue':d[2],'model_op':d[10],'wc':d[23],'fcf':d[26]}
    for name in ['DCF','FR']:
        for row in book[name]:
            for cell in row:
                assert cell.data_type!='e'and values[name][cell.coordinate].data_type!='e'
                if cell.data_type=='f':
                    functions={t.value.upper()for t in Tokenizer(cell.value).items if t.type=='FUNC'and t.subtype=='OPEN'}
                    assert functions<={'SUM('}and '#REF!'not in cell.value and '['not in cell.value
    result={'code':ledger.ds['code'],'company':ledger.ds['company'],'periods':len(ledger.periods),**dict(counts),
            'profit_model_differences':details,'workbook':path.name,'status':'pass'}
    book.close();values.close();return result


def verify(samples,originals=ORIGINALS):
    templates=original_contracts(originals);results=[]
    for audit in sorted(Path(samples).glob('*.audit.json')):results.append(verify_one(audit))
    assert results,'No exported audits found'
    return {'method':'Independent original-workbook mathematics, original source identities, visible final values and Excel formula-token evaluation; no production calculation imports.',
            'original_contracts':templates,'results':results,'failed_cases':0}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=Path,required=True)
    parser.add_argument('--json',type=Path)
    parser.add_argument('--original',type=Path,action='append')
    args=parser.parse_args();report=verify(args.samples,args.original or ORIGINALS)
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.json:args.json.write_text(text+'\n',encoding='utf-8')
    print(json.dumps({'results':report['results'],'failed_cases':0},ensure_ascii=False,indent=2))
