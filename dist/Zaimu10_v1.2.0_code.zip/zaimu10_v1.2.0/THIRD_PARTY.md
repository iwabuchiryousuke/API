# データ・ライブラリの出典

## 財務データ

金融庁EDINETの公式公開情報を使用します。

- [EDINETトップページ](https://disclosure2.edinet-fsa.go.jp/)
- [公式の書類検索画面](https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx)
- [EDINETコードリスト](https://disclosure2dl.edinet-fsa.go.jp/searchdocument/codelist/Edinetcode.zip)
- 原文閲覧URL：`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?書類ID`

銘柄コードと提出者の対応には、公式EDINETコードリストのCSVを使用します。**財務数値はCSV変換データではなく、各有価証券報告書の原文inline XBRLから取得します。** 有料データ、バフェットコードAPI、EDINET APIキーは使用していません。

開示資料の作成者は各提出会社です。本プログラムが生成するExcel・監査JSONには元書類を追跡できる識別子とURLを記録します。財務資料やEDINETの画面素材に本プログラムのライセンスを適用するものではありません。

回帰テストには、図研、ドーン、トリケミカル研究所、ニトリホールディングス、フルヤ金属の公開原文や訂正報告書を使用しています。図研の代表例は有価証券報告書第49期（提出日2025年6月20日、書類ID **S100W07I**）です。

- [図研 S100W07I の原文閲覧](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100W07I)
- 各フィクスチャの書類ID・対象期間・保存形式・照合目的：[tests/fixtures/README.md](tests/fixtures/README.md)

同梱の原文フィクスチャは取得・解析・訂正分類・表示整理の回帰検証用です。公開閲覧のセッション状態・Cookie・トークンを含めず、原文の名前空間やQNameを保持しています。

## 決算発表日・発表予定

- [JPX上場会社情報サービス](https://www2.jpx.co.jp/tseHpFront/JJK010010Action.do?Show=Show)：個社の適時開示情報にある本決算短信のタイトル・発表日・PDFリンク。
- [JPX決算発表予定日](https://www.jpx.co.jp/listing/event-schedules/financial-announcement/index.html)：公表済みの予定一覧。本決算・四半期の種別と対象期を確認します。
- 各社公式IRカレンダー：会社が明示した発表予定。取り込んだイベントごとに実際のURL・タイトルを保存します。

有価証券報告書の提出日を決算発表日に流用しません。第三者の推測日を公式予定として取り込みません。日付のキャッシュと登録履歴にも出典・取得日時を残します。

## 書式テンプレート

`zaimu10/assets/financial_template.xlsx`は、ユーザー提供のフルヤ金属の見本Excelから書式とラベルを抽出して作成した表示用テンプレートです。列幅・行高・罫線・色・フォント等を参照します。元の金額・数式・コメント・外部リンク・定義名は含めていません。

財務数値の取得元はEDINET原文です。見本の金額や手作業集計を対象企業の値として転用しません。出力する計算式は、原文から取得した数値と明示した項目対応に基づいてプログラムが生成します。原資料や書式の権利を、下記のPythonライブラリのライセンスへ変更するものではありません。

## Pythonライブラリ

ライブラリ本体は初回セットアップで通常のPythonパッケージとしてインストールします。各ライブラリにはそれぞれのライセンスが適用されます。正確な版はインストールされた環境で`python -m pip freeze`により確認できます。

|ライブラリ|用途|公開元・ライセンス|
|---|---|---|
|requests|HTTPS通信|[プロジェクト](https://github.com/psf/requests)・Apache-2.0|
|lxml|HTML／XML／inline XBRLの解析|[プロジェクト](https://lxml.de/)・BSD系。詳細は配布物のLICENSESを参照|
|cryptography|公式閲覧画面の応答処理|[プロジェクト](https://cryptography.io/)・Apache-2.0／BSD-3-Clause|
|openpyxl|Excel生成|[プロジェクト](https://openpyxl.readthedocs.io/)・MIT|
|Beautiful Soup 4|公開検索結果のHTML解析|[プロジェクト](https://www.crummy.com/software/BeautifulSoup/)・MIT|
|pytest（テスト用）|回帰テスト|[プロジェクト](https://pytest.org/)・MIT|

Python標準ライブラリとTkinterも使用します。Python・Tcl/Tkのライセンスは、それぞれの公式配布物を参照してください。
