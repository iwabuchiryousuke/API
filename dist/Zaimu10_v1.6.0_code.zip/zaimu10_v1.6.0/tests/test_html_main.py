"""Actual early IFRS filing plus hostile changes to its explicit table proof."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path
import pytest

from zaimu10.models import Filing
from zaimu10.parser import ParseError,parse_filing
from zaimu10.presentation import prepare_dataset,pl_metrics,local_name

FILING=Filing('S1009X6V',code='4519',edinet_code='E00932',company='中外製薬',
              start=date(2016,1,1),end=date(2016,12,31),submitted='2017-03-23')


def pages():
    with gzip.open(Path(__file__).parent/'fixtures/chugai_2016_html_main.json.gz','rt',encoding='utf-8') as f:
        return json.load(f)


def test_actual_untagged_ifrs_retains_real_textblock_and_physical_provenance():
    d=parse_filing(FILING,pages())
    assert d.complete and not d.warnings
    assert {k:len(v) for k,v in d.rows.items()}=={'PL':19,'BS_A':14,'BS_LE':17,'CF':28}
    key='2016-01-01/2016-12-31'
    revenue=pl_metrics(d)['revenue'].values[key]
    assert revenue.value==Decimal('491780000000')
    assert revenue.source.concept.endswith('}ConsolidatedStatementOfIncomeIFRSTextBlock')
    assert revenue.source.semantic_concept.startswith('{urn:zaimu10:html-table:E00932:')
    assert revenue.source.table_path and revenue.source.raw_value=='491,780'
    assert all(not c.source.concept.endswith('}RevenueIFRS')
               for row in d.rows['PL'] for c in row.values.values())


def test_signed_source_is_preserved_and_projection_reconciles_costs_and_liabilities():
    d=parse_filing(FILING,pages());key='2016-01-01/2016-12-31'
    original=deepcopy(d)
    x=prepare_dataset(d)
    raw=pl_metrics(d);projected=pl_metrics(x)
    assert raw['cost_of_sales'].values[key].value==Decimal('-247944000000')
    assert projected['cost_of_sales'].values[key].value==Decimal('247944000000')
    assert projected['income_taxes'].values[key].value==Decimal('20076000000')
    c=projected['cost_of_sales'].values[key]
    assert c.components[0].value==Decimal('-247944000000') and c.operation=='negate'
    liability=next(r for r in x.rows['BS_LE'] if local_name(r)=='LiabilitiesIFRS')
    assert liability.values[key].value==Decimal('159788000000')
    grand=next(r for r in x.rows['BS_LE'] if local_name(r)=='LiabilitiesAndEquityIFRS')
    assert grand.values[key].value==Decimal('806285000000')
    assert d==original


@pytest.mark.parametrize('change',['unit','date','issuer','number'])
def test_missing_or_conflicting_html_proof_is_rejected(change):
    data=pages();filing=deepcopy(FILING)
    if change=='issuer':filing.edinet_code=''
    else:
        changed=[]
        for name,text in data:
            if name.startswith('0105010'):
                if change=='unit':text=text.replace('百万円','通貨不明')
                if change=='date':text=text.replace('2016年12月31日','2020年12月31日')
                if change=='number':text=text.replace('491,780','491,7xx')
            changed.append((name,text))
        data=changed
    with pytest.raises((ParseError,ValueError)):
        parse_filing(filing,data)


def ajinomoto_pages():
    with gzip.open(Path(__file__).parent/'fixtures/ajinomoto_2017_html_main.json.gz','rt',encoding='utf-8')as stream:
        return json.load(stream)


def ajinomoto():
    return parse_filing(Filing('S100AO7M',code='2802',edinet_code='E00436',company='味の素',
        start=date(2016,4,1),end=date(2017,3,31),submitted='2017-06-27'),ajinomoto_pages())


def test_actual_ajinomoto_opening_column_is_explicitly_excluded_not_made_into_an_annual_period():
    d=ajinomoto()
    assert d.complete and not d.warnings
    assert [p.key for p in d.periods]==['2015-04-01/2016-03-31','2016-04-01/2017-03-31']
    checks=[c for c in d.checks if c['check']=='html_opening_bs_excluded']
    assert len(checks)==2 and all(c['ok']and c['date']=='2015-04-01'for c in checks)
    assert all('移行日'in c['header']and c['column']==2 for c in checks)
    cash=next(r for r in d.rows['BS_A']if local_name(r)=='CashAndCashEquivalentsIFRS')
    assert cash.values[d.periods[-1].key].value==Decimal('186003000000')
    assert {json.loads(c.source.table_path)['column']for c in cash.values.values()}=={3,4}
    assert all(c.source.concept.endswith('}ConsolidatedStatementOfFinancialPositionIFRSTextBlock')
               for c in cash.values.values())


@pytest.mark.parametrize('old,new',[('移行日','期首以外'),('2015年４月１日','2014年４月１日')])
def test_opening_column_requires_both_exact_heading_and_real_annual_start(old,new):
    data=ajinomoto_pages();changed=[]
    for name,text in data:
        if name.startswith('0105010'):
            assert old in text;text=text.replace(old,new)
        changed.append((name,text))
    with pytest.raises(ParseError,match='日付列'):
        parse_filing(Filing('S100AO7M',code='2802',edinet_code='E00436'),changed)


def test_actual_split_sga_uses_only_three_disclosed_expenses_not_gp_minus_operating_profit():
    raw=ajinomoto();d=prepare_dataset(raw);key='2016-04-01/2017-03-31'
    m=pl_metrics(d)
    assert m['revenue'].values[key].value==Decimal('1091195000000')
    sga=m['sga'].values[key]
    assert sga.value==Decimal('292701000000')
    assert sga.value!=m['gross_profit'].values[key].value-m['operating_profit'].values[key].value
    assert [c.value for c in sga.components]==[Decimal('169448000000'),Decimal('27134000000'),Decimal('96119000000')]
    assert all(c.operation=='negate'and c.components[0].value<0 for c in sga.components)
    assert all(c.components[0].source.concept.endswith('}ConsolidatedStatementOfIncomeIFRSTextBlock')for c in sga.components)
    assert m['net_profit_parent'].values[key].value==Decimal('53065000000')
    assert m['income_taxes'].values[key].value==Decimal('21717000000')
    # The parser keeps the true signed source; presentation has its own copy.
    original=next(r for r in raw.rows['PL']if local_name(r)=='SellingExpensesIFRS')
    assert original.values[key].value==Decimal('-169448000000')


@pytest.mark.parametrize('missing',['nil','absent','ambiguous'])
def test_incomplete_or_ambiguous_explicit_split_sga_is_blank_never_a_balancing_difference(missing):
    d=ajinomoto();key=d.periods[-1].key
    expense=next(r for r in d.rows['PL']if local_name(r)=='ResearchAndDevelopmentExpensesIFRS')
    if missing=='nil':expense.values[key].value=None;expense.values[key].nil=True
    elif missing=='absent':expense.values.pop(key)
    else:
        duplicate=deepcopy(expense);duplicate.key+=':ambiguous'
        duplicate.values[key].source.semantic_concept=duplicate.values[key].source.semantic_concept.replace('E00436','E99999')
        duplicate.values[key].source.doc_id='S100OTHER'
        d.rows['PL'].append(duplicate)
    assert key not in pl_metrics(prepare_dataset(d))['sga'].values


def test_actual_untagged_ifrs_subtotals_and_cash_disposal_bridge_are_counted_once():
    from zaimu10.excel import Writer,_pl,_bs,_cf
    from zaimu10.presentation import template_rows
    d=prepare_dataset(ajinomoto());w=Writer(d,'million')
    _pl(w,d);_bs(w,d,'BS_A');_bs(w,d,'BS_LE');_cf(w,d)
    assert not d.warnings and not any(c.get('ok')is False for c in w.checks)
    first,last=d.periods
    # Continuing tax scope differs from total profit only in this old prior
    # period. Keep its public total instead of hiding an extra formula operand.
    assert w.book['PL']['B19'].value==80931 and w.book['PL']['B19'].data_type=='n'
    assert w.book['PL']['C22'].value==53065
    assert any(c['row']==19 and'非継続事業'in c.get('reason','')for c in w.checks)
    roles=w.layout_metadata['CF']['roles']
    assert abs(w.values['CF',f'B{roles["64"]}']-Decimal(-2820))<=2
    # Per-line million-yen rounding propagates through the visible subtotals.
    assert abs(w.values['CF',f'B{roles["68"]}']-Decimal(204487))<=10
    extra=next(r for r in template_rows(d)if '処分グループに係る資産に含まれる現金'in r.label)
    assert extra.display_group=='cash_bridge'and extra.values[first.key].value==Decimal('-19346000000')
    layout=w.layout_metadata['BS-A'];current=next(n for n in layout['nodes']if n['role']=='current_assets')
    assert len(current['children'])==2  # 小計 plus held-for-sale assets
    current_number=current['row']
    assert abs(w.values['BS-A',f'B{current_number}']-Decimal(629730))<=5
    w.book.close();w.template.close()


def test_actual_other_financial_liabilities_keep_scope_and_block_unproved_debt_completeness():
    from zaimu10.analysis import analyze_dataset
    d=ajinomoto();key=d.periods[-1].key
    other=[r for r in d.rows['BS_LE']if r.label=='その他の金融負債']
    assert [(local_name(r),r.values[key].value)for r in other]==[
        ('OtherFinancialLiabilitiesCLIFRS',Decimal('5049000000')),
        ('OtherFinancialLiabilitiesNCLIFRS',Decimal('18452000000'))]
    assert all(r.values[key].source.concept.endswith('}ConsolidatedStatementOfFinancialPositionIFRSTextBlock')for r in other)
    analysis=analyze_dataset(prepare_dataset(d))
    status=analysis.metadata['interest_bearing_debt'][key]
    assert status['complete']is False and'その他の金融負債'in status['reason']
    assert key not in analysis.metrics['interest_bearing_debt'].values or analysis.metrics['interest_bearing_debt'].values[key].value is None


def test_tagged_ifrs_complete_three_expenses_use_real_standard_rd_concept():
    from zaimu10.models import Cell,Dataset,Period,Row,Source
    period=Period(date(2025,4,1),date(2026,3,31));key=period.key
    d=Dataset('2802','味の素','consolidated',[period],accounting_standard='IFRS')
    namespace='http://disclosure.edinet-fsa.go.jp/taxonomy/jpigp/2025-11-01/jpigp_cor'
    data=[('GrossProfitIFRS','売上総利益',597148),('OperatingProfitLossIFRS','営業利益',199412),
        ('SellingExpensesIFRS','販売費',225349),
        ('ResearchAndDevelopmentExpenditureRecognizedAsExpenseDuringPeriodIFRS','研究開発費',32108),
        ('GeneralAndAdministrativeExpensesIFRS','一般管理費',166640)]
    for local,label,millions in data:
        source=Source('S100Y992','0105010.htm','https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100Y992',
            concept='{'+namespace+'}'+local,context_id='CurrentYearDuration',unit='JPY',decimals='-6',
            original_label=label,basis='consolidated',scale=6,raw_value=f'{millions:,}')
        d.rows['PL'].append(Row(local,label,'PL',values={key:Cell(Decimal(millions)*1000000,source)}))
    metrics=pl_metrics(d);sga=metrics['sga'].values[key]
    assert sga.value==Decimal('424097000000')
    assert sga.value!=metrics['gross_profit'].values[key].value-metrics['operating_profit'].values[key].value
    assert [c.source.concept.rsplit('}',1)[-1]for c in sga.components]==[
        'SellingExpensesIFRS','ResearchAndDevelopmentExpenditureRecognizedAsExpenseDuringPeriodIFRS','GeneralAndAdministrativeExpensesIFRS']
    research=next(r for r in d.rows['PL']if r.label=='研究開発費')
    research.values[key].value=None;research.values[key].nil=True
    assert key not in pl_metrics(d)['sga'].values
