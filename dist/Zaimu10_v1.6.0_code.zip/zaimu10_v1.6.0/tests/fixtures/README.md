# Original EDINET iXBRL fixtures

These gzip JSON files contain lists of `[original_filename, original_html]`
pairs returned by EDINET's public document viewer. They contain publicly filed
company reports, without viewer session state, cookies, or tokens. Preservation
of namespace declarations and QName spelling is intentional.

Source URL pattern:
`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{document_id}`

| Fixture | Document | Financial period | Regression purpose |
| --- | --- | --- | --- |
| `zuken_2025_ixbrl.json.gz` | S100W07I | 図研, 2025/03 | Consolidated and standalone chapters, negative facts, nil facts, CF beginning/end contexts |
| `dawn_2026_ixbrl.json.gz` | S100YXLE | ドーン, 2026/05 | Standalone reports with twelve-column colspan indentation |
| `torichemical_2017_ixbrl.json.gz` | S100A4D9 | トリケミカル研究所, 2017/01 | Early taxonomy and standalone financial statements |
| `nitori_2026_ixbrl.json.gz` | S100YIMF | ニトリホールディングス, 2026/03 | IFRS, separate note columns, repeated total, EPS in yen per share |
| `nitori_2025_transition_ixbrl.json.gz` | S100W5DK | ニトリホールディングス, 2025/03 | Three BS columns including explicitly dated IFRS transition opening balances |

Independent source oracles used in the tests:

- 図研2025: BS 61 monetary rows / 122 facts, PL 34 / 68, CF 35 / 70;
  260 facts including 12 `xsi:nil=true`. Assets JPY 63,274,260,000,
  sales JPY 40,736,294,000, operating income JPY 5,392,252,000,
  operating cash flow JPY 4,861,697,000, closing cash JPY 27,224,029,000.
- ドーン2026: 216 facts including 6 nil facts. Assets JPY 3,343,042,000,
  sales JPY 1,734,668,000, operating income JPY 655,128,000,
  operating cash flow JPY 653,462,000.
- ニトリ2026: original BS 84 facts, PL 36 facts (including two repeated
  ProfitLoss facts), and CF 92 facts. Assets JPY 1,571,284,000,000;
  revenue JPY 912,248,000,000; operating cash flow JPY 148,911,000,000.
  Basic and diluted EPS are both JPY 157.98 per share, with scale zero.

Source rows and fact counts were inspected independently from parser output.

## フルヤ金属（7826）・v1.1 の追加資料

公式EDINET公開閲覧から取得した原文のみを保存しています。ブラウザーや公開検索のセッション状態・トークンは含みません。

- `furuya_2026_ixbrl.json.gz`: S100Z403、2026年6月期、連結本表を含む7ファイル。単位は百万円。棚卸資産と固定資産間の非資金振替を含みます。
- `furuya_2017_ixbrl.json.gz`: S100BDPD、2017年6月期、個別本表を含む2ファイル。単位は百万円。
- `amendments/furuya_*.json.gz`: 訂正報告書の原文。S100Z7DK（2026年・役員報酬方針の取締役会日付）、S100WUAI（2025年・役員の生年月日／社外役員の記述）、S100S7Z3（2023年・関係会社）、S100SS04（2022年・役員保有株の表示単位）、S100LFL0（2020年・大株主注記）、S100JLQS（2019年・経営指標の株価収益率／表題誤記と新株予約権）、S100E8NM（2018年・役員氏名）。

各書類の原本URLは `https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?書類ID` です。
訂正分類テストでは、本表以外という宣言だけで判断せず、実際の全見出し、表の列見出し、明示された訂正前後の範囲を照合します。経営指標の訂正では、金額・年度・単位などの不変も確認し、金額変更や未知の表を追加した変異データは拒否します。

- `zuken_retirement_series.json` は図研の2017年3月期〜2026年3月期のCF退職給付項目だけを抜き出した検証資料です。年度別の完全なQName、提出日、書類ID、原項目名、金額・nilを保持しています。10個の年度版の行と19個の比較情報を含み、同一企業内の名前空間更新と、2024年比較値が一致する旧・新要素名の接続を確認します。元の全原文は各 `source.url` で参照できます。これは原表の一部分であり、CF配置・小計の検証には完全な原文fixtureを使用します。公開画面のセッション状態は含みません。

## 中外製薬（4519）・v1.4 の訂正範囲

`chugai_corrections/manifest.json` と9書類の原文HTMLは、公式EDINETの公開閲覧から取得した訂正報告書です。書類ID・対象期・提出日・元URL・各原文のSHA-256をmanifestに保存しています。公開閲覧のCookie・GXState・トークンは含みません。

- S100U3VS：2023年・販売先別の説明とセグメント注記。
- S100TB9F：2023年・役員報酬のTSR順位と譲渡制限解除率。
- S100QD4U / S100QD54 / S100QD58 / S100QD5C / S100QD5F：2021〜2017年・収益、債権、株主資本、リスクマネジメント等の注記の実際の数値変更。
- S100NSNY：2021年・定款の未添付を補う訂正。
- S100DP2Y：2017年・役員個人別報酬。

財務注記の変更を「非財務」や「数値不変」と扱わず、明示された訂正事項、実際の注記見出し、訂正前後の全表、列・セル結合、表外文章を照合し、変更セルと変更行名を監査記録へ保持します。本表のXBRL値に未タグ付けの注記値を推測転記しません。サービス側では本表の同名科目との衝突と、注記由来の分析入力への影響も確認します。未対応の注記、単位・年度の変更、未分類の段落・表、財務諸表本表の追加を含む変異データを拒否する回帰検証に使用します。


## 中外製薬・本文HTMLと負債注記

`chugai_2016_html_main.json.gz` はS1009X6Vの表紙リソースとIFRS本表です。数値タグのない本文を、明示された年度・単位・物理セル位置で検証し、元のTextBlock QNameと表示上の役割を区別する回帰検証に使用します。費用と負債が負数の原表を、計算根拠と元値を残したまま表示変換する検証も行います。

`chugai_2025_debt_notes.json.gz` と `.sources.json` はS100XTBJの有利子負債分析に必要な公開注記です。流動・非流動リース負債の帳簿残高と、借入・社債等の範囲を証明する記述を検証します。未割引の支払期日表を帳簿残高に転用しません。

## v1.5 CAPM・株式分割の基準日

- `capm_reference.json` は新しい図研・フルヤ金属の見本CAPMから、月次価格の数値とLINESTの元式・保存済みβ／切片だけを抽出した数学的回帰検証資料です。財務金額・予測値は含みません。見本の指数名・日付・古い入力値の誤りを本番の取得データへ転用しません。
- `furuya_2024_share_split.json.gz` は公式EDINET S100UF6B（2024年6月期）の表紙・株式等の状況の原文です。権利落ち日2024年6月27日と、法的な分割効力日2024年7月1日の違い、期末8,463,212株から提出日25,389,636株への1対3の分割を照合します。
- `torichem_2021_share_split.json.gz` は公式EDINET S100L6LP（2021年1月期）の表紙・株式等の状況の原文です。2021年2月1日の1対4の分割に加え、2月24日の公募による1,250,000株の別途発行を、発行済株式総数推移の明示的な日付・原因・増減株数で確認します。期末7,812,160株→分割後31,248,640株→提出日32,498,640株が完全一致することを検証します。

株式分割フィクスチャはセッション状態を除いた公式の原文です。基準株数・発行日・比率・追加発行・原本ハッシュが矛盾する変異データでは時価総額の入力を未確定にし、数値のつじつま合わせをしません。
- `dawn_2026_share_split.json.gz` は公式EDINET S100YXLE（2026年5月期）の表紙・株式等の状況の原文です。「普通株式1株につき普通株式2株」の法的効力日2026年6月1日、権利落ち日5月28日、期末3,300,000株→提出日6,600,000株を照合します。
- `capm_parent_sources.json.gz` は図研とニトリの公式EDINET原文から、親会社帰属利益・当期利益合計・非支配持分利益・株主資本の該当事実だけを抽出した資料です。書類ID・原本URL・完全なQName・文脈ID・単位・原表示を保持し、ROEの分子を合計利益と混同しないこと、およびIFRSの株主資本構成を検証します。見本Excelの金額の転記ではありません。

## v1.6 新見本のCAPM

`capm_reference_v160.json` は「6947_図研 見本.xlsx」のCAPMから月次終値・LINESTの式・保存済みβと切片だけを抽出した数学的検証資料です。元ファイルのSHA-256を保持し、財務金額・時価総額・金利の固定値は含みません。新見本の10校正期間に加え、従来の30期間も継続検証します。

同梱の `assets/capm_template.xlsx` は新見本の書式と固定ラベルだけです。元の価格・年度・β・金利・財務金額・数式・コメント・外部リンクを除去しています。WACCのL/M列は、ユーザーの明示指示に従い、見本のMEDIANを過去10期・過去5期のAVERAGEに変更します。Rfと総株式リスク・プレミアムは取得原典の通貨・定義・対象日を確認した入力を使い、国リスク・プレミアムをRfと取り違えない回帰検証を行います。
