"""Desktop search/selection and registry behavior without network or a display."""
from datetime import date
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import threading

import pytest

from zaimu10.gui import App, UNIT_OPTIONS, calendar_values, initial_window_size


class Var:
    def __init__(self,value=None): self.value=value
    def get(self): return self.value
    def set(self,value): self.value=value


class Tree:
    def __init__(self): self.items={}; self.selected=(); self.focused=False
    def get_children(self): return tuple(self.items)
    def delete(self,*items):
        for item in items:self.items.pop(item,None)
        self.selected=()
    def insert(self,_parent,_where,*,iid,values): self.items[iid]=values
    def selection(self): return self.selected
    def selection_set(self,item): self.selected=(item,)
    def focus_set(self): self.focused=True


@pytest.fixture
def app():
    a=App.__new__(App)
    a.root=Mock()
    a.busy=False; a.closing=False; a.loading_company=False; a.cancel_event=threading.Event(); a.task_kind=''
    a.selected_company=None; a.search_results={}; a.registered={}; a.pending_search_action='show'
    a.code=Var('図研');a.years=Var(10);a.basis=Var('自動（連結を優先）')
    a.unit=Var(next(iter(UNIT_OPTIONS)));a.output=Var('/tmp/test_results');a.until=Var('')
    a.offline=Var(True);a.partial=Var(False);a.cache_dir=Path('/tmp/cache')
    a.status=Var();a.selected_text=Var();a.registry_text=Var()
    a.search_tree=Tree();a.registry_tree=Tree();a.notebook=Mock();a.create_tab=object();a.code_entry=Mock()
    a._set_busy=Mock();a._append=Mock();a._worker=Mock();a._show_search_results=Mock()
    return a


def company(code='6947',name='株式会社図研',fiscal='3月31日'):
    return {'code':code,'company':name,'display_name':name.removeprefix('株式会社'),'fiscal_year_end':fiscal}


def test_window_size_fits_ordinary_laptop_and_large_screen():
    assert initial_window_size(1366,768)==(1040,668)
    assert initial_window_size(1920,1080)==(1040,820)
    assert initial_window_size(1024,768)==(944,668)


def test_calendar_only_displays_observed_dates_and_keeps_unknown_release():
    row=calendar_values({'code':'6947','company':'株式会社図研','fiscal_year_end':'3月31日'})
    assert row==('6947','図研','未取得','未取得')
    row=calendar_values({'code':'6947','company':'株式会社図研','latest_period_end':'2026-03-31','latest_submitted':'2026-06-19T14:03:00','announcement_date':None})
    assert row[2:] == ('2026-03-31','未取得')


def test_search_ambiguous_company_requires_explicit_choice(app):
    complete=Mock();app._complete_search_action=complete
    app._search_done([company(),company('2354','株式会社ＹＥ　ＤＩＧＩＴＡＬ')],'start')
    assert app.selected_company is None
    assert len(app.search_tree.items)==2
    assert not app.search_tree.selection()
    complete.assert_not_called()
    assert '複数' in app.status.get()
    app.search_tree.selection_set('0')
    app._use_search_result()
    assert app.code.get()=='6947' and app.selected_company['company']=='株式会社図研'
    complete.assert_called_once_with('start')


def test_unique_company_search_resolves_code_and_continues_requested_action(app):
    complete=Mock();app._complete_search_action=complete
    app._search_done([company()],'register')
    assert app.code.get()=='6947'
    assert app.selected_company['company']=='株式会社図研'
    complete.assert_called_once_with('register')


def test_no_results_never_uses_previous_selection(app):
    app.selected_company=company();complete=Mock();app._complete_search_action=complete
    app._search_done([],'start')
    assert app.selected_company is None
    assert app.search_tree.items=={}
    complete.assert_not_called()


def test_editing_query_clears_stale_company_and_pending_registration(app):
    app.selected_company=company();app.pending_search_action='register'
    app._query_changed()
    assert app.selected_company is None
    assert app.pending_search_action=='show'


def test_company_name_start_searches_instead_of_guessed_code(app):
    app._search=Mock()
    app._start()
    app._search.assert_called_once_with('start')
    app._worker.assert_not_called()


def test_automatic_unit_is_default_and_manual_override_is_explicit(app):
    opts=app._make_options('6947')
    assert opts.unit=='auto' and opts.offline and opts.years==10
    for label,code in UNIT_OPTIONS.items():
        app.unit.set(label)
        assert app._make_options('6947').unit==code
    app.until.set('2025-03-31')
    assert app._make_options('6947').until==date(2025,3,31)


def test_registering_name_first_resolves_official_company(app):
    app._search=Mock();app.registry=Mock()
    app._register_company()
    app._search.assert_called_once_with('register')
    app.registry.register.assert_not_called()


def test_registry_rows_follow_registry_calendar_order_and_double_click_loads(app):
    newer={**company('2303','株式会社ドーン','5月31日'),'latest_period_end':'2026-05-31'}
    older={**company(),'latest_period_end':'2026-03-31'}
    app.registry=Mock();app.registry.calendar_rows.return_value=[newer,older]
    app._refresh_registry()
    assert list(app.registry_tree.items)==['2303','6947']
    app.registry_tree.selection_set('6947')
    app._use_registered()
    assert app.code.get()=='6947'
    app.notebook.select.assert_called_once_with(app.create_tab)


def test_unregister_only_removes_explicit_selected_company(app):
    app.registry=Mock();app._refresh_registry=Mock()
    app.registry_tree.selection_set('6947')
    app._remove_registered()
    app.registry.remove.assert_called_once_with('6947')
    app._refresh_registry.assert_called_once()


def test_closing_window_never_launches_followup_acquisition_or_registration(app):
    app.closing=True;app.code.set('6947');app.selected_company=company();app.registry=Mock()
    app._start();app._register_company();app._search();app._update_calendar()
    app._worker.assert_not_called()
    app.registry.register.assert_not_called()


def test_calendar_update_uses_selected_code_not_input_query(app,monkeypatch):
    app.registry_tree.selection_set('2303')
    app._update_earnings=Mock()
    app._update_calendar()
    app._update_earnings.assert_called_once_with(codes=['2303'])


def test_invalid_options_fail_before_company_name_network_search(app,monkeypatch):
    from zaimu10 import gui
    app.until.set('not-a-date');app._search=Mock()
    error=Mock();monkeypatch.setattr(gui.messagebox,'showerror',error)
    app._start()
    error.assert_called_once()
    app._search.assert_not_called();app._worker.assert_not_called()


def test_cancelled_queued_search_result_never_starts_new_acquisition(app):
    app.cancel_event.set();app._search_done=Mock()
    app._handle_event('search_done',([company()],'start'))
    app._search_done.assert_not_called();app._worker.assert_not_called()
    assert app.pending_search_action=='show' and '中止' in app.status.get()


def test_calendar_dates_are_sunday_first_with_stable_six_week_grid():
    from zaimu10.gui import month_dates
    days=month_dates(2024,2)
    assert len(days)==42 and days[0].weekday()==6
    assert date(2024,2,29)in days
    assert all((after-before).days==1 for before,after in zip(days,days[1:]))


def test_calendar_separates_actual_dates_from_published_schedules():
    from zaimu10.gui import calendar_event_view
    events=[{'code':'6947','date':'2026-05-14','kind':'actual'},
        {'code':'2303','date':'2027-07-08','kind':'scheduled'},
        {'code':'6947','date':'not-a-date','kind':'actual'}]
    today=date(2026,11,19)
    assert calendar_event_view(events,scope='今後の予定',today=today,year=2026,month=11)==[events[1]]
    assert calendar_event_view(events,scope='過去の発表',today=today,year=2026,month=11)==[events[0]]
    assert calendar_event_view(events,scope='表示中の月',today=today,year=2026,month=5)==[events[0]]
    assert calendar_event_view(events,scope='すべて',today=today,year=2026,month=5,selected_date=date(2027,7,8))==[events[1]]


def test_known_actual_release_replaces_same_day_schedule_without_fabrication():
    from zaimu10.gui import combined_calendar_events
    actual={'code':'6947','date':'2026-05-14','kind':'actual','fiscal_period':'2026年3月期'}
    planned={**actual,'kind':'scheduled'}
    other={'code':'2303','date':'2027-07-08','kind':'scheduled','fiscal_period':'2027年5月期'}
    assert combined_calendar_events([actual],[planned,other,other])==[actual,other]


def test_source_links_use_web_urls_only(app,monkeypatch):
    from zaimu10 import gui
    open_url=Mock();monkeypatch.setattr(gui.webbrowser,'open',open_url)
    app._open_url('https://www.jpx.co.jp/example')
    app._open_url('file:///tmp/not-a-website')
    open_url.assert_called_once_with('https://www.jpx.co.jp/example')


def test_calendar_uses_verified_fiscal_month_label_if_exact_day_is_unknown():
    row=calendar_values({'code':'7826','company':'フルヤ金属','latest_period_end':None,'latest_period_label':'2026年6月期','announcement_date':'2026-08-07'})
    assert row==('7826','フルヤ金属','2026年6月期','2026-08-07')


def test_chart_display_failure_does_not_discard_completed_excel(app):
    app.financial_charts=Mock();app.financial_charts.set_dataset.side_effect=ValueError('chart failed')
    app.registry=Mock();app.registry.update_result.return_value=None
    result=SimpleNamespace(dataset=SimpleNamespace(warnings=[]),workbook=Path('/tmp/test.xlsx'),audit=Path('/tmp/test.audit.json'))
    app._handle_event('done',result)
    assert app.result is result and '作成完了' in app.status.get()
    app.registry.update_result.assert_called_once_with(result.dataset)
    assert any('グラフを表示できません' in str(call)for call in app._append.call_args_list)


def test_calendar_list_can_expand_for_many_events_and_return_to_month(app):
    app.calendar_list_expanded=False;app.month_canvas=Mock();app.calendar_tab=Mock();app.list_expand_button=Mock()
    app._toggle_calendar_list()
    assert app.calendar_list_expanded
    app.month_canvas.grid_remove.assert_called_once()
    app.list_expand_button.configure.assert_called_with(text='月表示に戻す')
    app._toggle_calendar_list()
    assert not app.calendar_list_expanded
    app.month_canvas.grid.assert_called_once()
    app.list_expand_button.configure.assert_called_with(text='一覧を広く表示')


def test_cancelled_earnings_refresh_shows_already_verified_partial_updates(app):
    app.task_kind='earnings';app._refresh_registry=Mock()
    app._handle_event('cancelled','発表日の更新を中止しました。')
    app._refresh_registry.assert_called_once()
    assert '中止' in app.status.get()
