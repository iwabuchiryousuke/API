"""Fiscal market capitalisation from dated public prices and issued shares.

Issued shares are the fiscal-end figure, never EPS weighted averages or the
number at submission. Treasury shares are not deducted: this is the ordinary
issued-share market-cap convention used for the supplied CAPM input.
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation
import hashlib
from pathlib import Path
import re
import unicodedata

from bs4 import BeautifulSoup, Comment
from lxml import html

from .models import Filing, Period
from .parser import (Page, _contexts, _elements, _expanded, _namespaces,
                     _number, _text, _units, concept_identity)


class ShareCountError(ValueError):
    pass


def _compact_header(value: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value))


def _shares_header_date(value: str, label: str) -> date:
    """Read the date belonging to this exact *shares*, never submission, column."""
    match = re.fullmatch(re.escape(label) + r'\(株\)\((.+)\)', _compact_header(value))
    if not match:
        raise ShareCountError('発行済株式表の列名・株単位・日付を厳密に確認できません。')
    parts = re.fullmatch(r'(\d{4}|平成(?:元|\d+)|令和(?:元|\d+)|昭和(?:元|\d+))年(\d{1,2})月(\d{1,2})日', match[1])
    if not parts:
        raise ShareCountError('発行済株式表の日付書式を確認できません。')
    year_text = parts[1]
    bounds = None
    if year_text.isascii() and year_text.isdigit():
        year = int(year_text)
    else:
        era = year_text[:2]
        era_year = 1 if year_text[2:] == '元' else int(year_text[2:])
        offset, first, last = {
            '昭和': (1925, date(1926, 12, 25), date(1989, 1, 7)),
            '平成': (1988, date(1989, 1, 8), date(2019, 4, 30)),
            '令和': (2018, date(2019, 5, 1), date.max),
        }[era]
        if era_year < 1:
            raise ShareCountError('発行済株式表の元号年が不正です。')
        year, bounds = offset + era_year, (first, last)
    try:
        found = date(year, int(parts[2]), int(parts[3]))
    except ValueError as exc:
        raise ShareCountError('発行済株式表の日付が不正です。') from exc
    if bounds and not bounds[0] <= found <= bounds[1]:
        raise ShareCountError('発行済株式表の元号と日付が一致しません。')
    return found


def _share_integer(raw: str) -> Decimal:
    text = _compact_header(raw)
    if not re.fullmatch(r'(?:[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)', text):
        raise ShareCountError('事業年度末発行済株式数が正の整数ではありません。')
    return Decimal(text.replace(',', ''))


def _legacy_fiscal_shares(parsed, contexts, filing, fiscal_end, markup_by_name):
    """Accept only the dated ordinary/total cells in the standard shares block.

    Legacy EDINET tags this whole table, without individual numeric facts. The
    context is the filing date; the fiscal-date column header supplies the
    authoritative balance date. Unsupported table layouts remain unavailable.
    """
    found = []
    target = 'jpcrp_cor:IssuedSharesTotalNumberOfSharesEtcTextBlock'
    for page in parsed:
        blocks = list(_elements(page.root, 'nonnumeric'))
        page_tables = list(_elements(page.root, 'table'))
        for block_index, block in enumerate(blocks, 1):
            if concept_identity(_expanded(block.get('name', ''), page.namespaces)) != target:
                continue
            context = contexts.get(block.get('contextref', ''))
            if (context is None or context.id != 'FilingDateInstant' or not context.instant
                    or context.dimensions or context.basis is not None or context.end < fiscal_end
                    or block.get('continuedat')):
                raise ShareCountError('発行済株式TextBlockの提出日コンテキスト・範囲を確認できません。')
            tables = list(_elements(block, 'table'))
            if len(tables) != 1:
                raise ShareCountError('発行済株式TextBlockの表が複数・未確認です。')
            table = tables[0]
            rows = []
            for physical_row, row in enumerate(_elements(table, 'tr'), 1):
                cells = [cell for cell in row if isinstance(cell.tag, str)
                         and cell.tag.rsplit('}', 1)[-1].rsplit(':', 1)[-1].lower() in {'td', 'th'}]
                if any(cell.get('rowspan', '1') != '1' or cell.get('colspan', '1') != '1' for cell in cells):
                    raise ShareCountError('結合セルの発行済株式表は推測せず取得対象外にします。')
                texts = [_text(cell) for cell in cells]
                if any(texts):
                    rows.append((physical_row, texts))
            if len(rows) != 3 or any(len(texts) != 5 for _, texts in rows):
                raise ShareCountError('発行済株式表の種類・期末・提出日・普通株式・計の構成を確認できません。')
            header_row, headers = rows[0]
            if _compact_header(headers[0]) != '種類':
                raise ShareCountError('発行済株式表の種類列を確認できません。')
            fiscal_columns = [i for i, t in enumerate(headers) if _compact_header(t).startswith('事業年度末現在発行数')]
            submission_columns = [i for i, t in enumerate(headers) if _compact_header(t).startswith('提出日現在発行数')]
            if len(fiscal_columns) != 1 or len(submission_columns) != 1 or fiscal_columns == submission_columns:
                raise ShareCountError('期末現在と提出日現在の発行済株式列を区別できません。')
            fiscal_col, submission_col = fiscal_columns[0], submission_columns[0]
            fiscal_date = _shares_header_date(headers[fiscal_col], '事業年度末現在発行数')
            submission_date = _shares_header_date(headers[submission_col], '提出日現在発行数')
            if fiscal_date != fiscal_end or submission_date != context.end:
                raise ShareCountError('発行済株式表の期末日・提出日が対象資料と一致しません。')
            if filing.submitted and filing.submitted[:10] != submission_date.isoformat():
                raise ShareCountError('発行済株式表の提出日が公式提出日時と一致しません。')
            ordinary_row, ordinary = rows[1]
            total_row, total = rows[2]
            if _compact_header(ordinary[0]) != '普通株式' or _compact_header(total[0]) != '計':
                raise ShareCountError('普通株式以外の種類または複数種類の株式があり、普通株価と対応付けできません。')
            value, total_value = _share_integer(ordinary[fiscal_col]), _share_integer(total[fiscal_col])
            if value != total_value:
                raise ShareCountError('期末普通株式数と全種類株式の計が一致しません。')
            evidence = {
                'kind': 'issued_shares_textblock', 'block_index': block_index,
                'table_index': 1, 'page_table_index': page_tables.index(table) + 1,
                'header_physical_row': header_row, 'fiscal_column': fiscal_col + 1,
                'submission_column': submission_col + 1,
                'fiscal_header': headers[fiscal_col], 'submission_header': headers[submission_col],
                'fiscal_header_date': fiscal_date.isoformat(), 'submission_header_date': submission_date.isoformat(),
                'ordinary_physical_row': ordinary_row, 'total_physical_row': total_row,
                'ordinary_label': ordinary[0], 'total_label': total[0],
                'ordinary_raw': ordinary[fiscal_col], 'total_raw': total[fiscal_col],
                'submission_ordinary_raw': ordinary[submission_col],
                'submission_total_raw': total[submission_col], 'unit': 'shares', 'scale': 0,
            }
            found.append({
                'value_shares': str(value), 'fiscal_end': fiscal_end.isoformat(),
                'doc_id': filing.doc_id, 'filename': page.filename,
                'url': f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}',
                'submitted': filing.submitted, 'context_id': context.id,
                'concept': _expanded(block.get('name', ''), page.namespaces),
                'raw_value': ordinary[fiscal_col], 'scale': '0', 'unit': 'shares',
                'dimensions': [], 'sha256': hashlib.sha256(markup_by_name[page.filename].encode('utf-8')).hexdigest(),
                'extraction_method': 'issued_shares_textblock', 'source_evidence': evidence,
                'definition': '事業年度末発行済普通株式数。自己株式は控除しない。提出日現在・期中平均株式数は使用しない。',
            })
    if len(found) > 1:
        raise ShareCountError('発行済株式TextBlockが重複し、採用する表を一意に確定できません。')
    return found


def extract_fiscal_shares(pages: list[tuple[str, str]], filing: Filing,
                         fiscal_end: date, code: str) -> dict:
    """Accept only the official, aggregate fiscal-end issued-share fact."""
    if filing.end != fiscal_end or filing.code != code:
        raise ShareCountError('対象期末・銘柄と株式資料の年度・銘柄が一致しません。')
    parsed = [Page(name, html.fromstring(markup.lstrip('\ufeff').encode('utf-8'),
                parser=html.HTMLParser(encoding='utf-8', no_network=True)), _namespaces(markup))
              for name, markup in pages]
    contexts = _contexts(parsed)
    units = _units(parsed)
    dei = {}
    for page in parsed:
        for node in _elements(page.root, 'nonnumeric'):
            name = concept_identity(_expanded(node.get('name', ''), page.namespaces))
            if name in {'jpdei_cor:CurrentFiscalYearEndDateDEI', 'jpdei_cor:SecurityCodeDEI'}:
                dei.setdefault(name, set()).add(_text(node))
    if dei.get('jpdei_cor:CurrentFiscalYearEndDateDEI') != {fiscal_end.isoformat()}:
        raise ShareCountError('DEIの当事業年度末を対象期末と照合できません。')
    if dei.get('jpdei_cor:SecurityCodeDEI') != {code + '0'}:
        raise ShareCountError('DEIの証券コードを対象銘柄と照合できません。')
    target = 'jpcrp_cor:NumberOfIssuedSharesAsOfFiscalYearEndIssuedSharesTotalNumberOfSharesEtc'
    aggregates, ordinary = [], []
    markup_by_name = dict(pages)
    for page in parsed:
        for node in _elements(page.root, 'nonfraction'):
            identity = concept_identity(_expanded(node.get('name', ''), page.namespaces))
            if identity != target:
                continue
            context = contexts.get(node.get('contextref', ''))
            if context is None or not context.instant or context.end < fiscal_end:
                raise ShareCountError('事業年度末発行済株式数の残高コンテキストを確認できません。')
            if filing.submitted:
                try:
                    submitted_date = date.fromisoformat(filing.submitted[:10])
                except ValueError as exc:
                    raise ShareCountError('株式資料の公式提出日時が不正です。') from exc
                if context.end not in {fiscal_end, submitted_date}:
                    raise ShareCountError('発行済株式数のコンテキスト日付が対象期末・公式提出日と一致しません。')
            if node.get('continuedat'):
                raise ShareCountError('分割された発行済株式数factは推測せず取得対象外にします。')
            if units.get(node.get('unitref', '')) != 'shares':
                raise ShareCountError('発行済株式数の原単位が株ではありません。')
            value, nil, raw = _number(node)
            if nil or value is None or value <= 0 or value != value.to_integral_value():
                raise ShareCountError('事業年度末発行済株式数が未確定・非整数です。')
            evidence = {'value_shares': str(value), 'fiscal_end': fiscal_end.isoformat(),
                'doc_id': filing.doc_id, 'filename': page.filename,
                'url': f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}',
                'submitted': filing.submitted, 'context_id': context.id,
                'concept': _expanded(node.get('name', ''), page.namespaces),
                'raw_value': raw, 'scale': node.get('scale', '0'),
                'unit': 'shares', 'dimensions': [list(d) for d in context.dimensions],
                'sha256': hashlib.sha256(markup_by_name[page.filename].encode('utf-8')).hexdigest(),
                'definition': '事業年度末発行済普通株式数。自己株式は控除しない。提出日現在・期中平均株式数は使用しない。'}
            if context.basis is not None:
                raise ShareCountError('発行済株式数に未確認の連結・個別区分があります。')
            if not context.dimensions:
                aggregates.append(evidence)
            elif (len(context.dimensions) == 1
                  and context.dimensions[0][0] == 'jpcrp_cor:ClassesOfSharesAxis'
                  and context.dimensions[0][1] == 'jpcrp_cor:OrdinaryShareMember'):
                ordinary.append(evidence)
            else:
                raise ShareCountError('発行済株式数に普通株式以外・未確認の株式次元があります。')
    if not aggregates:
        tables = _legacy_fiscal_shares(parsed, contexts, filing, fiscal_end, markup_by_name)
        if not tables:
            raise ShareCountError('事業年度末発行済株式数の数値fact・厳密な期末株式表がありません。')
        selected = tables[0]
        if ordinary and {item['value_shares'] for item in ordinary} != {selected['value_shares']}:
            raise ShareCountError('普通株式数factと期末株式表の数値が一致しません。')
        selected['corroborating_facts'] = ordinary
        return selected
    values = {item['value_shares'] for item in aggregates}
    if len(values) != 1:
        raise ShareCountError('事業年度末発行済株式数の重複開示値が一致しません。')
    if not ordinary:
        ordinary = _legacy_fiscal_shares(parsed, contexts, filing, fiscal_end, markup_by_name)
        if not ordinary:
            raise ShareCountError('総発行数が普通株式のみであると確認できません。')
    if {item['value_shares'] for item in ordinary} != values:
        raise ShareCountError('普通株式数と全種類株式数が異なり、株価と対応付けできません。')
    selected = aggregates[0]
    selected['corroborating_facts'] = ordinary + aggregates[1:]
    return selected


def _share_amendment_review(pages: list[tuple[str, str]]) -> dict:
    """Prove bounded corrections cannot replace the fiscal issued-share count.

    A general ``nonfinancial_only`` decision is insufficient: shareholder and
    share-option chapters can contain share counts. Only the classifier's
    exhaustively recognised table schemas/invariants receive the narrow
    exceptions below; remaining issued-share prose is deliberately unknown.
    """
    from .amendment import inspect_amendment

    decision = inspect_amendment(pages)
    review = {'status': 'unknown', 'policy': 'strict-fiscal-shares-amendment-v1',
              'reason': '', 'scope_proof': decision}
    soups = [(filename, BeautifulSoup(markup, 'html.parser')) for filename, markup in pages]
    for filename, soup in soups:
        for node in soup.find_all():
            name = (node.get('name') or '').rsplit(':', 1)[-1]
            if ('IssuedShares' in name or name == 'ChangesInNumberOfIssuedSharesStatedCapitalEtcTextBlock'):
                review.update(status='share_data_present', reason='訂正書類に発行済株式数の対象タグがあり、全数値を再検証します。')
                return review
    status = decision.get('status')
    if status == 'financial_notes_only':
        eligible = decision.get('proof_complete') is True
    elif status == 'unchanged_financial_values':
        eligible = bool(decision.get('invariant'))
    elif status == 'nonfinancial_only':
        schemas = {p.get('table_schema') for p in decision.get('business_table_evidence', [])}
        supported = {'生産実績', '許認可の状況', '関係会社の状況', '役員一覧',
                     '役員略歴の年月・経歴', '大株主・大量保有の株式数',
                     '主要な経営指標等の推移', '経営指標の金額不変照合', 'ストックオプション制度の内容'}
        narrative = {'役員の報酬等', '役員の状況', '設備投資等の概要'}
        eligible = bool(decision.get('attachment_only')
                        or (decision.get('proof_complete') and decision.get('remuneration_table_schemas'))
                        or (schemas and schemas <= supported)
                        or (set(decision.get('actual_headings', [])) & narrative))
    else:
        eligible = False
    if not eligible:
        review['reason'] = '訂正範囲が期末発行済普通株式数へ影響しないという限定的な証明がありません。'
        return review
    business = decision.get('business_table_evidence', [])
    summary_invariant = any(p.get('table_schema') == '経営指標の金額不変照合'
                            and p.get('invariant', {}).get('summary_amounts_unchanged') is True
                            for p in business)
    shareholder_proof = any(p.get('table_schema') == '大株主・大量保有の株式数' for p in business)
    option_proof = any(p.get('table_schema') == 'ストックオプション制度の内容' for p in business)
    exclusions = []
    for filename, soup in soups:
        if filename.startswith('0000000_'):
            continue
        for hidden in soup.find_all(['head', 'script', 'style']):
            hidden.decompose()
        for comment in soup.find_all(string=lambda item: isinstance(item, Comment)):
            comment.extract()
        if summary_invariant:
            for table in list(soup.find_all('table')):
                rows = [[_compact_header(c.get_text(' ', strip=True))
                         for c in row.find_all(['td', 'th'], recursive=False)]
                        for row in table.find_all('tr') if row.find_parent('table') is table]
                rows = [row for row in rows if any(row)]
                if len(rows) >= 2 and rows[0][0] == '回次' and rows[1][0] == '決算年月':
                    exclusions.append({'filename': filename, 'kind': 'unchanged_summary_share_rows',
                                       'proof': 'paired_summary_amounts_unchanged'})
                    table.decompose()
        if option_proof:
            for row in soup.find_all('tr'):
                cells = row.find_all(['td', 'th'], recursive=False)
                if (len(cells) == 2 and _compact_header(cells[0].get_text(' ', strip=True)) ==
                        '新株予約権の目的となる株式の種類、内容及び数(株)※'):
                    # A right to acquire ordinary shares is not an already
                    # issued balance. Retain all other wording/counts for scan.
                    for text in list(cells[1].find_all(string=True)):
                        if '普通株式' in text:
                            text.replace_with(str(text).replace('普通株式', '取得対象株式'))
                    exclusions.append({'filename': filename, 'kind': 'option_underlying_class_only'})
        visible = _compact_header(soup.get_text(' ', strip=True))
        if shareholder_proof:
            header = '発行済株式(自己株式を除く。)の総数に対する所有株式数の割合(%)'
            if header in visible:
                exclusions.append({'filename': filename, 'kind': 'shareholder_percentage_header_only', 'header': header})
                visible = visible.replace(header, '')
        sensitive = re.search(r'事業年度末現在発行数|発行済株式|発行数|株式総数|株数|普通株式|種類株式|優先株式|株式分割|株式併合', visible)
        if sensitive:
            review.update(reason='訂正本文に未照合の発行済株式数・株式種類・分割等の記述があります。',
                          unclassified_share_text=visible[max(0, sensitive.start()-60):sensitive.end()+100],
                          exclusions=exclusions)
            return review
    review.update(status='shares_unaffected', exclusions=exclusions,
                  reason='訂正の全範囲が対応済みの限定された内容と照合され、期末発行済株式数の変更タグ・未分類の株式数記述がありません。')
    return review


def load_fiscal_share_counts(code: str, periods: list[Period], filings: list[Filing], *,
                            cache_dir: Path, offline=False, refresh=False,
                            cancel=None, log=print) -> dict:
    from .edinet import fetch_filing
    from .service import check_cancel
    result = {'shares': {}, 'missing': {}}
    for period in sorted(periods, key=lambda p: p.end):
        check_cancel(cancel)
        candidates = [f for f in filings if f.end == period.end and f.code == code]
        annuals = sorted((f for f in candidates if not f.amended),
                         key=lambda f: (f.submitted, f.doc_id), reverse=True)
        if not annuals:
            result['missing'][period.key] = ['同じ期末の通常年次報告書がなく、訂正だけから旧株式数を推測しません。']
            continue
        filing = annuals[0]
        try:
            pages = fetch_filing(filing.doc_id, cache_dir=cache_dir, offline=offline,
                                 refresh=refresh, include_shares=True, cancel=cancel, log=log)
            selected = extract_fiscal_shares(pages, filing, period.end, code)
            amendments = sorted((f for f in candidates if f.amended
                                  and (not f.submitted or f.submitted >= filing.submitted)),
                                 key=lambda f: (f.submitted, f.doc_id))
            reviews = []
            for amendment in amendments:
                check_cancel(cancel)
                if not filing.submitted or not amendment.submitted:
                    raise ShareCountError(f'{amendment.doc_id}: 訂正と通常年次の前後関係を公式提出日時で照合できません。')
                amended_pages = fetch_filing(amendment.doc_id, cache_dir=cache_dir, offline=offline,
                                            refresh=refresh, include_shares=True, cancel=cancel, log=log)
                review = _share_amendment_review(amended_pages)
                review.update(doc_id=amendment.doc_id, submitted=amendment.submitted)
                reviews.append(review)
                if review['status'] == 'share_data_present':
                    selected = extract_fiscal_shares(amended_pages, amendment, period.end, code)
                    review['status'] = 'validated_updated_share_count'
                    review['value_shares'] = selected['value_shares']
                elif review['status'] != 'shares_unaffected':
                    raise ShareCountError(f'{amendment.doc_id}: {review["reason"]} 旧年次の株式数へ戻しません。')
            selected['baseline_annual_doc_id'] = filing.doc_id
            selected['amendment_review'] = reviews
            result['shares'][period.key] = selected
        except InterruptedError:
            raise
        except Exception as exc:
            result['missing'][period.key] = [f'{filing.doc_id}: {exc}']
    return result


def assemble_market_caps(periods: list[Period], share_counts: dict, fiscal_prices: dict) -> dict:
    """Multiply only dated historical-price/share-basis matched inputs."""
    result = {}
    for period in periods:
        shares = share_counts.get('shares', {}).get(period.key)
        price = fiscal_prices.get('prices', {}).get(period.end.isoformat())
        if not shares or not price or price.get('available') is False:
            continue
        if ((price.get('price_provider') == 'YahooJapan'
             or price.get('share_basis_state') == 'nominal_quote_at_trading_date')
                and price.get('basis_alignment_status') not in {'aligned', 'not_needed'}):
            # Japan quotes remain on their trading-date share basis around an
            # ex-rights/legal-effective-date boundary. Require the verified
            # alignment before multiplying fiscal-end legal issued shares.
            continue
        try:
            n = Decimal(shares['value_shares'])
            p = Decimal(price['historical_close_jpy'])
            traded = date.fromisoformat(price['trading_date'])
            if (shares['fiscal_end'] != period.end.isoformat()
                    or not n.is_finite() or not p.is_finite() or n <= 0 or p <= 0
                    or traded > period.end or (period.end - traded).days > 10):
                raise ShareCountError('株式数・株価の対象日または値が不正です。')
            result[period.key] = {'value_jpy': str(n * p),
                'date': period.end.isoformat(), 'trading_date': traded.isoformat(),
                'issued_shares': shares, 'price': price,
                'definition': '事業年度末の発行済株式数（自己株式込み）×同日以前の最終取引日の当時株価。株式分割後換算株価を当時の株式基準へ戻して計算。'}
        except (InvalidOperation, ValueError, TypeError, KeyError) as exc:
            raise ShareCountError(f'{period.key}: 時価総額の構成値が不正です。{exc}') from exc
    return result
