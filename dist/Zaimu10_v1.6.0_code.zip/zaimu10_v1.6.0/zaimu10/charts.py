"""Small, dependency-free financial charts for the native desktop application.

Chart values come from analysis.chart_data. Missing values stay missing; line
segments never span a missing period. Canvas coordinates are display-only.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal
import math
import tkinter as tk
from tkinter import ttk
from typing import Callable

from .model_series import MODEL_VIEWS


COLORS = {
    'revenue':'#6797dd', 'gross_profit':'#9775cf', 'operating_profit':'#059a81',
    'net_profit':'#e79a35', 'assets':'#6797dd', 'liabilities':'#d87b76',
    'equity':'#079c82', 'current_assets':'#9cbde9', 'noncurrent_assets':'#8a79c5',
    'current_liabilities':'#d9a6a1', 'noncurrent_liabilities':'#b06373',
    'operating':'#148eab', 'investing':'#e39c48', 'financing':'#a080bd',
    'cash':'#079c82',
}
VIEW_KEYS = {
    'PL':('revenue','gross_profit','operating_profit','net_profit'),
    'BS':('assets','liabilities','equity','current_assets','noncurrent_assets','current_liabilities','noncurrent_liabilities'),
    'CF':('operating','investing','financing','cash'),
}
DEFAULT_KEYS = {'PL':('revenue','operating_profit','net_profit'),
                'BS':('assets','liabilities','equity'),
                'CF':('operating','investing','financing')}
SHORT_LABELS = {'revenue':'売上高','gross_profit':'粗利益','operating_profit':'営業利益',
    'net_profit':'当期利益','assets':'総資産','liabilities':'負債','equity':'純資産',
    'current_assets':'流動資産','noncurrent_assets':'固定資産',
    'current_liabilities':'流動負債','noncurrent_liabilities':'固定負債',
    'operating':'営業CF','investing':'投資CF','financing':'財務CF','cash':'期末現金'}
UNIT_LABELS = {'自動':'auto','百万円':'million','千円':'thousand','円':'yen'}
VIEW_LABELS = {'PL':'PL 売上・利益','BS':'BS 資産・負債','CF':'CF 資金の流れ'}
_MODEL_PALETTE = ('#148eab','#b7791f','#0a8b70','#a467b8','#cf6679','#6478be','#728d38','#bb7346')
for _view, (_sheet, _definitions) in MODEL_VIEWS.items():
    VIEW_KEYS[_view] = tuple(key for key, _, _ in _definitions)
    DEFAULT_KEYS[_view] = tuple(key for key, _, _ in _definitions
                               if _view!='FCF' or key not in {'trade_receivables','inventory','trade_payables'})
    VIEW_LABELS[_view] = _view
    for _index, (_key, _label, _kind) in enumerate(_definitions):
        SHORT_LABELS.setdefault(_key, _label)
        COLORS.setdefault(_key, _MODEL_PALETTE[_index % len(_MODEL_PALETTE)])


def faded_color(color: str, amount: float = .76) -> str:
    """Blend an unselected series with the white canvas, without changing data."""
    channels=[int(color[i:i+2],16) for i in (1,3,5)]
    return '#'+''.join(f'{round(v+(255-v)*amount):02x}' for v in channels)


@dataclass(frozen=True)
class PlotSeries:
    key: str
    label: str
    values: tuple[Decimal | None, ...]
    style: str
    axis: str
    kind: str
    color: str


def finite_number(value) -> float | None:
    if value is None:
        return None
    number = float(value)
    if not math.isfinite(number):
        raise ValueError('グラフに有限値以外の数値を描画できません。')
    return number


def axis_ticks(values, *, target: int = 5) -> tuple[float, float, tuple[float,...]]:
    """A readable scale including the actual zero baseline for signed money."""
    numbers = [finite_number(v) for v in values if v is not None]
    if not numbers or all(v == 0 for v in numbers):
        return 0.0, 1.0, (0.0, .2, .4, .6, .8, 1.0)
    low, high = min(0.0,min(numbers)), max(0.0,max(numbers))
    raw = (high-low)/max(2,target)
    magnitude = 10 ** math.floor(math.log10(raw))
    normalized = raw/magnitude
    multiple = next((n for n in (1,2,2.5,5,10) if normalized <= n),10)
    step = multiple*magnitude
    lower = math.floor(low/step)*step
    upper = math.ceil(high/step)*step
    count = max(1,int(round((upper-lower)/step)))
    ticks = tuple(0.0 if abs(lower+i*step) < abs(step)*1e-9 else lower+i*step for i in range(count+1))
    return lower, upper, ticks


def contiguous_segments(values) -> list[list[tuple[int,float]]]:
    """Return separately drawn runs, preserving gaps and legitimate zeros."""
    segments=[]
    current=[]
    for index,value in enumerate(values):
        number=finite_number(value)
        if number is None:
            if current:segments.append(current);current=[]
        else:
            current.append((index,number))
    if current:segments.append(current)
    return segments


def format_value(value, *, kind='money', unit_label='') -> str:
    if value is None:
        return 'データなし'
    number=Decimal(str(value))
    if not number.is_finite():
        raise ValueError('非有限のグラフ値です。')
    if kind=='ratio':
        return f'{number*100:,.2f}%'
    suffix={'multiple':'倍','months':'か月','days':'日'}.get(kind)
    if suffix:
        return f'{number:,.2f} {suffix}'
    text=format(number,',f')
    if '.' in text:text=text.rstrip('0').rstrip('.')
    return text + (f' {unit_label}' if unit_label else '')


def series_for_view(model: dict, view: str, selected=None, *, income_mode='金額', cash_style='棒グラフ') -> list[PlotSeries]:
    if view not in VIEW_KEYS:
        raise ValueError('グラフの種類が不正です。')
    wanted=set(DEFAULT_KEYS[view] if selected is None else selected)
    expected=len(model.get('periods',[]))
    result=[]
    for key in VIEW_KEYS[view]:
        if key not in wanted:continue
        source_key=key
        if view=='PL' and income_mode=='利益率' and key!='revenue':
            source_key={'gross_profit':'gross_margin','operating_profit':'operating_margin','net_profit':'net_margin'}[key]
        series=model.get(view,{}).get(source_key)
        if not series:continue
        values=tuple(series.get('values',[]))
        if len(values)!=expected:
            raise ValueError('グラフの期間数と数値の数が一致しません。')
        for value in values:finite_number(value)
        if view=='PL':
            style='bar' if key=='revenue' else 'line'
            axis='left' if key=='revenue' else 'right'
        elif view=='BS':
            style='bar' if key=='assets' else 'line';axis='left'
        elif view=='CF':
            style='bar' if key!='cash' and cash_style=='棒グラフ' else 'line';axis='left'
        else:
            style='bar' if view=='FCF' and key=='fcf' else 'line'
            axis='right' if (view=='バリュードライバー' and key=='invested_capital_turnover'
                            or view=='安全指標' and key=='liquidity_months'
                            or view=='生産指標' and key=='ppe_turnover') else 'left'
        result.append(PlotSeries(source_key,series.get('label') or SHORT_LABELS[key],values,
            style,axis,series.get('kind','money'),COLORS[key]))
    if result and not any(s.axis=='left' for s in result):
        result=[replace(s,axis='left') for s in result]
    return result


def axis_label(series: list[PlotSeries], axis: str, unit_label: str) -> str:
    matching=[s for s in series if s.axis==axis]
    if not matching:return ''
    if all(s.kind=='ratio' for s in matching):
        return '利益率（%）' if all(s.key in {'gross_margin','operating_margin','net_margin'}for s in matching) else '比率（%）'
    kinds={s.kind for s in matching}
    if kinds=={'multiple'}:return '回転（倍）'
    if kinds=={'months'}:return '月数（か月）'
    if kinds=={'days'}:return '期間（日）'
    if any(s.key=='revenue' for s in matching) and axis=='left':return f'売上高（{unit_label}）'
    if axis=='right':return f'利益（{unit_label}）'
    return f'金額（{unit_label}）'


def comparability_label(model: dict) -> str:
    bases=[];standards=[]
    for period in model.get('periods',[]):
        basis={'consolidated':'連結','standalone':'個別'}.get(period.get('basis'),'')
        standard=period.get('accounting_standard')or''
        if basis and basis not in bases:bases.append(basis)
        if standard and standard not in standards:standards.append(standard)
    note='・'.join(filter(None,['／'.join(bases),' → '.join(standards)]))
    return ('区分・会計基準の変更あり：'if len(bases)>1 or len(standards)>1 else'')+note


def _tick_label(value: float, ratio: bool) -> str:
    if ratio:return f'{value*100:g}%'
    if abs(value)>=1e10:return f'{value:.1e}'
    if abs(value)>=1:
        return f'{value:,.0f}' if float(value).is_integer() else f'{value:,.2f}'.rstrip('0').rstrip('.')
    return f'{value:g}'


class FinancialCanvas(tk.Canvas):
    def __init__(self,parent,*,selection_callback=None,**kwargs):
        super().__init__(parent,background='white',highlightthickness=0,**kwargs)
        self.model=None
        self.series=[]
        self._plot=None
        self._pending=None
        self._hover_index=None
        self.highlighted_key=None
        self.selection_callback=selection_callback
        self.bind('<Configure>',self._resize)
        self.bind('<Motion>',self._motion)
        self.bind('<Leave>',lambda _:self.delete('hover'))
        self.bind('<Button-1>',self._click)

    def _resize(self,_event=None):
        if self._pending is not None:self.after_cancel(self._pending)
        self._pending=self.after_idle(self.redraw)

    def set_chart(self,model:dict,series:list[PlotSeries]):
        self.model=model;self.series=series
        if self.highlighted_key not in {s.key for s in series}:self.highlighted_key=None
        self.redraw()

    def highlight(self,key=None):
        self.highlighted_key=key if key in {s.key for s in self.series} else None
        self.redraw()
        if self.selection_callback:self.selection_callback(self.highlighted_key)

    def _click(self,event):
        # A generous hit region also works for thin lines and touchpads. Hover
        # overlays and grid lines have no series tag, so they cannot steal a hit.
        key=None
        for item in reversed(self.find_overlapping(event.x-7,event.y-7,event.x+7,event.y+7)):
            keys=[tag.split(':',1)[1]for tag in self.gettags(item)if tag.startswith('series:')]
            if keys:
                key=keys[0];break
        self.highlight(None if key==self.highlighted_key else key)

    def redraw(self):
        self._pending=None
        self.delete('all')
        width,height=max(100,self.winfo_width()),max(100,self.winfo_height())
        if not self.model or not self.model.get('periods'):
            self.create_text(width/2,height/2,text='Excelの取得後、または保存済みデータを開くと\n10期の財務グラフを表示します。',fill='#64748b',font=('Yu Gothic UI',12),justify='center')
            self._plot=None;return
        if not self.series:
            self.create_text(width/2,height/2,text='表示する項目にチェックを入れてください。',fill='#64748b',font=('Yu Gothic UI',11))
            self._plot=None;return
        if not any(value is not None for s in self.series for value in s.values):
            self.create_text(width/2,height/2,text='選択した項目の算出に必要なデータがありません。\n取得済みの別の項目を選択できます。',fill='#64748b',font=('Yu Gothic UI',11),justify='center')
            self._plot=None;return
        right=any(s.axis=='right' for s in self.series)
        left_margin=83;right_margin=83 if right else 24
        x0,y0,x1,y1=left_margin,34,max(left_margin+40,width-right_margin),max(85,height-47)
        n=len(self.model['periods']);step=(x1-x0)/max(1,n)
        positions=[x0+step*(i+.5) for i in range(n)]
        scales={}
        unit=self.model.get('unit_label','')
        for axis in ('left','right'):
            items=[s for s in self.series if s.axis==axis]
            if not items:continue
            low,high,ticks=axis_ticks([value for s in items for value in s.values])
            scales[axis]=(low,high)
            ratio=all(s.kind=='ratio' for s in items)
            for value in ticks:
                y=y1-(value-low)/(high-low)*(y1-y0)
                if axis=='left':
                    self.create_line(x0,y,x1,y,fill='#e6ebf1',width=1)
                    self.create_text(x0-9,y,text=_tick_label(value,ratio),anchor='e',fill='#65758b',font=('Yu Gothic UI',9))
                else:
                    self.create_text(x1+9,y,text=_tick_label(value,ratio),anchor='w',fill='#65758b',font=('Yu Gothic UI',9))
            self.create_text(x0 if axis=='left' else x1,13,text=axis_label(self.series,axis,unit),anchor='w' if axis=='left' else 'e',fill='#52637b',font=('Yu Gothic UI',9))
        self.create_line(x0,y0,x0,y1,fill='#bbc7d5')
        if right:self.create_line(x1,y0,x1,y1,fill='#bbc7d5')
        self.create_line(x0,y1,x1,y1,fill='#bbc7d5')
        left_scale=scales['left']
        zero_y=y1-(0-left_scale[0])/(left_scale[1]-left_scale[0])*(y1-y0)
        self.create_line(x0,zero_y,x1,zero_y,fill='#94a3b8',width=1)
        if right and scales['right'][0] < 0:
            rlow,rhigh=scales['right']
            right_zero=y1-(0-rlow)/(rhigh-rlow)*(y1-y0)
            if abs(right_zero-zero_y)>1:self.create_line(x0,right_zero,x1,right_zero,fill='#a9b8c8',dash=(4,3))
        bars=[s for s in self.series if s.style=='bar']
        bar_width=min(30,max(2,step*.67/max(1,len(bars))))
        for series in self.series:
            emphasized=self.highlighted_key==series.key
            muted=self.highlighted_key is not None and not emphasized
            color=faded_color(series.color) if muted else series.color
            tags=('data','series:'+series.key)
            low,high=scales[series.axis]
            def point(index,value):
                return positions[index],y1-(value-low)/(high-low)*(y1-y0)
            if series.style=='bar':
                offset=(bars.index(series)-(len(bars)-1)/2)*bar_width
                baseline=y1-(0-low)/(high-low)*(y1-y0)
                for i,value in enumerate(series.values):
                    number=finite_number(value)
                    if number is None:continue
                    x,y=point(i,number);x+=offset
                    if number==0:self.create_line(x-bar_width*.4,baseline,x+bar_width*.4,baseline,fill=color,width=4 if emphasized else 2,tags=tags)
                    else:self.create_rectangle(x-bar_width*.43,min(y,baseline),x+bar_width*.43,max(y,baseline),fill=color,outline=series.color if emphasized else '',width=2,tags=tags)
            else:
                for segment in contiguous_segments(series.values):
                    coords=[coordinate for i,v in segment for coordinate in point(i,v)]
                    if len(segment)>1:self.create_line(*coords,fill=color,width=4.5 if emphasized else 1.5 if muted else 2.5,tags=tags)
                    for i,value in segment:
                        x,y=point(i,value)
                        radius=4.5 if emphasized else 2.5 if muted else 3
                        self.create_oval(x-radius,y-radius,x+radius,y+radius,fill=color,outline='white',width=1,tags=tags)
        if self.highlighted_key:self.tag_raise('series:'+self.highlighted_key)
        label_every=max(1,math.ceil(n/max(1,int((x1-x0)/70))))
        for i,period in enumerate(self.model['periods']):
            if i%label_every and i!=n-1:continue
            label=period.get('label','').replace('/','\n',1)
            self.create_text(positions[i],y1+9,text=label,anchor='n',fill='#65758b',font=('Yu Gothic UI',9),justify='center')
        self._plot=(x0,y0,x1,y1,positions)

    def _motion(self,event):
        self.delete('hover')
        if not self._plot:return
        x0,y0,x1,y1,positions=self._plot
        if not (x0<=event.x<=x1 and y0<=event.y<=y1):return
        index=min(range(len(positions)),key=lambda i:abs(positions[i]-event.x))
        x=positions[index]
        self.create_line(x,y0,x,y1,fill='#71839a',dash=(3,3),tags='hover')
        period=self.model['periods'][index]
        basis={'consolidated':'連結','standalone':'個別'}.get(period.get('basis'),'')
        lines=['　'.join(filter(None,[period.get('label',''),basis,period.get('accounting_standard')or'']))]
        chosen=next((s for s in self.series if s.key==self.highlighted_key),None)
        if chosen:lines.append('選択中：'+chosen.label)
        for series in self.series:
            lines.append(series.label+'  '+format_value(series.values[index],kind=series.kind,unit_label=self.model.get('unit_label','')))
        text='\n'.join(lines)
        # The tooltip stays inside the canvas even near either edge.
        item=self.create_text(0,0,text=text,anchor='nw',fill='#203047',font=('Yu Gothic UI',10),tags='hover')
        bbox=self.bbox(item);box_width=bbox[2]-bbox[0]+20;box_height=bbox[3]-bbox[1]+16
        bx=min(max(5,x+14),max(5,self.winfo_width()-box_width-5))
        by=min(max(26,event.y-box_height-12),max(26,self.winfo_height()-box_height-5))
        self.coords(item,bx+10,by+8)
        rectangle=self.create_rectangle(bx,by,bx+box_width,by+box_height,fill='#f6f9fd',outline='#cbd6e3',tags='hover')
        self.tag_raise(item,rectangle)


class FinancialCharts(ttk.Frame):
    """Company-specific chart controls, reusable by new and offline results."""
    def __init__(self,parent,*,open_callback:Callable|None=None,source_callback:Callable[[str],None]|None=None):
        super().__init__(parent)
        self.dataset=None;self.model=None;self.source_callback=source_callback
        self.view=tk.StringVar(value='PL');self.income_mode=tk.StringVar(value='金額')
        self.cash_style=tk.StringVar(value='棒グラフ');self.unit=tk.StringVar(value='自動')
        self.title=tk.StringVar(value='10期の財務グラフ')
        self.subtitle=tk.StringVar(value='会社ごとの売上・利益、資産と負債、キャッシュフローを比較できます。')
        self.selection_text=tk.StringVar(value='クリックで項目を強調')
        self._choices={view:{key:tk.BooleanVar(value=key in DEFAULT_KEYS[view]) for key in keys}for view,keys in VIEW_KEYS.items()}
        self.columnconfigure(0,weight=1);self.rowconfigure(3,weight=1,minsize=170)
        header=ttk.Frame(self);header.grid(row=0,column=0,sticky='ew',pady=(0,7));header.columnconfigure(0,weight=1)
        ttk.Label(header,textvariable=self.title,font=('Yu Gothic UI',15,'bold')).grid(row=0,column=0,sticky='w')
        if open_callback:ttk.Button(header,text='保存済みデータを開く',command=open_callback).grid(row=0,column=1,sticky='e')
        ttk.Label(self,textvariable=self.subtitle,style='Sub.TLabel').grid(row=1,column=0,sticky='w',pady=(0,8))
        toolbar=ttk.Frame(self);toolbar.grid(row=2,column=0,sticky='ew',pady=(0,7))
        ttk.Label(toolbar,text='グループ').grid(row=0,column=0,padx=(0,6))
        self.view_label=tk.StringVar(value=VIEW_LABELS['PL'])
        self.view_box=ttk.Combobox(toolbar,textvariable=self.view_label,values=list(VIEW_LABELS.values()),state='readonly',width=20)
        self.view_box.grid(row=0,column=1,padx=(0,10))
        self.view_box.bind('<<ComboboxSelected>>',self._choose_view)
        self.income_box=ttk.Combobox(toolbar,textvariable=self.income_mode,values=['金額','利益率'],state='readonly',width=8)
        self.income_box.grid(row=0,column=2,padx=(2,9));self.income_box.bind('<<ComboboxSelected>>',lambda _:self._render())
        self.cash_box=ttk.Combobox(toolbar,textvariable=self.cash_style,values=['棒グラフ','折れ線'],state='readonly',width=9)
        self.cash_box.grid(row=0,column=2,padx=(2,9));self.cash_box.grid_remove();self.cash_box.bind('<<ComboboxSelected>>',lambda _:self._render())
        ttk.Label(toolbar,text='単位').grid(row=0,column=3,padx=(6,5))
        self.unit_box=ttk.Combobox(toolbar,textvariable=self.unit,values=list(UNIT_LABELS),state='readonly',width=7)
        self.unit_box.grid(row=0,column=4);self.unit_box.bind('<<ComboboxSelected>>',lambda _:self._rebuild_model())
        ttk.Label(toolbar,textvariable=self.selection_text,style='Sub.TLabel').grid(row=0,column=5,padx=(13,5))
        ttk.Button(toolbar,text='強調を解除',command=lambda:self.canvas.highlight()).grid(row=0,column=6,padx=(4,0))
        self.canvas=FinancialCanvas(self,selection_callback=self._selection_changed);self.canvas.grid(row=3,column=0,sticky='nsew')
        self.legend=ttk.Frame(self);self.legend.grid(row=4,column=0,sticky='ew',pady=(8,4))
        footer=ttk.Frame(self);footer.grid(row=5,column=0,sticky='ew');footer.columnconfigure(0,weight=1)
        ttk.Label(footer,text='線・棒をクリックで強調、余白で解除。チェックで表示を切り替えます。',style='Sub.TLabel').grid(row=0,column=0,sticky='w')
        self.source_button=ttk.Button(footer,text='最新期の開示原文',command=self._open_source,state='disabled')
        self.source_button.grid(row=0,column=1,sticky='e')
        self._view_changed()

    def _choose_view(self,_event=None):
        chosen=next((key for key,label in VIEW_LABELS.items()if label==self.view_label.get()),'PL')
        self.view.set(chosen);self._view_changed()

    def _selection_changed(self,key):
        series=next((s for s in self.canvas.series if s.key==key),None)
        self.selection_text.set('強調：'+series.label if series else 'クリックで項目を強調')

    def _focus(self,key):
        if self.view.get()=='PL' and self.income_mode.get()=='利益率':
            key={'gross_profit':'gross_margin','operating_profit':'operating_margin','net_profit':'net_margin'}.get(key,key)
        self.canvas.highlight(None if self.canvas.highlighted_key==key else key)

    def set_dataset(self,dataset):
        # Build first: a rejected audit must not relabel an older graph with a
        # different company name while leaving the older plot on screen.
        from .analysis import chart_data
        model=chart_data(dataset,unit=UNIT_LABELS[self.unit.get()])
        self._commit_model(dataset,model)

    def _rebuild_model(self):
        if self.dataset is None:return
        self.set_dataset(self.dataset)

    def _commit_model(self,dataset,model):
        self.dataset=dataset;self.model=model
        self.title.set(f'{dataset.code}　{dataset.company}')
        periods=self.model['periods']
        dates=f"{periods[0]['label']} ～ {periods[-1]['label']}" if periods else ''
        self.subtitle.set(f"{dates}　／　{len(periods)}期　／　単位：{self.model['unit_label']}　／　{comparability_label(self.model)}")
        metadata=dataset.export_metadata or {}
        if metadata.get('supplemental') and metadata.get('format_version')!=6:
            self.subtitle.set(self.subtitle.get()+'　／　分析指標は新版でExcelを再作成')
        self.source_button.configure(state='normal' if self._source_url() else 'disabled')
        self._render()

    def _view_changed(self):
        view=self.view.get()
        self.view_label.set(VIEW_LABELS[view])
        self.canvas.highlighted_key=None
        self.selection_text.set('クリックで項目を強調')
        self.income_box.grid() if view=='PL' else self.income_box.grid_remove()
        self.cash_box.grid() if view=='CF' else self.cash_box.grid_remove()
        for child in self.legend.winfo_children():child.destroy()
        for i,key in enumerate(VIEW_KEYS[view]):
            frame=ttk.Frame(self.legend);frame.grid(row=i//4,column=i%4,sticky='w',padx=(0,12))
            swatch=ttk.Label(frame,text='■',foreground=COLORS[key],cursor='hand2');swatch.pack(side='left')
            swatch.bind('<Button-1>',lambda _,key=key:self._focus(key))
            ttk.Checkbutton(frame,text=SHORT_LABELS[key],variable=self._choices[view][key],command=self._render).pack(side='left')
        self._render()

    def _render(self):
        if self.model is None:
            self.canvas.redraw();return
        view=self.view.get();selected=[key for key,value in self._choices[view].items()if value.get()]
        specs=series_for_view(self.model,view,selected,income_mode=self.income_mode.get(),cash_style=self.cash_style.get())
        self.canvas.set_chart(self.model,specs)
        self._selection_changed(self.canvas.highlighted_key)

    def _source_url(self):
        if self.dataset is None or not self.dataset.periods:return None
        latest=max(self.dataset.periods).key
        candidates=[cell.source for rows in self.dataset.rows.values()for row in rows
            for key,cell in row.values.items()if key==latest and cell.value is not None and cell.source.url]
        return max(candidates,key=lambda s:(s.submitted,s.doc_id)).url if candidates else None

    def _open_source(self):
        url=self._source_url()
        if url and self.source_callback:self.source_callback(url)
