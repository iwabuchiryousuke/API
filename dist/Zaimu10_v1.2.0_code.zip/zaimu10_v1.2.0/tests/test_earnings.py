"""Original JPX evidence and regressions for actual/scheduled annual dates."""
from datetime import date, datetime
import gzip
import io
import json
from pathlib import Path
import threading

from bs4 import BeautifulSoup
from openpyxl import Workbook
import pytest
import requests

from zaimu10 import earnings
from zaimu10.earnings import EarningsError
from zaimu10.registry import CompanyRegistry, RegistryError
from zaimu10.models import Filing

FIXTURES=Path(__file__).parent/'fixtures'/'earnings'
TODAY=date(2026,11,19)


@pytest.fixture(autouse=True)
def stable_day(monkeypatch):
    monkeypatch.setattr(earnings,'_today',lambda:TODAY)


def raw(code):
    return gzip.decompress((FIXTURES/f'jpx_{code}.html.gz').read_bytes())


def event(code='6947',when='2026-05-14',period='2026年3月期',kind='actual',end=None,verified='2026-11-19T10:00:00+09:00'):
    source=f'https://www2.jpx.co.jp/disc/{code}0/140120260424510134.pdf'
    return earnings._event(code,'株式会社検証会社',when,period+' 決算短信〔日本基準〕(連結)',
                           source,kind=kind,fiscal_end=end,observed_at=verified)


def save(cache,events,code='6947'):
    path=cache/'earnings'/f'{code}.json'
    payload=dict(schema=1,code=code,company='検証会社',events=events,history=events,
                 checked_at='2026-11-01T10:00:00+09:00',stale=False,warnings=[],evidence=[])
    earnings._write_json(path,payload)
    return path,payload


@pytest.mark.parametrize('code,latest,period,earliest',[
    ('6947','2026-05-14','2026年3月期','2017-05-08'),
    ('7826','2026-08-06','2026年6月期','2017-08-07'),
    ('2303','2026-07-09','2026年5月期','2017-07-10'),
    ('4369','2026-03-13','2026年1月期','2017-03-15'),
    ('7309','2026-02-10','2025年12月期','2017-02-14'),
    ('9843','2026-05-14','2026年3月期','2017-03-28'),
])
def test_real_official_six_company_annual_history(code,latest,period,earliest):
    parsed=earnings.parse_jpx_detail(raw(code),code)
    active,history=earnings.merge_events([],parsed,today=TODAY)
    actual=[e for e in active if e['kind']=='actual']
    assert len(actual)==10
    assert (actual[0]['date'],actual[0]['fiscal_period'])==(latest,period)
    assert actual[-1]['date']==earliest
    assert all(e['period_type']=='annual' and e['is_annual'] for e in actual)
    assert all(e['source_url'].startswith(f'https://www2.jpx.co.jp/disc/{code}0/') for e in actual)
    assert all('四半期' not in e['title'] and '訂正' not in e['title'] for e in actual)
    # The title proves year/month only; no fiscal month-end is fabricated.
    assert all(e['fiscal_end'] is None for e in actual)


def test_nitori_original_jgaap_release_precedes_later_ifrs_republication():
    active,history=earnings.merge_events([],earnings.parse_jpx_detail(raw('9843'),'9843'),today=TODAY)
    chosen=next(e for e in active if e['fiscal_month']=='2025-03')
    assert chosen['date']=='2025-05-13'
    assert {s['date'] for s in chosen['sources']}=={'2025-05-13','2025-06-25'}
    assert any(e['date']=='2025-06-25' and e['fiscal_month']=='2025-03' for e in history)


@pytest.mark.parametrize('title',[
    '2026年3月期 第1四半期決算短信',
    '2026年3月期 第２四半期決算短信',
    '2026年3月期 第4四半期決算短信',
    '2026年3月期 中間決算短信',
    '(訂正)2026年3月期 決算短信',
    '2026年3月期決算短信の一部訂正について',
    '2026年3月期 決算短信補足説明資料',
    '2026年3月期 配当予想の修正に関するお知らせ',
    '2026年3月期 業績予想と決算短信のお知らせ',
])
def test_quarters_corrections_supplements_and_forecasts_are_not_original_annual_results(title):
    assert not earnings._annual_title(title)


def test_era_period_is_read_without_inventing_day():
    assert earnings._period('平成29年3月期 決算短信')==('2017年3月期','2017-03')
    assert earnings._period('令和元年12月期 決算短信')==('2019年12月期','2019-12')


def test_official_dawn_future_has_exact_date_and_excludes_quarters_and_expired_plans():
    body=(FIXTURES/'dawn_calendar.js').read_bytes()
    events=earnings.parse_company_schedule(body,'2303',source_url='https://www.dawn-corp.co.jp/ir/',company='ドーン')
    assert [(e['date'],e['fiscal_period'],e['kind']) for e in events]==[
        ('2027-07-08','2027年5月期','scheduled')]
    assert events[0]['fiscal_end'] is None
    assert events[0]['period_type']=='annual'
    assert '2027年07月08日' in events[0]['evidence_text']


def test_actual_replaces_old_schedule_same_period_and_corrections_cannot_move_date():
    scheduled=event(when='2026-05-14',kind='scheduled')
    actual=event()
    active,history=earnings.merge_events([scheduled],[actual],today=TODAY)
    assert [(e['kind'],e['date']) for e in active]==[('actual','2026-05-14')]
    assert {e['kind'] for e in history}=={'actual','scheduled'}


def test_fresh_rescheduled_future_replaces_previous_date_but_keeps_provenance():
    old=event(when='2027-05-14',period='2027年3月期',kind='scheduled',verified='2026-11-01T00:00:00+09:00')
    fresh=event(when='2027-05-17',period='2027年3月期',kind='scheduled')
    active,history=earnings.merge_events([old],[fresh],today=TODAY)
    assert [e['date'] for e in active]==['2027-05-17']
    assert {e['date'] for e in history}=={'2027-05-14','2027-05-17'}


def test_past_schedule_never_becomes_actual_by_passage_of_time():
    scheduled=event(when='2026-05-14',kind='scheduled')
    active,history=earnings.merge_events([scheduled],[],today=TODAY)
    assert active==[] and history[0]['kind']=='scheduled'


def test_repeated_jpx_rendering_cannot_drop_richer_fiscal_source_metadata():
    rich=event(end='2026-03-31');rich['financial_html_url']='https://www2.jpx.co.jp/disc/69470/one-ixbrl.htm'
    plain=event()
    active,_=earnings.merge_events([],[rich,plain],today=TODAY)
    assert active[0]['fiscal_end']=='2026-03-31'
    assert active[0]['financial_html_url'].endswith('one-ixbrl.htm')


def test_exact_fiscal_metadata_handles_hidden_check_digit_without_guessing_month_end():
    html=gzip.decompress((FIXTURES/'jpx_6947_fiscal.html.gz').read_bytes())
    assert earnings.parse_disclosure_fiscal_end(html,'6947',fiscal_month='2026-03')=='2026-03-31'
    midmonth=b'<html><ix:nonnumeric name="t:SecuritiesCode">9843<div>0</div></ix:nonnumeric><ix:nonnumeric name="t:FiscalYearEnd">2017-02-20</ix:nonnumeric></html>'
    assert earnings.parse_disclosure_fiscal_end(midmonth,'9843',fiscal_month='2017-02')=='2017-02-20'
    assert earnings.parse_disclosure_fiscal_end(midmonth,'9843',fiscal_month='2017-03') is None
    with pytest.raises(EarningsError,match='企業コード'):
        earnings.parse_disclosure_fiscal_end(midmonth,'6947',fiscal_month='2017-02')


def test_live_jpx_public_workbook_has_57_future_full_year_events_and_original_asof():
    path=FIXTURES/'kessan10_1106.xlsx'
    items=earnings.parse_market_workbook(path.read_bytes(),source_url='https://www.jpx.co.jp/'+path.name)
    active,_=earnings.merge_events([],items,today=TODAY)
    assert len(active)==57
    kobe=next(e for e in active if e['code']=='3038')
    assert (kobe['date'],kobe['fiscal_end'],kobe['source_as_of'])==('2026-12-14','2026-10-31','2026-11-05')
    assert all(e['kind']=='scheduled' for e in active)
    assert not any(e['code']=='4369' for e in active)  # 11/30 is Q3.


def test_market_parser_keeps_alphanumeric_code_and_does_not_turn_q4_or_undecided_into_annual():
    book=Workbook();sheet=book.active
    sheet.append(['2026年11月5日 現在'])
    sheet.append(['決算発表予定日\nScheduled Dates for Earnings Announcements','コード\nCode','会社名','Issue Name','決算期末\nFiscal Year-end','種別'])
    sheet.append([datetime(2026,12,14),'296A','企業','Company',datetime(2026,10,31),'本決算'])
    sheet.append([datetime(2026,12,14),1000,'四半期','Company',datetime(2026,10,31),'第４四半期'])
    sheet.append([None,1001,'未定','Company',datetime(2026,10,31),'本決算'])
    stream=io.BytesIO();book.save(stream);book.close()
    events=earnings.parse_market_workbook(stream.getvalue(),source_url='https://www.jpx.co.jp/test.xlsx')
    assert len(events)==1 and events[0]['code']=='296A'


def test_unrecognized_market_workbook_is_error_not_empty_unpublished_calendar():
    book=Workbook();book.active.append(['unexpected format']);stream=io.BytesIO();book.save(stream)
    with pytest.raises(EarningsError,match='表形式'):
        earnings.parse_market_workbook(stream.getvalue(),source_url='https://www.jpx.co.jp/test.xlsx')


def test_bad_workbook_http200_response_is_explicit_parse_failure():
    with pytest.raises(EarningsError,match='Excelファイルを読み取れません'):
        earnings.parse_market_workbook(b'<html>service unavailable</html>',source_url='https://www.jpx.co.jp/test.xlsx')


def test_market_update_failure_keeps_previous_verified_calendar(monkeypatch,tmp_path):
    path=tmp_path/'earnings'/'market_schedule.json'
    scheduled=event(when='2027-05-14',period='2027年3月期',kind='scheduled')
    payload=dict(schema=1,code=None,events=[scheduled],history=[scheduled],
                 checked_at='2026-11-01T10:00:00+09:00',stale=False,warnings=[],evidence=[])
    earnings._write_json(path,payload);before=path.read_bytes()
    class Response:
        content=b'<a href="/listing/event-schedules/financial-announcement/kessan10.xlsx">Excel</a>'
    def request(session,method,url,**kwargs):
        if url==earnings.JPX_SCHEDULE:return Response()
        class BadWorkbook:
            content=b'<html>upstream error</html>'
        return BadWorkbook()
    monkeypatch.setattr(earnings,'_request',request)
    result=earnings.load_market_schedule(cache_dir=tmp_path,refresh=True)
    assert result['stale'] and result['events'][0]['date']=='2027-05-14'
    assert result['checked_at']==payload['checked_at']
    assert path.read_bytes()==before


def test_overlapping_public_workbooks_use_latest_official_snapshot_not_download_order():
    newest=event(when='2027-05-15',period='2027年3月期',kind='scheduled')
    newest.update(source_as_of='2026-11-19',verified_at='2026-11-19T10:00:00+09:00')
    older=event(when='2027-05-14',period='2027年3月期',kind='scheduled')
    older.update(source_as_of='2026-11-05',verified_at='2026-11-19T10:01:00+09:00')
    active,history=earnings.merge_events([], [newest,older])
    assert len(active)==1 and active[0]['date']=='2027-05-15'
    assert len(history)==2


def test_failed_network_retains_verified_cache_and_original_timestamp(monkeypatch,tmp_path):
    path,payload=save(tmp_path,[event()]);before=path.read_bytes()
    def fail(*args,**kwargs):raise EarningsError('HTTP 503')
    monkeypatch.setattr(earnings,'_jpx_detail',fail)
    result=earnings.load_calendar('6947',cache_dir=tmp_path,refresh=True,log=lambda _:None)
    assert result['stale'] is True
    assert result['events'][0]['date']=='2026-05-14'
    assert result['checked_at']==payload['checked_at']
    assert any('更新失敗' in warning for warning in result['warnings'])
    assert path.read_bytes()==before


def test_failed_first_fetch_is_explicit_failure_not_unpublished(monkeypatch,tmp_path):
    def fail(*args,**kwargs):raise EarningsError('JPX unavailable')
    monkeypatch.setattr(earnings,'_jpx_detail',fail)
    with pytest.raises(EarningsError,match='取得に失敗'):
        earnings.load_calendar('6947',cache_dir=tmp_path,refresh=True,log=lambda _:None)
    assert not (tmp_path/'earnings'/'6947.json').exists()


def test_offline_uses_cache_without_network_and_invalid_json_never_reset(monkeypatch,tmp_path):
    path,_=save(tmp_path,[event()])
    def fail(*args,**kwargs):raise AssertionError('network must not run')
    monkeypatch.setattr(earnings,'_jpx_detail',fail)
    assert earnings.load_calendar('6947',cache_dir=tmp_path,offline=True)['offline']
    path.write_text('{broken')
    with pytest.raises(EarningsError,match='壊れて'):
        earnings.load_calendar('6947',cache_dir=tmp_path,refresh=True)
    assert path.read_text()=='{broken'


def test_checksum_detects_even_plausible_calendar_date_tampering(tmp_path):
    path,_=save(tmp_path,[event()]);payload=json.loads(path.read_text())
    payload['events'][0]['date']='2026-05-15';path.write_text(json.dumps(payload))
    with pytest.raises(EarningsError,match='壊れて'):
        earnings.load_calendar('6947',cache_dir=tmp_path,offline=True)


def test_cancelled_operation_never_fetches_or_writes(monkeypatch,tmp_path):
    cancel=threading.Event();cancel.set()
    def fail(*args,**kwargs):raise AssertionError('network must not run')
    monkeypatch.setattr(earnings,'_jpx_detail',fail)
    with pytest.raises(InterruptedError):
        earnings.load_calendar('6947',cache_dir=tmp_path,cancel=cancel)
    with pytest.raises(InterruptedError):
        earnings.load_market_schedule(cache_dir=tmp_path,cancel=cancel)
    assert not (tmp_path/'earnings').exists()


def test_network_has_two_short_attempts_and_long_server_wait_stops(monkeypatch):
    from zaimu10 import edinet
    monkeypatch.setattr(edinet,'_pause',lambda *args:None)
    class Session:
        calls=0
        def request(self,*args,**kwargs):
            self.calls+=1
            assert kwargs['timeout'][0]<=5 and kwargs['timeout'][1]<=18
            assert kwargs['allow_redirects'] is False
            raise requests.ConnectTimeout()
    session=Session()
    with pytest.raises(EarningsError,match='接続'):
        earnings._request(session,'GET','https://www.jpx.co.jp/')
    assert session.calls==2
    class BusySession:
        calls=0
        def request(self,*args,**kwargs):
            self.calls+=1
            class Response:
                status_code=429
                headers={'Retry-After':'31'}
            return Response()
    session=BusySession()
    with pytest.raises(EarningsError,match='31秒'):
        earnings._request(session,'GET','https://www.jpx.co.jp/')
    assert session.calls==1


def test_evidence_sanitization_removes_session_and_executable_transport():
    soup=BeautifulSoup('<form action="/path;jsessionid=SECRET"><input name="token" value="SECRET"><script>SECRET</script><a href="/file;jsessionid=SECRET?x=1" onclick="x()">公表値</a></form>','html.parser')
    clean=earnings._sanitize_html(soup)
    assert 'SECRET' not in clean and 'onclick' not in clean and '<input' not in clean
    assert '公表値' in clean


def registry(tmp_path,code='6947'):
    reg=CompanyRegistry(tmp_path/'companies.json')
    reg.register(dict(code=code,company='株式会社検証会社',edinet_code='E01966',fiscal_year_end='3月31日'))
    return reg


def calendar(events,code='6947'):
    return dict(code=code,events=events,history=events,checked_at='2026-11-19T10:00:00+09:00',warnings=[],stale=False)


def test_registry_actual_fiscal_period_advances_in_may_before_june_annual_report(tmp_path):
    reg=registry(tmp_path)
    reg.update_filings('6947',[Filing('S100AAAA',code='6947',edinet_code='E01966',start=date(2024,4,1),end=date(2025,3,31),submitted='2025-06-20 10:00')])
    actual=event(end='2026-03-31')
    planned=event(when='2027-05-14',period='2027年3月期',kind='scheduled',end='2027-03-31')
    record=reg.update_earnings('6947',calendar([actual,planned]))
    assert record['latest_period_end']=='2026-03-31'
    assert record['financial_latest_period_end']=='2025-03-31'
    assert record['announcement_date']=='2026-05-14'
    assert record['next_announcement_date']=='2027-05-14'
    reloaded=CompanyRegistry(reg.path).calendar_rows()[0]
    assert (reloaded['latest_period_end'],reloaded['announcement_date'])==('2026-03-31','2026-05-14')


def test_registry_midmonth_exact_end_is_preserved_and_unknown_day_not_invented(tmp_path):
    reg=registry(tmp_path,code='9843')
    reg.update_filings('9843',[Filing('S100AAAA',code='9843',edinet_code='E01966',start=date(2016,2,21),end=date(2017,2,20),submitted='2017-05-10 10:00')])
    reg.update_earnings('9843',calendar([event(code='9843',when='2017-03-28',period='2017年2月期')],code='9843'))
    assert reg.calendar_rows()[0]['latest_period_end']=='2017-02-20'
    reg=registry(tmp_path/'other',code='9843')
    reg.update_earnings('9843',calendar([event(code='9843',when='2017-03-28',period='2017年2月期')],code='9843'))
    row=reg.calendar_rows()[0]
    assert row['latest_period_end'] is None and row['latest_period_label']=='2017年2月期'


def test_registry_old_history_never_downgrades_actual_and_month_only_sorts_correctly(tmp_path):
    reg=registry(tmp_path)
    reg.register(dict(code='7826',company='フルヤ金属',edinet_code='E00001'))
    reg.update_earnings('6947',calendar([event(when='2026-11-10',period='2026年9月期')]))
    reg.update_earnings('7826',calendar([event(code='7826',when='2026-08-06',period='2026年6月期',end='2026-06-30')],code='7826'))
    reg.update_earnings('6947',calendar([event(when='2025-05-14',period='2025年3月期')]))
    rows=reg.calendar_rows()
    assert [r['code'] for r in rows]==['6947','7826']
    assert rows[0]['announcement_date']=='2026-11-10'
    assert rows[0]['latest_period_label']=='2026年9月期'


def test_registry_rejects_wrong_company_and_no_user_auto_registration(tmp_path):
    reg=registry(tmp_path)
    with pytest.raises(RegistryError,match='一致'):
        reg.update_earnings('6947',calendar([event(code='2303')],code='2303'))
    assert reg.update_earnings('2303',calendar([event(code='2303')],code='2303')) is None
    assert [r['code'] for r in reg.list_companies()]==['6947']


def test_registry_partial_old_announcement_history_cannot_downgrade_known_newer_financial_year(tmp_path):
    reg=registry(tmp_path)
    reg.update_filings('6947',[Filing('S100AAAA',code='6947',edinet_code='E01966',start=date(2025,4,1),end=date(2026,3,31),submitted='2026-06-19 11:04')])
    older=event(when='2025-05-12',period='2025年3月期',end='2025-03-31')
    record=reg.update_earnings('6947',calendar([older]))
    assert record['latest_period_end']=='2026-03-31'
    assert record['announcement_date'] is None
    row=CompanyRegistry(reg.path).calendar_rows()[0]
    assert row['latest_period_end']=='2026-03-31'
    assert row['announcement_date'] is None
    assert row['earnings_events'][0]['date']=='2025-05-12'


def test_registry_new_financial_period_after_older_announcement_clears_pair_and_sorts_latest_year(tmp_path):
    reg=registry(tmp_path)
    reg.update_earnings('6947',calendar([event(when='2025-05-12',period='2025年3月期',end='2025-03-31')]))
    reg.register(dict(code='7826',company='フルヤ金属',edinet_code='E00001'))
    reg.update_earnings('7826',calendar([event(code='7826',when='2025-08-07',period='2025年6月期',end='2025-06-30')],code='7826'))
    record=reg.update_filings('6947',[Filing('S100AAAA',code='6947',edinet_code='E01966',start=date(2025,4,1),end=date(2026,3,31),submitted='2026-06-19 11:04')])
    assert record['announcement_date'] is None
    rows=CompanyRegistry(reg.path).calendar_rows()
    assert [r['code'] for r in rows]==['6947','7826']
    assert rows[0]['latest_period_end']=='2026-03-31'
    assert rows[0]['announcement_date'] is None
    assert rows[0]['announcement_fiscal_month'] is None
    assert rows[0]['earnings_events'][0]['date']=='2025-05-12'
