"""Retrieve original iXBRL through EDINET's free public document viewer.

The viewer is a public GeneXus form. Its own JavaScript sends ONLINKCLICK
events using state and event tokens supplied in the GET response. We submit
the same event, using only that session's state; no API key or login is used.
Only original document content is cached. Session state/tokens are discarded.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
import uuid
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

VIEWER = 'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx'
CACHE_VERSION = 1
DOC_ID = re.compile(r'S[A-Z0-9]{7}\Z')
_request_lock = threading.Lock()
_last_request = 0.0
_MIN_INTERVAL = 1.25
_RETRY_STATUSES = {408, 429, 500, 502, 503, 504}


class FetchError(RuntimeError):
    """An unavailable filing or a changed public viewer, never missing data."""


class CancelledError(InterruptedError):
    """The user cancelled retrieval."""


def _check_cancel(cancel: threading.Event | None) -> None:
    if cancel is not None and cancel.is_set():
        raise CancelledError('取得を中止しました。')


def _pause(seconds: float, cancel: threading.Event | None) -> None:
    if cancel is not None:
        if cancel.wait(max(0.0, seconds)):
            raise CancelledError('取得を中止しました。')
    elif seconds > 0:
        time.sleep(seconds)


def _retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        try:
            until = parsedate_to_datetime(value)
            if until.tzinfo is None:
                until = until.replace(tzinfo=timezone.utc)
            return max(0.0, (until - datetime.now(timezone.utc)).total_seconds())
        except (ValueError, TypeError, OverflowError):
            return None


def _request(session: requests.Session, method: str, url: str, *,
             log: Callable[[str], None], cancel: threading.Event | None,
             **kwargs) -> requests.Response:
    """Bounded retry and a process-wide courtesy interval on the official host."""
    global _last_request
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname != 'disclosure2.edinet-fsa.go.jp':
        raise FetchError('取得先がEDINETの公開閲覧ホストではありません。')
    last_error = None
    for attempt in range(3):
        _check_cancel(cancel)
        with _request_lock:
            _pause(max(0, _MIN_INTERVAL - (time.monotonic() - _last_request)), cancel)
            _last_request = time.monotonic()
        try:
            response = session.request(method, url, timeout=(15, 90),
                                       allow_redirects=False, **kwargs)
            if response.status_code in _RETRY_STATUSES:
                wait = _retry_after(response.headers.get('Retry-After'))
                if wait is not None and wait > 300:
                    raise FetchError(f'EDINETから待機が指定されました（{wait:.0f}秒）。時間を置いて再実行してください。')
                if attempt < 2:
                    delay = max(wait or 0, 2 ** (attempt + 1))
                    log(f'EDINET HTTP {response.status_code}。{delay:.0f}秒後に再試行します。')
                    _pause(delay, cancel)
                    continue
            if response.status_code != 200:
                raise FetchError(f'EDINETの取得に失敗しました（HTTP {response.status_code}）。公開停止・混雑・閲覧方式の変更をご確認ください。')
            _check_cancel(cancel)
            return response
        except requests.RequestException as exc:
            last_error = exc
            if attempt < 2:
                delay = 2 ** (attempt + 1)
                log(f'EDINETへの接続に失敗しました。{delay}秒後に再試行します。')
                _pause(delay, cancel)
    raise FetchError('EDINETへ接続できません。ネットワークと公開サイトの稼働状況をご確認ください。') from last_error


def _ajax_marker(state: dict) -> str:
    """GeneXus gx.sec.encrypt('gxajaxEvt'), using the current form's values.

    The public client uses AES-CBC, zero padding, and prefixes the IV. This is
    form transport encoding, not an API credential or an authorization bypass.
    """
    try:
        key = bytes.fromhex(state['GX_AJAX_KEY'])
        iv = bytes.fromhex(state['GX_AJAX_IV'])
        encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
        plain = b'gxajaxEvt'
        plain += b'\0' * ((-len(plain)) % 16)
        return (iv + encryptor.update(plain) + encryptor.finalize()).hex()
    except (KeyError, ValueError, TypeError) as exc:
        raise FetchError('EDINET公開閲覧のイベント形式が変わっています。取得を停止しました。') from exc


def _reloads(commands: list) -> list[str]:
    pages = []
    for command in commands:
        event = command.get('exomethod', {})
        if event.get('Method') == 'ReloadHonbun':
            parms = event.get('Parms', [])
            if parms and isinstance(parms[0], str) and '<' in parms[0]:
                pages.append(parms[0])
    return pages


def _toc_links(toc: str) -> list[tuple[str, str]]:
    soup = BeautifulSoup(toc, 'html.parser')
    links = []
    for anchor in soup.select('a[href]'):
        match = re.search(r"linkclicknew\(['\"]([^'\"]+)['\"]\)", anchor['href'])
        if match:
            target = match.group(1)
            # Filename is selected only from links actually emitted by EDINET.
            filename = target.split('#', 1)[0]
            if re.fullmatch(r'[A-Za-z0-9_.-]+\.html?', filename):
                links.append((target, anchor.get_text(' ', strip=True)))
    return links


def _financial_targets(links: list[tuple[str, str]]) -> list[str]:
    statement = re.compile(r'貸借対照表|財政状態計算書|損益計算書|損益及び|包括利益計算書|キャッシュ[・･\s]?フロー計算書|キャッシュ[・･\s]?フロー表')
    selected = [target for target, label in links if statement.search(label)]
    if not selected:
        selected = [target for target, label in links if re.search(r'連結財務諸表|財務諸表|経理の状況', label)]
    # A financial chapter commonly includes all statements. Request it once.
    by_filename: dict[str, str] = {}
    for target in selected:
        by_filename.setdefault(target.split('#', 1)[0], target)
    return list(by_filename.values())


def _cache_read(directory: Path, doc_id: str) -> list[tuple[str, str]] | None:
    manifest_path = directory / 'manifest.json'
    if not manifest_path.is_file():
        return None
    try:
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        if manifest.get('version') != CACHE_VERSION or manifest.get('doc_id') != doc_id:
            return None
        files = manifest['files']
        if not isinstance(files, list) or not files:
            return None
        pages = []
        for file in files:
            path = file['path']
            if not re.fullmatch(r'\d{3}(?:-[0-9a-f]{64})?\.html', path):
                return None
            raw = (directory / path).read_bytes()
            if hashlib.sha256(raw).hexdigest() != file['sha256']:
                return None
            pages.append((file['filename'], raw.decode('utf-8')))
        if ('有価証券報告書の訂正報告書' in BeautifulSoup(pages[0][1], 'html.parser').get_text(' ', strip=True)
                and manifest.get('retrieval_policy') != 'all-amendment-chapters-v2'):
            return None
        return pages
    except (OSError, ValueError, KeyError, TypeError, UnicodeError):
        return None


def _atomic_write(path: Path, raw: bytes) -> None:
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_bytes(raw)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def _cache_write(directory: Path, doc_id: str, pages: list[tuple[str, str]]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    files = []
    for index, (filename, html) in enumerate(pages):
        raw = html.encode('utf-8')
        digest = hashlib.sha256(raw).hexdigest()
        # Immutable document files let the manifest be the single atomic
        # commit point. A failed refresh cannot corrupt a previous manifest.
        relative = f'{index:03}-{digest}.html'
        _atomic_write(directory / relative, raw)
        files.append({'filename': filename, 'path': relative,
                      'sha256': digest, 'bytes': len(raw)})
    manifest = {'version': CACHE_VERSION, 'retrieval_policy': 'all-amendment-chapters-v2', 'doc_id': doc_id,
                'source_url': f'{VIEWER}?{doc_id}',
                'fetched_at': datetime.now(timezone.utc).isoformat(), 'files': files}
    _atomic_write(directory / 'manifest.json',
                  json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))


def fetch_filing(doc_id: str, *, cache_dir: Path, log: Callable[[str], None] = print,
                 cancel: threading.Event | None = None, offline: bool = False,
                 refresh: bool = False) -> list[tuple[str, str]]:
    """Return original cover/resources and statement chapters, preserving XML.

    Missing/corrupt/offline data raises FetchError. It is never represented by
    empty financial facts. Cache files include a SHA-256 manifest for checking
    provenance and reproducibility. A completed cache remains available if a
    later refresh fails.
    """
    if not DOC_ID.fullmatch(doc_id):
        raise FetchError('EDINET書類IDの形式が正しくありません。例: S100W07I')
    _check_cancel(cancel)
    directory = Path(cache_dir) / 'filings' / doc_id
    cached = _cache_read(directory, doc_id)
    if cached is not None and (not refresh or offline):
        log(f'{doc_id}: 保存済みの原本を使用')
        return cached
    if offline:
        raise FetchError(f'{doc_id}: 照合可能な原本キャッシュがありません。オンラインで一度取得してください。')

    url = f'{VIEWER}?{doc_id}'
    log(f'{doc_id}: EDINETの公開原本を取得')
    with requests.Session() as session:
        session.headers.update({'User-Agent': 'Zaimu10/1.0 (public EDINET document viewer)',
                                'Accept-Language': 'ja,en;q=0.5'})
        response = _request(session, 'GET', url, log=log, cancel=cancel)
        soup = BeautifulSoup(response.content.decode('utf-8-sig'), 'html.parser')
        hidden = soup.find('input', attrs={'name': 'GXState'})
        try:
            state = json.loads(hidden['value']) if hidden else None
            if not isinstance(state, dict) or state.get('vP_SYORUI_KANRI_NO') != doc_id:
                raise ValueError('wrong document state')
            toc_element = soup.find('iframe', attrs={'id': 'frame_mokuji'})
            toc = toc_element.get('srcdoc', '') if toc_element else ''
            links = _toc_links(toc)
            first_pages = _reloads(state.get('GX_SRV_COMMANDS', []))
            if not links or not first_pages:
                raise ValueError('no document body or table of contents')
            targets = _financial_targets(links)
            title = soup.find('h1')
            is_amendment = title is not None and '訂正有価証券報告書' in title.get_text(' ', strip=True)
            if is_amendment:
                # Fetch ALL chapters of a correction, even when a financial
                # link exists, so the inspector can prove exhaustive coverage.
                # Its actual text is classified by the parser/service;
                # absence of financial links is not proof of no numeric change.
                targets = list(dict.fromkeys(target for target, _ in links))
            if not targets:
                raise ValueError('no financial chapters')
        except (ValueError, KeyError, TypeError) as exc:
            raise FetchError(f'{doc_id}: 閲覧可能なXBRL財務諸表を確認できません。公開停止・PDFのみ・閲覧方式の変更の可能性があります。') from exc

        # Include the cover because ix:resources/context definitions can live
        # there even when the financial chapters contain only numeric facts.
        first_filename = links[0][0].split('#', 1)[0]
        pages = [(first_filename, first_pages[0])]
        seen = {first_filename}
        try:
            marker = _ajax_marker(state)
            ajax_url = f'{VIEWER}?{marker},{doc_id},gx-no-cache={int(time.time() * 1000)}'
            headers = {'GxAjaxRequest': '1', 'Content-Type': 'application/json',
                       'AJAX_SECURITY_TOKEN': state['AJAX_SECURITY_TOKEN'],
                       'X-GXAUTH-TOKEN': state['GX_AUTH_WZEK0040'], 'Referer': url}
            hashes = [{'hsh': state['gxhash_vW_BUHIN_RETMSG'], 'row': ''},
                      {'hsh': state['gxhash_vP_SYORUI_KANRI_NO'], 'row': ''}]
            for target in targets:
                filename = target.split('#', 1)[0]
                if filename in seen:
                    continue
                payload = {'MPage': False, 'cmpCtx': '',
                           'parms': [state['vW_SESSIONKEY'], target, '', '', doc_id],
                           'hsh': hashes, 'objClass': 'wzek0040',
                           'pkgName': 'GeneXus.Programs',
                           'events': ["'ONLINKCLICK'"], 'grids': {}}
                response = _request(session, 'POST', ajax_url, json=payload,
                                    headers=headers, log=log, cancel=cancel)
                result = response.json()
                bodies = _reloads(result.get('gxCommands', []))
                if not bodies:
                    raise ValueError('no original chapter in response')
                pages.append((filename, bodies[0]))
                seen.add(filename)
        except (ValueError, KeyError, TypeError) as exc:
            raise FetchError(f'{doc_id}: EDINET公開閲覧の応答形式を確認できません。取得を停止しました。') from exc

    _check_cancel(cancel)
    if len(pages) < 2:
        raise FetchError(f'{doc_id}: 財務諸表または訂正書類の本文を取得できませんでした。')
    _cache_write(directory, doc_id, pages)
    log(f'{doc_id}: 原本{len(pages)}ファイルを保存（SHA-256付き）')
    return pages
