"""Forecasts are labelled UI projections, never official calendar evidence."""
from copy import deepcopy
from datetime import date

from zaimu10.calendar_projection import (project_annual_estimates,one_year_later,
    with_estimated_next_date,centered_calendar_start)
from zaimu10.gui import calendar_event_view,calendar_values


TODAY=date(2026,11,25)
RECORD={'code':'6947','company':'株式会社図研','latest_period_end':'2026-03-31'}


def event(day='2026-05-14',kind='actual',period='2026-03',code='6947',**extra):
    return dict(code=code,company='株式会社図研',date=day,kind=kind,
        fiscal_month=period,fiscal_end=period+'-31' if period else None,
        fiscal_period=f'{period[:4]}年{int(period[5:])}月期' if period else '通期',
        period_type='annual',is_annual=True,source_url='https://www.jpx.co.jp/actual.pdf',
        source_title='本決算の発表実績',**extra)


def predictions(events):return [e for e in events if e['kind']=='estimated']


def test_real_date_anniversary_has_explicit_nonofficial_status_and_preserves_sources():
    original=[event()];before=deepcopy((RECORD,original))
    result=project_annual_estimates([RECORD],original,today=TODAY)
    p=predictions(result)[0]
    assert p['date']=='2027-05-14' and p['fiscal_end']=='2027-03-31'
    assert p['projection_only'] is True and p['estimate_base_date']=='2026-05-14'
    assert p['source_url']==original[0]['source_url'] and '公式' in p['estimation_note']
    assert (RECORD,original)==before
    p['base_event']['date']='changed'
    assert original[0]['date']=='2026-05-14'


def test_leap_day_anniversary_and_fiscal_end_are_clamped():
    assert one_year_later(date(2024,2,29))==date(2025,2,28)
    source=event(day='2024-02-29',period='2024-02');source['fiscal_end']='2024-02-29'
    p=predictions(project_annual_estimates([RECORD],[source],today=TODAY))[0]
    assert p['date']=='2025-02-28' and p['fiscal_end']=='2025-02-28'


def test_latest_actual_not_filing_or_latest_scheduled_drives_the_anniversary():
    record={**RECORD,'latest_submitted':'2026-06-19','announcement_date':'2026-06-19'}
    assert not predictions(project_annual_estimates([record],[],today=TODAY))
    assert not predictions(project_annual_estimates([record],[event(day='2027-05-16',kind='scheduled',period='2027-03')],today=TODAY))
    result=project_annual_estimates([record],[event(day='2025-05-10',period='2025-03'),event()],today=TODAY)
    assert predictions(result)[0]['date']=='2027-05-14'


def test_future_or_nonannual_actual_cannot_create_forecasts():
    quarterly=event();quarterly.update(period_type='quarter',is_annual=False)
    result=project_annual_estimates([RECORD],[event(day='2027-05-14',period='2027-03'),quarterly],today=TODAY)
    assert not predictions(result)


def test_official_same_company_and_fiscal_year_wins_even_when_date_differs():
    for kind in ('actual','scheduled'):
        actual=event(day='2025-05-10',period='2025-03')
        confirmed=event(day='2026-05-20',kind=kind,period='2026-03')
        result=project_annual_estimates([RECORD],[actual,confirmed],today=TODAY)
        # An actual becomes the new basis, not a duplicate estimate for FY2026.
        assert not any(e['fiscal_month']=='2026-03' for e in predictions(result))
    assert not predictions(project_annual_estimates([RECORD],[event(),event(day='2027-05-20',kind='scheduled',period='2027-03')],today=TODAY))


def test_other_company_and_other_known_fiscal_period_do_not_suppress_target():
    result=project_annual_estimates([RECORD],[event(),event(day='2027-05-20',kind='scheduled',period='2028-03'),event(day='2027-05-14',kind='scheduled',period='2027-03',code='7826')],today=TODAY)
    assert predictions(result)[0]['fiscal_month']=='2027-03'


def test_unspecified_official_upcoming_period_suppresses_ambiguous_duplicate():
    assert not predictions(project_annual_estimates([RECORD],[event(),event(day='2027-05-20',kind='scheduled',period=None)],today=TODAY))


def test_quarterly_schedule_is_not_an_official_annual_override_or_next_annual_date():
    quarter=event(day='2027-05-20',kind='scheduled',period='2027-03');quarter.update(period_type='quarter',is_annual=False)
    result=project_annual_estimates([RECORD],[event(),quarter],today=TODAY)
    assert len(predictions(result))==1
    row=with_estimated_next_date(RECORD,result,today=TODAY)
    assert not row.get('display_next_announcement_date')
    assert '予想日' in calendar_values(row)[-1]


def test_projection_is_idempotent_and_never_rolls_old_actual_forward_many_years():
    source=event(day='2022-05-14',period='2022-03')
    result=project_annual_estimates([RECORD],[source],today=TODAY)
    assert predictions(result)[0]['date']=='2023-05-14'
    assert project_annual_estimates([RECORD],result,today=TODAY)==result
    assert not calendar_event_view(result,scope='今後の予定',today=TODAY,year=2026,month=11)


def test_registry_view_adds_forecast_fields_without_replacing_official_fields():
    record={**RECORD,'next_announcement_status':'not_in_checked_sources','next_announcement_date':None}
    result=project_annual_estimates([record],[event()],today=TODAY)
    before=deepcopy(record);view=with_estimated_next_date(record,result,today=TODAY)
    assert record==before and view['next_announcement_date'] is None
    assert calendar_values(view)[-1].startswith('2027-05-14（予想日）')
    official=event(day='2027-05-20',kind='scheduled',period='2027-03')
    view=with_estimated_next_date(record,[official],today=TODAY)
    assert '予想' not in calendar_values(view)[-1] and calendar_values(view)[-1].startswith('2027-05-20')


def test_all_view_is_chronological_with_forecasts_and_upcoming_filter_includes_them():
    p=predictions(project_annual_estimates([RECORD],[event()],today=TODAY))[0]
    result=calendar_event_view([p,event()],scope='すべて',today=TODAY,year=2026,month=11)
    assert [r['kind'] for r in result]==['actual','estimated']
    assert calendar_event_view(result,scope='今後の予定',today=TODAY,year=2026,month=11)==[p]


def test_centered_list_keeps_both_past_and_future_around_today_and_clamps_edges():
    rows=[{'date':f'2026-11-{d:02}'} for d in range(1,31)]
    assert centered_calendar_start(rows,date(2026,11,16),7)==12
    assert centered_calendar_start(rows,date(2026,11,1),7)==0
    assert centered_calendar_start(rows,date(2026,12,20),7)==23
    assert centered_calendar_start([],TODAY,7)==0
