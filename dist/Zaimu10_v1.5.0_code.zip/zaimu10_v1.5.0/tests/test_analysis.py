"""Reference definitions, missing-data safeguards, and chart/table agreement."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest

from zaimu10.analysis import analyze_dataset, bs_metrics, chart_data, metric_terms, used_debt_note_rows, debt_category
from zaimu10.debt_notes import extract_debt_notes
from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source
from zaimu10.parser import parse_filing
from zaimu10.presentation import annotate_filing, prepare_dataset

P = Period(date(2024, 4, 1), date(2025, 3, 31))
O = Period(date(2023, 4, 1), date(2024, 3, 31))
STD = 'http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'
EXT = 'http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E01966-000/2025-03-31/01/2025-06-20'
FIXTURES = Path(__file__).parent / 'fixtures'


def fact(name, value, *, period=P, statement='BS_A', section=(), nil=False,
         basis='consolidated', dims=(), role='end', unit='JPY', label=None, namespace=STD):
    source = Source('S100TEST', 'original.xhtml', 'https://disclosure2.edinet-fsa.go.jp/',
                    concept=f'{{{namespace}}}{name}', basis=basis, unit=unit,
                    original_label=label or name, decimals='-3', scale=3)
    key = json.dumps([statement, name, list(dims), role, unit, basis])
    return Row(key, label or name, statement, section=section,
               values={period.key: Cell(None if value is None else Decimal(value), source, nil=nil,
                                         source_section=section)})


def dataset(*rows, periods=None):
    ds = Dataset('6947', '図研', 'consolidated', periods or [P], accounting_standard='J-GAAP')
    for row in rows:
        ds.rows[row.statement].append(row)
    return ds


def actual(name='zuken_2025', code='6947'):
    content = json.load(gzip.open(FIXTURES / f'{name}_ixbrl.json.gz', 'rt', encoding='utf-8'))
    return prepare_dataset(annotate_filing(parse_filing(Filing('S100FIXTURE', code=code), content)))


def value(result, name, p=P):
    return result.metrics[name].values[p.key].value


def basic_rows():
    return [fact('CurrentAssets', '1000', section=('資産の部', '流動資産')),
            fact('NoncurrentAssets', '800', section=('資産の部', '固定資産')),
            fact('CurrentLiabilities', '600', statement='BS_LE', section=('負債の部', '流動負債'))]


def test_zuken_reference_equations_preserve_signed_allowance_and_cross_sheet_inputs():
    rows = basic_rows() + [
        fact('DeferredTaxAssetsCA', '20', section=('資産の部', '流動資産')),
        fact('DeferredTaxAssets', '30', section=('資産の部', '固定資産', '投資その他の資産')),
        fact('AllowanceForDoubtfulAccountsCA', '-7', section=('資産の部', '流動資産')),
        fact('AllowanceForDoubtfulAccountsIOAByGroup', '-999', section=('資産の部', '固定資産', '投資その他の資産')),
        fact('OtherCA', '888', section=('資産の部', '流動資産')),
        fact('ProvisionForBonuses', '40', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('ProvisionForDirectorsBonuses', '10', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('OtherProvisionCL', '5', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('ShortTermLoansPayable', '100', statement='BS_LE', section=('負債の部', '流動負債'))]
    ds = dataset(*rows)
    before = asdict(ds)
    result = analyze_dataset(ds)
    assert value(result, 'net_noncurrent_assets') == 770
    assert value(result, 'net_current_assets') == 987
    assert value(result, 'net_current_liabilities') == 545  # no debt deduction
    assert value(result, 'net_working_capital') == 442
    assert value(result, 'invested_capital') == 1212
    terms = metric_terms(result.metrics['net_current_assets'].values[P.key])
    assert [sign for sign, _, _ in terms] == [1, -1, -1]
    assert [cell.value for _, _, cell in terms] == [1000, 20, -7]
    assert asdict(ds) == before


def test_real_zuken_source_balances_match_exact_restored_reference_definition():
    ds = actual()
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'net_noncurrent_assets', p) == Decimal('13739027000')
    assert value(result, 'net_current_assets', p) == Decimal('48527222000')
    assert value(result, 'net_current_liabilities', p) == Decimal('18028620000')
    assert value(result, 'net_working_capital', p) == Decimal('30498602000')
    assert value(result, 'invested_capital', p) == Decimal('44237629000')
    assert value(result, 'interest_bearing_debt', p) is None  # absent is not explicit zero
    assert '注記' in result.metadata['interest_bearing_debt'][p.key]['reason']
    for name in ['net_noncurrent_assets', 'net_current_assets', 'net_current_liabilities']:
        assert all(cell.source.doc_id == 'S100FIXTURE' for _, _, cell in metric_terms(result.metrics[name].values[p.key]))


def test_furuya_other_current_assets_and_long_other_payable_are_not_adopted_as_zuken_terms():
    ds = actual('furuya_2017', '7826')
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'net_current_assets', p) == Decimal('11290000000')  # 11,605-315; not -OtherCA34
    assert value(result, 'interest_bearing_debt', p) == Decimal('2489000000')
    debt_sources = [c.source.concept for _, _, c in metric_terms(result.metrics['interest_bearing_debt'].values[p.key])]
    assert not any('LongTermAccountsPayableOther' in c for c in debt_sources)


def test_nil_known_operand_propagates_without_becoming_zero_but_numeric_zero_is_valid():
    ds = dataset(*basic_rows(), fact('AllowanceForDoubtfulAccountsCA', None, nil=True, section=('資産の部', '流動資産')))
    result = analyze_dataset(ds)
    assert value(result, 'net_current_assets') is None
    assert value(result, 'net_working_capital') is None
    assert value(result, 'invested_capital') is None
    assert 'nil' in result.metadata['net_current_assets'][P.key]['reason']
    ds.rows['BS_A'][-1].values[P.key] = Cell(Decimal(0), ds.rows['BS_A'][-1].values[P.key].source)
    assert value(analyze_dataset(ds), 'net_current_assets') == 1000
    ds = actual('furuya_2026', '7826')
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'interest_bearing_debt', p) is None
    assert 'nil' in result.metadata['interest_bearing_debt'][p.key]['reason']


def test_absent_optional_exclusion_is_omitted_with_proof_and_note_not_a_synthetic_zero():
    result = analyze_dataset(dataset(*basic_rows()))
    cell = result.metrics['net_current_assets'].values[P.key]
    assert cell.value == 1000
    assert len(cell.components) == 1 and cell.components[0].value == 1000
    assert result.metadata['net_current_assets'][P.key]['omitted_absent_inputs'] == ['流動の繰延税金資産', '流動の貸倒引当金']
    assert value(analyze_dataset(dataset()), 'net_current_assets') is None


def test_current_and_noncurrent_tax_with_generic_name_use_original_cell_section():
    current = fact('DeferredTaxAssets', '20', section=('資産の部', '流動資産'))
    noncurrent = fact('DeferredTaxAssets', '30', section=('資産の部', '固定資産', '投資その他の資産'))
    noncurrent.key += ':noncurrent'
    result = analyze_dataset(dataset(*basic_rows(), current, noncurrent))
    assert value(result, 'net_current_assets') == 980
    assert value(result, 'net_noncurrent_assets') == 770
    unknown = fact('DeferredTaxAssets', '50')
    result = analyze_dataset(dataset(*basic_rows(), unknown))
    assert value(result, 'net_current_assets') is None
    assert value(result, 'net_noncurrent_assets') is None


def test_extension_tax_exact_original_label_and_section_are_auditable_not_ignored():
    extension = fact('CustomDeferredTax', '12', namespace=EXT, label='繰延税金資産', section=('資産の部', '固定資産', '投資その他の資産'))
    result = analyze_dataset(dataset(*basic_rows(), extension))
    assert value(result, 'net_noncurrent_assets') == 788
    assert metric_terms(result.metrics['net_noncurrent_assets'].values[P.key])[-1][2].source.concept.endswith('CustomDeferredTax')


def test_provision_subtotal_replaces_breakdown_and_noncurrent_provisions_stay_excluded():
    rows = basic_rows() + [fact('ProvisionsCLIFRS', '70', statement='BS_LE'),
                          fact('ProvisionForBonuses', '50', statement='BS_LE', section=('負債の部', '流動負債')),
                          fact('ProvisionForRetirementBenefits', '999', statement='BS_LE', section=('負債の部', '固定負債'))]
    result = analyze_dataset(dataset(*rows))
    assert value(result, 'net_current_liabilities') == 530
    assert len(metric_terms(result.metrics['net_current_liabilities'].values[P.key])) == 2


def test_opaque_financial_liability_blocks_full_debt_and_no_debt_nil_inference():
    rows = [fact('BorrowingsCLIFRS', '100', statement='BS_LE'),
            fact('OtherFinancialLiabilitiesCLIFRS', '5', statement='BS_LE')]
    result = analyze_dataset(dataset(*rows))
    assert value(result, 'interest_bearing_debt') is None
    assert 'その他の金融負債' in result.metadata['interest_bearing_debt'][P.key]['reason']
    rows[1].values[P.key].value = Decimal(0)
    assert value(analyze_dataset(dataset(*rows)), 'interest_bearing_debt') == 100
    zero = fact('ShortTermLoansPayable', '0', statement='BS_LE')
    assert value(analyze_dataset(dataset(zero)), 'interest_bearing_debt') is None  # one component is not a full zero proof
    complete_zero=[zero]+[fact(n,'0',statement='BS_LE')for n in
                          ['CurrentPortionOfLongTermLoansPayable','LeaseObligationsCL','BondsPayable','LongTermLoansPayable','LeaseObligationsNCL']]
    assert value(analyze_dataset(dataset(*complete_zero)), 'interest_bearing_debt') == 0
    assert value(analyze_dataset(dataset()), 'interest_bearing_debt') is None


def test_totals_refuse_wrong_basis_dimensions_currency_beginning_and_ambiguous_values():
    for kwargs in [{'basis':'standalone'}, {'dims':(('axis','member'),)}, {'role':'begin'}, {'unit':'USD'}]:
        assert bs_metrics(dataset(fact('CurrentAssets', '100', **kwargs)))['current_assets'].values == {}
    conflicting = fact('CurrentAssets', '200'); conflicting.key += ':conflict'
    assert bs_metrics(dataset(fact('CurrentAssets', '100'), conflicting))['current_assets'].values == {}


def test_chart_period_order_missing_zero_negative_ratio_and_public_sources():
    rows = [fact('NetSales', '1000000', statement='PL', role='duration'),
            fact('GrossProfit', '-50000', statement='PL', role='duration'),
            fact('OperatingIncome', '0', statement='PL', role='duration'),
            fact('NetSales', '0', statement='PL', role='duration', period=O)]
    chart = chart_data(dataset(*rows, periods=[P, O]), 'thousand')
    assert [p['label'] for p in chart['periods']] == ['2024/03', '2025/03']
    assert chart['PL']['revenue']['values'] == [Decimal(0), Decimal(1000)]
    assert chart['PL']['gross_profit']['values'] == [None, Decimal(-50)]
    assert chart['PL']['gross_margin']['values'] == [None, Decimal('-0.05')]
    assert chart['PL']['operating_margin']['values'] == [None, Decimal(0)]
    assert chart['PL']['gross_profit']['cells'][1].source.url.startswith('https://')
    assert chart['BS']['equity']['values'] == [None, None]
    assert chart['CF']['cash']['values'] == [None, None]
    with pytest.raises(ValueError):
        chart_data(dataset(), 'arbitrary')


def test_chart_prefers_exported_final_table_values_with_unit_conversion_and_explicit_blank():
    ds = dataset(fact('NetSales', '1000000', statement='PL', role='duration'),
                 fact('GrossProfit', '499000', statement='PL', role='duration'),
                 fact('CurrentAssets', '1000000'))
    ds.export_metadata = {'unit':'million', 'cells':[
        {'sheet':'PL', 'row_key':'metric:revenue', 'period':P.key, 'display_value':'1', 'unit':'million'},
        {'sheet':'PL', 'row_key':'metric:gross_profit', 'period':P.key, 'display_value':'0.5', 'unit':'million'},
        {'sheet':'BS-A', 'row_key':ds.rows['BS_A'][0].key, 'period':P.key, 'display_value':None, 'unit':'million'}]}
    chart = chart_data(ds, 'thousand')
    assert chart['PL']['gross_profit']['values'] == [Decimal(500)]
    assert chart['PL']['gross_margin']['values'] == [Decimal('0.5')]
    assert chart['BS']['current_assets']['values'] == [None]
    assert chart['PL']['gross_profit']['cells'][0].value == 499000  # source evidence retained


def test_real_ifrs_chart_does_not_replace_total_equity_with_parent_equity():
    ds = actual('nitori_2026', '9843')
    chart = chart_data(ds, 'million')
    assert chart['BS']['equity']['values'][-1] == Decimal('988570')
    assert chart['BS']['equity']['values'][-1] != Decimal('988559')
    result = analyze_dataset(ds)
    assert value(result, 'interest_bearing_debt', ds.periods[-1]) is None


def test_chart_resolves_original_bs_source_key_to_canonical_exported_address():
    row = fact('CurrentAssets', '999000')
    ds = dataset(row)
    ds.export_metadata = {'unit':'thousand', 'source_addresses':{
        row.key: {P.key:{'sheet':'BS-A', 'address':'B20', 'row_key':'canonical:current_assets'}}},
        'cells':[{'sheet':'BS-A', 'address':'B20', 'row_key':'canonical:current_assets',
                  'period':P.key, 'display_value':'1000', 'unit':'thousand'}]}
    assert chart_data(ds, 'million')['BS']['current_assets']['values'] == [Decimal(1)]


def test_same_period_other_framework_total_is_refused_even_with_same_currency_and_basis():
    row = fact('CurrentAssets', '100')
    row.key = json.dumps(['BS_A', 'jppfs_cor', 'CurrentAssets', [], 'end', 'JPY',
                          'consolidated', 'IFRS', []])
    ds = dataset(row)
    assert bs_metrics(ds)['current_assets'].values == {}
    assert value(analyze_dataset(ds), 'net_current_assets') is None


def note(category, value, *, period=P, operation='', basis='consolidated'):
    source = Source('S100TEST','notes.xhtml','https://disclosure2.edinet-fsa.go.jp/',
                    concept='{http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor}AnnexedConsolidatedDetailedScheduleOfBorrowingsTextBlock',
                    context_id='CurrentYearDuration',basis=basis,unit='JPY',decimals='0',
                    original_label=category,raw_value='－' if operation=='explicit_no_balance' else str(value))
    return Row(f'notes:debt:{category}:{basis}',category,'BS_LE',values={period.key:
               Cell(None if value is None else Decimal(value),source,operation=operation)})


def actual_with_notes(name='zuken_2025',code='6947'):
    content=json.load(gzip.open(FIXTURES/f'{name}_ixbrl.json.gz','rt',encoding='utf8'))
    raw=annotate_filing(parse_filing(Filing('S100FIXTURE',code=code),content))
    raw.analysis_inputs=extract_debt_notes(content,raw)
    return prepare_dataset(raw)


def test_real_zuken_lease_buried_in_other_is_recovered_from_notes_without_guessing_zero():
    ds=actual_with_notes();before=asdict(ds);result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt',ds.periods[-1])==Decimal('115778000')
    assert value(result,'interest_bearing_debt',ds.periods[0])==Decimal('98498000')
    rows=used_debt_note_rows(ds,result)
    leases=[r for r in rows if r.key.split(':')[2]in{'current_lease','noncurrent_lease'}]
    assert len(leases)==2 and all(len(r.values)==2 for r in leases)
    assert all(c.source.concept.endswith('}AnnexedConsolidatedDetailedScheduleOfBorrowingsTextBlock')for r in leases for c in r.values.values())
    assert all(c.value==0 and c.operation=='explicit_no_balance'for r in rows if r not in leases for c in r.values.values())
    assert all('debt_note_evidence:' in c.note for r in rows for c in r.values.values())
    assert asdict(ds)==before


def test_real_furuya_annex_total_does_not_erase_main_short_term_borrowing_or_double_count_peers():
    ds=actual_with_notes('furuya_2017','7826');p=ds.periods[-1];result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt',p)==Decimal('2489000000')
    assert not any(r.key.split(':')[2]=='short_term_borrowings' for r in ds.analysis_inputs)
    assert all(c.value==0 for row in used_debt_note_rows(ds,result)for c in row.values.values())  # positive peers already in BS
    assert 'borrowings_coverage' in result.metadata['interest_bearing_debt'][p.key]['coverage']['note_status']


def test_notes_same_scope_conflict_is_unknown_not_hidden_by_main_priority():
    main=fact('LeaseObligationsCL','1000000',statement='BS_LE')
    ds=dataset(main);ds.analysis_inputs=[note('current_lease','2000000')]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')is None
    assert '本表と注記' in result.metadata['interest_bearing_debt'][P.key]['reason']


def test_explicit_note_zero_repairs_nil_balance_but_an_absent_note_does_not():
    main=fact('ShortTermLoansPayable',None,statement='BS_LE',nil=True)
    ds=dataset(main)
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None
    ds.analysis_inputs=[note('short_term_borrowings','0',operation='explicit_no_balance')]
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None  # other debt categories not yet established
    ds.analysis_inputs.extend(note(category,'0',operation='explicit_no_balance')for category in
                              ['current_long_term_borrowings','current_lease','bonds','long_term_borrowings','noncurrent_lease'])
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==0
    assert metric_terms(result.metrics['interest_bearing_debt'].values[P.key])[0][1].startswith('notes:debt:')


def test_note_failure_blanks_only_debt_even_when_main_borrowing_is_numeric():
    ds=dataset(*basic_rows(),fact('ShortTermLoansPayable','1000000',statement='BS_LE'))
    base=analyze_dataset(ds)
    ds.analysis_input_errors[P.key]=['注記表の期末列が不明です。']
    out=analyze_dataset(ds)
    assert value(out,'interest_bearing_debt')is None
    assert '期末列' in out.metadata['interest_bearing_debt'][P.key]['reason']
    for name in set(out.metrics)-{'interest_bearing_debt'}:
        assert value(out,name)==value(base,name)
    assert ds.warnings==[]


def test_zero_requires_verified_non_debt_decomposition_and_rejects_generic_other():
    rows=[fact('IncomeTaxesPayable','100000',statement='BS_LE',section=('負債の部','流動負債')),
          fact('CurrentLiabilities','100000',statement='BS_LE',section=('負債の部','流動負債')),
          fact('NetDefinedBenefitLiability','200000',statement='BS_LE',section=('負債の部','固定負債')),
          fact('NoncurrentLiabilities','200000',statement='BS_LE',section=('負債の部','固定負債')),
          fact('Liabilities','300000',statement='BS_LE',section=('負債の部',))]
    ds=dataset(*rows);result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==0
    assert result.metrics['interest_bearing_debt'].values[P.key].operation=='analysis_zero_proven'
    assert result.metadata['interest_bearing_debt'][P.key]['zero_evidence']
    rows[0]=fact('OtherCL','100000',statement='BS_LE',section=('負債の部','流動負債'))
    assert value(analyze_dataset(dataset(*rows)),'interest_bearing_debt')is None
    rows[0]=fact('IncomeTaxesPayable','90000',statement='BS_LE',section=('負債の部','流動負債'))
    assert value(analyze_dataset(dataset(*rows)),'interest_bearing_debt')is None  # unexplained residual


def test_ifrs_current_borrowing_aggregate_excludes_note_loan_breakdown_but_adds_separate_lease():
    ds=dataset(fact('BorrowingsCLIFRS','100000000',statement='BS_LE'))
    ds.analysis_inputs=[note('short_term_borrowings','40000000'),note('current_long_term_borrowings','60000000'),
                        note('current_lease','10000000'),note('noncurrent_lease','0')]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==Decimal('110000000')
    assert {r.key.split(':')[2]for r in used_debt_note_rows(ds,result)}=={'current_lease','noncurrent_lease'}
    ds.analysis_inputs[0].values[P.key].value=Decimal('90000000')
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None


def test_proven_html_interest_bearing_aggregates_already_include_note_lease():
    short=fact('BorrowingsCLIFRS','135000000',statement='BS_LE',label='短期有利子負債')
    long=fact('BorrowingsNCLIFRS','510000000',statement='BS_LE',label='長期有利子負債')
    for row in [short,long]:
        cell=row.values[P.key];local=cell.source.concept.rsplit('}',1)[-1]
        cell.source.semantic_concept='{urn:zaimu10:html-table:E00932:IFRS}'+local
        cell.source.concept='{http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2016-02-29/jpcrp_cor}ConsolidatedStatementOfFinancialPositionIFRSTextBlock'
        cell.source.table_path='table1/row2/column3'
    ds=dataset(short,long)
    ds.analysis_inputs=[note('current_lease','135000000'),note('noncurrent_lease','510000000')]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==Decimal('645000000')
    assert used_debt_note_rows(ds,result)==[]
    assert len(metric_terms(result.metrics['interest_bearing_debt'].values[P.key]))==2


def test_used_note_rows_keep_only_adopted_periods_and_ignore_other_basis():
    main=fact('LeaseObligationsCL','1000000',statement='BS_LE',period=O)
    ds=dataset(main,periods=[O,P])
    source=note('current_lease','1000000',period=O)
    source.values.update(note('current_lease','2000000',period=P).values)
    wrong=note('long_term_borrowings','999999999',basis='standalone')
    ds.analysis_inputs=[source,wrong]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt',O)==1000000
    assert value(result,'interest_bearing_debt',P)==2000000
    [used]=used_debt_note_rows(ds,result)
    assert set(used.values)=={P.key}


def test_ifrs_lease_notes_need_nonlease_coverage_to_resolve_opaque_financial_balances():
    ds=dataset(fact('OtherFinancialLiabilitiesCLIFRS','50000000',statement='BS_LE'),
               fact('OtherFinancialLiabilitiesNCLIFRS','100000000',statement='BS_LE'))
    ds.analysis_inputs=[note('current_lease','10000000'),note('noncurrent_lease','20000000')]
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None
    ds.analysis_inputs.append(note('nonlease_debt_absent','0',operation='explicit_no_nonlease_debt'))
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==Decimal('30000000')
    assert 'nonlease_debt_absent' in result.metadata['interest_bearing_debt'][P.key]['coverage']['note_status']


def test_actual_early_ifrs_colon_headings_preserve_tax_and_current_provision_scope():
    pages=json.load(gzip.open(FIXTURES/'chugai_2016_html_main.json.gz','rt',encoding='utf8'))
    raw=annotate_filing(parse_filing(Filing('S1009X6V',code='4519',edinet_code='E00932',company='中外製薬'),pages))
    assert any('：'in part or ':'in part for row in raw.rows['BS_A']for cell in row.values.values()for part in cell.source_section)
    ds=prepare_dataset(raw);result=analyze_dataset(ds);p=ds.periods[-1]
    assert value(result,'net_noncurrent_assets',p)==Decimal('200051000000')  # 227,525-27,474 million
    assert value(result,'net_current_liabilities',p)==Decimal('123584000000')  # 123,660-76 million
    assert value(result,'interest_bearing_debt',p)==Decimal('645000000')
    assert result.metadata['net_noncurrent_assets'][p.key]['complete']
    assert result.metadata['net_current_liabilities'][p.key]['complete']


def test_heading_punctuation_normalization_does_not_turn_internal_text_into_a_scope():
    unknown=fact('DeferredTaxAssets','20',section=('注記:流動資産',))
    assert value(analyze_dataset(dataset(*basic_rows(),unknown)),'net_current_assets')is None


def test_bounded_ifrs_note_scope_sums_defined_debt_and_preserves_unclassified_other():
    ds=dataset(fact('BorrowingsCLIFRS','100000000',statement='BS_LE'),
               fact('BorrowingsNCLIFRS','20000000',statement='BS_LE'),
               fact('OtherFinancialLiabilitiesCLIFRS','50000000',statement='BS_LE'),
               fact('OtherFinancialLiabilitiesNCLIFRS','60000000',statement='BS_LE'))
    ds.analysis_inputs=[note('short_term_borrowings','40000000'),
                        note('current_long_term_borrowings','60000000'),
                        note('long_term_borrowings','20000000'),
                        note('current_lease','10000000'),note('noncurrent_lease','30000000'),
                        note('ifrs_borrowings_coverage',None,operation='ifrs_borrowings_complete')]
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None
    coverage=note('financial_liabilities_coverage',None,operation='financial_liabilities_complete')
    coverage.values[P.key].note='debt_note_evidence:'+json.dumps({'excluded_rows':[
        {'label':'その他','value_jpy':'1001000000'},{'label':'預り敷金保証金','value_jpy':'5000000'}]})
    ds.analysis_inputs.append(coverage)
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==Decimal('160000000')  # loans120+leases40; never Other/Deposits
    detail=result.metadata['interest_bearing_debt'][P.key]
    assert detail['coverage']['bounded_ifrs_core_scope']
    assert [r['label']for r in detail['excluded_financial_components']]==['その他','預り敷金保証金']
    assert all('断定しない'in r['scope_reason']for r in detail['excluded_financial_components'])
    assert 'その他: 1001000000円'in result.metrics['interest_bearing_debt'].values[P.key].note


def test_real_standard_short_term_caption_can_be_a_validated_current_loan_aggregate():
    examples=json.loads((FIXTURES/'current_loan_scope_examples.json').read_text(encoding='utf8'))
    for example in examples:
        period=Period(date.fromisoformat(example['period']['start']),date.fromisoformat(example['period']['end']))
        def load_row(raw):
            attrs={k:v for k,v in raw.items()if k not in {'values','section'}}
            values={}
            for key,item in raw['values'].items():
                ca={k:v for k,v in item.items()if k not in {'value','source','components','source_section'}}
                values[key]=Cell(None if item['value']is None else Decimal(item['value']),Source(**item['source']),
                                 source_section=None if item.get('source_section')is None else tuple(item['source_section']),**ca)
            return Row(**attrs,section=tuple(raw['section']),values=values)
        ds=Dataset(example['code'],example['company'],example['basis'],[period],accounting_standard=example['accounting_standard'])
        ds.rows['BS_LE']=[load_row(r)for r in example['main_rows']]
        ds.analysis_inputs=[load_row(r)for r in example['notes']]
        before=asdict(ds);result=analyze_dataset(ds)
        expected=Decimal('7477000000')if example['code']=='7309'else Decimal('625000000')
        assert value(result,'interest_bearing_debt',period)==expected
        proof=result.metadata['interest_bearing_debt'][period.key]['current_loan_aggregate_proof']
        assert proof['doc_id']==example['primary_doc']
        assert abs(Decimal(proof['main_value_jpy'])-Decimal(proof['note_sum_jpy']))<=Decimal(proof['rounding_tolerance_jpy'])
        terms=metric_terms(result.metrics['interest_bearing_debt'].values[period.key])
        assert len(terms)==1 and terms[0][1]==ds.rows['BS_LE'][0].key
        assert used_debt_note_rows(ds,result)==[] and asdict(ds)==before


@pytest.mark.parametrize('case',['separate_current_lt','wrong_doc','other_category','material_difference'])
def test_current_loan_scope_inference_refuses_unproven_or_conflicting_relationships(case):
    ds=dataset(fact('ShortTermLoansPayable','125000000',statement='BS_LE'))
    ds.analysis_inputs=[note('short_term_borrowings','100000000'),
                        note('current_long_term_borrowings','25000000'),
                        note('borrowings_coverage',None,operation='debt_schedule_complete')]
    if case=='separate_current_lt':
        ds.rows['BS_LE'].append(fact('CurrentPortionOfLongTermLoansPayable','25000000',statement='BS_LE'))
    elif case=='wrong_doc':
        for row in ds.analysis_inputs:row.values[P.key].source.doc_id='S100OTHER'
    elif case=='other_category':
        ds.analysis_inputs[1]=note('current_lease','25000000')
    else:
        ds.rows['BS_LE'][0].values[P.key].value=Decimal('130000000')
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')is None
    assert 'current_loan_aggregate_proof'not in result.metadata['interest_bearing_debt'][P.key]


def interest_total(current,noncurrent):
    ns='http://disclosure.edinet-fsa.go.jp/taxonomy/jpigp/2018-03-31/jpigp_cor'
    return dataset(fact('InterestBearingLiabilitiesCLIFRS',current,statement='BS_LE',namespace=ns,nil=current is None),
                   fact('InterestBearingLiabilitiesNCLIFRS',noncurrent,statement='BS_LE',namespace=ns,nil=noncurrent is None))


def test_actual_standard_whole_interest_totals_recover_chugai_2018_without_historical_fallback():
    item=json.loads((FIXTURES/'standard_interest_total_example.json').read_text(encoding='utf8'))
    assert item['primary_doc']=='S100IAU4'
    period=Period(date.fromisoformat(item['period']['start']),date.fromisoformat(item['period']['end']))
    ds=Dataset(item['code'],item['company'],item['basis'],[period],accounting_standard=item['accounting_standard'])
    for raw in item['main_rows']:
        old=next(iter(raw['values'].values()));source=Source(**old['source'])
        row=fact(source.account_concept.rsplit('}',1)[-1],old['value'],period=period,statement='BS_LE',namespace=source.account_concept[1:].split('}',1)[0])
        row.values[period.key].source=source;ds.rows['BS_LE'].append(row)
    ds.analysis_inputs=[note('current_lease','0',period=period),note('noncurrent_lease','0',period=period)]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt',period)==Decimal('215000000')
    cell=result.metrics['interest_bearing_debt'].values[period.key]
    assert len(metric_terms(cell))==2 and all(not key.startswith('notes:')for _,key,_ in metric_terms(cell))
    assert result.metadata['interest_bearing_debt'][period.key]['coverage']['whole_reported_interest_bearing_scope']


def test_numeric_whole_interest_totals_do_not_add_contained_lease_components_again():
    ds=interest_total('100000000','60000000')
    ds.analysis_inputs=[note('short_term_borrowings','30000000'),note('current_lease','70000000'),
                        note('long_term_borrowings','30000000'),note('noncurrent_lease','30000000')]
    result=analyze_dataset(ds)
    assert value(result,'interest_bearing_debt')==Decimal('160000000')
    assert used_debt_note_rows(ds,result)==[]
    ds.analysis_inputs[1].values[P.key].value=Decimal('110000000')
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None


@pytest.mark.parametrize('current,noncurrent',[(None,None),(None,'0'),('0',None)])
def test_missing_whole_interest_totals_never_become_a_zero_debt_from_nonlease_only(current,noncurrent):
    ds=interest_total(current,noncurrent)
    ds.analysis_inputs=[note(c,'0',operation='explicit_no_balance')for c in
                        ['short_term_borrowings','current_long_term_borrowings','long_term_borrowings','bonds','current_bonds','commercial_paper']]
    ds.analysis_inputs.append(note('nonlease_debt_absent','0',operation='explicit_no_nonlease_debt'))
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None
    if current is None and noncurrent is None:
        ds.analysis_inputs.extend([note('current_lease','7263000000'),note('noncurrent_lease','5489000000')])
        assert value(analyze_dataset(ds),'interest_bearing_debt')==Decimal('12752000000')


def test_standard_interest_total_scope_is_not_assumed_for_an_issuer_local_name():
    row=fact('InterestBearingLiabilitiesCLIFRS','100',statement='BS_LE',namespace=EXT)
    assert debt_category(row)is None


def test_whole_interest_total_cannot_hide_a_positive_primary_component_under_zero():
    ds=interest_total('0','0')
    ds.rows['BS_LE'].append(fact('LeaseObligationsCL','10000000',statement='BS_LE'))
    assert value(analyze_dataset(ds),'interest_bearing_debt')is None
