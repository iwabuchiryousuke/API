from datetime import date
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
import json

from openpyxl import Workbook,load_workbook
from openpyxl.worksheet.formula import ArrayFormula
import pytest

from zaimu10.capm import (calibration_window,linest,market_horizon,write_capm,
                          TEMPLATE_PATH,RISK_FREE_RATE,MARKET_RISK_PREMIUM)
from zaimu10.models import Dataset,Period,Cell,Source,Row

D=Decimal

class Refs:
    def __init__(self, writer, *, debt=D(300), interest=D(-30), shareholder=D(1000), parent_profit=D(80)):
        self.writer=writer;self.debt=debt;self.interest=interest;self.shareholder=shareholder
        self.parent_profit=parent_profit;self.parent_refs={}
    def parent_profit_input(self,period):
        if self.parent_profit is None:return None
        source=Source('S100SOURCE','source.htm','https://example.test/official',concept='jppfs_cor:ProfitLossAttributableToOwnersOfParent',unit='JPY')
        return SimpleNamespace(row=Row('parent_profit','親会社株主に帰属する当期純利益','PL'),
            fact=Cell(self.parent_profit*self.writer.factor,source),visible=None,reason='Exact parent profit, excluding noncontrolling profit')
    def register_parent_profit(self,period,address):
        self.parent_refs[period.key]=SimpleNamespace(sheet='CAPM',address=address,
            value=self.writer.values[('CAPM',address)],excel="'CAPM'!"+address)
    def get(self,name,period):
        if name=='net_profit_parent':return self.parent_refs.get(period.key)
        column='B' if period.end.year==2023 else 'C'
        source={'interest_bearing_debt':('BS-L,E',42,self.debt),
                'interest_paid':('CF',35,self.interest),
                'net_profit':('PL',19,D(100)),
                'shareholders_equity':('BS-L,E',30,self.shareholder)}.get(name)
        if source is None or source[2] is None:return None
        sheet,row,value=source
        self.writer.book[sheet][f'{column}{row}']=float(value)
        return SimpleNamespace(sheet=sheet,address=f'{column}{row}',value=value,
                               excel=f"'{sheet}'!{column}{row}")


def example(*,code='7826',**kwargs):
    periods=[Period(date(y,1,1),date(y,12,31)) for y in [2023,2024]]
    ds=Dataset(code,'株式会社テスト','consolidated',periods)
    book=Workbook();book.active.title='PL'
    for name in ['BS-A','BS-L,E','CF','DCF']:book.create_sheet(name)
    writer=SimpleNamespace(book=book,periods=periods,factor=D(1000),unit='thousand',unit_label='千円',
        values={('DCF','B13'):D('.3'),('DCF','C13'):D('.3')},cached={},cells=[],layout_metadata={})
    book['DCF']['B13']=.3;book['DCF']['C13']=.3
    refs=Refs(writer,**kwargs)
    stock=[];index=[]
    # Nonconstant paired integer closing-price series from Dec2018 to Aug2024.
    for year in range(2018,2025):
        for month in range(1,13):
            if year==2018 and month<12 or year==2024 and month>8:continue
            n=(year-2018)*12+month
            stamp=f'{year}-{month:02d}'
            stock.append(dict(month=stamp,date=f'{stamp}-28',close=str(1000+13*n+(n%7)*9)+'.75'))
            index.append(dict(month=stamp,date=f'{stamp}-28',close=str(30000+71*n+(n%5)*30)+'.99'))
    market={'code':code,'benchmark':'^N225','stock_symbol':code+'.T',
            'stock_rows':stock,'index_rows':index,'end_month':'2024-08',
            'market_caps':{periods[0].key:dict(value_jpy='1000000',date='2023-12-31'),
                           periods[1].key:dict(value_jpy='1200000',date='2024-12-31')},
            'source_provenance':{'stock':{'source_url':'https://example.test/stock'},'index':{'source_url':'https://example.test/index'}}}
    return writer,ds,refs,market


def test_original_linest_cached_betas_and_intercepts_independent_reference():
    fixture=json.loads((Path(__file__).parent/'fixtures/capm_reference.json').read_text())
    for sample in fixture:
        rows={row['row']:row for row in sample['rows']}
        for regression in sample['regressions']:
            ys=[];xs=[]
            for n in range(regression['first_row'],regression['last_row']+1):
                ys.append(D(rows[n]['stock'])/D(rows[n+1]['stock'])-1)
                xs.append(D(rows[n]['index'])/D(rows[n+1]['index'])-1)
            beta,intercept=linest(ys,xs)
            assert float(beta)==pytest.approx(regression['beta'],abs=2e-14)
            assert float(intercept)==pytest.approx(regression['intercept'],abs=2e-14)


def test_historical_windows_do_not_copy_future_2014_beta():
    periods=[Period(date(2011,1,1),date(2011,12,31)),Period(date(2026,1,1),date(2026,12,31))]
    assert market_horizon(periods,today=date(2026,11,20))==('2006-12','2026-10')
    assert calibration_window(2011,2026,'2026-10')==('2007-01','2011-12')
    assert calibration_window(2026,2026,'2026-10')==('2022-01','2026-10')


def test_reference_top_formulas_and_array_linest_preserved():
    writer,ds,refs,market=example()
    metadata=write_capm(writer,ds,market,refs)
    ws=writer.book['CAPM']
    assert ws['B2'].value=="='BS-L,E'!B42"
    assert ws['B3'].value=="=-'CF'!B35/B2"
    assert ws['B5'].value=='=B4'
    assert ws['C5'].value=='=(B4+C4)/2'
    assert ws['B6'].value=='=H22' and ws['C6'].value=='=H21'
    assert ws['B7'].value=='=M9+B6*O9' and ws['C7'].value=='=M9+H21*O9'
    assert ws['B11'].value=="='CAPM'!B14/'BS-L,E'!B30"
    assert ws['B14'].value==80
    assert writer.cached[('CAPM','B11')]==D('.08')
    assert ws['B12'].value=='=B11*30%'
    assert ws['B10'].value=="=(B3*(1-'DCF'!B13)*B2+B7*B5)/(B2+B5)"
    assert ws['B13'].value=="=(B3*(1-'DCF'!B13)*B2+B12*B5)/(B2+B5)"
    assert isinstance(ws['H21'].value,ArrayFormula)
    assert ws['H21'].value.ref=='H21:I21'
    assert ws['H21'].value.text.startswith('=LINEST(N16:N71,O16:O71,,FALSE)')
    assert writer.cached[('CAPM','I21')] is not None
    assert metadata['calibrations'][0]['observations']==56
    assert metadata['calibrations'][1]['observations']==60
    assert ws['M15'].value=='日経平均終値'
    assert D(str(ws['M9'].value))==RISK_FREE_RATE
    assert D(str(ws['O9'].value))==MARKET_RISK_PREMIUM
    assert writer.values[('CAPM','B4')]==1000
    assert writer.values[('CAPM','C5')]==1100


def test_raw_precision_is_preserved_but_truncated_for_model_inputs():
    writer,ds,refs,market=example()
    metadata=write_capm(writer,ds,market,refs)
    assert metadata['monthly_inputs'][0]['stock_close_raw'].endswith('.75')
    assert metadata['monthly_inputs'][0]['index_close_raw'].endswith('.99')
    assert not metadata['monthly_inputs'][0]['stock_input'].endswith('.75')
    assert writer.book['CAPM']['N16'].value=='=L16/L17-1'
    assert 'TRUNC' in writer.book['CAPM']['L16'].comment.text


def test_missing_month_does_not_shorten_window_or_interpolate():
    writer,ds,refs,market=example()
    market['stock_rows']=[row for row in market['stock_rows'] if row['month']!='2023-07']
    metadata=write_capm(writer,ds,market,refs)
    assert all(not row['complete'] for row in metadata['calibrations'])
    assert writer.book['CAPM']['B6'].value is None
    assert writer.book['CAPM']['C7'].value is None
    assert '2023-07' in metadata['calibrations'][0]['missing_months']


def test_unknown_market_cap_and_shareholder_capital_stay_blank():
    writer,ds,refs,market=example(shareholder=None)
    market.pop('market_caps')
    write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['B4'].value is None
    assert writer.book['CAPM']['B10'].value is None
    assert writer.book['CAPM']['B11'].value is None
    assert writer.book['CAPM']['B13'].value is None
    assert writer.book['CAPM']['B7'].value is not None


def test_zero_debt_does_not_create_division_or_conditional_guards():
    writer,ds,refs,market=example(debt=D(0),interest=D(0))
    write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['B3'].value is None
    assert writer.book['CAPM']['B10'].value is not None
    assert writer.cached[('CAPM','B10')]==writer.cached[('CAPM','B7')]
    for row in writer.book['CAPM']:
        for cell in row:
            expression=getattr(cell.value,'text',cell.value)
            if isinstance(expression,str) and expression.startswith('='):
                assert not any(word+'(' in expression.upper() for word in ['IF','IFERROR','COUNT','ISNUMBER'])


def test_zero_index_variance_does_not_invent_beta():
    with pytest.raises(ValueError,match='分散がゼロ'):
        linest([.1,.2,.3],[0,0,0])


def test_zuken_reference_layout_preserved_with_corrected_benchmark():
    writer,ds,refs,market=example(code='6947')
    write_capm(writer,ds,market,refs)
    ws=writer.book['CAPM']
    assert ws['N16'].value=='日経平均終値'
    assert ws['B6'].value=='=I18' and ws['C6'].value=='=I17'
    assert ws['I17'].value.ref=='I17:J17'
    assert ws['N9'].value==pytest.approx(.0103)
    assert ws.freeze_panes=='B1'


def test_packaged_template_contains_styles_and_only_explicit_assumptions():
    book=load_workbook(TEMPLATE_PATH)
    for ws in book:
        numeric=[]
        for row in ws:
            for cell in row:
                assert cell.data_type!='f'
                if isinstance(cell.value,(int,float)):numeric.append(cell.value)
        assert sorted(numeric)==[.0103,.0563]
        assert ws.sheet_state=='visible'
        assert not any(dim.hidden for dim in ws.row_dimensions.values())
    assert not book._external_links


@pytest.mark.parametrize('field,value', [('code','6947'),('benchmark','^TOPX'),('stock_symbol','6947.T')])
def test_foreign_stock_or_benchmark_never_used(field,value):
    writer,ds,refs,market=example()
    market[field]=value
    metadata=write_capm(writer,ds,market,refs)
    assert metadata['warnings']
    assert not metadata['monthly_inputs']
    assert writer.book['CAPM']['B4'].value is None
    assert writer.book['CAPM']['B6'].value is None
    assert writer.book['CAPM']['B10'].value is None
    assert writer.book['CAPM']['B2'].value is not None


def test_array_beta_and_intercept_are_both_cached_on_saved_workbook(tmp_path):
    from zaimu10.excel import _write_cached
    writer,ds,refs,market=example()
    write_capm(writer,ds,market,refs)
    path=tmp_path/'CAPM.xlsx';writer.book.save(path)
    _write_cached(path,writer.cached)
    formulas=load_workbook(path,data_only=False)
    cached=load_workbook(path,data_only=True)
    assert formulas['CAPM']['H21'].value.ref=='H21:I21'
    for key in ['H21','I21','B7','B10','B11','B13']:
        assert cached['CAPM'][key].value==pytest.approx(float(writer.cached[('CAPM',key)]),abs=1e-14)
    assert cached['CAPM'].max_row<100


def test_original_median_ignores_blank_years_without_changing_formula_range():
    writer,ds,refs,market=example()
    original=refs.get
    refs.get=lambda name,period: None if name=='interest_paid' and period.end.year==2023 else original(name,period)
    write_capm(writer,ds,market,refs)
    ws=writer.book['CAPM']
    assert ws['B10'].value is None and ws['C10'].value is not None
    assert ws['D10'].value=='=MEDIAN(B10:C10)'
    assert writer.cached[('CAPM','D10')]==writer.cached[('CAPM','C10')]
    assert ws['D13'].value=='=MEDIAN(B13:C13)'
    assert writer.cached[('CAPM','D13')]==writer.cached[('CAPM','C13')]
    assert '数値1期' in ws['D10'].comment.text and '空欄1期' in ws['D10'].comment.text


def test_all_missing_wacc_median_stays_blank_with_reason():
    writer,ds,refs,market=example()
    market.pop('market_caps')
    write_capm(writer,ds,market,refs)
    for row in (10,13):
        assert writer.book['CAPM'].cell(row,4).value is None
        assert 'すべて空欄' in writer.book['CAPM'].cell(row,4).comment.text


def actual_parent_dataset(code):
    import gzip
    from dataclasses import fields
    payload=json.loads(gzip.decompress((Path(__file__).parent/'fixtures/capm_parent_sources.json.gz').read_bytes()))
    raw=next(item for item in payload if item['code']==code)
    periods=[Period(date.fromisoformat(p['start']),date.fromisoformat(p['end']))for p in raw['periods']]
    ds=Dataset(code,raw['company'],raw['basis'],periods)
    ds.period_bases=raw['period_bases'];ds.accounting_standard=raw['accounting_standard'];ds.period_standards=raw['period_standards']
    for statement,rows in raw['rows'].items():
        for record in rows:
            values={}
            for key,c in record['values'].items():
                source=Source(**{k:v for k,v in c['source'].items()if k in{f.name for f in fields(Source)}})
                values[key]=Cell(D(c['value'])if c['value']is not None else None,source,nil=c['nil'])
            attrs={k:v for k,v in record.items()if k in{f.name for f in fields(Row)}-{'values','section'}}
            ds.rows[statement].append(Row(**attrs,values=values,section=tuple(record['section'])))
    return ds


def actual_parent_writer(ds):
    from openpyxl.utils import get_column_letter
    book=Workbook();book.active.title='PL'
    for name in ['BS-A','BS-L,E','CF','DCF']:book.create_sheet(name)
    writer=SimpleNamespace(book=book,periods=sorted(ds.periods),factor=D(1000),unit='thousand',unit_label='千円',
        values={},cached={},cells=[],layout_metadata={},source_addresses={},sources={},bs_metrics={})
    for col,period in enumerate(writer.periods,2):
        letter=get_column_letter(col)
        for row in ds.rows['PL']:
            cell=row.values.get(period.key)
            if cell is None or cell.nil or cell.value is None:continue
            local=cell.source.concept.rsplit('}',1)[-1]
            if local in {'ProfitLoss','ProfitLossIFRS','NetIncomeLoss'}:
                value=cell.value/writer.factor;writer.values['PL',letter+'19']=value;book['PL'][letter+'19']=float(value)
                writer.cells.append(dict(sheet='PL',address=letter+'19',row_key='metric:net_profit',period=period.key,display_value=str(value)))
        for row in ds.rows['BS_LE']:
            cell=row.values.get(period.key)
            if cell is not None and not cell.nil and cell.value is not None:
                value=cell.value/writer.factor;writer.values['BS-L,E',letter+'30']=value;book['BS-L,E'][letter+'30']=float(value)
                writer.source_addresses.setdefault(row.key,{})[period.key]=dict(sheet='BS-L,E',address=letter+'30')
    return writer


def test_actual_zuken_ten_year_noncontrolling_profit_never_used_as_parent_profit():
    from zaimu10.financial_refs import FinancialRefs
    from openpyxl.utils import get_column_letter
    ds=actual_parent_dataset('6947');writer=actual_parent_writer(ds);refs=FinancialRefs(writer,ds)
    write_capm(writer,ds,None,refs)
    checked=0;different_from_total=0
    for col,period in enumerate(writer.periods,2):
        by_name={cell.source.concept.rsplit('}',1)[-1]:cell.value for row in ds.rows['PL']
                 if(cell:=row.values.get(period.key))is not None and not cell.nil}
        parent=by_name['ProfitLossAttributableToOwnersOfParent'];total=by_name['ProfitLoss'];nci=by_name.get('ProfitLossAttributableToNonControllingInterests')
        # The disclosed amounts can have one unit of printed rounding.
        if nci is not None:
            assert abs(parent-(total-nci))<=1000
        address=f'{get_column_letter(col)}14'
        assert writer.values['CAPM',address]==parent/writer.factor
        shareholder=next(row.values[period.key].value for row in ds.rows['BS_LE']if period.key in row.values)
        expected=parent/shareholder
        assert writer.cached['CAPM',f'{get_column_letter(col)}11']==expected
        assert writer.book['CAPM'][f'{get_column_letter(col)}11'].value.startswith("='CAPM'!")
        checked+=1;different_from_total+=parent!=total
    assert checked==10 and different_from_total>=8


def test_actual_nitori_ifrs_parent_role_keeps_genuine_parent_qname():
    from zaimu10.financial_refs import FinancialRefs
    ds=actual_parent_dataset('9843');writer=actual_parent_writer(ds);refs=FinancialRefs(writer,ds)
    checked=0
    for period in writer.periods:
        rows=[row for row in ds.rows['PL']if period.key in row.values and row.values[period.key].source.concept.endswith('}ProfitLossAttributableToOwnersOfParentIFRS')]
        if not rows:continue
        source=refs.parent_profit_input(period)
        assert source is not None
        assert source.fact.value==rows[0].values[period.key].value
        assert source.fact.source.concept.endswith('}ProfitLossAttributableToOwnersOfParentIFRS')
        checked+=1
    assert checked>=2


def test_missing_parent_profit_is_not_substituted_by_consolidated_total():
    writer,ds,refs,market=example(parent_profit=None)
    write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['B14'].value is None
    assert writer.book['CAPM']['B11'].value is None
    assert writer.book['CAPM']['B12'].value is None
    assert writer.book['CAPM']['B13'].value is None
    assert writer.book['CAPM']['B10'].value is not None
