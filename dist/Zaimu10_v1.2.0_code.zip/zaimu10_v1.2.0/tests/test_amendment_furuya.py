"""Real issuer corrections plus mutations that must never be silently skipped."""
from copy import deepcopy
import gzip
import json
from pathlib import Path

from bs4 import BeautifulSoup
import pytest

from zaimu10.amendment import inspect_amendment

FIXTURES = Path(__file__).parent / 'fixtures' / 'amendments'
DOCS = ['S100Z7DK', 'S100WUAI', 'S100S7Z3', 'S100SS04', 'S100LFL0', 'S100JLQS', 'S100E8NM']
SAFE = {'nonfinancial_only', 'unchanged_financial_values'}


def source(doc):
    with gzip.open(FIXTURES / f'furuya_{doc}.json.gz', 'rt', encoding='utf-8') as stream:
        return [tuple(p) for p in json.load(stream)]


def mutate(doc, edit):
    pages = source(doc)
    soup = BeautifulSoup(pages[1][1], 'html.parser')
    edit(soup)
    return [pages[0], (pages[1][0], str(soup))]


@pytest.mark.parametrize('doc', DOCS)
def test_real_furuya_corrections_have_positive_nonstatement_scope_proof(doc):
    result = inspect_amendment(source(doc))
    assert result['status'] == 'nonfinancial_only', result
    assert result['declared_scope']
    assert result['actual_headings']
    assert result['explicit_before_after_pairs'] in {1, 2}
    assert all(len(e['sha256']) == 64 for e in result['evidence'])


def test_management_indicator_correction_changes_only_derived_ratio_and_caption_typo():
    result = inspect_amendment(source('S100JLQS'))
    proof = next(x for x in result['business_table_evidence'] if x['table_schema'] == '経営指標の金額不変照合')['invariant']
    assert proof['summary_amounts_unchanged'] is True
    assert proof['rows_compared'] == 20
    assert {x['kind'] for x in proof['changes']} == {'caption_typo', 'derived_ratio'}
    ratio = next(x for x in proof['changes'] if x['kind'] == 'derived_ratio')
    assert ratio['label'] == '株価収益率'
    assert ratio['before'][-1] == '8.30'
    assert ratio['after'][-1] == '8.26'


def test_officer_career_nested_tables_are_exhaustively_classified():
    result = inspect_amendment(source('S100SS04'))
    evidence = result['business_table_evidence']
    assert len(evidence) == 32
    assert sum(x['table_schema'] == '役員略歴の年月・経歴' for x in evidence) == 22
    assert sum(x['table_schema'] == '役員一覧' for x in evidence) == 10


@pytest.mark.parametrize('doc', DOCS)
def test_unknown_extra_table_rejected_in_every_real_scope(doc):
    def edit(soup):
        extra = BeautifulSoup('<table><tr><td>売上高</td><td>999</td></tr></table>', 'html.parser').table
        soup.body.append(extra)
    assert inspect_amendment(mutate(doc, edit))['status'] not in SAFE


@pytest.mark.parametrize('tag', ['p', 'div', 'span', 'table'])
def test_extra_actual_accounting_chapter_never_hidden_by_multiple_nonfinancial_pairs(tag):
    def edit(soup):
        n = soup.new_tag(tag)
        n.string = '【経理の状況】売上高を999に訂正'
        soup.body.append(n)
    assert inspect_amendment(mutate('S100WUAI', edit))['status'] not in SAFE


def test_nested_financial_table_cannot_borrow_role_career_scope():
    def edit(soup):
        nested = next(t for t in soup.find_all('table') if t.find_parent('table') is not None)
        first = nested.find('td')
        first.clear()
        first.string = '売上高'
    assert inspect_amendment(mutate('S100SS04', edit))['status'] not in SAFE


def test_career_table_in_stock_count_column_is_not_career_evidence():
    def edit(soup):
        nested = next(t for t in soup.find_all('table') if t.find_parent('table') is not None)
        parent_row = nested.find_parent('td').find_parent('tr')
        target = parent_row.find_all('td', recursive=False)[-1]
        target.append(nested.extract())
    assert inspect_amendment(mutate('S100WUAI', edit))['status'] not in SAFE


@pytest.mark.parametrize('old,new', [('21,451', '21,452'), ('4,484', '4,485'), ('百万円', '千円')])
def test_changed_management_summary_amounts_or_units_require_main_statement_review(old, new):
    def edit(soup):
        after = soup.find_all('table')[1]
        text = after.find(string=lambda s: s is not None and old in s)
        assert text is not None
        text.replace_with(str(text).replace(old, new, 1))
    result = inspect_amendment(mutate('S100JLQS', edit))
    assert result['status'] not in SAFE


def test_added_financial_row_inside_stock_option_table_is_rejected():
    def edit(soup):
        option = soup.find_all('table')[2]
        option.append(BeautifulSoup('<tr><td>売上高</td><td>999</td></tr>', 'html.parser').tr)
    assert inspect_amendment(mutate('S100JLQS', edit))['status'] not in SAFE


def test_missing_after_marker_in_second_correction_is_rejected():
    def edit(soup):
        markers = [n for n in soup.find_all('p') if n.get_text(' ', strip=True) in {'(訂正後）', '（訂正後）', '(訂正後)'}]
        assert len(markers) == 2
        markers[-1].clear()
        markers[-1].string = '訂正後の未確認情報'
    assert inspect_amendment(mutate('S100WUAI', edit))['status'] not in SAFE


def test_separate_bodies_each_need_independent_positive_scope():
    first = source('S100Z7DK')
    second = source('S100E8NM')
    result = inspect_amendment([first[0], first[1], ('another_body.htm', second[1][1])])
    assert result['status'] == 'nonfinancial_only'
    assert len(result['body_decisions']) == 2
    bad = inspect_amendment([first[0], first[1], ('unclassified.htm', '<html><body><p>未分類の売上999</p></body></html>')])
    assert bad['status'] not in SAFE


def test_unlabelled_monetary_cell_is_not_a_career_event():
    def edit(soup):
        nested = next(t for t in soup.find_all('table') if t.find_parent('table') is not None)
        cells = nested.find('tr').find_all('td', recursive=False)
        cells[0].clear()
        cells[1].clear()
        cells[1].string = '999百万円'
    assert inspect_amendment(mutate('S100WUAI', edit))['status'] not in SAFE
