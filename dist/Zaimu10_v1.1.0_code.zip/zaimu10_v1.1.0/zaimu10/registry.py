"""User-registered companies and an annual-period calendar.

The registry contains the user's choices and observed filing dates. Fiscal
year-end month/day comes from EDINET's directory. It is never treated as a
future earnings-announcement date. Corrupt or unfamiliar files are preserved.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import date, datetime, timezone, timedelta
import json
import os
from pathlib import Path
import re
import tempfile
from typing import Iterable

from .discovery import display_company_name, normalize_code
from .models import Dataset, Filing

SCHEMA_VERSION = 1
DEFAULT_REGISTRY_PATH = Path(__file__).resolve().parent.parent / 'data' / 'companies.json'


class RegistryError(RuntimeError):
    """User data was not readable/writable; never fall back to an empty file."""


def _now() -> str:
    return datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds')


def _iso_date(value, *, optional=True) -> str | None:
    if value in ('', None) and optional:
        return None
    try:
        return date.fromisoformat(str(value)).isoformat()
    except (TypeError, ValueError):
        raise RegistryError('実績決算期末の日付形式が不正です。') from None


def _submitted(value: str | None) -> str | None:
    if not value:
        return None
    try:
        normalized = str(value).replace('/', '-')
        parsed = datetime.fromisoformat(normalized)
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone(timedelta(hours=9))).replace(tzinfo=None)
        return parsed.isoformat(sep=' ', timespec='minutes')
    except (TypeError, ValueError):
        raise RegistryError('原本提出日時の日付形式が不正です。') from None


@contextmanager
def _file_lock(path: Path):
    """Cross-process lock using a persistent sibling file on Unix/Windows."""
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_name(path.name + '.lock')
    with lock_path.open('a+b') as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b'\0')
            stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


class CompanyRegistry:
    """Persistent company registration, always updating the latest disk state.

    ``register`` is the only operation that adds companies. Export completion
    updates only existing registrations. Removing one registration preserves
    the other records, including fields not written by this app version.
    """

    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path is not None else DEFAULT_REGISTRY_PATH

    def _read(self) -> dict:
        if not self.path.exists():
            return {'schema_version': SCHEMA_VERSION, 'companies': []}
        try:
            payload = json.loads(self.path.read_text(encoding='utf-8-sig'))
        except (OSError, UnicodeError, ValueError):
            raise RegistryError(f'登録企業ファイルを読み取れません。元のファイルは変更していません：{self.path}') from None
        if (not isinstance(payload, dict) or payload.get('schema_version') != SCHEMA_VERSION
                or not isinstance(payload.get('companies'), list)):
            raise RegistryError(f'登録企業ファイルの形式または版を確認できません。元のファイルは変更していません：{self.path}')
        seen = set()
        for record in payload['companies']:
            if not isinstance(record, dict):
                raise RegistryError('登録企業ファイルに不正な企業レコードがあります。')
            try:
                code = normalize_code(record['code'])
                if record['code'] != code or code in seen:
                    raise ValueError
                if not isinstance(record['company'], str) or not record['company'].strip():
                    raise ValueError
                if not re.fullmatch(r'E[0-9]{5}', record['edinet_code']):
                    raise ValueError
                _iso_date(record.get('latest_period_end'))
                _iso_date(record.get('latest_period_start'))
                _submitted(record.get('latest_submitted'))
            except (KeyError, TypeError, ValueError):
                raise RegistryError('登録企業ファイルの企業識別子や実績日付が不正です。') from None
            seen.add(code)
        return payload

    def _write(self, payload: dict) -> None:
        """A single atomic replace is the commit point; never truncate in place."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.path.parent,
                                             prefix='.' + self.path.name + '-', suffix='.tmp',
                                             delete=False) as stream:
                temporary = Path(stream.name)
                json.dump(payload, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
                stream.flush()
                os.fsync(stream.fileno())
            temporary.replace(self.path)
        except (OSError, TypeError, ValueError):
            raise RegistryError(f'登録企業ファイルを保存できません。既存ファイルは保持されています：{self.path}') from None
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def list_companies(self) -> list[dict]:
        # Atomic replacement means a reader always sees one complete version.
        records = self._read()['companies']
        return sorted(deepcopy(records), key=lambda r: r['code'])

    def register(self, company: dict) -> dict:
        """Add/refresh official metadata without losing a registered history."""
        try:
            code = normalize_code(company['code'])
            name = company['company']
            edinet_code = company['edinet_code']
        except (KeyError, TypeError, ValueError):
            raise RegistryError('登録する企業の銘柄コード・正式名・EDINETコードが必要です。') from None
        if not isinstance(name, str) or not name.strip() or not re.fullmatch(r'E[0-9]{5}', str(edinet_code)):
            raise RegistryError('登録する企業の正式名またはEDINETコードが不正です。')
        try:
            with _file_lock(self.path):
                payload = self._read()
                previous = next((r for r in payload['companies'] if r['code'] == code), None)
                if previous is not None and previous['edinet_code'] != edinet_code:
                    raise RegistryError('同じ銘柄コードに異なるEDINET提出者が登録済みです。自動で上書きしません。')
                record = previous if previous is not None else {
                    'code': code, 'registered_at': _now(),
                    'latest_period_start': None, 'latest_period_end': None,
                    'latest_fiscal_year': None, 'latest_submitted': None,
                    'latest_doc_id': None, 'announcement_date': None,
                }
                record.update(company=name, display_name=display_company_name(name),
                              edinet_code=edinet_code,
                              fiscal_year_end=str(company.get('fiscal_year_end')
                                                  or record.get('fiscal_year_end') or ''),
                              updated_at=_now())
                if 'consolidated' in company:
                    record['consolidated'] = bool(company['consolidated'])
                if previous is None:
                    payload['companies'].append(record)
                self._write(payload)
                return deepcopy(record)
        except OSError:
            raise RegistryError(f'登録企業ファイルをロックできません：{self.path}') from None

    def remove(self, code: str) -> bool:
        """Remove exactly one registration, preserving all other user data."""
        code = normalize_code(code)
        try:
            with _file_lock(self.path):
                payload = self._read()
                kept = [r for r in payload['companies'] if r['code'] != code]
                if len(kept) == len(payload['companies']):
                    return False
                payload['companies'] = kept
                self._write(payload)
                return True
        except OSError:
            raise RegistryError(f'登録企業ファイルをロックできません：{self.path}') from None

    def _update_actual(self, code: str, *, start, end, submitted, doc_id,
                       submitted_kind: str) -> dict | None:
        code = normalize_code(code)
        period_end = _iso_date(end, optional=False)
        period_start = _iso_date(start)
        submitted_at = _submitted(submitted)
        today = datetime.now(timezone(timedelta(hours=9))).date()
        if date.fromisoformat(period_end) > today:
            raise RegistryError('将来の決算期末を実績として登録できません。')
        if submitted_at and datetime.fromisoformat(submitted_at).date() > today:
            raise RegistryError('将来の提出日時を実績として登録できません。')
        if period_start and period_start > period_end:
            raise RegistryError('実績期間の開始日と終了日が逆転しています。')
        if doc_id and not re.fullmatch(r'S[A-Z0-9]{7}', str(doc_id)):
            raise RegistryError('実績のEDINET書類IDが不正です。')
        try:
            with _file_lock(self.path):
                payload = self._read()
                record = next((r for r in payload['companies'] if r['code'] == code), None)
                if record is None:
                    return None
                old_end = record.get('latest_period_end')
                old_submitted = record.get('latest_submitted') or ''
                # A historical export never moves the calendar back in time.
                if old_end and period_end < old_end:
                    return deepcopy(record)
                if old_end == period_end and old_submitted and not submitted_at:
                    return deepcopy(record)
                if old_end == period_end and submitted_at and submitted_at < old_submitted:
                    return deepcopy(record)
                record.update(latest_period_start=period_start,
                              latest_period_end=period_end,
                              latest_fiscal_year=date.fromisoformat(period_end).year,
                              latest_submitted=submitted_at,
                              latest_doc_id=str(doc_id) if doc_id else None,
                              latest_submitted_kind=submitted_kind,
                              updated_at=_now())
                self._write(payload)
                return deepcopy(record)
        except OSError:
            raise RegistryError(f'登録企業ファイルをロックできません：{self.path}') from None

    def update_filings(self, code: str, filings: Iterable[Filing]) -> dict | None:
        """Store the latest observed original annual report (not a forecast)."""
        code = normalize_code(code)
        registered = next((r for r in self.list_companies() if r['code'] == code), None)
        if registered is None:
            return None
        annuals = []
        for filing in filings:
            if normalize_code(filing.code) != code or (filing.edinet_code and
                    filing.edinet_code != registered['edinet_code']):
                raise RegistryError('異なる企業の提出書類を登録情報に混在させません。')
            if not filing.amended and filing.end is not None:
                annuals.append(filing)
        if not annuals:
            return deepcopy(registered)
        latest = max(annuals, key=lambda f: (f.end or date.min, _submitted(f.submitted) or '', f.doc_id))
        return self._update_actual(code, start=latest.start, end=latest.end,
                                   submitted=latest.submitted, doc_id=latest.doc_id,
                                   submitted_kind='annual_report')

    def update_result(self, dataset: Dataset) -> dict | None:
        """Update an existing registration from actual exported source facts."""
        code = normalize_code(dataset.code)
        registered = next((r for r in self.list_companies() if r['code'] == code), None)
        if registered is None:
            return None
        if not dataset.periods:
            return deepcopy(registered)
        latest = max(dataset.periods, key=lambda p: (p.end, p.start))
        sources = [cell.source for rows in dataset.rows.values() for row in rows
                   if not row.is_heading for key, cell in row.values.items()
                   if key == latest.key and cell.value is not None and not cell.nil]
        if not sources:
            raise RegistryError('実績決算期末を更新する原本数値がありません。')
        source = max(sources, key=lambda s: (_submitted(s.submitted) or '', s.doc_id))
        return self._update_actual(code, start=latest.start, end=latest.end,
                                   submitted=source.submitted, doc_id=source.doc_id,
                                   submitted_kind='export_source')

    def calendar_rows(self) -> list[dict]:
        """Latest actual fiscal year first; unknown announcement dates stay blank."""
        rows = self.list_companies()
        for row in rows:
            row['display_name'] = display_company_name(row['company'])
            row['calendar_note'] = '決算期末と決算発表日は別の日時です。決算発表日は自動推定しません。'
            # No announcement service is used. Manual unknown fields can remain
            # in the persistent record, but are not presented as verified dates.
            row['announcement_date'] = None
        rows.sort(key=lambda row: row['code'])
        rows.sort(key=lambda row: row.get('latest_period_end') or '', reverse=True)
        return rows
