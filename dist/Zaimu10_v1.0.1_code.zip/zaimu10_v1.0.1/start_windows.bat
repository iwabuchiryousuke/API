@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" || exit /b 1
if not exist ".venv\Scripts\python.exe" goto setup
".venv\Scripts\python.exe" setup_app.py --check >nul 2>&1
if errorlevel 1 goto setup
goto run
:setup
call setup_windows.bat --no-pause
if errorlevel 1 goto failed
:run
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo.
echo 起動できませんでした。はじめに.txt と logs フォルダーをご確認ください。
pause
popd
exit /b 1
