"""Four-sheet Excel output, styled after the supplied 図研 workbook.

The export uses disclosed facts as values, never reconstructed totals.  Source
metadata lives in cell comments, so there are exactly four visible worksheets.
"""

from __future__ import annotations

from copy import copy
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
import tempfile
from typing import Any

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .models import Dataset, Row, SHEETS, Source


SHEET_NAMES = tuple(SHEETS.values())
NUMBER_FORMAT = '#,##0.###_);[Red](#,##0.###)'
INTEGER_FORMAT = '#,##0_);[Red](#,##0)'
LABEL_FONT = Font(name="ＭＳ Ｐゴシック", size=9, color="000000")
NUMBER_FONT = Font(name="Times New Roman", size=10, color="000000")
HEADER_FONT = Font(name="ＭＳ Ｐゴシック", size=9, color="000000")
SECTION_FONT = Font(name="ＭＳ Ｐゴシック", size=12, color="000000")
THIN = Side(style="thin", color="000000")
WHITE_FILL = PatternFill(fill_type=None)


def _text(value: Any) -> str:
    """Return plain text without allowing Excel formula interpretation."""
    return "" if value is None else str(value)


def _write_text(cell: Any, value: Any) -> None:
    cell.value = _text(value)
    cell.data_type = "s"


def _base_sheet(ws: Any, title: str, company: str, code: str, basis: str,
                display_unit: str, period_count: int, fetched_at: str,
                source_mode: str, has_unit_column: bool = False,
                accounting_standard: str = "") -> None:
    last_column = max(2, period_count + 1)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "B7"
    ws.sheet_format.defaultColWidth = 12
    ws.sheet_format.defaultRowHeight = 16
    ws.column_dimensions["A"].width = 46
    for col in range(2, last_column + 1):
        ws.column_dimensions[get_column_letter(col)].width = 14
    for row in range(1, 5):
        ws.merge_cells(start_row=row, start_column=1,
                       end_row=row, end_column=last_column)
        ws.cell(row, 1).font = copy(LABEL_FONT)
        ws.cell(row, 1).alignment = Alignment(vertical="center", wrap_text=True)
    _write_text(ws["A1"], f"{company}（{code}）　{title}")
    ws["A1"].font = Font(name="ＭＳ Ｐゴシック", size=14, color="000000")
    ws.row_dimensions[1].height = 27
    _write_text(ws["A2"], f"対象：{basis}・通期"
                + (f"　／　会計基準：{accounting_standard}" if accounting_standard else "")
                + f"　／　金額表示単位：{display_unit}"
                + ("（金額以外は原単位。右端の表示単位を参照）" if has_unit_column else ""))
    ws.row_dimensions[2].height = 30
    _write_text(ws["A3"], "空白＝当該年度の開示値なし。項目名は同一識別子の最新表示名。原項目名・出典はセルのメモを参照。")
    ws.row_dimensions[3].height = 28
    _write_text(ws["A4"], f"取得元：{source_mode}　／　取得日時：{fetched_at}")
    ws.row_dimensions[5].height = 6
    ws.row_dimensions[6].height = 30
    ws.print_title_rows = "1:6"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = False
    ws.oddFooter.center.text = "&P / &N"
    ws.oddFooter.right.text = f"{code}　{display_unit}"
    ws.sheet_properties.outlinePr.summaryRight = False


def _style_header(cell: Any) -> None:
    cell.font = copy(HEADER_FONT)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
    cell.fill = copy(WHITE_FILL)


def _style_record(ws: Any, row: int, column_count: int, label: str,
                  depth: int = 0, total: bool = False, heading: bool = False) -> None:
    for column in range(1, column_count + 1):
        cell = ws.cell(row, column)
        cell.fill = copy(WHITE_FILL)
        cell.font = copy(LABEL_FONT if column == 1 else NUMBER_FONT)
        cell.alignment = Alignment(
            horizontal="left" if column == 1 else "right",
            vertical="center", wrap_text=column == 1,
            indent=min(max(depth, 0), 10) if column == 1 else 0,
        )
        cell.border = Border(left=THIN if column == 1 else Side(), right=THIN,
                             top=THIN if total or heading else Side(),
                             bottom=THIN if total else Side())
        if column > 1:
            cell.number_format = NUMBER_FORMAT
    if heading:
        ws.cell(row, 1).font = copy(SECTION_FONT)
    # Original labels must remain visible even for long extension concepts.
    estimated_lines = max(1, (len(label) + max(depth, 0) * 2 + 24) // 25)
    ws.row_dimensions[row].height = max(18 if heading else 16, estimated_lines * 13)


def _as_number(value: Any, factor: Decimal) -> int | float | None:
    if value is None:
        return None
    number = Decimal(str(value)) / factor
    if not number.is_finite():
        raise ValueError("財務数値に非有限値があります")
    if number == number.to_integral_value():
        return int(number)
    return float(number)


def _source_comment(source: Source, row: Row, value: Any,
                    nil: bool, note: str, accounting_standard: str = "") -> str:
    pairs = [
        ("項目識別子", row.key),
        ("当該年度の原項目名", source.original_label),
        ("XBRL QName", source.concept),
        ("区分", " > ".join(row.section)),
        ("値（原単位・換算前）", value),
        ("nil", str(nil)),
        ("書類ID", source.doc_id),
        ("提出日", source.submitted),
        ("出典URL", source.url),
        ("ファイル名", source.filename),
        ("contextRef", source.context_id),
        ("原単位", source.unit),
        ("decimals", source.decimals),
        ("原表記", source.raw_value),
        ("scale", source.scale),
        ("連結区分", source.basis),
        ("会計基準", accounting_standard),
        ("注記", note),
    ]
    return "\n".join(f"{key}: {_text(value)}" for key, value in pairs)


def export_workbook(dataset: Dataset, output_path: Path,
                    unit: str = "thousand") -> Path:
    """Write disclosed financial facts to four worksheets atomically.

    ``unit`` controls display conversion only.  Missing and nil facts remain
    blank; reported zero stays numeric zero.  All original facts and taxonomy
    identifiers are retained by the service's machine-readable manifest and
    duplicated in comments for individual-cell inspection.
    """
    units = {
        "yen": (Decimal(1), "円"),
        "thousand": (Decimal(1000), "千円"),
        "million": (Decimal(1000000), "百万円"),
    }
    if unit not in units:
        raise ValueError("unitはyen / thousand / millionから指定してください")
    factor, display_unit = units[unit]
    fractional_digits = {"yen": 0, "thousand": 3, "million": 6}[unit]
    decimal_places = "." + "#" * fractional_digits if fractional_digits else ""
    number_format = f'#,##0{decimal_places}_);[Red](#,##0{decimal_places})'
    periods = sorted(dataset.periods, key=lambda period: (period.end, period.start))
    if not periods:
        raise ValueError("出力する年度がありません")
    if len({period.key for period in periods}) != len(periods):
        raise ValueError("年度キーが重複しています")
    output_path = Path(output_path)
    if output_path.suffix.lower() != ".xlsx":
        raise ValueError("出力ファイルの拡張子は.xlsxにしてください")
    wb = Workbook()
    wb.remove(wb.active)
    wb.properties.creator = "Zaimu10"
    wb.properties.title = f"{dataset.company}（{dataset.code}）財務諸表"
    wb.properties.subject = "公開XBRL財務諸表の原項目による年度比較"
    wb.properties.description = "項目・値の出典情報は各セルのメモを参照。"
    mixed_basis = dataset.basis == "mixed"
    basis_names = {"consolidated": "連結", "standalone": "個別"}
    period_bases = getattr(dataset, "period_bases", {})
    if mixed_basis and any(period_bases.get(period.key) not in basis_names for period in periods):
        raise ValueError("年度別出力では、全年度の連結・個別区分が必要です")
    basis = ("年度別（連結・個別は列見出しを参照）" if mixed_basis
             else basis_names.get(dataset.basis, dataset.basis))
    standard_names = {"J-GAAP": "日本基準", "IFRS": "IFRS", "US-GAAP": "米国基準"}
    accounting_standard = getattr(dataset, "accounting_standard", "")
    period_standards = getattr(dataset, "period_standards", {})
    mixed_standard = accounting_standard == "mixed"
    if mixed_standard and any(period_standards.get(period.key) not in standard_names
                              for period in periods):
        raise ValueError("会計基準が年度別に異なる場合は、全年度の会計基準が必要です")
    standard_label = ("年度別（列見出しを参照）" if mixed_standard
                      else standard_names.get(accounting_standard, accounting_standard))
    fetched_at = dataset.fetched_at or datetime.now(timezone.utc).isoformat(timespec="seconds")

    for statement, title in SHEETS.items():
        ws = wb.create_sheet(title)
        records = dataset.rows.get(statement, [])
        has_unit_column = any(fact.source.unit != "JPY"
                              for record in records if not record.is_heading
                              for fact in record.values.values())
        column_count = len(periods) + 1 + int(has_unit_column)
        _base_sheet(ws, title, dataset.company, dataset.code, basis,
                    display_unit, column_count - 1, fetched_at,
                    dataset.source_mode, has_unit_column, standard_label)
        header_lines = (1 if statement.startswith("BS") else 2) + int(mixed_basis) + int(mixed_standard)
        ws.row_dimensions[6].height = max(45 if mixed_basis or mixed_standard else 30,
                                         header_lines * 15)
        _write_text(ws.cell(6, 1), "開示項目" if has_unit_column
                    else f"開示項目（{display_unit}）")
        _style_header(ws.cell(6, 1))
        for column, period in enumerate(periods, start=2):
            cell = ws.cell(6, column)
            if statement.startswith("BS"):
                header = f"{period.end:%Y/%m/%d}"
            else:
                header = f"{period.end:%Y/%m/%d}\n（{period.days}日間）"
            period_basis = basis_names.get(period_bases.get(period.key, dataset.basis), "不明")
            period_standard = standard_names.get(period_standards.get(period.key, accounting_standard),
                                                 period_standards.get(period.key, accounting_standard))
            if mixed_basis:
                header += "\n" + period_basis
            if mixed_standard:
                header += "\n" + period_standard
            _write_text(cell, header)
            cell.comment = Comment(
                f"対象期間: {period.start.isoformat()} ～ {period.end.isoformat()}\n"
                f"Period.key: {period.key}\n開示区分: {period_basis}\n"
                f"会計基準: {period_standard}", "Zaimu10")
            _style_header(cell)
        if has_unit_column:
            _write_text(ws.cell(6, column_count), "表示単位")
            _style_header(ws.cell(6, column_count))
            ws.column_dimensions[get_column_letter(column_count)].width = 22

        for row_number, record in enumerate(records, start=7):
            _write_text(ws.cell(row_number, 1), record.label)
            _style_record(ws, row_number, column_count, record.label,
                          record.indent, record.is_total, record.is_heading)
            ws.cell(row_number, 1).comment = Comment(
                f"項目識別子: {record.key}\n"
                f"区分: {' > '.join(record.section)}\n"
                "開示区分: " + " / ".join(sorted({basis_names.get(fact.source.basis,
                                      fact.source.basis or "不明")
                                      for fact in record.values.values()})) + "\n"
                "会計基準: " + " / ".join(sorted({standard_names.get(
                                      period_standards.get(key, accounting_standard),
                                      period_standards.get(key, accounting_standard))
                                      for key in record.values})) + "\n"
                f"採用表示名の年度: {record.label_period}\n"
                "同じ行の各数値セルのメモに当該年度の原項目名とXBRL情報があります。",
                "Zaimu10")
            for column, period in enumerate(periods, start=2):
                fact = record.values.get(period.key)
                if fact is None:
                    continue
                cell = ws.cell(row_number, column)
                if not record.is_heading:
                    fact_factor = factor if fact.source.unit == "JPY" else Decimal(1)
                    cell.value = None if fact.nil else _as_number(fact.value, fact_factor)
                    cell.number_format = (INTEGER_FORMAT if isinstance(cell.value, int)
                                          else (number_format if fact.source.unit == "JPY"
                                                else '#,##0.########_);[Red](#,##0.########)'))
                cell.comment = Comment(
                    _source_comment(fact.source, record, fact.value, fact.nil, fact.note,
                                    standard_names.get(period_standards.get(period.key, accounting_standard),
                                                       period_standards.get(period.key, accounting_standard))),
                    "Zaimu10")
                cell.comment.width = 570
                cell.comment.height = 370
            if has_unit_column and not record.is_heading:
                raw_units = {fact.source.unit for fact in record.values.values()}
                friendly_units = {"JPY": display_unit, "JPY/shares": "円/株",
                                  "shares": "株", "pure": "無次元（pure）"}
                labels = sorted(friendly_units.get(value, value) for value in raw_units)
                unit_label = " / ".join(labels)
                if len(labels) > 1:
                    unit_label = "年度で異なる：" + unit_label
                cell = ws.cell(row_number, column_count)
                _write_text(cell, unit_label)
                cell.font = copy(LABEL_FONT)
                cell.alignment = Alignment(wrap_text=True, vertical="center")

        last_record = 6 + len(records)
        # No SUM formula: disclosed totals may include rounding or omitted detail.
        if records:
            for cell in ws[last_record][:column_count]:
                cell.border = Border(left=copy(cell.border.left),
                                     right=copy(cell.border.right),
                                     top=copy(cell.border.top), bottom=THIN)
        if not records:
            _write_text(ws.cell(7, 1), "当該計算書の開示値を取得できませんでした。")
            ws.cell(7, 1).font = copy(LABEL_FONT)
            last_record = 7
        footer_entries = [("注記", text) for text in dataset.warnings]
        footer_entries += [("取得注記", text) for text in getattr(dataset, "source_notes", [])]
        if footer_entries:
            for offset, (label, note) in enumerate(footer_entries, start=2):
                row_number = last_record + offset
                ws.merge_cells(start_row=row_number, start_column=1,
                               end_row=row_number, end_column=column_count)
                rendered_note = label + "：" + note
                _write_text(ws.cell(row_number, 1), rendered_note)
                ws.cell(row_number, 1).font = copy(LABEL_FONT)
                ws.cell(row_number, 1).alignment = Alignment(wrap_text=True, vertical="top")
                # The smallest supported export has one period, so give long
                # informational source notes room even on its narrow page.
                available_chars = max(30, 30 + 7 * len(periods))
                lines = max(2, (len(rendered_note) + available_chars - 1) // available_chars)
                ws.row_dimensions[row_number].height = min(409, lines * 14)
        end_row = last_record + len(footer_entries) + (1 if footer_entries else 0)
        ws.print_area = f"A1:{get_column_letter(column_count)}{end_row}"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".zaimu10-", suffix=".xlsx",
                                     dir=output_path.parent, delete=False) as handle:
        temporary_path = Path(handle.name)
    try:
        wb.save(temporary_path)
        wb.close()
        temporary_path.replace(output_path)
    finally:
        temporary_path.unlink(missing_ok=True)
    return output_path
