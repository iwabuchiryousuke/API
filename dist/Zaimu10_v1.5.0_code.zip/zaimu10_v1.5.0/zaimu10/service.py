"""Acquisition, conservative merging, audit trails, and export orchestration."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path
from copy import deepcopy
import json
import hashlib
import os
import re
import tempfile
import threading
from typing import Callable

from .models import Dataset, Filing, Period, Row, Cell, SHEETS

class AcquisitionError(RuntimeError):
    """No complete, verified result is available; never report success."""

@dataclass
class Options:
    code: str
    output_dir: Path
    cache_dir: Path = Path('.cache/zaimu10')
    years: int = 10
    basis: str = 'auto'
    unit: str = 'auto'
    until: date | None = None
    offline: bool = False
    refresh: bool = False
    allow_partial: bool = False

@dataclass
class Result:
    dataset: Dataset
    workbook: Path
    audit: Path
    requested_basis: str = ''
    resolved_basis: str = ''
    basis_notice: str = ''
    basis_resolution: dict = field(default_factory=dict)


def _complete_period(dataset: Dataset, period: Period, statements=SHEETS) -> bool:
    return all(any(period.key in row.values and row.values[period.key].value is not None
                   for row in dataset.rows[statement] if not row.is_heading)
               for statement in statements)


def _standalone_cf_absence(dataset: Dataset, filing: Filing, selected: list[Period]) -> bool:
    """Only a structurally absent solo CF can trigger the full-set fallback.

    Missing values in a published CF, another missing statement, or an unrelated
    parser warning must retain the ordinary strict failure path.
    """
    expected=f'{filing.doc_id}: standaloneのCF本表がありません。'
    return (dataset.basis=='standalone' and expected in dataset.warnings
            and all(warning==expected for warning in dataset.warnings)
            and not dataset.rows['CF']
            and any(_complete_period(dataset,period,('PL','BS_A','BS_LE'))
                    for period in selected))


def _attach_analysis_inputs(dataset: Dataset, pages, log: Callable[[str],None], *,
                            filing: Filing, options: Options, cancel=None) -> Dataset:
    """Supplement valid primary statements without making uncertain ratios."""
    from .debt_notes import DebtNoteError, extract_debt_notes
    if not options.offline:
        from .edinet import fetch_filing
        check_cancel(cancel)
        try:
            pages=fetch_filing(filing.doc_id,cache_dir=options.cache_dir,log=log,cancel=cancel,
                               offline=False,refresh=options.refresh,include_notes=True)
        except InterruptedError:
            raise
        except Exception as exc:
            reason=f'財務注記・借入明細の追加取得に失敗したため、負債関係指標を未算出にしました。{exc}'
            for period in dataset.periods:
                dataset.analysis_input_errors.setdefault(period.key,[]).append(reason)
            message=f'{filing.doc_id}：{reason}'
            dataset.source_notes.append(message);log('指標補足資料の確認：'+message)
    try:
        dataset.analysis_inputs=extract_debt_notes(pages,dataset)
    except DebtNoteError as exc:
        keys={period.key for period in dataset.periods}
        scoped=getattr(exc,'periods',None)
        affected=keys&set(scoped) if isinstance(scoped,list) else keys
        if not affected:affected=keys
        source=next((cell.source for rows in dataset.rows.values() for row in rows
                     for cell in row.values.values()),None)
        basis={'consolidated':'連結','standalone':'個別'}.get(dataset.basis,dataset.basis)
        message=f'{source.doc_id if source else dataset.code}（{basis}）：借入・リース注記を確定できず、該当期の負債関係指標を未算出にしました。{exc}'
        dataset.analysis_inputs=[]
        for key in affected:
            dataset.analysis_input_errors.setdefault(key,[]).append(str(exc))
        dataset.source_notes.append(message);log('指標補足資料の確認：'+message)
    return dataset


def _bs_liability_fingerprint(dataset: Dataset, period: Period) -> dict | None:
    """Exact disclosed BS line identities, including explicit nils, not labels.

    Standard taxonomy release dates alone are normalized. HTML-derived rows,
    unknown identities and duplicate identities cannot certify this fallback.
    """
    from .parser import concept_identity
    result={}
    for row in dataset.rows['BS_LE']:
        cell=row.values.get(period.key)
        if row.is_heading or cell is None or (cell.value is None and not cell.nil):
            continue
        if cell.source.semantic_concept or not cell.source.concept or cell.source.basis!=dataset.basis:
            return None
        try:
            parts=json.loads(row.key)
            if (not isinstance(parts,list) or len(parts)!=6 or parts[0]!='BS_LE'
                    or not isinstance(parts[2],list) or parts[3] not in {'end','begin','duration'}
                    or parts[4]!=cell.source.unit or parts[5]!=dataset.basis):
                return None
            identity=json.dumps([concept_identity(cell.source.concept),parts[2],parts[3],
                                 cell.source.unit,cell.source.basis],ensure_ascii=False,
                                sort_keys=True,separators=(',',':'))
        except (ValueError,TypeError,IndexError):
            return None
        if identity in result:
            return None
        result[identity]=cell
    return result if result and any(cell.value is not None for cell in result.values()) else None


def _matching_bs_liabilities(authority: Dataset, original: Dataset, period: Period) -> tuple[bool,dict]:
    left=_bs_liability_fingerprint(authority,period)
    right=_bs_liability_fingerprint(original,period)
    if left is None or right is None:
        return False,{'reason':'BS負債純資産の完全なXBRL科目指紋を確認できません。'}
    only_left=set(left)-set(right);only_right=set(right)-set(left)
    ignored={'authority':[],'original':[]};ignored_sources=[];unmatched={}
    for side,keys,values in [('authority',only_left,left),('original',only_right,right)]:
        for identity in sorted(keys):
            cell=values[identity]
            if cell.nil and cell.value is None:
                ignored[side].append(identity)
                ignored_sources.append(dict(present_in=side,identity=identity,source=asdict(cell.source)))
            else:
                unmatched.setdefault(side,[]).append(dict(identity=identity,value_jpy=str(cell.value),
                                                          nil=bool(cell.nil),source=asdict(cell.source)))
    if unmatched:
        return False,{'reason':'数値のあるBS負債純資産の科目・次元・期間役割・単位が一致しません。',
                      'authority_lines':len(left),'original_lines':len(right),
                      'unmatched_numeric_keys':unmatched,'ignored_nil_keys':ignored,
                      'ignored_nil_sources':ignored_sources}
    comparisons=[]
    shared=set(left)&set(right)
    for identity in sorted(shared):
        a,b=left[identity],right[identity]
        if bool(a.nil)!=bool(b.nil) or (a.value is None)!=(b.value is None):
            return False,{'reason':'BS負債純資産の明示的nilと数値の状態が一致しません。','identity':identity}
        tolerance=Decimal(0)
        for cell in (a,b):
            if re.fullmatch(r'-?\d+',str(cell.source.decimals)):
                tolerance+=Decimal(10)**-int(cell.source.decimals)
        difference=abs(a.value-b.value) if a.value is not None else Decimal(0)
        if difference>tolerance:
            return False,{'reason':'BS負債純資産の数値が開示精度の範囲で一致しません。',
                          'identity':identity,'authority_value_jpy':str(a.value),
                          'original_value_jpy':str(b.value),'difference_jpy':str(difference),
                          'tolerance_jpy':str(tolerance)}
        comparisons.append(dict(identity=identity,nil=bool(a.nil),
            authority_value_jpy=str(a.value) if a.value is not None else None,
            original_value_jpy=str(b.value) if b.value is not None else None,
            difference_jpy=str(difference),tolerance_jpy=str(tolerance),
            authority_source=asdict(a.source),original_source=asdict(b.source)))
    digest=hashlib.sha256('\n'.join(sorted(shared)).encode('utf-8')).hexdigest()
    return True,{'reason':'BS負債純資産の全数値科目・共通nil・次元・期間役割・単位が開示精度内で一致。片側だけの明示nil項目は構造差として記録し、ゼロとは扱わない。',
                 'line_count':len(shared),'authority_line_count':len(left),'original_line_count':len(right),
                 'identity_sha256':digest,'comparisons':comparisons,
                 'ignored_nil_keys':ignored,'ignored_nil_sources':ignored_sources}


def _explicit_na_groups(dataset: Dataset, period: Period, filing: Filing) -> list[list[Row]]:
    """Require reader-proven current-year prose NA, never a blank or dash."""
    definitions={
        'borrowings_absent':('explicit_no_borrowings',{
            'borrowings_absent','short_term_borrowings','current_long_term_borrowings',
            'current_lease','long_term_borrowings','noncurrent_lease'},'Borrowings'),
        'bonds_absent':('explicit_no_bonds',{'bonds_absent','bonds','current_bonds'},'CorporateBonds'),
    }
    by_category={}
    for row in dataset.analysis_inputs:
        parts=row.key.split(':')
        if len(parts)==4 and parts[:2]==['notes','debt'] and parts[3]==dataset.basis and period.key in row.values:
            if parts[2] in by_category:
                return []
            by_category[parts[2]]=row
    groups=[]
    for status,(operation,categories,kind) in definitions.items():
        if not categories<=set(by_category):
            continue
        accepted=[]
        for category in sorted(categories):
            row=by_category[category];cell=row.values[period.key]
            try:
                evidence=json.loads(cell.note.split('debt_note_evidence:',1)[1])
                if (cell.value!=0 or cell.nil or cell.source.unit!='JPY'
                        or cell.source.basis!=dataset.basis or cell.source.doc_id!=filing.doc_id
                        or cell.operation!=(operation if category==status else 'explicit_no_balance')
                        or evidence.get('kind')!='explicit_none'
                        or evidence.get('document_id')!=filing.doc_id
                        or evidence.get('category')!=category
                        or evidence.get('basis')!=dataset.basis
                        or evidence.get('period_start')!=period.start.isoformat()
                        or evidence.get('period_end')!=period.end.isoformat()
                        or evidence.get('context_period_start')!=period.start.isoformat()
                        or evidence.get('context_period_end')!=period.end.isoformat()
                        or not re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpcrp/\d{4}-\d{2}-\d{2}/jpcrp_cor\}'
                            +r'Annexed(?:Consolidated)?DetailedScheduleOf'+kind
                            +r'(?:FinancialStatements)?(?:NA)?TextBlock',cell.source.concept)):
                    break
            except (ValueError,TypeError,IndexError,KeyError):
                break
            accepted.append(row)
        if len(accepted)==len(categories):groups.append(accepted)
    return groups


def _supplementary_na_fallback(merged: Dataset, datasets: list[Dataset],
        period_authorities: dict[str,Dataset], dataset_filings: dict[int,Filing],
        amendment_decisions: list[dict], log: Callable[[str],None]) -> list[dict]:
    """Recover only missing explicit-NA note evidence; never change four tables."""
    checks=[]
    for period in merged.periods:
        authority=period_authorities.get(period.key)
        if (authority is None or merged.analysis_input_errors.get(period.key)
                or authority.analysis_input_errors.get(period.key)):continue
        candidates=[ds for ds in datasets if ds.code==merged.code and ds.basis==authority.basis
                    and ds.accounting_standard==authority.accounting_standard
                    and not dataset_filings[id(ds)].amended
                    and dataset_filings[id(ds)].start==period.start
                    and dataset_filings[id(ds)].end==period.end]
        candidates.sort(key=lambda ds:(dataset_filings[id(ds)].submitted,dataset_filings[id(ds)].doc_id),reverse=True)
        if not candidates:continue
        original=candidates[0];filing=dataset_filings[id(original)]
        if original.analysis_input_errors.get(period.key) or original.warnings or authority.warnings:continue
        groups=_explicit_na_groups(original,period,filing)
        present={row.key.split(':')[2] for row in merged.analysis_inputs
                 if row.key.startswith('notes:debt:') and period.key in row.values}
        groups=[[row for row in group if row.key.split(':')[2] not in present] for group in groups]
        groups=[group for group in groups if group]
        if not groups:continue
        decision=dict(check='supplementary_note_fallback',period=period.key,ok=None,
                      authority_doc_id=dataset_filings[id(authority)].doc_id,
                      supplementary_doc_id=filing.doc_id,basis=original.basis,
                      accounting_standard=original.accounting_standard)
        blocked=False
        for amendment in amendment_decisions:
            status=amendment.get('status')
            if (amendment.get('analysis_inputs_affected') is not True
                    and status in {'nonfinancial_only','unchanged_financial_values'}):continue
            if amendment.get('analysis_inputs_affected') is False:continue
            explicit=amendment.get('affected_periods')
            affected=set(explicit) if isinstance(explicit,list) else {
                p.key for ds in datasets if f'{dataset_filings[id(ds)].start}/{dataset_filings[id(ds)].end}'==amendment.get('period')
                for p in ds.periods}
            if (period.key in affected or not isinstance(explicit,list) and not affected):
                # Dates are not a license to reuse an older amended note. A
                # later primary comparative may omit this prior-year prose.
                blocked=True;decision.update(status='not_applied',reason='当期原本の補足注記が後の訂正で影響を受ける可能性があります。',
                                             blocking_amendment_doc_id=amendment.get('doc_id'));break
        if blocked:checks.append(decision);continue
        matches,proof=_matching_bs_liabilities(authority,original,period)
        decision['balance_match']=proof
        decision['ignored_nil_keys']=proof.get('ignored_nil_keys',{})
        if not matches:
            decision.update(status='not_applied',reason=proof['reason']);checks.append(decision);continue
        added=[];sources=[]
        for group in groups:
            for row in group:
                target=next((r for r in merged.analysis_inputs if r.key==row.key),None)
                if target is None:
                    target=deepcopy(row);target.values={};merged.analysis_inputs.append(target)
                cell=deepcopy(row.values[period.key])
                cell.note=('採用済み比較BSの全数値科目・共通nil・次元・単位との照合後、当期原本の明示的な該当事項なしだけを補完。片側だけの明示nil項目はゼロと扱わない。\n'+cell.note)
                target.values[period.key]=cell;added.append(row.key)
                sources.append(dict(row_key=row.key,source=asdict(cell.source),operation=cell.operation,note=cell.note))
        decision.update(ok=True,status='applied',reason='全数値科目と共通nilが一致したBSを持つ当期原本の明示的な該当事項なしを、欠けた補足注記に限定して採用。',
                        added_note_keys=added,sources=sources)
        checks.append(decision)
        message=(f'{period.end}：{filing.doc_id}の当期原本に明示された該当事項なしを補足注記へ採用。'
                 f'BS負債純資産の全数値科目と共通nilを照合し、本表4表は{dataset_filings[id(authority)].doc_id}を維持。')
        merged.source_notes.append(message);log('補足注記の照合：'+message)
    return checks


def validate_code(code: str) -> str:
    # JPX's alphanumeric securities codes were introduced in 2024.
    import unicodedata
    code = unicodedata.normalize('NFKC', str(code)).strip().upper()
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}', code):
        raise ValueError('銘柄コードは4桁の数字・英字で入力してください（例：6947、285A）。')
    return code


def check_cancel(cancel: threading.Event | None) -> None:
    if cancel is not None and cancel.is_set():
        raise InterruptedError('処理を中止しました。取得済みキャッシュは次回再利用できます。')


def merge_datasets(datasets: list[Dataset], periods: list[Period], *, code: str,
                   basis: str, period_bases: dict[str, str] | None = None,
                   period_standards: dict[str, str] | None = None,
                   period_authorities: dict[str, Dataset] | None = None) -> Dataset:
    """Merge selected fiscal periods while retaining each fact's provenance.

    Production passes period_authorities and takes each period's complete
    statement set from that authority, including comparative reclassifications.
    Retired items are not filled from older tables. Callers without authorities
    retain the legacy newest-fact merge. Labels never determine raw identity.
    """
    if not datasets:
        raise AcquisitionError('結合できる財務諸表がありません。')
    wanted = {p.key for p in periods}
    result = Dataset(code, datasets[0].company, basis, sorted(periods),
                     fetched_at=datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds'))
    result.period_bases = period_bases or {p.key: basis for p in periods}
    result.period_standards = period_standards or {p.key: datasets[0].accounting_standard for p in periods}
    standards = set(result.period_standards.values())
    result.accounting_standard = next(iter(standards)) if len(standards) == 1 else 'mixed'
    for ds in datasets:
        if validate_code(ds.code) != validate_code(code):
            raise AcquisitionError('異なる企業のデータが混在するため出力を中止しました。')
        if ds.basis != basis and basis != 'mixed':
            raise AcquisitionError('連結と個別が混在するため出力を中止しました。')
        result.warnings.extend(ds.warnings)
        result.source_notes.extend(ds.source_notes)
        for statement in SHEETS:
            output = result.rows[statement]
            index = {r.key: r for r in output}
            previous: str | None = None
            for original in ds.rows[statement]:
                cells = {k: v for k, v in original.values.items() if k in wanted
                         and result.period_bases.get(k, ds.basis) == ds.basis
                         and result.period_standards.get(k, ds.accounting_standard) == ds.accounting_standard
                         and (period_authorities is None or period_authorities.get(k) is ds)}
                # Don't keep an old heading unless its adjacent data is retained.
                if not cells and not original.is_heading:
                    continue
                if original.key in index:
                    target = index[original.key]
                    # A late amendment to an old year can supply newer numeric
                    # evidence without making its historical label the latest
                    # fiscal year's display name.
                    candidate_label_period = max(cells, default=original.label_period)
                    if cells and candidate_label_period > target.label_period:
                        target.label = original.label
                        target.label_period = candidate_label_period
                    for key, cell in cells.items():
                        if key not in target.values:
                            target.values[key] = deepcopy(cell)
                else:
                    target = deepcopy(original)
                    target.values = deepcopy(cells)
                    if cells:
                        target.label_period = max(cells)
                    if previous is None:
                        # A new old-only row belongs before the first known row.
                        next_key = next((r.key for r in ds.rows[statement]
                                         if r.key in index), None)
                        pos = next((i for i, r in enumerate(output)
                                    if r.key == next_key), len(output))
                    else:
                        pos = next((i+1 for i, r in enumerate(output)
                                    if r.key == previous), len(output))
                    output.insert(pos, target)
                    index[target.key] = target
                previous = original.key
    note_index: dict[str, Row] = {}
    for ds in datasets:
        for original in ds.analysis_inputs:
            cells={key:cell for key,cell in original.values.items() if key in wanted
                   and result.period_bases.get(key,ds.basis)==ds.basis
                   and cell.source.basis==ds.basis
                   and result.period_standards.get(key,ds.accounting_standard)==ds.accounting_standard
                   and (period_authorities is None or period_authorities.get(key) is ds)}
            if not cells:
                continue
            target=note_index.get(original.key)
            if target is None:
                target=deepcopy(original);target.values={}
                result.analysis_inputs.append(target);note_index[target.key]=target
            for key,cell in cells.items():
                if key not in target.values:target.values[key]=deepcopy(cell)
        for key,reasons in ds.analysis_input_errors.items():
            if (key in wanted and result.period_bases.get(key,ds.basis)==ds.basis
                    and result.period_standards.get(key,ds.accounting_standard)==ds.accounting_standard
                    and (period_authorities is None or period_authorities.get(key) is ds)):
                result.analysis_input_errors.setdefault(key,[]).extend(reasons)
    result.analysis_input_errors={key:list(dict.fromkeys(reasons))
                                  for key,reasons in result.analysis_input_errors.items()}
    result.warnings = list(dict.fromkeys(result.warnings))
    result.source_notes = list(dict.fromkeys(result.source_notes))
    # Remove headings whose section has no data after it before the next heading.
    for statement in SHEETS:
        rows = result.rows[statement]
        kept: list[Row] = []
        for i, row in enumerate(rows):
            if row.is_heading:
                content = []
                for following in rows[i+1:]:
                    if following.is_heading and following.indent <= row.indent:
                        break
                    content.append(following)
                if not any(not r.is_heading and r.values for r in content):
                    continue
            kept.append(row)
        result.rows[statement] = kept
    return result


def _concept_local(cell: Cell) -> str:
    return cell.source.account_concept.rsplit('}', 1)[-1].rsplit(':', 1)[-1]


def _standard_concept(cell: Cell) -> bool:
    return bool(re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp)/\d{4}-\d{2}-\d{2}/\1_cor\}.+',cell.source.account_concept)
                or (cell.source.semantic_concept.startswith('{urn:zaimu10:html-table:')
                    and cell.source.table_path))


def _signed_html_balance(dataset: Dataset, period: Period, assets: Cell | None) -> dict | None:
    """Verify an explicitly signed HTML net-assets presentation as printed."""
    liabilities=_find_total(dataset,'BS_LE',period,{'LiabilitiesIFRS','TotalLiabilitiesIFRS'})
    equity=_find_total(dataset,'BS_LE',period,{'EquityIFRS','TotalEquityIFRS'})
    if assets is None or liabilities is None or equity is None or liabilities.value>=0:
        return None
    cells=(assets,liabilities,equity)
    if not all(cell.source.semantic_concept.startswith('{urn:zaimu10:html-table:')
               and cell.source.table_path and cell.source.context_id and cell.source.unit=='JPY'
               for cell in cells):
        return None
    if len({(cell.source.doc_id,cell.source.filename,cell.source.concept,cell.source.context_id)
            for cell in cells})!=1:
        return None
    difference=assets.value+liabilities.value-equity.value
    tolerance=_rounding_tolerance(*cells)
    return dict(check='balance_sheet_equation',period=period.key,
                ok=abs(difference)<=tolerance,difference_jpy=str(difference),
                rounding_tolerance_jpy=str(tolerance),
                calculation_method='html_signed_net_assets',
                equation='assets + signed_liabilities - equity = 0',
                input_values_jpy=dict(assets=str(assets.value),signed_liabilities=str(liabilities.value),
                                      equity=str(equity.value)),
                sources=[dict(doc_id=cell.source.doc_id,filename=cell.source.filename,
                              concept=cell.source.concept,table_path=cell.source.table_path)
                         for cell in cells])


def _find_total(ds: Dataset, statement: str, period: Period, names: set[str]) -> Cell | None:
    candidates = [r.values[period.key] for r in ds.rows[statement]
                  if period.key in r.values and _concept_local(r.values[period.key]) in names
                  and _standard_concept(r.values[period.key])
                  and r.values[period.key].value is not None]
    vals = {c.value for c in candidates}
    return candidates[0] if candidates and len(vals) == 1 else None


def _rounding_tolerance(*cells: Cell) -> Decimal:
    tolerance = Decimal(0)
    for cell in cells:
        try:
            d = int(cell.source.decimals)
        except (ValueError, TypeError):
            continue
        tolerance += Decimal(10) ** -d
    return max(tolerance, Decimal(1))


def cash_flow_checks(dataset: Dataset, period: Period) -> list[dict]:
    """Check disclosed CF roll-forwards only when every component is explicit.

    Unknown bridge adjustments cause an unverified result rather than a guessed
    zero or a reconstructed total. Rounding precision comes from each fact.
    """
    rows = dataset.rows['CF']
    def locate(names: set[str], role: str | None = None):
        found = []
        for i, row in enumerate(rows):
            cell = row.values.get(period.key)
            if cell is None or cell.value is None or cell.source.unit != 'JPY' or not _standard_concept(cell):
                continue
            if _concept_local(cell) not in names:
                continue
            if role is not None:
                try:
                    if json.loads(row.key)[3] != role:
                        continue
                except (ValueError, IndexError, TypeError):
                    continue
            found.append((i, cell))
        return found[0] if len(found) == 1 else None
    operations = locate({'NetCashProvidedByUsedInOperatingActivities', 'NetCashProvidedByUsedInOperatingActivitiesIFRS'})
    investment = locate({'NetCashProvidedByUsedInInvestmentActivities', 'NetCashProvidedByUsedInInvestingActivitiesIFRS'})
    finance = locate({'NetCashProvidedByUsedInFinancingActivities', 'NetCashProvidedByUsedInFinancingActivitiesIFRS'})
    fx = locate({'EffectOfExchangeRateChangeOnCashAndCashEquivalents', 'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS'})
    increase = locate({'NetIncreaseDecreaseInCashAndCashEquivalents', 'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS'})
    beginning = locate({'CashAndCashEquivalents', 'CashAndCashEquivalentsIFRS'}, 'begin')
    ending = locate({'CashAndCashEquivalents', 'CashAndCashEquivalentsIFRS'}, 'end')
    def extra_between(first: int, last: int, allowed: set[int]) -> bool:
        if first > last:
            return True
        return any(i not in allowed and period.key in row.values
                   and row.values[period.key].value is not None
                   for i, row in enumerate(rows) if first <= i <= last)
    def check(name: str, found: list, difference: Decimal | None, safe: bool) -> dict:
        result = {'check': name, 'period': period.key, 'ok': None}
        if safe and all(found) and difference is not None:
            tolerance = _rounding_tolerance(*(item[1] for item in found))
            result.update(ok=abs(difference) <= tolerance, difference_jpy=str(difference),
                          rounding_tolerance_jpy=str(tolerance))
        else:
            result['reason'] = '明示された標準項目が不足、または追加調整項目があり、自動照合を省略。'
        return result
    flows = [operations, investment, finance, fx, increase]
    flows_safe = bool(all(flows))
    flows_diff = None
    if flows_safe:
        total_position = max(item[0] for item in flows[:3])
        flows_safe = not extra_between(total_position, increase[0], {item[0] for item in flows})
        flows_diff = sum((item[1].value for item in flows[:4]), Decimal(0)) - increase[1].value
    bridge = [beginning, increase, ending]
    bridge_safe = bool(all(bridge))
    bridge_diff = None
    if bridge_safe:
        bridge_safe = not extra_between(increase[0], ending[0], {item[0] for item in bridge})
        bridge_diff = ending[1].value - beginning[1].value - increase[1].value
    return [check('cash_flow_components', flows, flows_diff, flows_safe),
            check('cash_balance_rollforward', bridge, bridge_diff, bridge_safe)]


def verify_dataset(dataset: Dataset, requested_years: int) -> list[dict]:
    checks: list[dict] = []
    checks.append({'check': 'period_count', 'ok': len(dataset.periods) == requested_years,
                   'actual': len(dataset.periods), 'expected': requested_years})
    for period in dataset.periods:
        for statement in SHEETS:
            counts = sum(1 for r in dataset.rows[statement] if period.key in r.values
                         and r.values[period.key].value is not None)
            checks.append({'check': 'statement_coverage', 'period': period.key,
                           'statement': statement, 'ok': counts > 0, 'numeric_facts': counts})
        assets = _find_total(dataset, 'BS_A', period, {'Assets', 'TotalAssetsIFRS', 'AssetsIFRS'})
        le = _find_total(dataset, 'BS_LE', period,
                         {'LiabilitiesAndNetAssets', 'TotalLiabilitiesAndEquityIFRS', 'LiabilitiesAndEquityIFRS'})
        if assets is not None and le is not None:
            diff = assets.value - le.value
            tolerance = _rounding_tolerance(assets, le)
            checks.append({'check': 'balance_sheet_equation', 'period': period.key,
                           'ok': abs(diff) <= tolerance,
                           'difference_jpy': str(diff), 'rounding_tolerance_jpy': str(tolerance)})
        else:
            signed=_signed_html_balance(dataset,period,assets) if le is None else None
            checks.append(signed or {'check': 'balance_sheet_equation', 'period': period.key,
                           'ok': None, 'reason': '照合可能な標準タクソノミの両側合計がありません。'})
        checks.extend(cash_flow_checks(dataset, period))
    ends = sorted(dataset.periods, key=lambda p: p.end)
    for before, after in zip(ends, ends[1:]):
        checks.append({'check': 'consecutive_periods', 'before': before.key,
                       'after': after.key, 'ok': after.start == before.end + timedelta(days=1)})
    dataset.checks = checks
    return checks


def _serialize(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime, Path)):
        return str(value)
    raise TypeError(type(value).__name__)


def _atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,
                                         suffix='.tmp',delete=False) as stream:
            tmp = Path(stream.name)
            json.dump(obj,stream,ensure_ascii=False,indent=2,default=_serialize)
            stream.write('\n')
        os.replace(tmp,path)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def save_audit(dataset: Dataset, path: Path, options: Options, raw_dataset: Dataset | None = None,
               basis_resolution: dict | None = None) -> None:
    _atomic_json(path, {'format_version': 2, 'application': 'Zaimu10',
        'options': asdict(options), 'dataset': asdict(dataset),
        'raw_dataset': asdict(raw_dataset) if raw_dataset is not None else None,
        'basis_resolution': basis_resolution or {
            'requested':options.basis,'resolved':dataset.basis,
            'periods':{p.key:{'requested_basis':options.basis,
                'resolved_basis':dataset.period_bases.get(p.key,dataset.basis)} for p in dataset.periods},
            'fallback_used':False,'notice':''},
        'identity_policy': '原文の識別子を保持。表示時に標準項目、同じ提出者の同じ拡張要素、明示的な会計科目対応表で同一項目を統合。集約値はcomponentsに元の値と出典を保存。異なる基準・連結区分・次元・単位は混同しない。',
        'selection_policy': '本表4表は年度ごとに最新の完全な連結/個別・会計基準の報告書を採用し、比較情報の遡及修正・再分類も反映。完全な比較表にない旧報告の本表項目は追加しない。欠けた補足注記の明示的な該当事項なしだけは、同年度・同区分・同基準の当期原本とBS負債純資産の全数値科目・共通nil・次元・役割・単位を照合し、影響する訂正や取得エラーがない場合に限り出典付きで補完。片側だけの明示nil項目は構造差として記録し、ゼロとは扱わない。原文キャッシュに取得した全報告書を保持。'})


def _prepare_capm_market(dataset: Dataset, filings: list[Filing], options: Options,
                         *, cancel=None, log=print) -> dict:
    """Market failures cannot invalidate otherwise verified financial tables."""
    from .market import load_capm_market, load_fiscal_prices
    from .market_cap import load_fiscal_share_counts, assemble_market_caps
    from .split_basis import align_fiscal_share_basis
    from .edinet import fetch_filing
    today = datetime.now(timezone(timedelta(hours=9))).date()
    as_of = min(options.until, today) if options.until else today
    last_closed = as_of.replace(day=1) - timedelta(days=1)
    first_year = min(p.end.year for p in dataset.periods)
    result = {'schema': 1, 'code': dataset.code, 'warnings': [],
              'as_of': as_of.isoformat(), 'market_caps': {}}
    log('CAPM：月末株価・日経平均・各決算期末の発行済株式数を確認しています。')
    try:
        result.update(load_capm_market(dataset.code, start_month=f'{first_year-5}-12',
            end_month=last_closed.strftime('%Y-%m'), cache_dir=options.cache_dir,
            offline=options.offline, refresh=options.refresh, cancel=cancel, log=log))
        result['as_of'] = as_of.isoformat()
    except InterruptedError:
        raise
    except Exception as exc:
        result['warnings'].append(f'CAPM月次市場データを取得できません：{exc}')
    check_cancel(cancel)
    try:
        shares = load_fiscal_share_counts(dataset.code, dataset.periods, filings,
            cache_dir=options.cache_dir, offline=options.offline, refresh=options.refresh,
            cancel=cancel, log=log)
        result['share_counts'] = shares
        prices = load_fiscal_prices(dataset.code, [p.end for p in dataset.periods],
            cache_dir=options.cache_dir, offline=options.offline, refresh=options.refresh,
            cancel=cancel, log=log)
        by_document={filing.doc_id:filing for filing in filings}
        for period in dataset.periods:
            check_cancel(cancel)
            count=shares.get('shares',{}).get(period.key)
            quote=prices.get('prices',{}).get(period.end.isoformat())
            if not count or not quote or quote.get('available') is False:
                continue
            filing=by_document.get(count.get('doc_id'))
            try:
                if filing is None:
                    raise ValueError('発行済株式数の原本書類を取得一覧と照合できません。')
                pages=fetch_filing(filing.doc_id,cache_dir=options.cache_dir,offline=options.offline,
                    include_shares=True,cancel=cancel,log=log)
                quote=align_fiscal_share_basis(pages,filing,period,count,quote)
            except InterruptedError:
                raise
            except Exception as exc:
                quote={**quote,'available':False,'basis_alignment_status':'unverified',
                       'reason':f'株価と株式数の基準を照合できません。{exc}'}
            prices['prices'][period.end.isoformat()]=quote
            if quote.get('available') is False:
                result['warnings'].append(f'{period.label}：{quote.get("reason", "株価の株式基準が未確認です。")}')
        result['market_caps'] = assemble_market_caps(dataset.periods, shares, prices)
        result['share_counts'] = shares
        result['fiscal_prices'] = prices
    except InterruptedError:
        raise
    except Exception as exc:
        result['warnings'].append(f'決算期末時価総額を取得できません：{exc}')
    for message in result.get('warnings', []):
        log(message)
    log(f"CAPM：期末時価総額 {len(result['market_caps'])}/{len(dataset.periods)}期。市場データの出典はCAPMセルのメモと監査JSONに保存します。")
    return result


def run(options: Options, log: Callable[[str], None] = print,
        cancel: threading.Event | None = None) -> Result:
    from .discovery import discover_filings
    from .edinet import fetch_filing
    from .parser import parse_filing
    from .excel import export_workbook
    from .amendment import inspect_amendment
    from .discovery import resolve_company_query, display_company_name
    from .presentation import prepare_dataset, detect_display_unit, annotate_filing

    try:
        options.code = validate_code(options.code)
    except ValueError:
        company = resolve_company_query(options.code, cache_dir=Path(options.cache_dir),
                                        offline=options.offline, cancel=cancel, log=log)
        options.code = company['code']
    if not 1 <= options.years <= 10:
        raise ValueError('取得する期数は1～10で指定してください。')
    if options.basis not in {'auto', 'consolidated', 'standalone'}:
        raise ValueError('連結区分が不正です。')
    if options.unit not in {'auto', 'yen', 'thousand', 'million'}:
        raise ValueError('表示単位が不正です。')
    options.output_dir = Path(options.output_dir).expanduser().resolve()
    options.cache_dir = Path(options.cache_dir).expanduser().resolve()
    check_cancel(cancel)
    log(f'{options.code}：EDINET公式の提出書類を検索しています。')
    filings = discover_filings(options.code, cache_dir=options.cache_dir,
                               years=10, log=log, cancel=cancel, offline=options.offline)
    filings = [f for f in filings if f.end is not None and
               (options.until is None or f.end <= options.until)]
    if not filings:
        raise AcquisitionError('対象の有価証券報告書がありません。銘柄コード・対象期・公開期間を確認してください。')
    primary = [f for f in filings if not f.amended]
    current_periods = sorted({Period(f.start, f.end) for f in primary if f.start and f.end},reverse=True)
    selected = current_periods[:options.years]
    if not selected:
        raise AcquisitionError('対象の会計期間を特定できません。')
    wanted = {p.key for p in selected}
    # Restrict the source filings to the selected fiscal horizon. Comparatives
    # inside that horizon can provide restated values for the preceding period.
    min_end, max_end = min(p.end for p in selected), max(p.end for p in selected)
    selected_filings = [f for f in filings if f.end and min_end <= f.end <= max_end]
    selected_filings.sort(key=lambda f: (f.submitted, f.doc_id), reverse=True)
    datasets: list[Dataset] = []
    errors: list[str] = []
    amendment_decisions: list[dict] = []
    source_notes: list[str] = []
    cf_absence_datasets: set[int] = set()
    basis_attempts: list[dict] = []
    fallback_eligible: dict[int,set[str]] = {}
    dataset_filings: dict[int,Filing] = {}
    financial_note_amendments: list[tuple[Filing,dict]] = []
    resolved_basis = options.basis
    for i, filing in enumerate(selected_filings):
        check_cancel(cancel)
        log(f'[{i+1}/{len(selected_filings)}] {filing.end} {filing.doc_id}：原文を取得・解析しています。')
        try:
            pages = fetch_filing(filing.doc_id, cache_dir=options.cache_dir,
                                 log=log, cancel=cancel, offline=options.offline,
                                 refresh=options.refresh)
            if filing.amended:
                decision = inspect_amendment(pages)
                decision.update(check='amendment_scope', doc_id=filing.doc_id,
                                period=f'{filing.start}/{filing.end}', ok=None)
                amendment_decisions.append(decision)
                if decision['status'] in {'nonfinancial_only', 'unchanged_financial_values'}:
                    decision['ok'] = True
                    note = f"{filing.doc_id}（{filing.submitted}提出の訂正報告書）：{decision['reason']}"
                    source_notes.append(note)
                    log('訂正報告書の照合：' + note)
                    continue
                if decision['status']=='financial_notes_only' and decision.get('proof_complete') is True:
                    decision.update(ok=True,handled='財務諸表本表を変更しない財務注記の訂正と構造で確認。原本の4表を維持。')
                    note=f"{filing.doc_id}（{filing.submitted}提出の訂正報告書）：財務注記のみの訂正。本表4表の変更がないことを確認。{decision['reason']}"
                    source_notes.append(note);log('訂正報告書の照合：'+note)
                    financial_note_amendments.append((filing,decision))
                    continue
            dataset = annotate_filing(parse_filing(filing, pages, basis=options.basis))
            if options.basis!='auto' and dataset.basis!=options.basis:
                raise AcquisitionError('原本の連結区分が指定した解析区分と一致しません。')
            dataset=_attach_analysis_inputs(dataset,pages,log,filing=filing,options=options,cancel=cancel)
            if filing.amended:
                decision.update(ok=True, handled='原文XBRLとして解析し、新しい提出書類の値を優先。')
            datasets.append(dataset)
            dataset_filings[id(dataset)]=filing
            if options.basis=='standalone' and _standalone_cf_absence(dataset,filing,selected):
                cf_absence_datasets.add(id(dataset))
                attempt=dict(doc_id=filing.doc_id,requested_basis='standalone',
                             attempted_basis='consolidated',reason='standalone_cf_main_statement_absent')
                basis_attempts.append(attempt)
                log(f'{filing.doc_id}：個別CF本表がないため、同じ原本の連結4表を確認しています。')
                check_cancel(cancel)
                fallback=annotate_filing(parse_filing(filing,pages,basis='consolidated'))
                if fallback.basis!='consolidated':
                    raise AcquisitionError('代替原本の連結区分を連結と確認できません。')
                fallback=_attach_analysis_inputs(fallback,pages,log,filing=filing,options=options,cancel=cancel)
                eligible=[p.key for p in selected if fallback.basis=='consolidated'
                          and _complete_period(fallback,p)
                          and _complete_period(dataset,p,('PL','BS_A','BS_LE'))]
                attempt.update(complete_periods=eligible,status='complete_candidate' if eligible else 'incomplete')
                if eligible:
                    datasets.append(fallback)
                    dataset_filings[id(fallback)]=filing
                    fallback_eligible[id(fallback)]=set(eligible)
                else:
                    errors.extend(f'{filing.doc_id}（連結代替候補）: {warning}'
                                  for warning in fallback.warnings)
                    log(f'{filing.doc_id}：同じ原本にも完全な連結4表がなく、個別CFの欠落を補えません。')
        except InterruptedError:
            raise
        except Exception as exc:
            error = f'{filing.doc_id}（{filing.end}）: {exc}'
            log('取得・解析エラー：' + error)
            errors.append(error)
    check_cancel(cancel)
    if not datasets:
        raise AcquisitionError('財務諸表を取得できませんでした。\n'+'\n'.join(errors))
    # Auto selects each fiscal period's available primary statements. A company
    # beginning consolidation must not lose its earlier standalone statements.
    # Basis is explicit in column headers and part of each row's identity.
    period_bases: dict[str, str] = {}
    period_standards: dict[str, str] = {}
    period_authorities: dict[str, Dataset] = {}
    for period in selected:
        supporting = [ds for ds in datasets if (id(ds) not in fallback_eligible
                      or period.key in fallback_eligible[id(ds)]) and any(period.key in r.values
                      for records in ds.rows.values() for r in records)]
        complete_support = [ds for ds in supporting if _complete_period(ds,period)]
        if options.basis == 'auto':
            complete_support.sort(key=lambda ds: ds.basis != 'consolidated')
            supporting.sort(key=lambda ds: ds.basis != 'consolidated')
        elif options.basis=='standalone':
            # Preserve a complete requested solo representation even when a
            # newer report provides a consolidated fallback for the same year.
            complete_support.sort(key=lambda ds:ds.basis!='standalone')
            supporting.sort(key=lambda ds:ds.basis!='standalone')
        if complete_support:
            period_authorities[period.key] = complete_support[0]
            period_bases[period.key] = complete_support[0].basis
            period_standards[period.key] = complete_support[0].accounting_standard
        elif supporting:
            period_authorities[period.key] = supporting[0]
            period_bases[period.key] = supporting[0].basis
            period_standards[period.key] = supporting[0].accounting_standard
        else:
            period_bases[period.key] = options.basis if options.basis != 'auto' else datasets[0].basis
            period_standards[period.key] = datasets[0].accounting_standard
    distinct_bases = set(period_bases.values())
    resolved_basis = next(iter(distinct_bases)) if len(distinct_bases) == 1 else 'mixed'
    log('取得区分：' + {'consolidated': '連結', 'standalone': '個別', 'mixed': '年度ごとの連結・個別（Excelの列見出しに明記）'}[resolved_basis])
    selected_ids={id(ds) for ds in period_authorities.values()}
    authority_datasets=[ds for ds in datasets if id(ds) in selected_ids]
    merged = merge_datasets(authority_datasets, selected, code=options.code, basis=resolved_basis,
                            period_bases=period_bases, period_standards=period_standards,
                            period_authorities=period_authorities)
    for dataset in datasets:
        if id(dataset) not in selected_ids:
            # Keep every unrelated warning strict. Only the expected absent
            # standalone CF of an unused representation is superseded by a
            # complete selected statement set.
            if id(dataset) not in cf_absence_datasets:
                merged.warnings.extend(dataset.warnings)
            merged.source_notes.extend(dataset.source_notes)
    merged.warnings=list(dict.fromkeys(merged.warnings))
    merged.source_notes=list(dict.fromkeys(merged.source_notes))
    fallback_periods=[p for p in sorted(selected) if options.basis=='standalone'
                      and period_bases[p.key]=='consolidated']
    basis_notice=''
    if fallback_periods:
        basis_notice=(f'個別CF本表が原本にないため、{len(fallback_periods)}期は4表すべてを同じ原本の連結財務諸表に切り替えました。'
                      +'対象期末：'+'、'.join(p.end.isoformat() for p in fallback_periods)+'。')
        merged.source_notes.append(basis_notice)
        log('取得区分の切替：'+basis_notice)
    basis_resolution=dict(requested=options.basis,resolved=resolved_basis,
        fallback_used=bool(fallback_periods),notice=basis_notice,attempts=basis_attempts,
        periods={p.key:dict(requested_basis=options.basis,resolved_basis=period_bases[p.key],
            fallback=p in fallback_periods,
            source_doc_id=next((c.source.doc_id for records in period_authorities[p.key].rows.values()
                               for row in records for key,c in row.values.items() if key==p.key),'')
                if p.key in period_authorities else '',
            reason='standalone_cf_main_statement_absent' if p in fallback_periods else 'requested_or_automatic_basis')
            for p in selected})
    merged.period_sources = {key:next((c.source.doc_id for records in ds.rows.values()
                              for r in records for k,c in r.values.items() if k==key),'')
                             for key,ds in period_authorities.items()}
    def submitted_time(value):
        try:
            parsed=datetime.fromisoformat(str(value).replace('/','-'))
            return parsed.replace(tzinfo=timezone(timedelta(hours=9))) if parsed.tzinfo is None else parsed
        except (ValueError,TypeError):
            return None
    for amendment,decision in financial_note_amendments:
        explicit=decision.get('affected_periods')
        if isinstance(explicit,list):
            affected=set(explicit)&wanted
        else:
            matching=[ds for ds in datasets if dataset_filings[id(ds)].start==amendment.start
                      and dataset_filings[id(ds)].end==amendment.end]
            affected=({p.key for ds in matching for p in ds.periods}&wanted) if matching else set(wanted)
        amendment_at=submitted_time(amendment.submitted)
        blocked=[]
        conflicts=set()
        import unicodedata
        def caption(value):
            return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(value or '')))
        generic={'計','合計','小計','その他','その他の項目','合計額','当期','前期','残高','金額'}
        changed={caption(label) for label in decision.get('changed_row_labels',[])
                 if caption(label) and caption(label) not in generic}
        for key in sorted(affected):
            authority=period_authorities.get(key)
            if authority is None:continue
            authority_at=submitted_time(dataset_filings[id(authority)].submitted)
            if amendment_at is not None and authority_at is not None and authority_at>amendment_at:
                continue
            primary_labels={caption(label) for rows in authority.rows.values() for row in rows
                            if not row.is_heading and key in row.values
                            for label in (row.label,row.values[key].source.original_label)}
            conflicts.update(changed&primary_labels)
            if not decision.get('analysis_inputs_affected',True):
                continue
            reason=f'{amendment.doc_id}：財務注記の訂正が借入・リース明細に影響する可能性があるため、負債関係の指標を未算出にしました。'
            merged.analysis_input_errors.setdefault(key,[]).append(reason)
            blocked.append(key)
        decision['analysis_blocked_periods']=blocked
        decision['primary_label_conflicts']=sorted(conflicts)
        if conflicts:
            decision['ok']=False
            message=(f'{amendment.doc_id}：財務注記の変更項目が本表の科目と一致し、数値の整合を確定できません。'
                     +'対象：'+'、'.join(sorted(conflicts)))
            errors.append(message);log('訂正内容の確認が必要：'+message)
        if blocked:log(f'{amendment.doc_id}：訂正注記の影響を確定できない{len(blocked)}期の負債関係指標を未算出にしています。')
    supplementary_checks=_supplementary_na_fallback(merged,datasets,period_authorities,
                                                   dataset_filings,amendment_decisions,log)
    merged.source_notes.append('年度ごとに最新の完全な比較表を採用。再分類済みの比較表と旧報告の内訳を混ぜず、二重計上を防止。')
    merged.source_notes.extend(source_notes)
    merged.warnings.extend(errors)
    if len(selected) != options.years:
        merged.warnings.append(f'要求{options.years}期に対し取得対象は{len(selected)}期です。上場・設立・公開期間を確認してください。')
    checks = verify_dataset(merged, options.years)
    checks.extend(amendment_decisions)
    checks.extend(supplementary_checks)
    failures = [c for c in checks if c['ok'] is False]
    for failure in failures:
        kind = failure['check']
        if kind == 'statement_coverage':
            title = 'CF（キャッシュフロー）' if failure['statement']=='CF' else SHEETS[failure['statement']]
            message = f"{failure['period']}：{title}の数値がありません。"
        elif kind == 'balance_sheet_equation':
            message = f"{failure['period']}：BS左右合計が許容丸め差を超えて不一致（差額{failure['difference_jpy']}円）。"
        elif kind == 'consecutive_periods':
            message = f"会計期間が連続していません：{failure['before']} → {failure['after']}。"
        elif kind in {'cash_flow_components', 'cash_balance_rollforward'}:
            message = f"{failure['period']}：キャッシュフローの増減照合が許容丸め差を超えて不一致（{failure['check']}、差額{failure['difference_jpy']}円）。"
        elif kind=='amendment_scope':
            message=f"{failure['doc_id']}：財務注記の変更と本表の数値の整合を確認できません。"
        else:
            message = f"要求{failure.get('expected')}期に対し対象は{failure.get('actual')}期です。"
        if message not in merged.warnings:
            merged.warnings.append(message)
    if options.basis=='standalone' and any(c['check']=='statement_coverage' and c.get('statement')=='CF'
                                           for c in failures):
        merged.warnings.insert(0,'個別CFを取得できず、同じ原本の完全な連結4表でも補えませんでした。連結指定または対象期を確認してください。')
    # A parser warning indicates possible omission or ambiguous facts, so require
    # explicit partial-output option rather than calling this a complete export.
    raw_dataset = deepcopy(merged)
    resolved_unit = detect_display_unit(merged) if options.unit == 'auto' else options.unit
    merged = prepare_dataset(merged)
    merged.company = display_company_name(merged.company)
    log('表示単位：' + {'yen':'円','thousand':'千円','million':'百万円'}[resolved_unit] + ('（原文から自動判定）' if options.unit == 'auto' else '（手動指定）'))
    incomplete = bool(failures or errors or merged.warnings)
    safe_company = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', merged.company).strip(' .')[:70] or options.code
    basename = f'{options.code}_{safe_company}_{max(p.end for p in selected):%Y-%m-%d}' + ('_要確認' if incomplete else '')
    options.output_dir.mkdir(parents=True,exist_ok=True)
    # Users may edit the exported workbook by hand. A repeated download must
    # preserve that work, and keep its original matching audit alongside it.
    original_basename = basename
    counter = 2
    while any((options.output_dir / (basename + suffix)).exists() for suffix in ('.xlsx', '.audit.json')):
        basename = f'{original_basename}_{counter}'
        counter += 1
    audit = options.output_dir / (basename + '.audit.json')
    save_audit(merged, audit, options, raw_dataset,basis_resolution)
    if incomplete and not options.allow_partial:
        raise AcquisitionError('完全な結果として出力できない項目があります。Excel出力を停止し、監査結果を保存しました。\n'
                               f'{audit}\n'+'\n'.join(merged.warnings[:8])+
                               ('\n検証NG: '+str(failures[:3]) if failures else '')+
                               '\n内容を確認して部分出力を明示的に許可すると、要確認と表示したExcelを作成できます。')
    check_cancel(cancel)
    merged.market_data = _prepare_capm_market(merged, filings, options, cancel=cancel, log=log)
    check_cancel(cancel)
    workbook = options.output_dir / (basename + '.xlsx')
    export_workbook(merged,workbook,unit=resolved_unit)
    export_failures = [c for c in merged.checks if c.get('ok') is False and c not in failures]
    if export_failures:
        message = f'集約・計算式と開示値の照合で{len(export_failures)}件の不一致があります。監査JSONのchecksをご確認ください。'
        if message not in merged.warnings:merged.warnings.append(message)
    # Export adds source-versus-formula checks and emitted-cell metadata.
    save_audit(merged, audit, options, raw_dataset,basis_resolution)
    if export_failures and not options.allow_partial:
        workbook.unlink(missing_ok=True)
        raise AcquisitionError('計算式の検証で不一致があるためExcel出力を停止しました。\n'+str(audit))
    if export_failures and '_要確認' not in workbook.stem:
        target = workbook.with_name(workbook.stem+'_要確認.xlsx')
        count = 2
        while target.exists() or target.with_suffix('.audit.json').exists():
            target = workbook.with_name(workbook.stem+f'_要確認_{count}.xlsx');count+=1
        workbook.rename(target)
        new_audit = target.with_suffix('.audit.json');audit.rename(new_audit)
        workbook,audit = target,new_audit
    log(f'完了：{len(selected)}期・7シート。Excel：{workbook.name}')
    return Result(merged,workbook,audit,requested_basis=options.basis,
                  resolved_basis=resolved_basis,basis_notice=basis_notice,
                  basis_resolution=basis_resolution)
