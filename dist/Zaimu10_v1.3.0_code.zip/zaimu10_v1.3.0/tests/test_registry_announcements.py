"""Registered actual/future announcement fields, including offline transitions."""
from datetime import date
import json

import pytest

from zaimu10 import registry as registry_module
from zaimu10.models import Filing
from zaimu10.registry import CompanyRegistry, RegistryError


def event(*, code='6947', when='2027-05-14', period='2027年3月期',
          end='2027-03-31', kind='scheduled', verified='2026-11-20T10:00:00+09:00'):
    return dict(code=code,company='検証会社',date=when,kind=kind,
                period_type='annual',is_annual=True,fiscal_period=period,
                fiscal_month=(end or '')[:7] or None,fiscal_end=end,
                title=period+(' 決算短信' if kind=='actual' else ' 本決算発表予定'),
                source_url=f'https://www2.jpx.co.jp/disc/{code}0/{when}.pdf',
                source_title='JPX公式',publisher='日本取引所グループ',verified_at=verified)


def calendar(events, *, code='6947', checked='2026-11-20T10:00:00+09:00',
             stale=False, status='verified_schedules', history=None):
    return dict(code=code,events=events,history=events if history is None else history,
                checked_at=checked,stale=stale,warnings=[],schedule_status=status)


@pytest.fixture
def reg(tmp_path,monkeypatch):
    monkeypatch.setattr(registry_module,'_today',lambda:date(2026,11,20))
    result=CompanyRegistry(tmp_path/'companies.json')
    result.register(dict(code='6947',company='株式会社図研',edinet_code='E01966'))
    return result


def actual(**kwargs):
    return event(when='2026-05-14',period='2026年3月期',end='2026-03-31',kind='actual',**kwargs)


def test_actual_and_next_official_plan_have_separate_period_and_source_fields(reg):
    result=reg.update_earnings('6947',calendar([actual(),event()]))
    assert result['announcement_date']=='2026-05-14'
    assert result['latest_actual_announcement_fiscal_period']=='2026年3月期'
    assert result['next_announcement_date']=='2027-05-14'
    assert result['next_announcement_fiscal_period']=='2027年3月期'
    assert result['next_announcement_source_url'].endswith('/2027-05-14.pdf')
    assert result['next_announcement_status']=='scheduled'
    assert result['latest_period_end']=='2026-03-31'  # Future plan cannot advance it.
    reloaded=CompanyRegistry(reg.path).calendar_rows()[0]
    assert reloaded['next_announcement_event']['kind']=='scheduled'


def test_matching_period_actual_removes_even_differently_dated_future_plan(reg):
    old=event(when='2026-12-01',period='2026年3月期',end='2026-03-31')
    reg.update_earnings('6947',calendar([old],checked='2026-11-19T10:00:00+09:00'))
    result=reg.update_earnings('6947',calendar([actual()],status='not_in_checked_sources'))
    assert result['announcement_date']=='2026-05-14'
    assert result['next_announcement_date'] is None
    assert result['next_announcement_status']=='not_in_checked_sources'
    assert any(e['kind']=='scheduled' for e in result['earnings_history'])


def test_next_year_original_release_replaces_matching_plan_but_keeps_following_year(reg,monkeypatch):
    from zaimu10 import earnings
    reg.update_earnings('6947',calendar([actual(),event()]))
    monkeypatch.setattr(registry_module,'_today',lambda:date(2027,5,15))
    monkeypatch.setattr(earnings,'_today',lambda:date(2027,5,15))
    released=event(when='2027-05-14',kind='actual',verified='2027-05-15T10:00:00+09:00')
    following=event(when='2028-05-15',period='2028年3月期',end='2028-03-31',
                    verified='2027-05-15T10:00:00+09:00')
    result=reg.update_earnings('6947',calendar([released,following],checked='2027-05-15T10:00:00+09:00'))
    assert result['announcement_date']=='2027-05-14'
    assert result['latest_period_end']=='2027-03-31'
    assert result['next_announcement_date']=='2028-05-15'
    assert result['next_announcement_fiscal_period']=='2028年3月期'
    assert any(e['kind']=='scheduled' and e['date']=='2027-05-14' for e in result['earnings_history'])


def test_actual_for_other_fiscal_year_does_not_remove_next_plan(reg):
    result=reg.update_earnings('6947',calendar([actual(),event()]))
    assert result['next_announcement_fiscal_month']=='2027-03'
    assert len(result['earnings_events'])==2


def test_new_official_reschedule_replaces_plan_but_preserves_provenance(reg):
    first=event(when='2027-05-14',verified='2026-11-19T10:00:00+09:00')
    reg.update_earnings('6947',calendar([first],checked=first['verified_at']))
    revised=event(when='2027-05-17')
    result=reg.update_earnings('6947',calendar([revised]))
    assert result['next_announcement_date']=='2027-05-17'
    assert {e['date'] for e in result['earnings_history']}=={'2027-05-14','2027-05-17'}


@pytest.mark.parametrize('stale',[False,True])
def test_older_cache_cannot_undo_newer_registered_official_reschedule(reg,stale):
    reg.update_earnings('6947',calendar([event(when='2027-05-17')]))
    older=event(when='2027-05-14',verified='2026-11-19T10:00:00+09:00')
    result=reg.update_earnings('6947',calendar([older],checked=older['verified_at'],stale=stale))
    assert result['next_announcement_date']=='2027-05-17'
    assert result['earnings_checked_at']=='2026-11-20T10:00:00+09:00'
    assert result['next_announcement_status']=='stale_schedule'
    assert result['next_announcement_stale'] is True
    assert any('古い' in w for w in result['earnings_warnings'])


def test_failed_refresh_keeps_verified_plan_and_marks_it_stale(reg):
    plan=event()
    reg.update_earnings('6947',calendar([actual(),plan]))
    result=reg.update_earnings('6947',calendar([actual(),plan],stale=True))
    assert result['next_announcement_date']=='2027-05-14'
    assert result['next_announcement_status']=='stale_schedule'
    assert result['announcement_date']=='2026-05-14'


def test_partial_schedule_source_failure_keeps_old_plan_explicitly_stale(reg):
    plan=event(verified='2026-11-19T10:00:00+09:00')
    reg.update_earnings('6947',calendar([actual(),plan],checked=plan['verified_at']))
    result=reg.update_earnings('6947',calendar([actual()],status='partial_fetch_failure'))
    assert result['next_announcement_date']=='2027-05-14'
    assert result['next_announcement_status']=='stale_schedule'
    assert result['next_announcement_verified_at']=='2026-11-19T10:00:00+09:00'
    assert result['earnings_checked_at']=='2026-11-20T10:00:00+09:00'


def test_partial_other_source_failure_does_not_override_fresh_official_reschedule(reg):
    old=event(when='2027-05-14',verified='2026-11-19T10:00:00+09:00')
    reg.update_earnings('6947',calendar([old],checked=old['verified_at']))
    new=event(when='2027-05-17')
    result=reg.update_earnings('6947',calendar([new],status='partial_fetch_failure'))
    assert result['next_announcement_date']=='2027-05-17'
    assert result['next_announcement_stale'] is False


def test_matching_actual_clears_retained_partial_failure_schedule(reg):
    old=event(when='2026-12-01',period='2026年3月期',end='2026-03-31')
    reg.update_earnings('6947',calendar([old],checked='2026-11-19T10:00:00+09:00'))
    result=reg.update_earnings('6947',calendar([actual()],status='partial_fetch_failure'))
    assert result['next_announcement_date'] is None
    assert result['next_announcement_status']=='partial_fetch_failure'


def test_read_after_planned_day_does_not_keep_it_upcoming_or_fabricate_actual(reg,monkeypatch):
    reg.update_earnings('6947',calendar([actual(),event()]))
    before=reg.path.read_bytes()
    monkeypatch.setattr(registry_module,'_today',lambda:date(2027,5,15))
    row=CompanyRegistry(reg.path).calendar_rows()[0]
    assert row['next_announcement_date'] is None
    assert row['next_announcement_status']=='past_unconfirmed'
    assert row['announcement_date']=='2026-05-14'
    assert row['latest_period_end']=='2026-03-31'
    assert reg.path.read_bytes()==before  # A display read never rewrites user data.


def test_same_day_plan_stays_scheduled_until_original_disclosure(reg,monkeypatch):
    reg.update_earnings('6947',calendar([event()]))
    monkeypatch.setattr(registry_module,'_today',lambda:date(2027,5,14))
    row=reg.calendar_rows()[0]
    assert row['next_announcement_date']=='2027-05-14'
    assert row['announcement_date'] is None


def test_public_source_freshly_removing_plan_clears_next_without_erasing_history(reg):
    reg.update_earnings('6947',calendar([event()],checked='2026-11-19T10:00:00+09:00'))
    result=reg.update_earnings('6947',calendar([actual()],status='not_in_checked_sources'))
    assert result['next_announcement_date'] is None
    assert result['next_announcement_status']=='not_in_checked_sources'
    assert any(e['kind']=='scheduled' for e in result['earnings_history'])


def test_two_registered_companies_keep_independent_actual_and_future_metadata(reg):
    reg.register(dict(code='2303',company='株式会社ドーン',edinet_code='E05289'))
    reg.update_earnings('6947',calendar([actual(),event()]))
    dawn_actual=event(code='2303',when='2026-07-09',period='2026年5月期',end='2026-05-31',kind='actual')
    dawn_plan=event(code='2303',when='2027-07-08',period='2027年5月期',end=None)
    reg.update_earnings('2303',calendar([dawn_actual,dawn_plan],code='2303'))
    rows=CompanyRegistry(reg.path).calendar_rows()
    assert [r['code'] for r in rows]==['2303','6947']
    assert rows[0]['next_announcement_date']=='2027-07-08'
    assert rows[0]['next_announcement_fiscal_month']=='2027-05'
    assert rows[0]['next_announcement_fiscal_end'] is None
    assert rows[1]['next_announcement_date']=='2027-05-14'


def test_unknown_or_partial_fetch_status_is_not_unpublished_claim(reg):
    assert reg.calendar_rows()[0]['next_announcement_status']=='not_fetched'
    result=reg.update_earnings('6947',calendar([actual()],status='partial_fetch_failure'))
    assert result['next_announcement_status']=='partial_fetch_failure'
    result=reg.update_earnings('6947',calendar([actual()],status='partial_fetch_failure',stale=True))
    assert result['next_announcement_status']=='stale_no_schedule'


def test_latest_actual_keeps_own_period_when_newer_financial_year_has_no_release(reg):
    old=event(when='2025-05-12',period='2025年3月期',end='2025-03-31',kind='actual')
    reg.update_filings('6947',[Filing('S100AAAA',code='6947',edinet_code='E01966',
        start=date(2025,4,1),end=date(2026,3,31),submitted='2026-06-19 11:04')])
    reg.update_earnings('6947',calendar([old,event()]))
    row=reg.calendar_rows()[0]
    assert row['latest_period_end']=='2026-03-31'
    assert row['announcement_date'] is None
    assert row['latest_actual_announcement_date']=='2025-05-12'
    assert row['latest_actual_announcement_fiscal_period']=='2025年3月期'
    assert row['next_announcement_fiscal_period']=='2027年3月期'


def test_malformed_confirmation_timestamp_preserves_registry(reg):
    before=reg.path.read_bytes()
    with pytest.raises(RegistryError,match='確認日時'):
        reg.update_earnings('6947',calendar([event()],checked='broken'))
    assert reg.path.read_bytes()==before


@pytest.mark.parametrize('invalid',['broken',[dict(event(),fiscal_month=202703)]])
def test_corrupt_saved_announcement_history_is_explicit_error_and_never_reset(reg,invalid):
    reg.update_earnings('6947',calendar([event()]))
    payload=json.loads(reg.path.read_text())
    payload['companies'][0]['earnings_history']=invalid
    reg.path.write_text(json.dumps(payload))
    before=reg.path.read_bytes()
    with pytest.raises(RegistryError,match='元ファイルは保持'):
        CompanyRegistry(reg.path).calendar_rows()
    with pytest.raises(RegistryError,match='元ファイルは保持'):
        CompanyRegistry(reg.path).register(dict(code='2303',company='株式会社ドーン',edinet_code='E05289'))
    assert reg.path.read_bytes()==before
