"""Resolve analytical inputs to the final visible financial statement cells.

This module never reads a raw amount as a fallback and never modifies a sheet.
Account identities, annual scope and display metadata choose the reference;
its value comes from the emitted workbook/cache in the selected display unit.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import json
import re
import unicodedata
from typing import Any

from openpyxl.utils.cell import column_index_from_string, get_column_letter

from .models import Cell, Dataset, Period, Row
from .presentation import CF_LOCAL_SLOTS, PL_CONCEPTS, _concept, _key_parts


@dataclass(frozen=True)
class CellRef:
    sheet: str
    address: str
    value: Decimal
    row_key: str
    source: Any = None

    @property
    def excel(self) -> str:
        return "'" + self.sheet.replace("'", "''") + "'!" + self.address


@dataclass(frozen=True)
class ResolvedInput:
    excel: str
    value: Decimal
    refs: tuple[CellRef, ...]
    reason: str = ''


@dataclass(frozen=True)
class ParentProfitInput:
    """An explicitly disclosed ROE input for a visible parent-profit row."""
    row: Row
    fact: Cell
    visible: ResolvedInput | None = None
    reason: str = ''


_SHEETS = {'PL':'PL', 'BS_A':'BS-a', 'BS_LE':'BS-le', 'CF':'CF'}
_SHEET_ALIASES = {'BS_A':('BS-a','BS-A'), 'BS_LE':('BS-le','BS-L,E','BS-L&E')}
_PL = {'revenue','cost_of_sales','operating_profit','net_profit',
       'profit_before_tax','income_taxes','sga'}
_ROLE_NAMES = {
    'equity': ('BS_LE','net_assets',('NetAssets','EquityIFRS','TotalEquityIFRS')),
    'current_assets': ('BS_A','current_assets',('CurrentAssets','CurrentAssetsIFRS','TotalCurrentAssetsIFRS')),
    'current_liabilities': ('BS_LE','current_liabilities',('CurrentLiabilities','CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS')),
    'ppe': ('BS_A','ppe',('PropertyPlantAndEquipment','PropertyPlantAndEquipmentIFRS')),
}
_CF_EXTRA = {
    44: {'PurchaseOfPropertyPlantAndEquipmentInvCFIFRS'},
    45: {'ProceedsFromSaleOfPropertyPlantAndEquipmentInvCFIFRS','ProceedsFromSalesOfPropertyPlantAndEquipmentInvCFIFRS'},
    46: {'PurchaseOfIntangibleAssetsInvCFIFRS'},
    47: {'ProceedsFromSaleOfIntangibleAssetsInvCFIFRS','ProceedsFromSalesOfIntangibleAssetsInvCFIFRS'},
}
_CF_SHARE_INVESTMENTS = {
    50: {'PaymentsForAcquisitionOfSubsidiariesInvCFIFRS',
         'PurchaseOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS'},
    51: {'ProceedsFromSaleOfSubsidiariesInvCFIFRS',
         'ProceedsFromSaleOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS'},
}
_INTEREST_CASH = {
    'InterestPaidOpeCFIFRS','InterestPaidFinCFIFRS','InterestPaidFinCF',
    'InterestExpensesPaidFinCF','InterestExpensesPaidFinCFIFRS','InterestExpensesPaidOpeCFFinCF',
}
_CHUGAI_HTML_DISPOSALS = {
    45: ('有形固定資産の処分','HtmlRow_e91ca8b8c278f493ef'),
    47: ('無形資産の処分','HtmlRow_8d2a562025f959eb08'),
}
_CURRENT_ASSET = {'流動資産'}
_NONCURRENT_ASSET = {'固定資産','非流動資産','投資その他の資産','有形固定資産','無形固定資産','無形資産'}
_CURRENT_SECURITIES = {'Securities','SecuritiesCA','ShortTermInvestmentSecurities','MarketableSecuritiesCAIFRS'}


def _decimal(value) -> Decimal | None:
    if value is None or isinstance(value,bool):return None
    try:
        result=value if isinstance(value,Decimal) else Decimal(str(value))
    except (InvalidOperation,ValueError,TypeError):return None
    return result if result.is_finite() else None


def _parts(address: str):
    match=re.fullmatch(r'([A-Z]+)([1-9]\d*)',str(address).replace('$','').upper())
    if not match:return None
    return column_index_from_string(match.group(1)),int(match.group(2))


def _scope(row: Row, period: str) -> set[str]:
    cell=row.values.get(period)
    section=cell.source_section if cell is not None and cell.source_section is not None else row.section
    return {re.sub(r'\s+','',unicodedata.normalize('NFKC',text or '')).strip(':：') for text in section}


def _local(row: Row, period: str) -> str:
    cell=row.values.get(period)
    return _concept(cell.source.account_concept)[1] if cell else ''


def _group(row: Row, name: str) -> bool:
    try:
        parts=json.loads(row.key.removeprefix('display:'))
        return isinstance(parts,list) and len(parts)>=2 and parts[0]=='BS_A' and parts[1]==name
    except (ValueError,TypeError):return False


def _source_dict(item):
    source=item.get('source') if isinstance(item,dict) else None
    if isinstance(source,dict):return source.get('source',source)
    return getattr(source,'source',source)


def _source_field(source,name):
    return source.get(name,'') if isinstance(source,dict) else getattr(source,name,'')


def _identity(source):
    if source is None:return None
    fields=('doc_id','filename','context_id','concept','unit','semantic_concept','table_path','original_label')
    values=tuple(str(_source_field(source,name)) for name in fields)
    return values if values[3] and any(values[:3]) else None


def _expression(refs: tuple[CellRef, ...]) -> str:
    """Adjacent visible cells form a SUM; separate blocks use plain addition."""
    groups=[]
    for ref in refs:
        column,row=_parts(ref.address)
        if groups and groups[-1][0]==ref.sheet and groups[-1][1]==column and row==groups[-1][3]+1:
            sheet,c,start,end=groups[-1];groups[-1]=(sheet,c,start,row)
        else:groups.append((ref.sheet,column,row,row))
    pieces=[]
    for sheet,column,start,end in groups:
        prefix="'"+sheet.replace("'","''")+"'!"
        letter=get_column_letter(column)
        first=f'{prefix}{letter}{start}'
        pieces.append(first if start==end else f'SUM({first}:{letter}{end})')
    return '+'.join(pieces)


class FinancialRefs:
    """Final-cell lookup for DCF/FR/CAPM consumers; no source-number guessing."""

    def __init__(self, writer, dataset: Dataset):
        self.writer=writer;self.dataset=dataset
        self.periods={p.key:p for p in writer.periods}
        self.columns={p.key:i for i,p in enumerate(writer.periods,2)}
        self._cache={};self._reasons={};self._parent_inputs={};self._parent_addresses={}
        self._metadata={}
        self._by_row={}
        self._by_source={}
        for item in writer.cells:
            sheet,address=item.get('sheet'),item.get('address')
            self._metadata[(sheet,address)]=item
            self._by_row.setdefault((sheet,item.get('row_key'),item.get('period')),[]).append(item)
            identity=_identity(_source_dict(item))
            if identity:self._by_source.setdefault((sheet,item.get('period'),identity),[]).append(item)

    def get(self,name: str,period: Period | str) -> ResolvedInput | None:
        key=period.key if hasattr(period,'key') else str(period)
        cache_key=(name,key)
        if cache_key not in self._cache:
            if name=='net_profit_parent':self._reasons.setdefault(cache_key,'')
            else:self._reasons[cache_key]=''
            if key not in self.periods:
                result=None;self._reasons[cache_key]='対象の会計期間が表示列にありません。'
            else:result=self._resolve(name,key)
            if result is None and not self._reasons[cache_key]:
                self._reasons[cache_key]='必要な対象科目の数値を可視の財務シートで確認できません。'
            self._cache[cache_key]=result
        return self._cache[cache_key]

    def reason(self,name: str,period: Period | str) -> str:
        key=period.key if hasattr(period,'key') else str(period)
        result=self.get(name,key)
        return result.reason if result is not None else self._reasons[(name,key)]

    def status(self,name: str,period: Period | str) -> str:
        """Separate an absent optional field from a disclosed unknown amount.

        No amount is read as a fallback: this only qualifies whether the
        reference model may omit an optional term when no such field exists.
        """
        key=period.key if hasattr(period,'key')else str(period)
        if self.get(name,key) is not None:return 'available'
        optional={
            'construction_in_progress':{'ConstructionInProgress','ConstructionInProgressPPE','ConstructionInProgressIFRS','ConstructionInProgressPPEIFRS'},
            'current_securities':_CURRENT_SECURITIES,
        }
        if name not in optional:return 'unresolved'
        rows=self._security_rows(key)if name=='current_securities'else self._rows('BS_A',key,optional[name])
        if name=='current_securities':
            relevant=[]
            for row in rows:
                scope=_scope(row,key)
                if scope&_NONCURRENT_ASSET and not scope&_CURRENT_ASSET:continue
                relevant.append(row)
            rows=relevant
        if not rows:return 'absent'
        if any(row.values[key].nil or row.values[key].value is None for row in rows):return 'disclosed_blank'
        return 'unresolved'

    def parent_profit_input(self,period: Period | str) -> ParentProfitInput | None:
        """Return a typed source for an explicitly visible parent-profit row.

        This does not make an undisplayed source amount a financial reference.
        The consumer must show its genuine fact/lineage before registering it.
        """
        key=period.key if hasattr(period,'key')else str(period)
        if key in self._parent_inputs:return self._parent_inputs[key]
        if key not in self.periods:return None

        def candidates(names):
            rows=self._rows('PL',key,names)
            rows=[r for r in rows if (_concept(r.values[key].source.account_concept)[0]
                    in {'jppfs_cor','jpigp_cor','us-gaap'} or
                    r.values[key].source.semantic_concept.startswith('{urn:zaimu10:html-table:'))]
            unique={(_identity(r.values[key].source),r.values[key].source.basis):r for r in rows}
            return list(unique.values())

        def one(rows):
            if len(rows)!=1:return None
            row=rows[0];fact=row.values[key]
            return (row,fact)if fact.value is not None and not fact.nil else None

        parent_rows=candidates(PL_CONCEPTS['net_profit_parent'])
        chosen=one(parent_rows)
        reason='親会社帰属当期純利益の標準科目・明示された原文の数値。'
        if parent_rows and chosen is None:
            self._parent_inputs[key]=None
            self._reasons['net_profit_parent',key]='親会社帰属当期純利益の開示がnil・空欄、又は一意ではありません。総利益で補完しません。'
            return None
        if chosen is None:
            total=one(candidates(PL_CONCEPTS['net_profit']))
            nci_rows=candidates({'ProfitLossAttributableToNonControllingInterests',
                'ProfitLossAttributableToNonControllingInterestsIFRS',
                'NetIncomeLossAttributableToNoncontrollingInterest','MinorityInterestsInIncome'})
            nci=one(nci_rows)
            basis=self.dataset.period_bases.get(key,self.dataset.basis)
            if total and nci:
                total_row,total_fact=total;nci_row,nci_fact=nci
                if (total_fact.source.doc_id,total_fact.source.basis)==(nci_fact.source.doc_id,nci_fact.source.basis):
                    source=deepcopy(total_fact.source)
                    source.concept='{urn:zaimu10:analysis}ParentProfit'
                    source.semantic_concept='';source.table_path=''
                    source.original_label='親会社帰属当期純利益（開示総利益−開示非支配利益）'
                    source.raw_value='開示当期純利益−開示非支配株主帰属利益'
                    fact=Cell(total_fact.value-nci_fact.value,source,
                        components=[deepcopy(total_fact),deepcopy(nci_fact)],operation='difference',
                        component_keys=[total_row.key,nci_row.key],
                        note='同じ対象年度・原本・連結区分の当期純利益から非支配株主帰属利益を控除。')
                    chosen=(Row('CAPM:parent_profit:'+key,source.original_label,'PL',values={key:fact}),fact)
                    reason=fact.note
            elif total and not nci_rows and basis=='standalone':
                chosen=total;reason='個別財務諸表の当期純利益。非支配株主への利益配分がない対象区分。'
        if chosen is None:
            self._parent_inputs[key]=None
            self._reasons['net_profit_parent',key]='親会社帰属利益又は同年度の総利益・非支配利益の両開示を確認できません。非支配利益の欠損を0にはしません。'
            return None
        row,fact=chosen
        visible=None
        candidate=self._row_ref(row,key)
        if isinstance(candidate,CellRef):candidate=ResolvedInput(candidate.excel,candidate.value,(candidate,))
        if candidate and candidate.value==fact.value/self.writer.factor:visible=candidate
        if visible is None:
            total_visible=self.get('net_profit',key)
            if total_visible and total_visible.value==fact.value/self.writer.factor:
                visible=ResolvedInput(total_visible.excel,total_visible.value,total_visible.refs,
                    '原文の親会社帰属利益と表示PL当期純利益が同額であることを確認。'+reason)
        result=ParentProfitInput(row,fact,visible,reason)
        self._parent_inputs[key]=result
        return result

    def register_parent_profit(self,period: Period | str,address: str) -> ResolvedInput | None:
        """Register the disclosed CAPM input after the consumer has shown it."""
        key=period.key if hasattr(period,'key')else str(period)
        source=self.parent_profit_input(key)
        ref=self._at('CAPM',address,row_key='CAPM:parent_profit:'+key,
                     source=source.fact if source else None)
        if source is None or ref is None or ref.value!=source.fact.value/self.writer.factor:
            self._cache['net_profit_parent',key]=None
            self._parent_addresses.pop(key,None)
            return self._fail('net_profit_parent',key,'可視CAPMの親会社帰属利益入力を原文の値と照合できません。')
        self._parent_addresses[key]=address
        result=ResolvedInput(ref.excel,ref.value,(ref,),source.reason)
        self._cache['net_profit_parent',key]=result
        self._reasons['net_profit_parent',key]=''
        return result

    def _fail(self,name,period,reason):
        self._reasons[(name,period)]=reason
        return None

    def _sheet(self,statement):
        return next((name for name in _SHEET_ALIASES.get(statement,(_SHEETS[statement],))
                     if name in self.writer.book),_SHEETS[statement])

    def _at(self,sheet,address,*,row_key='',source=None) -> CellRef | None:
        parts=_parts(address)
        if sheet not in self.writer.book or parts is None:return None
        column,row=parts;address=f'{get_column_letter(column)}{row}'
        ws=self.writer.book[sheet]
        if row<=1:return None
        dimension=ws.row_dimensions.get(row)
        if dimension is not None and dimension.hidden:return None
        for dim in ws.column_dimensions.values():
            if dim.hidden and dim.min and dim.min<=column<=(dim.max or dim.min):return None
        cell=ws._cells.get((row,column))
        if cell is None or cell.value is None:return None
        meta=self._metadata.get((sheet,address),{})
        if (sheet,address) in self.writer.values:
            value=_decimal(self.writer.values[(sheet,address)])
        elif isinstance(cell.value,(Decimal,int,float)) and not isinstance(cell.value,bool):
            value=_decimal(cell.value)
        elif cell.data_type=='f':value=_decimal(meta.get('display_value'))
        else:value=None
        if value is None:return None
        source=self.writer.sources.get((sheet,address),source)
        if source is None:source=meta.get('source')
        return CellRef(sheet,address,value,meta.get('row_key') or row_key,source)

    def _choose(self,refs,reason='') -> ResolvedInput | None:
        unique={(r.sheet,r.address):r for r in refs if r is not None}
        if len(unique)!=1:return None
        ref=next(iter(unique.values()))
        return ResolvedInput(ref.excel,ref.value,(ref,),reason)

    def _combine(self,inputs,reason='') -> ResolvedInput | None:
        unique={}
        for item in inputs:
            if item is not None:
                for ref in item.refs:unique.setdefault((ref.sheet,ref.address),ref)
        if not unique:return None
        refs=tuple(sorted(unique.values(),key=lambda r:(r.sheet,_parts(r.address)[0],_parts(r.address)[1])))
        return ResolvedInput(_expression(refs),sum((ref.value for ref in refs),Decimal(0)),refs,reason)

    def _eligible(self,row,period):
        if row.is_heading or period not in row.values:return False
        fact=row.values[period]
        dimensions,role,unit,_=_key_parts(row)
        if dimensions or unit!='JPY' or fact.source.unit!='JPY':return False
        if row.statement.startswith('BS') and role!='end':return False
        basis=self.dataset.period_bases.get(period,self.dataset.basis)
        if basis in {'consolidated','standalone'} and fact.source.basis!=basis:return False
        try:
            parts=json.loads(row.key.removeprefix('display:'))
            standard=parts[6] if row.key.startswith('display:') and len(parts)==8 else parts[7] if len(parts)==9 else ''
        except (ValueError,TypeError,IndexError):standard=''
        expected=self.dataset.period_standards.get(period,self.dataset.accounting_standard)
        return not standard or expected not in {'J-GAAP','IFRS','US-GAAP'} or standard==expected

    def _rows(self,statement,period,names=(),*,groups=(),current=False):
        found=[]
        for row in self.dataset.rows[statement]:
            if not self._eligible(row,period):continue
            if _local(row,period) not in names and not any(_group(row,name) for name in groups):continue
            scope=_scope(row,period)
            if current and (not scope&_CURRENT_ASSET or scope&_NONCURRENT_ASSET):continue
            found.append(row)
        return found

    def _row_ref(self,row,period):
        sheet=self._sheet(row.statement);fact=row.values[period]
        mapped=self.writer.source_addresses.get(row.key,{}).get(period)
        if mapped:
            # A condensed net row is a different amount from its original
            # gross/contra components. Keep those aliases for audit only.
            if mapped.get('net_display')and mapped.get('net_source_role')!='net':return None
            return self._at(mapped.get('sheet',sheet),mapped['address'],row_key=mapped.get('row_key',row.key),source=fact)
        items=self._by_row.get((sheet,row.key,period),[])
        if not items:
            items=self._by_source.get((sheet,period,_identity(fact.source)),[])
        return self._choose([self._at(item['sheet'],item['address'],row_key=row.key,source=fact) for item in items])

    def _row_refs(self,rows,period):
        refs=[]
        for row in rows:
            value=self._row_ref(row,period)
            if isinstance(value,ResolvedInput):refs.extend(value.refs)
            elif isinstance(value,CellRef):refs.append(value)
        return refs

    def _posted(self,statement,period,names=(),*,groups=(),current=False,reason=''):
        rows=self._rows(statement,period,names,groups=groups,current=current)
        if not rows:return None,False
        return self._choose(self._row_refs(rows,period),reason),True

    def _role(self,name,period):
        statement,role,names=_ROLE_NAMES[name];sheet=self._sheet(statement)
        nodes=[node for node in self.writer.layout_metadata.get(sheet,{}).get('nodes',[]) if node.get('role')==role]
        refs=[self._at(sheet,f'{get_column_letter(self.columns[period])}{node["row"]}',row_key=node.get('row_key','')) for node in nodes]
        result=self._choose(refs,'財務シートに表示された区分合計を参照。')
        if result:return result
        if nodes:return self._fail(name,period,'対象区分の表示値が空欄、または同じ年度の表示合計を一意に識別できません。')
        for local in names:
            result,exists=self._posted(statement,period,{local},reason='明示された対象区分の開示合計を参照。')
            if exists:return result or self._fail(name,period,'対象区分の表示合計が空欄、または複数あります。')
        return self._fail(name,period,'対象区分の開示合計がありません。')

    def _analysis(self,name,period):
        item=self.writer.bs_metrics.get(name,{}).get(period)
        result=self._choose([self._at(item['sheet'],item['address'],row_key=item.get('row_key',''))] if item else [],
                            '財務シートの確定した分析行を直接参照。')
        return result or self._fail(name,period,'分析行の表示値が未算出・空欄です。注記や原数値で置き換えません。')

    def _pl(self,name,period):
        items=self._by_row.get(('PL','metric:'+name,period),[])
        result=self._choose([self._at('PL',item['address'],row_key=item.get('row_key','')) for item in items],
                            '確定したPLの対応行を参照。')
        return result or self._fail(name,period,'対応するPLの表示値が空欄、または一意に識別できません。')

    def _pl_ratio(self,name,period):
        ws=self.writer.book['PL'];column=self.columns[period]
        def label(number):
            cell=ws._cells.get((number,1))
            return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(cell.value or ''))) if cell else ''
        if name=='effective_tax_rate':numbers=[r for r in range(2,ws.max_row+1) if label(r)=='実効税率']
        else:
            revenue_rows=[_parts(item['address'])[1] for item in self.writer.cells if item.get('sheet')=='PL' and item.get('row_key')=='metric:revenue']
            cost_rows=[_parts(item['address'])[1] for item in self.writer.cells if item.get('sheet')=='PL' and item.get('row_key')=='metric:cost_of_sales']
            if not revenue_rows:return self._fail(name,period,'売上高の表示行を確認できないため、対応する成長率を特定できません。')
            start=min(revenue_rows);stop=min((r for r in cost_rows if r>start),default=ws.max_row+1)
            numbers=[r for r in range(start+1,stop) if label(r) in {'(増加率)','(前年比)','前年比','売上高成長率','売上高増加率'}]
        result=self._choose([self._at('PL',f'{get_column_letter(column)}{r}') for r in numbers],
                            'PL内の対応する比率表示行を参照。')
        return result or self._fail(name,period,'対応するPL比率が未算出・空欄です（初年度、分母0、入力未開示等）。')

    def _trade_receivables(self,period):
        name='trade_receivables'
        for names,groups in [({'NotesAndAccountsReceivableTrade'},('trade_receivables',)),
                             ({'TradeReceivablesCAIFRS','TradeReceivablesIFRS'},())]:
            result,exists=self._posted('BS_A',period,names,groups=groups,reason='売上債権だけの開示合算額・検証済み統合行を参照。')
            if exists:return result or self._fail(name,period,'売上債権の合算表示が空欄・nil、または一意でないため内訳で補完しません。')
        inputs=[]
        for local in ['NotesReceivableTrade','AccountsReceivableTrade']:
            result,exists=self._posted('BS_A',period,{local})
            if exists and result is None:return self._fail(name,period,'売上債権の開示構成項目に空欄・nil又は重複があります。')
            if result:inputs.append(result)
        return self._combine(inputs,'開示された独立の受取手形・売掛金だけを合計。') or self._fail(name,period,'売上債権だけの表示行がありません。TradeAndOther等の広い残高は代用しません。')

    def _security_rows(self,period,*,current=False):
        rows=self._rows('BS_A',period,_CURRENT_SECURITIES,current=current)
        rows=[row for row in rows if _local(row,period)!='MarketableSecuritiesCAIFRS' or
              _concept(row.values[period].source.account_concept)[0]=='jpigp_cor']
        if (self.dataset.code!='4519' or
                self.dataset.period_standards.get(period,self.dataset.accounting_standard)!='IFRS'):
            return rows
        semantic='{urn:zaimu10:html-table:E00932:ConsolidatedStatementOfFinancialPositionIFRSTextBlock}HtmlRow_75a00c5d50a158d817'
        for row in self.dataset.rows['BS_A']:
            if not self._eligible(row,period):continue
            cell=row.values[period];source=cell.source
            family,local,_=_concept(source.concept)
            if (family!='jpcrp_cor' or local!='ConsolidatedStatementOfFinancialPositionIFRSTextBlock'
                    or source.semantic_concept!=semantic or source.original_label!='有価証券'
                    or '_E00932-'not in source.filename or source.basis!='consolidated'):
                continue
            scope=_scope(row,period)
            if not scope&_CURRENT_ASSET or scope&_NONCURRENT_ASSET:continue
            try:
                path=json.loads(source.table_path)
                if any(type(path.get(k))is not int or path[k]<0 for k in ('table','row','column')):continue
            except (ValueError,TypeError,AttributeError):continue
            rows.append(row)
        return rows

    def _inventory(self,period):
        name='inventory'
        result,exists=self._posted('BS_A',period,{'Inventories','InventoriesIFRS','InventoriesCAIFRS','TotalInventories'},reason='開示済みの棚卸資産合計を優先。')
        if exists:return result or self._fail(name,period,'棚卸資産合計の表示が空欄・nil、または一意でないため内訳で補完しません。')
        inputs=[]
        for names,groups,parts in [({'MerchandiseAndFinishedGoods'},('inventory_goods',),['Merchandise','FinishedGoods']),
                                   ({'WorkInProcess'},(),[]),
                                   ({'RawMaterialsAndSupplies'},('inventory_materials',),['RawMaterials','Supplies'])]:
            result,exists=self._posted('BS_A',period,names,groups=groups)
            if exists:
                if result is None:return self._fail(name,period,'棚卸資産の開示構成項目に空欄・nil又は重複があります。')
                inputs.append(result);continue
            for local in parts:
                item,known=self._posted('BS_A',period,{local})
                if known and item is None:return self._fail(name,period,'棚卸資産の開示構成項目に空欄・nil又は重複があります。')
                if item:inputs.append(item)
        return self._combine(inputs,'開示のある商品・製品、仕掛品、原材料・貯蔵品だけを合計。存在しない項目を原数値0として作成しません。') or self._fail(name,period,'棚卸資産の合計・既知構成項目の可視数値がありません。')

    def _trade_payables(self,period):
        name='trade_payables'
        result,exists=self._posted('BS_LE',period,{'NotesAndAccountsPayableTrade','TradePayablesCLIFRS','TradePayablesIFRS'},reason='開示された仕入債務合算額を優先。')
        if exists:return result or self._fail(name,period,'仕入債務合算額が空欄・nil又は一意でないため内訳で補完しません。')
        inputs=[]
        for local in ['NotesPayableTrade','AccountsPayableTrade']:
            result,exists=self._posted('BS_LE',period,{local})
            if exists and result is None:return self._fail(name,period,'仕入債務の開示構成項目に空欄・nil又は重複があります。')
            if result:inputs.append(result)
        return self._combine(inputs,'開示された独立の支払手形・買掛金のみを合計。') or self._fail(name,period,'仕入債務だけの可視数値がありません。TradeAndOtherPayables等の広い残高は代用しません。')

    def _cf_slot(self,slot,period):
        sheet=self._sheet('CF');roles=self.writer.layout_metadata.get(sheet,{}).get('roles',{})
        shares=self._share_investment_rows(slot,period)
        number=roles.get(str(slot),roles.get(slot))
        if number:
            ref=self._at(sheet,f'{get_column_letter(self.columns[period])}{number}',row_key='template:CF:'+str(slot))
            if ref:
                primary=ResolvedInput(ref.excel,ref.value,(ref,),'確定したCF表示区分を参照。')
                if not shares:return primary
                additional=[ResolvedInput(r.excel,r.value,(r,))for r in self._row_refs(shares,period)]
                return self._combine([primary]+additional,'確定した関係会社株式区分と、別行で開示された子会社・持分法適用会社の株式取得/売却を原符号で合計。')
        names={local for local,value in CF_LOCAL_SLOTS.items() if value==slot}|_CF_EXTRA.get(slot,set())
        rows=self._rows('CF',period,names)+self._html_disposal_rows(slot,period)+shares
        refs=self._row_refs(rows,period)
        if not refs:return None
        # A known combined acquisition line dominates its narrower spelling.
        broad={'PurchaseOfPropertyPlantAndEquipmentAndInvestmentPropertyInvCFIFRS',
               'ProceedsFromSaleOfPropertyPlantAndEquipmentAndInvestmentPropertyInvCFIFRS'}
        broad_rows=[row for row in rows if _local(row,period) in broad]
        if broad_rows:return self._choose(self._row_refs(broad_rows,period),'同範囲の開示合算額を優先。')
        return self._combine([ResolvedInput(ref.excel,ref.value,(ref,)) for ref in refs],
                             '固定区分にない既知のCF原項目を、実際の表示行から参照。')

    def _share_investment_rows(self,slot,period):
        if (slot not in _CF_SHARE_INVESTMENTS or
                self.dataset.period_standards.get(period,self.dataset.accounting_standard)!='IFRS'):
            return []
        rows=[]
        for row in self.dataset.rows['CF']:
            if not self._eligible(row,period):continue
            cell=row.values[period];source=cell.source
            if not _scope(row,period)&{'投資活動によるキャッシュ・フロー','投資活動によるキャッシュフロー'}:continue
            family,local,_=_concept(source.account_concept)
            if family=='jpigp_cor' and local in _CF_SHARE_INVESTMENTS[slot] and '株式'in source.original_label:
                rows.append(row);continue
            if self.dataset.code!='2802' or source.basis!='consolidated' or '_E00436-'not in source.filename:continue
            caption,html_local={50:('持分法で処理される投資の株式の取得による支出','HtmlRow_856acc641e50c270c2'),
                51:('持分法で処理される投資の株式の売却による収入','HtmlRow_f778a77013062783cd')}[slot]
            genuine_family,genuine_local,_=_concept(source.concept)
            semantic='{urn:zaimu10:html-table:E00436:ConsolidatedStatementOfCashFlowsIFRSTextBlock}'+html_local
            if (genuine_family!='jpcrp_cor' or genuine_local!='ConsolidatedStatementOfCashFlowsIFRSTextBlock'
                    or source.semantic_concept!=semantic or source.original_label!=caption):continue
            try:
                path=json.loads(source.table_path)
                if any(type(path.get(k))is not int or path[k]<0 for k in ('table','row','column')):continue
            except (ValueError,TypeError,AttributeError):continue
            rows.append(row)
        return rows

    def _html_disposal_rows(self,slot,period):
        """Verified old Chugai main-CF disposal rows, not taxonomy aliases.

        The 2016–17 authoritative comparative tables predate numeric tagging.
        Their exact disposal captions continue as standard numeric tags in
        the later IFRS main statement. Preserve the original signed cash flow.
        """
        if slot not in _CHUGAI_HTML_DISPOSALS or self.dataset.code!='4519':return []
        if self.dataset.period_standards.get(period,self.dataset.accounting_standard)!='IFRS':return []
        caption,semantic_local=_CHUGAI_HTML_DISPOSALS[slot]
        semantic='{urn:zaimu10:html-table:E00932:ConsolidatedStatementOfCashFlowsIFRSTextBlock}'+semantic_local
        rows=[]
        for row in self.dataset.rows['CF']:
            if not self._eligible(row,period):continue
            cell=row.values[period];source=cell.source
            family,local,_=_concept(source.concept)
            if (family!='jpcrp_cor' or local!='ConsolidatedStatementOfCashFlowsIFRSTextBlock'
                    or source.semantic_concept!=semantic or source.original_label!=caption
                    or '_E00932-' not in source.filename or source.basis!='consolidated'):
                continue
            if (cell.display_group or row.display_group)!='investing':continue
            if not _scope(row,period)&{'投資活動によるキャッシュ・フロー','投資活動によるキャッシュフロー'}:continue
            try:
                path=json.loads(source.table_path)
                if any(type(path.get(k))is not int or path[k]<0 for k in ('table','row','column')):continue
            except (ValueError,TypeError,AttributeError):continue
            rows.append(row)
        return rows

    def _interest_paid(self,period):
        inputs=[];operating=self._cf_slot(35,period)
        if operating:inputs.append(operating)
        rows=self._rows('CF',period,_INTEREST_CASH)+self._html_interest_rows(period)
        for row in rows:
            ref=self._row_ref(row,period)
            if isinstance(ref,ResolvedInput):inputs.append(ref)
            elif isinstance(ref,CellRef):inputs.append(ResolvedInput(ref.excel,ref.value,(ref,)))
        return self._combine(inputs,'実際の営業・財務CFの支払利息を原符号のまま合計。非現金の支払利息調整（CF11）は含めません。') or self._fail('interest_paid',period,'実際の現金支払利息の可視数値がありません。CF11の損益調整は代用しません。')

    def _html_interest_rows(self,period):
        """Exact Chugai financing-cash interest in pre-numeric-tag tables."""
        if (self.dataset.code!='4519' or
                self.dataset.period_standards.get(period,self.dataset.accounting_standard)!='IFRS'):
            return []
        semantic='{urn:zaimu10:html-table:E00932:ConsolidatedStatementOfCashFlowsIFRSTextBlock}HtmlRow_cbd37ad74075e2cf7b'
        rows=[]
        for row in self.dataset.rows['CF']:
            if not self._eligible(row,period):continue
            cell=row.values[period];source=cell.source
            family,local,_=_concept(source.concept)
            if (family!='jpcrp_cor' or local!='ConsolidatedStatementOfCashFlowsIFRSTextBlock'
                    or source.semantic_concept!=semantic or source.original_label!='利息の支払'
                    or '_E00932-'not in source.filename or source.basis!='consolidated'):
                continue
            if (cell.display_group or row.display_group)!='financing':continue
            if not _scope(row,period)&{'財務活動によるキャッシュ・フロー','財務活動によるキャッシュフロー'}:continue
            try:
                path=json.loads(source.table_path)
                if any(type(path.get(k))is not int or path[k]<0 for k in ('table','row','column')):continue
            except (ValueError,TypeError,AttributeError):continue
            rows.append(row)
        return rows

    def _shareholders_equity(self,period):
        name='shareholders_equity'
        rows=[row for row in self._rows('BS_LE',period,{'ShareholdersEquity'})
              if _concept(row.values[period].source.account_concept)[0]=='jppfs_cor']
        if rows:
            return self._choose(self._row_refs(rows,period),'日本基準の株主資本合計を参照。') or self._fail(name,period,'株主資本合計の表示が空欄又は一意ではありません。')
        components=[]
        for aliases in [({'ShareCapitalIFRS','IssuedCapitalIFRS'}),({'CapitalSurplusIFRS','SharePremiumIFRS'}),
                        ({'RetainedEarningsIFRS'}),({'TreasurySharesIFRS'})]:
            candidates=[row for row in self._rows('BS_LE',period,aliases)
                        if self._ifrs_capital_source(row.values[period].source,period)]
            item=self._choose(self._row_refs(candidates,period))
            if item is None:return self._fail(name,period,'標準の株主資本合計、又はIFRSの資本金・資本剰余金・利益剰余金・符号付き自己株式の全表示項目を確認できません。親会社帰属持分で代用しません。')
            components.append(item)
        owner_rows=[row for row in self._rows('BS_LE',period,{'EquityAttributableToOwnersOfParentIFRS'})
                    if self._ifrs_capital_source(row.values[period].source,period)]
        owner=self._choose(self._row_refs(owner_rows,period))
        if owner is None:return self._fail(name,period,'IFRSの四構成項目を検証する親会社帰属持分の表示合計がありません。')
        sheet=self._sheet('BS_LE');owner_ref=owner.refs[0]
        node=next((node for node in self.writer.layout_metadata.get(sheet,{}).get('nodes',[])
                   if node.get('row')==_parts(owner_ref.address)[1]),None)
        component_refs=[ref for item in components for ref in item.refs]
        component_rows={_parts(ref.address)[1] for ref in component_refs}
        if node is None or not component_rows<=set(node.get('children',[])):
            return self._fail(name,period,'親会社帰属持分の原文階層で四構成項目の包含関係を確認できません。')
        excluded_names={'OtherComponentsOfEquityIFRS','AccumulatedOtherComprehensiveIncomeIFRS'}
        excluded=[]
        for number in node.get('children',[]):
            if number in component_rows:continue
            address=f'{get_column_letter(self.columns[period])}{number}'
            ref=self._at(sheet,address)
            if ref is None:
                unknown=self.writer.sources.get((sheet,address))
                original=_source_dict({'source':unknown})
                if _source_field(original,'semantic_concept').startswith('{urn:zaimu10:html-table:E00436:ConsolidatedStatementOfFinancialPositionIFRSTextBlock}'):
                    return self._fail(name,period,'HTML資本区分に明示的なnil・未確定の構成残高があり、完全な分解を照合できません。')
                continue
            source=_source_dict({'source':ref.source})
            account=_source_field(source,'semantic_concept') or _source_field(source,'concept')
            family,local,_=_concept(account)
            if not self._ifrs_capital_source(source,period) or local not in excluded_names:
                return self._fail(name,period,'親会社帰属持分の分解に、OCI等と確認できない追加資本項目があります。未分類項目を株主資本へ推測加算しません。')
            excluded.append(ref)
        proof_refs=component_refs+excluded+list(owner.refs)
        html_prefix='{urn:zaimu10:html-table:E00436:ConsolidatedStatementOfFinancialPositionIFRSTextBlock}'
        if any(_source_field(_source_dict({'source':ref.source}),'semantic_concept').startswith(html_prefix)for ref in proof_refs):
            frames=set()
            for ref in proof_refs:
                original=_source_dict({'source':ref.source})
                raw=ref.source
                section=raw.get('source_section')if isinstance(raw,dict)else getattr(raw,'source_section',None)
                try:path=json.loads(_source_field(original,'table_path'))
                except (ValueError,TypeError):path={}
                if (not _source_field(original,'semantic_concept').startswith(html_prefix)
                        or tuple(section or ())!=('資本',)or not all(type(path.get(k))is int and path[k]>=0 for k in ('table','row','column'))):
                    return self._fail(name,period,'HTML資本構成項目を同じ原文の資本区分・年度列・表へ照合できません。')
                frames.add(tuple(_source_field(original,k)for k in ('doc_id','filename','context_id','unit','basis'))+
                           (tuple(section),path['table'],path['column']))
            if len(frames)!=1:return self._fail(name,period,'HTML資本構成項目と親会社帰属持分の原本・年度列・対象区分が一致しません。')
        origins={(_source_field(_source_dict({'source':ref.source}),'doc_id'),
                  _source_field(_source_dict({'source':ref.source}),'basis')) for ref in proof_refs}
        if len(origins)!=1:return self._fail(name,period,'IFRS資本構成項目と親会社帰属持分の原本・連結区分が一致しません。')
        tolerance=Decimal(0)
        for ref in proof_refs:
            try:tolerance+=Decimal(10)**(-int(_source_field(_source_dict({'source':ref.source}),'decimals')))/self.writer.factor
            except (ValueError,TypeError,InvalidOperation):pass
        tolerance=max(tolerance,Decimal(1)/self.writer.factor)
        total=sum((ref.value for ref in component_refs+excluded),Decimal(0))
        if abs(total-owner.value)>tolerance:
            return self._fail(name,period,'IFRSの資本構成項目と親会社帰属持分が原文の丸め精度内で照合できません。')
        return self._combine(components,'原文で確認した四構成項目（資本金・資本剰余金・利益剰余金・符号付き自己株式）の完全な分解を原文階層・親会社帰属持分と照合。OCI・非支配持分・その他資本は含めません。')

    def _ifrs_capital_source(self,source,period):
        account=_source_field(source,'semantic_concept')or _source_field(source,'concept')
        family,local,_=_concept(account)
        if family=='jpigp_cor':return True
        if (self.dataset.code!='2802' or self.dataset.period_standards.get(period,self.dataset.accounting_standard)!='IFRS'
                or _source_field(source,'basis')!='consolidated' or _source_field(source,'unit')!='JPY'
                or '_E00436-'not in _source_field(source,'filename')):return False
        prefix='{urn:zaimu10:html-table:E00436:ConsolidatedStatementOfFinancialPositionIFRSTextBlock}'
        captions={'ShareCapitalIFRS':'資本金','CapitalSurplusIFRS':'資本剰余金','RetainedEarningsIFRS':'利益剰余金',
            'TreasurySharesIFRS':'自己株式','OtherComponentsOfEquityIFRS':'その他の資本の構成要素',
            'EquityAttributableToOwnersOfParentIFRS':'親会社の所有者に帰属する持分'}
        genuine_family,genuine_local,_=_concept(_source_field(source,'concept'))
        return (genuine_family=='jpcrp_cor'and genuine_local=='ConsolidatedStatementOfFinancialPositionIFRSTextBlock'
            and account==prefix+local and local in captions and _source_field(source,'original_label')==captions[local])

    def _resolve(self,name,period):
        if name=='net_profit_parent':
            if self._by_row.get(('PL','metric:net_profit_parent',period)):
                return self._pl('net_profit_parent',period)
            parent=self.parent_profit_input(period)
            if parent and parent.visible:return parent.visible
            return self._fail(name,period,self._reasons.get((name,period))or
                '親会社帰属利益の原文は確認できましたが、可視の対応行としてまだ出力されていません。')
        if name in _PL:return self._pl(name,period)
        if name in {'effective_tax_rate','sales_growth'}:return self._pl_ratio(name,period)
        if name in {'invested_capital','interest_bearing_debt'}:return self._analysis(name,period)
        if name in _ROLE_NAMES:return self._role(name,period)
        if name=='shareholders_equity':return self._shareholders_equity(period)
        if name=='trade_receivables':return self._trade_receivables(period)
        if name=='inventory':return self._inventory(period)
        if name=='trade_payables':return self._trade_payables(period)
        if name=='cash':
            result,exists=self._posted('BS_A',period,{'CashAndDeposits','CashAndCashEquivalentsIFRS'},reason='主表の現金及び預金・現金同等物を参照。')
            return result or self._fail(name,period,'主表の現金及び預金・現金同等物の可視数値がありません。')
        if name=='current_securities':
            result=self._choose(self._row_refs(self._security_rows(period,current=True),period),
                                '流動資産の独立した有価証券を参照。')
            return result or self._fail(name,period,'流動有価証券の独立表示を確認できません。非流動投資有価証券や広い金融資産は代用しません。')
        if name=='construction_in_progress':
            result,exists=self._posted('BS_A',period,{'ConstructionInProgress','ConstructionInProgressPPE','ConstructionInProgressIFRS','ConstructionInProgressPPEIFRS'},reason='開示された建設仮勘定のみを参照。')
            return result or self._fail(name,period,'建設仮勘定の可視数値がありません。設備全体や前渡金で代用しません。')
        if name=='interest_paid':return self._interest_paid(period)
        if name in {'noncash','ebitda_addback','capex'}:
            slots=([4,5,6]if name=='noncash'else [4,5]if name=='ebitda_addback'else [44,45,46,47,50,51])
            result=self._combine([self._cf_slot(slot,period) for slot in slots],
                '見本で定義されたCF区分のうち、実際に数値が表示された項目だけを原符号で合計。未開示項目の原数値0は作成しません。')
            return result or self._fail(name,period,'定義に該当するCF項目の可視数値がありません。全欠損を0に置き換えません。')
        return self._fail(name,period,'未定義の財務入力名です: '+str(name))
