"""Align a nominal market quote to the officially dated issued-share basis.

An exchange ex-rights date is not a company's legal split effective date. An
annual-report share count can therefore remain pre-split after the quoted price
has already become ex-rights. Only explicit official legal-date/ratio evidence
and matching fiscal/filing share counts justify changing the price basis.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
import hashlib
import re
import unicodedata

from lxml import html, etree

from .models import Filing, Period
from .parser import Page, _contexts, _elements, _expanded, _namespaces, _number, _text, _units, concept_identity

BLOCK = 'jpcrp_cor:IssuedSharesTotalNumberOfSharesEtcTextBlock'
FISCAL_COUNT = 'jpcrp_cor:NumberOfIssuedSharesAsOfFiscalYearEndIssuedSharesTotalNumberOfSharesEtc'
FILING_COUNT = 'jpcrp_cor:NumberOfIssuedSharesAsOfFilingDateIssuedSharesTotalNumberOfSharesEtc'
_DATE = r'(?P<year>\d{4}|令和(?:\d+|元)|平成(?:\d+|元))年(?P<month>\d{1,2})月(?P<day>\d{1,2})日'
_NUMBER = r'\d[\d,]*(?:\.\d+)?'
_RATIO = re.compile(r'(?P<before>'+_NUMBER+r')株(?:を|につき|に対し(?:て)?)(?:普通株式)?(?P<after>'+_NUMBER+r')株')
_LEGAL = re.compile(_DATE+r'(?:付(?:け)?(?:で|に)?|を効力発生日とし(?:て)?|を効力発生日として)')
CHANGES_BLOCK = 'jpcrp_cor:ChangesInNumberOfIssuedSharesStatedCapitalEtcTextBlock'


class _IdentityError(ValueError):
    pass


def _compact(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', str(value)))


def _positive(value):
    try:
        amount = Decimal(str(value).replace(',', ''))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError('正の数値を確認できません。') from None
    if not amount.is_finite() or amount <= 0:
        raise ValueError('正の数値を確認できません。')
    return amount


def _day(match):
    text = match.group('year')
    if text.startswith(('令和', '平成')):
        base = 2018 if text.startswith('令和') else 1988
        year = base + (1 if text[2:] == '元' else int(text[2:]))
    else:
        year = int(text)
    return date(year, int(match.group('month')), int(match.group('day')))


def _parse_pages(pages):
    return [Page(filename, html.fromstring(markup.lstrip('\ufeff').encode('utf-8'),
                parser=html.HTMLParser(encoding='utf-8', no_network=True)), _namespaces(markup))
            for filename, markup in pages]


def _official_evidence(pages, filing):
    parsed = _parse_pages(pages)
    contexts, units = _contexts(parsed), _units(parsed)
    submitted = date.fromisoformat(filing.submitted[:10])
    dei = {}
    for page in parsed:
        for node in _elements(page.root, 'nonnumeric'):
            concept = concept_identity(_expanded(node.get('name', ''), page.namespaces))
            if concept in {'jpdei_cor:SecurityCodeDEI', 'jpdei_cor:CurrentFiscalYearEndDateDEI'}:
                dei.setdefault(concept, set()).add(_text(node))
    if (dei.get('jpdei_cor:SecurityCodeDEI') != {filing.code+'0'} or
            dei.get('jpdei_cor:CurrentFiscalYearEndDateDEI') != {filing.end.isoformat()}):
        raise _IdentityError('株式分割の原文DEIが対象銘柄・期末と一致しません。')
    blocks = []
    for page in parsed:
        for node in _elements(page.root, 'nonnumeric'):
            if concept_identity(_expanded(node.get('name', ''), page.namespaces)) == BLOCK:
                blocks.append((page, node))
    if len(blocks) != 1:
        raise ValueError('発行済株式TextBlockを一意に確認できません。')
    page, block = blocks[0]
    if block.get('continuedat'):
        raise ValueError('発行済株式TextBlockの継続参照は推測しません。')
    counts = {FISCAL_COUNT: [], FILING_COUNT: []}
    for node in _elements(block, 'nonfraction'):
        concept = concept_identity(_expanded(node.get('name', ''), page.namespaces))
        if concept not in counts:
            continue
        context = contexts.get(node.get('contextref'))
        if not context or context.dimensions or context.basis is not None:
            continue
        if not context.instant or context.end not in {filing.end, submitted} or units.get(node.get('unitref')) != 'shares':
            raise ValueError('発行済株式数の期間・単位を確認できません。')
        amount, nil, raw = _number(node)
        if nil or amount is None or amount <= 0 or amount != amount.to_integral_value():
            raise ValueError('発行済株式数が未確定です。')
        counts[concept].append({'value': amount, 'raw': raw, 'concept': _expanded(node.get('name', ''), page.namespaces),
                                'context_id': context.id})
    for values in counts.values():
        if len({value['value'] for value in values}) > 1:
            raise ValueError('同じ期末・提出日の発行済株式数に矛盾があります。')
    declarations = []
    unparsed = []
    for paragraph in block.xpath('.//p | .//h1 | .//h2 | .//h3 | .//h4'):
        text = _text(paragraph)
        compact = _compact(text)
        if not re.search(r'株式(?:分割|併合)', compact):
            continue
        matched = False
        for sentence in compact.split('。'):
            if not re.search(r'株式(?:分割|併合)', sentence):
                continue
            legal = list(_LEGAL.finditer(sentence))
            ratios = list(_RATIO.finditer(sentence))
            if len(legal) != 1 or len(ratios) != 1:
                continue
            if any(word in sentence for word in ('仮定', '行う場合', '分割する場合', '併合する場合', '中止', '延期', '予定')):
                continue
            effective = _day(legal[0])
            if effective > submitted:
                continue  # A future announced event cannot explain filing shares.
            ratio = _positive(ratios[0].group('after'))/_positive(ratios[0].group('before'))
            if ratio == 1:
                continue
            declarations.append({'legal_effective_date': effective.isoformat(), 'ratio': str(ratio),
                'before_shares_per_unit': ratios[0].group('before'), 'after_shares_per_unit': ratios[0].group('after'),
                'quoted_paragraph': text, 'filename': page.filename, 'textblock_qname': _expanded(block.get('name', ''), page.namespaces),
                'context_id': block.get('contextref', ''), 'doc_id': filing.doc_id,
                'source_url': f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}'})
            matched = True
        if not matched:
            unparsed.append(text)
    unique = {}
    for item in declarations:
        key = item['legal_effective_date']
        if key in unique and unique[key]['ratio'] != item['ratio']:
            raise ValueError('同じ法的効力発生日に異なる分割比率があります。')
        unique[key] = item
    return list(unique.values()), counts, unparsed


def _capital_movement_reconciliation(pages, filing, fiscal_end, opening, closing, declarations):
    """Account for separately documented post-fiscal issuances, never a plug.

    Statutory tables often stop at the fiscal date and put later split/issuance
    events in dated footnotes. Both remain inside the genuine capital-history
    TextBlock. Every used delta is explicit; the timeline must equal the filing
    share count exactly, including each split's stated increase if provided.
    """
    parsed = _parse_pages(pages)
    contexts = _contexts(parsed)
    submitted = date.fromisoformat(filing.submitted[:10])
    candidates = [(page, node) for page in parsed for node in _elements(page.root, 'nonnumeric')
                  if concept_identity(_expanded(node.get('name', ''), page.namespaces)) == CHANGES_BLOCK]
    if len(candidates) != 1:
        raise ValueError('追加発行を照合する発行済株式総数推移TextBlockが一意ではありません。')
    page, block = candidates[0]
    context = contexts.get(block.get('contextref'))
    if (not context or not context.instant or context.end != submitted or context.dimensions
            or context.basis is not None or block.get('continuedat')):
        raise ValueError('発行済株式総数推移の期間・対象を確認できません。')
    tables = block.xpath('.//table')
    if not tables or any(table.xpath('.//table') for table in tables):
        raise ValueError('発行済株式総数推移の対応する表がありません。')
    headers = [_compact(_text(cell)) for cell in tables[0].xpath('.//tr')[0].xpath('./td | ./th')]
    if (len(headers) < 3 or headers[0] != '年月日' or
            headers[1] != '発行済株式総数増減数(株)' or headers[2] != '発行済株式総数残高(株)'):
        raise ValueError('発行済株式総数推移の列見出しを確認できません。')
    dated_rows = []
    for table in tables:
        for row in table.xpath('.//tr')[1:]:
            cells = row.xpath('./td | ./th')
            if len(cells) < 3:
                continue
            dates = list(re.finditer(_DATE, _compact(_text(cells[0]))))
            future = [match for match in dates if fiscal_end < _day(match) <= submitted]
            if not future:
                continue
            if len(dates) != 1:
                raise ValueError('期末後の発行済株式推移の期間行を単一の効力日と推定しません。')
            raw_delta = _compact(_text(cells[1])).replace('△', '-').replace('▲', '-').replace('−', '-')
            if not re.fullmatch(r'-?\d[\d,]*', raw_delta):
                raise ValueError('期末後の発行済株式推移の増減数が未確認です。')
            dated_rows.append({'date': _day(dates[0]).isoformat(),
                               'delta_shares': str(Decimal(raw_delta.replace(',', ''))),
                               'closing_shares': str(_positive(_compact(_text(cells[2])))),
                               'quoted_row': _text(row)})
    future_splits = {item['legal_effective_date']: item for item in declarations
                     if fiscal_end < date.fromisoformat(item['legal_effective_date']) <= submitted}
    corroborated = {}
    issuances = {}
    for paragraph in block.xpath('.//p'):
        text = _text(paragraph)
        compact = _compact(text)
        if '発行済株式総数' not in compact or not re.search(r'株(?:増加|減少)', compact):
            continue
        dates = list(re.finditer(_DATE, compact))
        after_fiscal = [match for match in dates if fiscal_end < _day(match) <= submitted]
        if not after_fiscal:
            continue
        if re.search(r'株式(?:分割|併合)', compact):
            legal = list(_LEGAL.finditer(compact)); ratios = list(_RATIO.finditer(compact))
            changes = re.findall(r'発行済株式総数は('+_NUMBER+r')株(増加|減少)', compact)
            if len(legal) != 1 or len(ratios) != 1 or len(changes) != 1:
                raise ValueError('資本推移注記の分割増減数・効力日を一意に確認できません。')
            day = _day(legal[0]).isoformat()
            ratio = _positive(ratios[0].group('after'))/_positive(ratios[0].group('before'))
            if day not in future_splits or ratio != _positive(future_splits[day]['ratio']):
                raise ValueError('発行済株式表と資本推移注記の分割日・比率が一致しません。')
            delta = _positive(changes[0][0]) * (1 if changes[0][1] == '増加' else -1)
            if day in corroborated and corroborated[day]['delta'] != delta:
                raise ValueError('同じ分割の明示増減数が一致しません。')
            corroborated[day] = dict(delta=delta, quoted_paragraph=text)
        else:
            # A payment date with an explicit new-share cause and issued-share
            # delta is strong evidence; arbitrary narrative numbers are not.
            payment = list(re.finditer(_DATE+r'を払込期日とする', compact))
            changes = re.findall(r'発行済株式総数は('+_NUMBER+r')株(増加|減少)', compact)
            if (len(payment) != 1 or len(changes) != 1
                    or not re.search(r'公募|第三者割当|新株式の発行', compact)
                    or any(word in compact for word in ('予定', '仮定', '中止'))):
                raise ValueError('期末後の発行済株式増減を明示された払込日・原因・株数で照合できません。')
            day = _day(payment[0]).isoformat()
            delta = _positive(changes[0][0]) * (1 if changes[0][1] == '増加' else -1)
            if day in issuances and issuances[day]['delta'] != delta:
                raise ValueError('同じ払込日の追加発行数が一致しません。')
            issuances[day] = dict(delta=delta, quoted_paragraph=text)
    if not issuances or set(corroborated) != set(future_splits):
        raise ValueError('分割以外の追加発行と全ての法的分割を照合できません。')
    balance = opening
    movements = []
    for day in sorted(set(future_splits) | set(issuances)):
        if day in future_splits and day in issuances:
            raise ValueError('同日の分割と追加発行の適用順序を推測しません。')
        if day in future_splits:
            ratio = _positive(future_splits[day]['ratio'])
            delta = balance*(ratio-1)
            evidence = corroborated[day]
            if delta != evidence['delta']:
                raise ValueError('分割前残高×分割比率と明示された株数増減が一致しません。')
            kind = 'legal_split'
        else:
            evidence = issuances[day]; delta = evidence['delta']; kind = 'new_issuance'
        balance += delta
        movements.append(dict(date=day, kind=kind, delta_shares=str(delta), closing_shares=str(balance),
                              quoted_paragraph=evidence['quoted_paragraph']))
    if balance != closing:
        raise ValueError('明示された分割・追加発行の合計が提出日発行済株式数と一致しません。')
    for row in dated_rows:
        matching = [movement for movement in movements if movement['date'] == row['date']
                    and movement['delta_shares'] == row['delta_shares']
                    and movement['closing_shares'] == row['closing_shares']]
        if len(matching) != 1:
            raise ValueError('期末後の資本推移表と注記による発行数の照合が一致しません。')
    return {'method': 'official dated split and separately stated issuance movements',
            'opening_fiscal_shares': str(opening), 'closing_filing_shares': str(closing),
            'movements': movements, 'dated_table_rows': dated_rows, 'filename': page.filename,
            'textblock_qname': _expanded(block.get('name', ''), page.namespaces),
            'context_id': block.get('contextref', ''), 'doc_id': filing.doc_id}


def align_fiscal_share_basis(pages: list[tuple[str, str]], filing: Filing, period: Period,
                             share_count: dict, fiscal_price: dict) -> dict:
    """Return a copied price; ambiguous boundary actions become unavailable.

    Input price is a true nominal domestic close on its trading date. The
    official fiscal share count stays unchanged. Events describe exchange
    ex-rights dates; explicit official declarations supply legal dates.
    """
    result = deepcopy(fiscal_price)
    result.setdefault('basis_adjustments', [])
    result['basis_alignment_status'] = 'unverified'
    def unavailable(reason):
        result.update(available=False, basis_alignment_status='unverified', basis_reason=reason, reason=reason)
        return result
    if result.get('available') is False:
        return unavailable(result.get('reason') or '基準となる株価が未取得です。')
    try:
        if (filing.end != period.end or str(share_count.get('doc_id')) != filing.doc_id
                or share_count.get('fiscal_end') != period.end.isoformat()
                or share_count.get('unit') != 'shares'):
            raise ValueError('株価と公式発行済株式数の原本・期末が一致しません。')
        fiscal_shares = _positive(share_count.get('value_shares'))
        if fiscal_shares != fiscal_shares.to_integral_value():
            raise ValueError('発行済株式数が整数ではありません。')
        source = dict(pages)
        source_markup = source.get(share_count.get('filename'))
        if source_markup is None or hashlib.sha256(source_markup.encode('utf-8')).hexdigest() != share_count.get('sha256'):
            raise ValueError('発行済株式数の原本ハッシュを照合できません。')
        trading = date.fromisoformat(result.get('trading_date') or result.get('date') or '')
        if trading > period.end or (period.end-trading).days > 10:
            raise ValueError('株価の取引日が対象期末と対応しません。')
        if 'nominal_close_jpy' not in result:
            raise ValueError('当時の名目終値を特定できません。分割調整後終値を推測で使用しません。')
        nominal = _positive(result['nominal_close_jpy'])
        events = result.get('stock_split_events')
        if not isinstance(events, list):
            raise ValueError('取引日に適用された株式分割イベントの一覧がありません。')
        normalized = []
        seen = set()
        for event in events:
            day = date.fromisoformat(str(event['date']))
            ratio = _positive(event['numerator'])/_positive(event['denominator'])
            key = (day, ratio)
            if key not in seen:
                normalized.append((day, ratio, event)); seen.add(key)
        near = [(day, ratio, event) for day, ratio, event in normalized
                if period.end-timedelta(days=14) <= day <= period.end]
        # A missing/contradictory stock chapter cannot prove that no boundary
        # adjustment is needed; unsupported material stays unavailable.
        declarations, counts, unparsed = _official_evidence(pages, filing)
        # Even a missing exchange event cannot justify assuming that a proved
        # post-fiscal legal split had no ex-rights price transition.
        future_declarations = [item for item in declarations if period.end <
                               date.fromisoformat(item['legal_effective_date'])]
        for item in future_declarations:
            legal = date.fromisoformat(item['legal_effective_date'])
            matches = [(day, ratio) for day, ratio, event in normalized
                       if ratio == _positive(item['ratio']) and legal-timedelta(days=14) <= day <= legal]
            if len(matches) != 1:
                raise ValueError('期末後の法的分割は明示されていますが、対応する権利落ち日を一意に確認できません。')
        factor = Decimal(1)
        adjustments = []
        for ex_date, ratio, event in near:
            matches = [item for item in declarations if _positive(item['ratio']) == ratio
                       and ex_date <= date.fromisoformat(item['legal_effective_date']) <= ex_date+timedelta(days=14)]
            if len(matches) != 1:
                raise ValueError('期末近傍の権利落ち日に対応する法的効力発生日・比率を一意に確認できません。')
            declaration = matches[0]
            legal = date.fromisoformat(declaration['legal_effective_date'])
            quote_post = ex_date <= trading
            shares_post = legal <= period.end
            action_factor = ratio if quote_post and not shares_post else Decimal(1)/ratio if not quote_post and shares_post else Decimal(1)
            count_proof = {}
            if action_factor != 1:
                original = counts.get(FISCAL_COUNT, [])
                submitted = counts.get(FILING_COUNT, [])
                old = original[0]['value'] if original else None
                new = submitted[0]['value'] if submitted else None
                # The validated HTML extractor preserves equivalent physical
                # table evidence for older documents without numeric tags.
                physical = share_count.get('source_evidence', {})
                if old is None and share_count.get('extraction_method') == 'issued_shares_textblock':
                    old = _positive(physical.get('ordinary_raw'))
                    new = _positive(physical.get('submission_ordinary_raw'))
                    if new != _positive(physical.get('submission_total_raw')):
                        raise ValueError('提出日時点の普通株式数と合計が一致しません。')
                expected_filing = old*ratio if quote_post and not shares_post and old is not None else old
                if old != fiscal_shares or new is None:
                    raise ValueError('期末・提出日発行数と分割比率が整合しません。増資等の別要因を推測しません。')
                additional = None
                if new != expected_filing:
                    additional = _capital_movement_reconciliation(pages, filing, period.end, old, new, declarations)
                factor *= action_factor
                count_proof = {'fiscal_issued_shares': str(old), 'filing_issued_shares': str(new),
                               'issued_share_count_check': 'official dated capital-movement reconciliation' if additional else
                                  'fiscal × split ratio = filing' if not shares_post else 'fiscal = filing (both post-split)'}
                if additional:
                    count_proof['additional_issuance_reconciliation'] = additional
            adjustments.append(dict(declaration, exchange_ex_date=ex_date.isoformat(),
                exchange_event=event, quote_is_post_split=quote_post,
                fiscal_shares_are_post_split=shares_post, price_factor=str(action_factor), **count_proof))
        # A date-bearing but unsupported near-fiscal split notice must not be
        # ignored merely because another paragraph happened to parse.
        for text in unparsed:
            for match in re.finditer(_DATE, _compact(text)):
                mentioned = _day(match)
                if period.end < mentioned <= period.end+timedelta(days=14):
                    raise ValueError('期末直後の株式分割注記の比率・法的日付が未確認です。')
        result.update(available=True, historical_close_jpy=str(nominal*factor),
            basis_original_close_jpy=str(nominal), basis_price_factor=str(factor),
            basis_alignment_status='aligned' if factor != 1 else 'not_needed',
            basis_adjustments=adjustments, reconstruction_basis_date=period.end.isoformat(),
            basis_reason='公式の法的効力発生日と権利落ち日を区別し、期末発行数の株式基準へ株価を対応。')
        return result
    except (ValueError, TypeError, KeyError, InvalidOperation, etree.ParserError) as exc:
        return unavailable(str(exc))
