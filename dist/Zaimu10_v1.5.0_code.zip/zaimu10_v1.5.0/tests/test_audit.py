from dataclasses import asdict
from datetime import date
from decimal import Decimal
import json

import pytest

from zaimu10.audit import AuditError, load_result
from zaimu10.models import Cell, Dataset, Period, Row, Source


def saved(tmp_path):
    p = Period(date(2025,4,1), date(2026,3,31))
    d = Dataset('6947','図研','consolidated',[p])
    s = Source('S100TEST','original.xhtml','https://example.test/source',concept='{test}NetSales')
    c = Cell(Decimal('1234000'),s,components=[Cell(Decimal('1000'),s)],source_section=('売上',))
    d.rows['PL'] = [Row('sales','売上高','PL',values={p.key:c})]
    d.export_metadata = {'unit':'thousand','cells':[{'formula':'=SUM(B1:B2)'}]}
    raw = {'application':'Zaimu10','format_version':2,'dataset':asdict(d)}
    path = tmp_path/'6947_図研_2026-03-31.audit.json'
    path.write_text(json.dumps(raw,default=str),encoding='utf-8')
    return path,raw


def test_reopen_preserves_precise_values_sources_components_and_formula_as_text(tmp_path):
    path,_ = saved(tmp_path)
    result = load_result(path)
    row, = result.dataset.rows['PL']
    c = next(iter(row.values.values()))
    assert c.value == Decimal('1234000')
    assert c.components[0].value == Decimal('1000')
    assert c.source_section == ('売上',)
    assert c.source.url == 'https://example.test/source'
    assert result.dataset.export_metadata['cells'][0]['formula'] == '=SUM(B1:B2)'
    assert result.workbook.name == '6947_図研_2026-03-31.xlsx'
    assert not result.workbook.exists()  # Charts do not require Excel to remain alongside it.


@pytest.mark.parametrize('change', ['version','period','statement','nonfinite','outside'])
def test_invalid_saved_data_is_rejected_without_modifying_file(tmp_path,change):
    path,raw=saved(tmp_path)
    d=raw['dataset'];r=d['rows']['PL'][0];key=next(iter(r['values']))
    if change=='version':raw['format_version']=999
    if change=='period':d['periods'][0]['end']='2020-03-31'
    if change=='statement':r['statement']='CF'
    if change=='nonfinite':r['values'][key]['value']='NaN'
    if change=='outside':r['values']['1900-01-01/1900-12-31']=r['values'].pop(key)
    path.write_text(json.dumps(raw,default=str),encoding='utf-8');before=path.read_bytes()
    with pytest.raises(AuditError):load_result(path)
    assert path.read_bytes()==before


def test_reopen_keeps_note_inputs_typed_and_separate_from_primary_bs(tmp_path):
    path,raw=saved(tmp_path)
    key=next(iter(raw['dataset']['rows']['PL'][0]['values']))
    source=Source('S100W07I','original.xhtml','https://example.test/note',
                  concept='{jpcrp}AnnexedConsolidatedDetailedScheduleOfBorrowingsTextBlock',
                  context_id='CurrentYearDuration',original_label='リース債務（流動）',
                  raw_value='56,239',scale=3,basis='consolidated')
    note=Row('note:lease_current','リース債務（流動）','BS_LE',
             section=('借入金等明細表',),values={key:Cell(Decimal('56239000'),source)})
    raw['dataset']['analysis_inputs']=[asdict(note)]
    path.write_text(json.dumps(raw,default=str),encoding='utf-8')
    loaded=load_result(path).dataset
    assert loaded.rows['BS_LE']==[]
    item,=loaded.analysis_inputs
    assert item.values[key].value==Decimal('56239000')
    assert item.values[key].source.context_id=='CurrentYearDuration'
    assert item.section==('借入金等明細表',)


def test_reopen_preserves_explicit_individual_to_consolidated_resolution(tmp_path):
    path,raw=saved(tmp_path)
    raw['basis_resolution']={'requested':'standalone','resolved':'consolidated',
        'notice':'個別CF本表が原本にないため4表を連結へ切り替えました。','fallback_used':True}
    path.write_text(json.dumps(raw,default=str),encoding='utf-8')
    result=load_result(path)
    assert result.requested_basis=='standalone' and result.resolved_basis=='consolidated'
    assert result.basis_notice==raw['basis_resolution']['notice']
    assert result.basis_resolution['fallback_used'] is True


@pytest.mark.parametrize('change',['container','statement','outside','nonfinite'])
def test_invalid_note_evidence_is_rejected_without_rewriting(tmp_path,change):
    path,raw=saved(tmp_path)
    row=raw['dataset']['rows']['PL'][0]
    if change=='statement':row['statement']='UNKNOWN'
    if change=='outside':row['values']['1900-01-01/1900-12-31']=row['values'].pop(next(iter(row['values'])))
    if change=='nonfinite':next(iter(row['values'].values()))['value']='Infinity'
    raw['dataset']['analysis_inputs']={} if change=='container' else [row]
    path.write_text(json.dumps(raw,default=str),encoding='utf-8');before=path.read_bytes()
    with pytest.raises(AuditError):load_result(path)
    assert path.read_bytes()==before
