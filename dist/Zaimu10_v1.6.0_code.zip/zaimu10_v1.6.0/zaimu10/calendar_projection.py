"""View-only annual announcement estimates; official registry data stays intact."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
import calendar
import re


def one_year_later(day: date) -> date:
    """Keep the calendar anniversary; February 29 becomes February 28."""
    return date(day.year+1,day.month,min(day.day,calendar.monthrange(day.year+1,day.month)[1]))


def fiscal_month(event: dict) -> str | None:
    value=event.get('fiscal_month') or (event.get('fiscal_end') or '')[:7]
    if not value:
        match=re.search(r'(\d{4})年\s*(\d{1,2})月期',event.get('fiscal_period') or '')
        if match:value=f'{int(match[1]):04}-{int(match[2]):02}'
    try:
        if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}',value):return None
        date.fromisoformat(value+'-01')
    except ValueError:return None
    return value


def _annual(event):
    return event.get('period_type','annual')=='annual' and event.get('is_annual',True) is True


def _actual(event, today):
    try:day=date.fromisoformat(event.get('date',''))
    except (ValueError,TypeError):return False
    return event.get('kind')=='actual' and day<=today and _annual(event)


def project_annual_estimates(records: list[dict], events: list[dict], *, today: date) -> list[dict]:
    """Append at most one certified-actual anniversary per registered company.

    A known target fiscal month is suppressed by any official actual/schedule
    for that same company and period, even when its date differs. An upcoming
    official schedule with an unspecified fiscal period also takes priority.
    No estimate is written to earnings caches or company registration fields.
    """
    result=deepcopy([e for e in events if e.get('kind')!='estimated'])
    codes={str(r.get('code')):r for r in records if r.get('code')}
    for code,record in codes.items():
        actuals=[e for e in result if str(e.get('code'))==code and _actual(e,today)]
        if not actuals:continue
        # The producer certifies original full-year releases, not corrections
        # or filing dates. Do not infer an announcement from registry metadata.
        latest=max(actuals,key=lambda e:(e['date'],fiscal_month(e) or ''))
        day=one_year_later(date.fromisoformat(latest['date']))
        month=fiscal_month(latest)
        target=f'{int(month[:4])+1:04}-{month[5:]}' if month else None
        official=[]
        for event in result:
            if str(event.get('code'))!=code or event.get('kind') not in {'actual','scheduled'}:continue
            if not _annual(event):continue
            try:observed=date.fromisoformat(event.get('date',''))
            except (ValueError,TypeError):continue
            if event.get('kind')=='actual' and observed>today:continue
            known=fiscal_month(event)
            if target and known==target:official.append(event)
            elif event.get('kind')=='scheduled' and observed>=today and (not target or not known):official.append(event)
        if official:continue
        end=None
        if latest.get('fiscal_end'):
            try:end=one_year_later(date.fromisoformat(latest['fiscal_end'])).isoformat()
            except (ValueError,TypeError):pass
        label=f'{target[:4]}年{int(target[5:])}月期' if target else '次期本決算（対象期は未確認）'
        result.append(dict(code=code,company=latest.get('company') or record.get('company') or '',
            date=day.isoformat(),time=None,kind='estimated',period_type='annual',is_annual=True,
            fiscal_month=target,fiscal_end=end,fiscal_period=label,
            title='本決算発表の予想日（前年実績の1年後）',
            source_url=latest.get('source_url') or '',source_title='予想の根拠：'+(latest.get('source_title') or latest.get('title') or '前年の本決算発表実績'),
            publisher='前年実績からの予想',verified_at=latest.get('verified_at'),
            projection_only=True,estimate_base_date=latest['date'],
            estimate_method='latest_actual_plus_one_calendar_year',
            estimation_note=f"{latest['date']}の発表実績の1年後。公式に発表された予定日ではありません。",
            base_event=deepcopy(latest)))
    return result


def with_estimated_next_date(record: dict, events: list[dict], *, today: date) -> dict:
    """Provide display fields separately; never overwrite official next dates."""
    row=deepcopy(record)
    upcoming=[]
    for event in events:
        if str(event.get('code'))!=str(record.get('code')) or event.get('kind')!='scheduled':continue
        if not _annual(event):continue
        try:day=date.fromisoformat(event.get('date',''))
        except (ValueError,TypeError):continue
        if day>=today:upcoming.append(event)
    if upcoming and not row.get('next_announcement_date'):
        item=min(upcoming,key=lambda e:e['date'])
        row.update(display_next_announcement_date=item['date'],
                   display_next_announcement_fiscal_period=item.get('fiscal_period'),
                   display_next_announcement_kind='scheduled')
    choices=[e for e in events if str(e.get('code'))==str(record.get('code')) and e.get('kind')=='estimated']
    if choices:
        item=max(choices,key=lambda e:e['date'])
        row.update(estimated_next_announcement_date=item['date'],
                   estimated_next_announcement_fiscal_period=item['fiscal_period'],
                   estimated_next_announcement_event=deepcopy(item))
    return row


def centered_calendar_start(events: list[dict], today: date, visible_rows: int) -> int:
    """Place the nearest dated entry near the middle, retaining both sides."""
    if not events:return 0
    index=min(range(len(events)),key=lambda i:(abs((date.fromisoformat(events[i]['date'])-today).days),i))
    rows=max(1,visible_rows)
    return max(0,min(index-rows//2,len(events)-rows))
