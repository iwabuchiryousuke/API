"""Only explicit current-year NA notes may cross a fully matched BS face."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import json

import pytest

from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source
from zaimu10.parser import concept_identity
from zaimu10.service import _supplementary_na_fallback

OLD=Period(date(2024,4,1),date(2025,3,31))
NEW=Period(date(2025,4,1),date(2026,3,31))
BORROW={'borrowings_absent','short_term_borrowings','current_long_term_borrowings',
        'current_lease','long_term_borrowings','noncurrent_lease'}
BONDS={'bonds_absent','bonds','current_bonds'}


def primary(doc,periods,*,release='2024-11-01',basis='standalone',standard='J-GAAP',code='2303'):
    ds=Dataset(code,'株式会社ドーン',basis,list(periods),accounting_standard=standard)
    for local,value in [('OtherCL','10000000'),('NetAssets','20000000')]:
        qname='{http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/'+release+'/jppfs_cor}'+local
        key=json.dumps(['BS_LE',concept_identity(qname),[],'end','JPY',basis])
        values={p.key:Cell(Decimal(value),Source(doc,'financial.xhtml','https://disclosure2.edinet-fsa.go.jp/',
            concept=qname,context_id='CurrentYearInstant',unit='JPY',basis=basis,decimals='-3')) for p in periods}
        ds.rows['BS_LE'].append(Row(key,local,'BS_LE',values=values))
    return ds


def add_na(ds,filing,period):
    for status,categories,kind,operation in [
        ('borrowings_absent',BORROW,'Borrowings','explicit_no_borrowings'),
        ('bonds_absent',BONDS,'CorporateBonds','explicit_no_bonds')]:
        text='該当事項はありません。'
        qname='{http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor}AnnexedDetailedScheduleOf'+kind+'FinancialStatementsNATextBlock'
        for category in sorted(categories):
            evidence=dict(kind='explicit_none',document_id=filing.doc_id,category=category,basis=ds.basis,
                period_start=period.start.isoformat(),period_end=period.end.isoformat(),
                context_period_start=period.start.isoformat(),context_period_end=period.end.isoformat())
            source=Source(filing.doc_id,'annex.xhtml','https://disclosure2.edinet-fsa.go.jp/',
                concept=qname,context_id='CurrentYearDuration',unit='JPY',basis=ds.basis,
                raw_value=text,decimals='0')
            cell=Cell(Decimal(0),source,operation=operation if category==status else 'explicit_no_balance',
                      note='原文の該当事項なし\ndebt_note_evidence:'+json.dumps(evidence))
            ds.analysis_inputs.append(Row('notes:debt:'+category+':'+ds.basis,category,'BS_LE',values={period.key:cell}))


@pytest.fixture
def case():
    authority=primary('S100NEXT',[OLD,NEW])
    original=primary('S100ORIG',[OLD],release='2023-11-01')
    fa=Filing('S100NEXT',code='2303',start=NEW.start,end=NEW.end,submitted='2026-06-20 10:00')
    fo=Filing('S100ORIG',code='2303',start=OLD.start,end=OLD.end,submitted='2025-06-20 10:00')
    add_na(authority,fa,NEW);add_na(original,fo,OLD)
    merged=deepcopy(authority);merged.periods=[OLD];merged.analysis_inputs=[]
    for rows in merged.rows.values():
        for row in rows:row.values={OLD.key:row.values[OLD.key]}
    return merged,authority,original,{id(authority):fa,id(original):fo}


def apply(case,amendments=()):
    merged,authority,original,filings=case
    return _supplementary_na_fallback(merged,[authority,original],{OLD.key:authority},filings,list(amendments),lambda _:None)


def categories(ds):
    return {row.key.split(':')[2] for row in ds.analysis_inputs if OLD.key in row.values}


def test_explicit_current_year_na_recovered_after_full_bs_match_without_changing_primary(case):
    merged,authority,original,filings=case
    before=asdict(merged)['rows']
    [check]=apply(case)
    assert check['ok'] is True and check['status']=='applied'
    assert check['authority_doc_id']=='S100NEXT' and check['supplementary_doc_id']=='S100ORIG'
    assert check['balance_match']['line_count']==2
    assert categories(merged)==BORROW|BONDS
    assert asdict(merged)['rows']==before
    assert all(cell.source.doc_id=='S100ORIG' and cell.value==0 and not cell.nil
               for row in merged.analysis_inputs for cell in row.values.values())
    assert all(source['source']['filename']=='annex.xhtml' for source in check['sources'])
    assert merged.warnings==[] and merged.analysis_input_errors=={}


@pytest.mark.parametrize('change',['amount','concept','dimension','nil','html_source'])
def test_changed_bs_face_or_unproven_source_rejects_note_only_fallback(case,change):
    merged,authority,original,_=case
    row=original.rows['BS_LE'][0];cell=row.values[OLD.key]
    if change=='amount':cell.value+=Decimal('1000000')
    elif change=='concept':cell.source.concept=cell.source.concept.replace('OtherCL','OtherNCL')
    elif change=='dimension':
        parts=json.loads(row.key);parts[2]=[['axis','member']];row.key=json.dumps(parts)
    elif change=='nil':cell.value=None;cell.nil=True
    else:cell.source.semantic_concept='{urn:zaimu10:html-table:E05289:BS}OtherCL'
    [check]=apply(case)
    assert check['ok'] is None and check['status']=='not_applied'
    assert categories(merged)==set() and merged.warnings==[]


@pytest.mark.parametrize('change',['basis','standard','code','amended'])
def test_original_must_match_company_basis_standard_and_be_original_current_year(case,change):
    merged,authority,original,filings=case
    if change=='basis':original.basis='consolidated'
    elif change=='standard':original.accounting_standard='IFRS'
    elif change=='code':original.code='6947'
    else:filings[id(original)].amended=True
    assert apply(case)==[]
    assert categories(merged)==set()


@pytest.mark.parametrize('which',['merged','authority','original'])
def test_note_acquisition_or_parser_error_cannot_be_hidden(case,which):
    merged,authority,original,_=case
    if which=='merged':merged.analysis_input_errors[OLD.key]=['原本注記が不明確']
    elif which=='authority':authority.analysis_input_errors[OLD.key]=['原本注記が不明確']
    else:original.analysis_input_errors[OLD.key]=['原本注記が不明確']
    assert apply(case)==[]
    assert categories(merged)==set()


def test_existing_authority_category_including_explicit_nil_is_never_overwritten(case):
    merged,_,original,_=case
    row=deepcopy(next(r for r in original.analysis_inputs if ':current_lease:' in r.key))
    row.values[OLD.key].value=None;row.values[OLD.key].nil=True
    row.values[OLD.key].source.doc_id='S100NEXT';merged.analysis_inputs.append(row)
    [check]=apply(case)
    kept=next(r for r in merged.analysis_inputs if ':current_lease:' in r.key).values[OLD.key]
    assert kept.value is None and kept.nil and kept.source.doc_id=='S100NEXT'
    assert row.key not in check['added_note_keys']


@pytest.mark.parametrize('change',['dash_table','positive_amount','wrong_current_period'])
def test_only_explicit_current_year_prose_zero_is_eligible(case,change):
    merged,_,original,_=case
    for row in original.analysis_inputs:
        cell=row.values[OLD.key]
        if change=='positive_amount':cell.value=Decimal(1)
        else:
            evidence=json.loads(cell.note.split('debt_note_evidence:',1)[1])
            if change=='dash_table':evidence['kind']='borrowings_schedule'
            else:evidence['context_period_end']=NEW.end.isoformat()
            cell.note='debt_note_evidence:'+json.dumps(evidence)
    assert apply(case)==[]
    assert categories(merged)==set()


@pytest.mark.parametrize('flag',[True,None])
def test_relevant_later_or_unknown_debt_amendment_blocks_old_na(case,flag):
    change=dict(doc_id='S100CORR',status='financial_notes_only',period=OLD.key,
                affected_periods=[OLD.key])
    if flag is not None:change['analysis_inputs_affected']=flag
    [check]=apply(case,[change])
    assert check['status']=='not_applied' and check['blocking_amendment_doc_id']=='S100CORR'
    assert categories(case[0])==set()


@pytest.mark.parametrize('change',[
    dict(status='nonfinancial_only'),
    dict(status='financial_notes_only',analysis_inputs_affected=False),
    dict(status='financial_notes_only',analysis_inputs_affected=True,affected_periods=[NEW.key]),
    dict(status='financial_notes_only',analysis_inputs_affected=True,affected_periods=[]),
])
def test_proven_unrelated_or_nondebt_amendment_does_not_remove_valid_na(case,change):
    [check]=apply(case,[dict(doc_id='S100CORR',period=OLD.key,**change)])
    assert check['ok'] is True and categories(case[0])==BORROW|BONDS


def test_rounding_precision_is_respected_but_exact_values_are_not_rounded_away(case):
    case[2].rows['BS_LE'][0].values[OLD.key].value+=Decimal('1000')
    assert apply(case)[0]['ok'] is True
    merged,authority,original,_=case;merged.analysis_inputs=[]
    for ds in (authority,original):ds.rows['BS_LE'][0].values[OLD.key].source.decimals='INF'
    assert apply(case)[0]['status']=='not_applied'


def test_missing_note_in_most_recent_original_is_not_backfilled_from_an_older_original(case):
    merged,authority,original,filings=case
    newer=deepcopy(original);newer.analysis_inputs=[]
    filings[id(newer)]=Filing('S100LAST',code='2303',start=OLD.start,end=OLD.end,submitted='2025-06-21 10:00')
    checks=_supplementary_na_fallback(merged,[authority,original,newer],{OLD.key:authority},filings,[],lambda _:None)
    assert checks==[] and categories(merged)==set()


@pytest.mark.parametrize('side',['authority','original'])
def test_disjoint_explicit_nil_is_only_a_recorded_structural_difference_not_an_imputed_zero(case,side):
    merged,authority,original,_=case
    target=authority if side=='authority' else original
    source=deepcopy(target.rows['BS_LE'][0].values[OLD.key].source)
    source.concept=source.concept.replace('OtherCL','OtherNCL')
    key=json.dumps(['BS_LE',concept_identity(source.concept),[],'end','JPY','standalone'])
    target.rows['BS_LE'].append(Row(key,'その他固定負債','BS_LE',values={OLD.key:Cell(None,source,nil=True)}))
    [check]=apply(case)
    assert check['ok'] is True
    assert len(check['ignored_nil_keys'][side])==1
    assert 'OtherNCL' in check['ignored_nil_keys'][side][0]
    assert check['balance_match']['ignored_nil_sources'][0]['source']['doc_id']==source.doc_id
    assert categories(merged)==BORROW|BONDS
    assert target.rows['BS_LE'][-1].values[OLD.key].value is None


def test_overlapping_nil_to_numeric_zero_is_rejected_even_though_both_have_no_positive_amount(case):
    merged,authority,original,_=case
    authority.rows['BS_LE'][0].values[OLD.key].value=Decimal(0)
    original.rows['BS_LE'][0].values[OLD.key].value=None
    original.rows['BS_LE'][0].values[OLD.key].nil=True
    [check]=apply(case)
    assert check['status']=='not_applied'
    assert 'nilと数値' in check['reason'] and categories(merged)==set()


def test_disjoint_real_571000_yen_item_is_rejected_while_other_nil_structure_changes_are_recorded(case):
    merged,authority,original,_=case
    source=deepcopy(original.rows['BS_LE'][0].values[OLD.key].source)
    source.concept=source.concept.replace('OtherCL','DeferredTaxLiabilitiesNCL')
    key=json.dumps(['BS_LE',concept_identity(source.concept),[],'end','JPY','standalone'])
    original.rows['BS_LE'].append(Row(key,'繰延税金負債','BS_LE',values={OLD.key:Cell(Decimal(571000),source)}))
    [check]=apply(case)
    assert check['status']=='not_applied'
    assert check['balance_match']['unmatched_numeric_keys']['original'][0]['value_jpy']=='571000'
    assert categories(merged)==set()
