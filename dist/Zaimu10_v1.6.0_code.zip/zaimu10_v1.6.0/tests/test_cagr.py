"""Source-faithful historical CAGR, with no forecast or missing-value guesses."""
from copy import copy
from datetime import date
from decimal import Decimal, localcontext

from openpyxl import Workbook, load_workbook
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils import get_column_letter
import pytest

from zaimu10.cagr import TEMPLATE_PATH, write_cagr
from zaimu10.excel import _write_cached
from zaimu10.financial_refs import CellRef, ResolvedInput
from zaimu10.models import Dataset, Period


class Writer:
    def __init__(self, periods):
        self.periods = periods
        self.book = Workbook()
        self.book.active.title = 'FR'
        self.book.create_sheet('BS-a')
        self.values = {}; self.cached = {}; self.cells = []
        self.layout_metadata = {'FR': {'rows': {30: 'roic', 42: 'invested_capital_turnover', 55: 'wacc_c'}}}
        self.unit = 'thousand'; self.unit_label = '千円'

    @staticmethod
    def fit_number(cell):
        alignment = copy(cell.alignment)
        alignment.wrap_text = False; alignment.shrink_to_fit = True
        cell.alignment = alignment


class Refs:
    def __init__(self, writer):
        self.writer = writer; self.inputs = {}
        for index, period in enumerate(writer.periods):
            address = f'{get_column_letter(index + 2)}45'
            value = Decimal(1000 + index * 100)
            writer.book['BS-a'][address] = float(value)
            writer.values[('BS-a', address)] = value
            ref = CellRef('BS-a', address, value, 'analysis:invested_capital')
            self.inputs[period.key] = ResolvedInput(ref.excel, value, (ref,))

    def get(self, name, period):
        assert name == 'invested_capital'
        return self.inputs.get(period.key)

    def reason(self, name, period):
        return '投下資本の開示入力不足'


def model(count=10):
    periods = [Period(date(year - 1, 7, 1), date(year, 6, 30)) for year in range(2017, 2017 + count)]
    dataset = Dataset('0000', '株式会社テスト', 'consolidated', periods)
    writer = Writer(periods)
    for index, period in enumerate(periods):
        for metric, row, value in [('roic', 30, Decimal('.1') + Decimal(index) / 100),
                                   ('invested_capital_turnover', 42, Decimal(1) + Decimal(index) / 50),
                                   ('wacc_c', 55, Decimal('.05'))]:
            set_fr(writer, metric, row, index, value)
    return dataset, writer, Refs(writer)


def set_fr(writer, metric, row, index, value):
    address = f'{get_column_letter(index + 2)}{row}'
    writer.book['FR'][address] = None if value is None else float(value)
    writer.values[('FR', address)] = value
    writer.cells[:] = [cell for cell in writer.cells if not (cell.get('sheet') == 'FR' and cell.get('address') == address)]
    writer.cells.append({'sheet': 'FR', 'address': address, 'row_key': 'supplement:FR:' + metric,
                         'period': writer.periods[index].key})


def test_template_has_only_reference_labels_and_styles_not_source_amounts_or_formulas():
    with TEMPLATE_PATH.open('rb') as stream:
        book = load_workbook(stream)
    assert book.sheetnames == ['CAGR']
    assert not book._external_links and not book.defined_names
    ws = book['CAGR']
    assert (ws.max_row, ws.max_column) == (12, 8)
    assert all(cell.value is None for row in ws for cell in row if cell.row > 1 or cell.column == 1)
    assert not any(cell.data_type == 'f' for row in ws for cell in row)
    assert ws['B1'].value == '①ROIC'
    assert ws['H1'].value == 'EVA\n（①-③）✖④'
    assert ws['F1'].border.top.style is None
    assert ws['D12'].border.top.style is None
    assert ws['D12'].number_format == '0.00%'
    assert ws['H12'].number_format == '0.00%'
    book.close()


def test_ten_periods_use_transposed_visible_inputs_and_nine_annual_intervals(tmp_path):
    dataset, writer, refs = model()
    original = {(name, cell.coordinate): cell.value for name in writer.book.sheetnames for row in writer.book[name] for cell in row}
    result = write_cagr(writer, dataset, refs)
    ws = writer.book['CAGR']
    assert (ws.max_row, ws.max_column) == (12, 8)
    assert [ws.cell(row, 1).value for row in range(2, 12)] == list(range(2017, 2027))
    assert ws['B2'].value == "='FR'!B30" and ws['B11'].value == "='FR'!K30"
    assert ws['C2'].value == "='FR'!B42" and ws['E2'].value == "='FR'!B55"
    assert ws['D2'].value == '=B2*C2' and ws['F2'].value == '=B2-E2'
    assert ws['G2'].value == "='BS-a'!B45" and ws['H2'].value == '=F2*G2'
    assert ws['D12'].value == '=MEDIAN(D2:D11)'
    assert ws['H12'].value == '=(H11/H2)^(1/9)-1'
    assert writer.values[('CAGR', 'H2')] == Decimal(50)
    assert writer.values[('CAGR', 'H11')] == Decimal(266)
    with localcontext() as context:
        context.prec = 34
        expected = (Decimal(266) / 50) ** (Decimal(1) / 9) - 1
    assert abs(writer.values[('CAGR', 'H12')] - expected) < Decimal('1e-30')
    assert result['summary']['eva_cagr']['intervals'] == 9
    assert result['periods'][dataset.periods[0].key]['invested_capital']['display_value'] == '1000'
    assert result['periods'][dataset.periods[-1].key]['roic']['address'] == 'B11'
    assert [cell['period'] for cell in writer.cells if cell.get('row_key') == 'supplement:CAGR:roic'] == [p.key for p in dataset.periods]
    assert writer.layout_metadata['CAGR']['columns']['H'] == 'eva'
    assert str(ws.print_area) == "'CAGR'!$A$1:$H$12"
    assert not any(d.hidden for d in ws.row_dimensions.values())
    assert not any(d.hidden for d in ws.column_dimensions.values())
    assert ws['H11'].alignment.shrink_to_fit and ws['H11'].alignment.wrap_text is False
    assert ws['B2'].font.name == 'Times New Roman' and ws['B2'].font.sz == 10
    assert ws['H2'].number_format == '#,##0.00_);[Red](#,##0.00)'
    assert ws['D12'].border.top.style is None
    assert all(writer.book[name][address].value == value for (name, address), value in original.items())
    functions = [token.value for row in ws for cell in row if cell.data_type == 'f'
                 for token in Tokenizer(cell.value).items if token.type == 'FUNC' and token.subtype == 'OPEN']
    assert functions == ['MEDIAN(']
    path = tmp_path / 'cagr.xlsx'
    writer.book.save(path); _write_cached(path, writer.cached)
    cached = load_workbook(path, data_only=True)
    assert cached['CAGR']['H2'].value == 50
    assert abs(cached['CAGR']['H12'].value - float(expected)) < 1e-14
    cached.close(); writer.book.close()


@pytest.mark.parametrize('count', [1, 2, 5])
def test_fewer_years_keep_summary_immediately_after_actual_periods(count):
    dataset, writer, refs = model(count)
    result = write_cagr(writer, dataset, refs)
    ws = writer.book['CAGR']
    assert ws.max_row == count + 2
    assert ws.cell(count + 2, 4).value == f'=MEDIAN(D2:D{count + 1})'
    if count == 1:
        assert ws.cell(count + 2, 8).value is None
        assert result['summary']['eva_cagr']['missing']
    else:
        assert ws.cell(count + 2, 8).value == f'=(H{count + 1}/H2)^(1/{count - 1})-1'
    writer.book.close()


@pytest.mark.parametrize('first,last,expected,missing', [
    ('.05', '.2', None, '0'),
    ('.01', '.2', None, '正負'),
    ('.1', '.05', Decimal(-1), ''),
    ('.01', '.02', Decimal('-.175'), ''),
])
def test_eva_cagr_has_no_guards_or_absolute_value_guess(first, last, expected, missing):
    dataset, writer, refs = model(2)
    set_fr(writer, 'roic', 30, 0, Decimal(first))
    set_fr(writer, 'roic', 30, 1, Decimal(last))
    result = write_cagr(writer, dataset, refs)
    info = result['summary']['eva_cagr']
    if expected is None:
        assert writer.book['CAGR']['H4'].value is None
        assert missing in ''.join(info['missing'])
    else:
        assert writer.book['CAGR']['H4'].value == '=(H3/H2)^(1/1)-1'
        assert writer.values[('CAGR', 'H4')] == expected
        if Decimal(first) < Decimal('.05'):
            assert '両端EVAが負数' in info['note']
    writer.book.close()


def test_missing_data_stays_blank_with_reasons_without_changing_the_original_sheets():
    dataset, writer, refs = model(3)
    set_fr(writer, 'roic', 30, 0, None)
    refs.inputs.pop(dataset.periods[1].key)
    result = write_cagr(writer, dataset, refs)
    ws = writer.book['CAGR']
    for address in ['B2', 'D2', 'F2', 'H2', 'G3', 'H3', 'H5']:
        assert ws[address].value is None
        assert writer.values[('CAGR', address)] is None
    assert ws['D5'].value == '=MEDIAN(D2:D4)'
    assert result['periods'][dataset.periods[0].key]['roic']['missing']
    assert result['periods'][dataset.periods[1].key]['invested_capital']['missing'] == ['投下資本の開示入力不足']
    assert result['summary']['eva_cagr']['missing']
    assert writer.book['FR']['B30'].value is None
    assert writer.book['BS-a']['C45'].value == 1100
    writer.book.close()


def test_dynamic_fr_layout_fallback_and_idempotent_rewrite_only_clear_owned_state():
    dataset, writer, refs = model(2)
    writer.cells.clear()  # The declared FR layout is independently sufficient.
    first = write_cagr(writer, dataset, refs)
    before = len(writer.cells)
    writer.values[('CAGR', 'H999')] = Decimal(999)
    writer.cached[('CAGR', 'H999')] = Decimal(999)
    second = write_cagr(writer, dataset, refs)
    assert second == first
    assert len(writer.cells) == before
    assert ('CAGR', 'H999') not in writer.values and ('CAGR', 'H999') not in writer.cached
    assert writer.book.sheetnames == ['FR', 'BS-a', 'CAGR']
    assert writer.book['CAGR']['B3'].value == "='FR'!C30"
    assert writer.values[('BS-a', 'B45')] == Decimal(1000)
    writer.book.close()
