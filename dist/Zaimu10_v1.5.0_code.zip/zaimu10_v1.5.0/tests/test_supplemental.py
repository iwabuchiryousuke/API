"""Original historical DCF/FR arithmetic, visible references and clean assets."""
from copy import copy
from datetime import date
from decimal import Decimal

from openpyxl import load_workbook
from openpyxl.formula.tokenizer import Tokenizer
import pytest

from zaimu10.excel import Writer,_write_cached
from zaimu10.financial_refs import CellRef,ResolvedInput
from zaimu10.models import Dataset,Period
from zaimu10.supplemental import TEMPLATE_PATH,DCF_LABELS,FR_LABELS,write_dcf,write_fr

OLD=Period(date(2023,7,1),date(2024,6,30))
NEW=Period(date(2024,7,1),date(2025,6,30))


class VisibleRefs:
    """A visible financial ledger with declared metric identities for the model."""
    def __init__(self,writer):
        self.writer=writer;self.values={};self.statuses={}
        matrix={
            'revenue':('PL',2,1000,1200),'cost_of_sales':('PL',4,600,700),
            'sga':('PL',8,200,250),'operating_profit':('PL',9,200,250),
            'effective_tax_rate':('PL',22,'0.3','0.25'),'sales_growth':('PL',3,None,'0.2'),
            'noncash':('CF',4,50,60),'trade_receivables':('BS-A',4,100,130),
            'inventory':('BS-A',5,80,100),'trade_payables':('BS-L,E',3,90,110),
            'capex':('CF',44,-40,-50),'invested_capital':('BS-A',50,500,600),
            'current_assets':('BS-A',10,300,360),'current_liabilities':('BS-L,E',10,150,180),
            'cash':('BS-A',3,50,60),'current_securities':('BS-A',6,20,30),
            'ppe':('BS-A',20,250,300),'construction_in_progress':('BS-A',19,10,20),
        }
        for name,(sheet,row,*numbers)in matrix.items():
            for column,(period,number)in enumerate(zip(writer.periods,numbers),2):
                if number is None:continue
                value=Decimal(str(number));address=f'{chr(64+column)}{row}'
                writer.book[sheet][address]=float(value)
                writer.values[(sheet,address)]=value
                ref=CellRef(sheet,address,value,'input:'+name)
                self.values[(name,period.key)]=ResolvedInput(ref.excel,value,(ref,))
    def get(self,name,period):return self.values.get((name,period.key if hasattr(period,'key')else period))
    def reason(self,name,period):return '対応する可視入力なし: '+name
    def status(self,name,period):
        return 'available'if self.get(name,period)is not None else self.statuses.get((name,period.key),'absent')
    def remove(self,name,period):self.values.pop((name,period.key),None)


@pytest.fixture
def model():
    ds=Dataset('0000','株式会社見本会社','consolidated',[OLD,NEW],accounting_standard='J-GAAP')
    writer=Writer(ds,'thousand')
    writer.book['PL']['B1']='R6-2024\n6/30';writer.book['PL']['C1']='R7-2025\n6/30'
    refs=VisibleRefs(writer)
    yield ds,writer,refs
    writer.book.close();writer.template.close()


def save(writer,path):
    writer.book.save(path);_write_cached(path,writer.cached)
    return load_workbook(path),load_workbook(path,data_only=True)


def number(value):return Decimal(str(value))


def capm_values(writer):
    writer.book.create_sheet('CAPM')
    for column,(c,r)in enumerate([('0.08','0.10'),('0.09','0.11')],2):
        for row,value in [(10,c),(13,r)]:
            address=f'{chr(64+column)}{row}';writer.book['CAPM'][address]=float(value)
            writer.values[('CAPM',address)]=Decimal(value)


def test_sanitized_templates_load_and_contain_no_company_amounts_forecasts_or_formulas():
    with TEMPLATE_PATH.open('rb')as stream:workbook=load_workbook(stream)
    assert workbook.sheetnames==['DCF','FR']
    assert not workbook._external_links and not workbook.defined_names
    for ws in workbook:
        assert ws.max_row==(27 if ws.title=='DCF' else 25)
        assert ws['A1'].value is None
        assert all(cell.value is None for row in ws for cell in row if cell.column>1)
        assert not any(cell.data_type=='f'for row in ws for cell in row)
        assert not any(d.hidden for d in ws.row_dimensions.values())
    workbook.close()


def test_historical_dcf_original_math_and_first_blank_delta_exception(model,tmp_path):
    ds,writer,refs=model;metadata=write_dcf(writer,ds,refs)
    workbook,cached=save(writer,tmp_path/'dcf.xlsx');ws=workbook['DCF'];values=cached['DCF']
    assert ws.max_row==27 and ws.max_column==3
    assert ws['B1'].value==writer.book['PL']['B1'].value and ws['C1'].value==writer.book['PL']['C1'].value
    assert [ws.cell(row,1).value for row in range(2,28)]==[DCF_LABELS[row]for row in range(2,28)]
    assert ws['B2'].value=="='PL'!B2" and ws['C13'].value=="='PL'!C22"
    assert ws['B10'].value=='=B7-B8'
    assert ws['B24'].value is None and ws['B26'].value=='=B14+B15-B24+B25'
    assert values['B14'].value==140 and values['B26'].value==150
    assert values['C23'].value==120 and values['C24'].value==30
    assert values['C14'].value==187.5 and values['C26'].value==167.5
    assert abs(values['C3'].value-0.2)<1e-12
    assert abs(values['C27'].value-(167.5/150-1))<1e-12
    assert '初年度' in ws['B26'].comment.text and '0として' in ws['B26'].comment.text
    assert metadata['historical_only'] and metadata['forecast_generated']is False
    assert metadata['periods'][OLD.key]['fcf']['assumptions']
    assert ws.print_area=="'DCF'!$A$1:$C$27"
    workbook.close();cached.close()


@pytest.mark.parametrize('missing',['effective_tax_rate','noncash','capex'])
def test_missing_first_fcf_required_input_is_not_converted_to_zero(model,tmp_path,missing):
    ds,writer,refs=model;refs.remove(missing,OLD)
    metadata=write_dcf(writer,ds,refs)
    assert writer.book['DCF']['B26'].value is None
    assert metadata['periods'][OLD.key]['fcf']['missing']
    assert '0とはみなしません' in writer.book['DCF']['B26'].comment.text


def test_missing_later_working_capital_delta_keeps_fcf_blank(model):
    ds,writer,refs=model;refs.remove('trade_receivables',NEW)
    metadata=write_dcf(writer,ds,refs)
    assert writer.book['DCF']['B26'].value=='=B14+B15-B24+B25'
    assert writer.book['DCF']['C24'].value is None and writer.book['DCF']['C26'].value is None
    assert metadata['periods'][NEW.key]['fcf']['missing']


def test_ifrs_other_operating_profit_difference_is_disclosed_without_changing_model_formula(model):
    ds,writer,refs=model
    old=refs.get('operating_profit',NEW);ref=CellRef('PL','C9',Decimal(300),'metric:operating_profit')
    refs.values[('operating_profit',NEW.key)]=ResolvedInput(ref.excel,ref.value,(ref,))
    writer.values[('PL','C9')]=Decimal(300);writer.book['PL']['C9']=300
    metadata=write_dcf(writer,ds,refs)
    assert writer.book['DCF']['C10'].value=='=C7-C8'
    assert writer.values[('DCF','C10')]==250
    assert metadata['periods'][NEW.key]['model_operating_profit']['difference_from_pl']=='-50'
    assert 'モデルとの差' in writer.book['DCF']['C10'].comment.text
    assert writer.values[('PL','C9')]==300


def test_fr_full_union_matches_reference_definitions_and_capm_visible_links(model,tmp_path):
    ds,writer,refs=model;write_dcf(writer,ds,refs);capm_values(writer)
    metadata=write_fr(writer,ds,refs)
    workbook,cached=save(writer,tmp_path/'fr.xlsx');ws=workbook['FR'];v=cached['FR']
    assert ws.max_row==26 and ws.max_column==3
    assert all(ws.cell(row,1).value==label for row,label in FR_LABELS.items())
    assert ws['B5'].value=="='CAPM'!B10" and ws['C6'].value=="='CAPM'!C13"
    assert number(v['B2'].value)==Decimal('0.28') and number(v['C2'].value)==Decimal('0.3125')
    assert v['B3'].value==2 and v['C3'].value==2
    assert number(v['B4'].value)==Decimal('0.56')
    assert v['B9'].value==100 and v['C9'].value==133.5
    assert abs(v['B18'].value-0.84)<1e-12 and abs(v['C18'].value-0.9)<1e-12
    assert v['B19'].value==2 and abs(v['B20'].value-170/150)<1e-12
    assert abs(v['B22'].value-1000/240)<1e-12
    assert v['B23'].value==36.5 and v['B24'].value==29.2 and v['B25'].value==54.75
    assert abs(v['B26'].value-10.95)<1e-12
    assert ws['B13'].value is None  # missing first sales growth does not become0
    assert '/12' in ws['B18'].value and '*365' in ws['B24'].value
    assert '売上原価ではない' in ws['B24'].comment.text
    assert metadata['historical_only'] and ws.freeze_panes=='B2'
    workbook.close();cached.close()


def test_supplements_keep_template_fonts_borders_and_numeric_fit(model):
    ds,writer,refs=model;write_dcf(writer,ds,refs);capm_values(writer);write_fr(writer,ds,refs)
    with TEMPLATE_PATH.open('rb')as stream:template=load_workbook(stream)
    for name in ['DCF','FR']:
        ws=writer.book[name]
        for row in range(2,ws.max_row+1):
            source_row=row if name=='DCF'or row<=5 else 5 if row==6 else row-1
            for col in [1,2,3]:
                assert copy(ws.cell(row,col).font)==copy(template[name].cell(source_row,col).font)
                assert copy(ws.cell(row,col).border)==copy(template[name].cell(source_row,col).border)
                assert ws.cell(row,col).number_format==template[name].cell(source_row,col).number_format
                if col>1:
                    assert ws.cell(row,col).alignment.shrink_to_fit is True
                    assert ws.cell(row,col).alignment.wrap_text is not True
    template.close()


def test_supplement_formulas_have_no_guards_forecasts_or_copied_assumptions(model):
    ds,writer,refs=model;write_dcf(writer,ds,refs);capm_values(writer);write_fr(writer,ds,refs)
    for name in ['DCF','FR']:
        ws=writer.book[name]
        assert ws.max_column==len(ds.periods)+1
        for row in ws:
            for cell in row:
                if cell.data_type=='f':
                    functions={t.value for t in Tokenizer(cell.value).items if t.type=='FUNC'and t.subtype=='OPEN'}
                    assert functions<={'SUM('}
                    assert '#REF!'not in cell.value and 'IF'not in cell.value
        assert not any('理論株価'in str(c.value)or'終価'in str(c.value)or'2029(予)'in str(c.value)for row in ws for c in row)
    assert writer.book['DCF']['B13'].value=="='PL'!B22"


@pytest.mark.parametrize('status',['disclosed_blank','unresolved'])
def test_unknown_cip_is_not_silently_removed_from_ppe_turnover(model,status):
    ds,writer,refs=model;refs.remove('construction_in_progress',NEW)
    refs.statuses[('construction_in_progress',NEW.key)]=status
    write_dcf(writer,ds,refs);capm_values(writer);metadata=write_fr(writer,ds,refs)
    assert writer.book['FR']['C22'].value is None
    assert metadata['periods'][NEW.key]['ppe_turnover']['optional_input_status']['construction_in_progress']==status
    assert 'nil' in writer.book['FR']['C22'].comment.text


def test_genuinely_absent_cip_keeps_reference_no_additional_deduction_convention(model):
    ds,writer,refs=model;refs.remove('construction_in_progress',NEW)
    refs.statuses[('construction_in_progress',NEW.key)]='absent'
    write_dcf(writer,ds,refs);capm_values(writer);metadata=write_fr(writer,ds,refs)
    assert writer.values['FR','C22']==4  # Sales1200 / PPE300; no invented CIP source0
    assert metadata['periods'][NEW.key]['ppe_turnover']['optional_input_status']['construction_in_progress']=='absent'


def test_unknown_current_security_does_not_turn_into_zero_in_liquidity_ratios(model):
    ds,writer,refs=model;refs.remove('current_securities',NEW)
    refs.statuses[('current_securities',NEW.key)]='disclosed_blank'
    write_dcf(writer,ds,refs);capm_values(writer);metadata=write_fr(writer,ds,refs)
    assert writer.book['FR']['C18'].value is None and writer.book['FR']['C20'].value is None
    assert writer.values['FR','C19']==2  # independent current ratio remains valid
    assert metadata['periods'][NEW.key]['quick_ratio']['optional_input_status']['current_securities']=='disclosed_blank'
