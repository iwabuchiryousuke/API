"""Financial presentation, separate from the immutable disclosed-fact dataset.

Only explicit semantic rules are used. Company extension identities retain their
issuer, and presentation groups retain basis, accounting standard, dimensions,
instant/duration role and unit. Versioned disclosures are selected, never added.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import asdict
from decimal import Decimal
import json
import re
import unicodedata
from typing import Iterable

from .models import Cell, Dataset, Period, Row, Source


class PresentationError(ValueError):
    pass


PL_METRICS = {
    'revenue': '売上高', 'cost_of_sales': '売上原価', 'gross_profit': 'Ⅰ 売上総利益',
    'sga': '販売費及び一般管理費計', 'operating_profit': 'Ⅱ 営業利益',
    'nonoperating_income': '営業外収益', 'nonoperating_expense': '営業外費用',
    'ordinary_profit': 'Ⅲ 経常利益', 'extraordinary_income': '特別利益',
    'extraordinary_expense': '特別損失', 'profit_before_tax': 'Ⅳ 税金等調整前当期純利益',
    'income_taxes': '法人税等合計', 'net_profit': 'Ⅴ 当期純利益',
    'net_profit_parent': '親会社株主に帰属する当期純利益',
}
PL_CONCEPTS = {
    'revenue': {'NetSales','NetSalesIFRS','RevenueIFRS','Revenue','OperatingRevenue','OperatingRevenue1','OperatingRevenue2','OperatingRevenue3','OperatingRevenueSEC'},
    'cost_of_sales': {'CostOfSales','CostOfSalesIFRS'},
    'gross_profit': {'GrossProfit','GrossProfitIFRS'},
    'sga': {'SellingGeneralAndAdministrativeExpenses','SellingGeneralAndAdministrativeExpensesIFRS'},
    'operating_profit': {'OperatingIncome','OperatingProfitLossIFRS','OperatingIncomeLoss'},
    'nonoperating_income': {'NonOperatingIncome','FinanceIncomeIFRS'},
    'nonoperating_expense': {'NonOperatingExpenses','FinanceCostsIFRS'},
    'ordinary_profit': {'OrdinaryIncome'},
    'extraordinary_income': {'ExtraordinaryIncome'},
    'extraordinary_expense': {'ExtraordinaryLoss'},
    'profit_before_tax': {'IncomeBeforeIncomeTaxes','ProfitLossBeforeTaxIFRS','IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest'},
    'income_taxes': {'IncomeTaxes','IncomeTaxExpenseIFRS','IncomeTaxesExpenseIFRS','IncomeTaxExpenseBenefit'},
    'net_profit': {'ProfitLoss','ProfitLossIFRS','NetIncomeLoss'},
    'net_profit_parent': {'ProfitLossAttributableToOwnersOfParent','ProfitLossAttributableToOwnersOfParentIFRS','NetIncomeLossAttributableToParent'},
}

# These are spelling/terminology aliases, not a blanket removal of OpeCF, CA,
# IOA, CL/NCL, NOI/EI or any other economically meaningful suffix.
_LOCAL_ALIASES = {
    'AccumulatedDepreclationRightOfUseAssets': 'AccumulatedDepreciationRightOfUseAssets',
    'PenaltyForTheScrapBuildOfOutletsEL': 'PenaltyForTheScrapAndBuildOfOutletsEL',
}
_ISSUER_ALIASES = {
    # EDINET consecutive-year comparatives bridge these names with identical
    # values, including FY2024=-252,821,000. No separate benefit asset balance
    # exists in the affected Zuken series. This is deliberately issuer-scoped.
    ('E01966','CF','IncreaseDecreaseInNetDefinedBenefitAssetOrLiabilityOpeCF'): 'IncreaseDecreaseInRetirementBenefitLiabilityOpeCF',
}


def _compact(text: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text or ''))


def _concept(concept: str) -> tuple[str,str,str]:
    if concept.startswith('{') and '}' in concept:
        uri,local=concept[1:].split('}',1)
    else:
        uri,local='',concept.rsplit(':',1)[-1]
    html_issuer=re.match(r'urn:zaimu10:html-table:(E\d{5}):',uri)
    standard=re.fullmatch(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp|jpcrp|jpdei)/\d{4}-\d{2}-\d{2}/\1_cor',uri)
    issuer=re.fullmatch(r'https?://disclosure\.edinet-fsa\.go\.jp/(jpcrp\d+)/(asr|qrr|ssr|srs)/(\d+)/(E\d{5})-(\d{3})/\d{4}-\d{2}-\d{2}/\d+/\d{4}-\d{2}-\d{2}',uri)
    family=('issuer:html:'+html_issuer.group(1) if html_issuer else standard.group(1)+'_cor' if standard else
            ('issuer:'+':'.join(issuer.groups()) if issuer else uri))
    return family,local,html_issuer.group(1) if html_issuer else issuer.group(4) if issuer else ''


def local_name(row: Row) -> str:
    cell=next(iter(row.values.values()),None)
    return _concept(cell.source.account_concept)[1] if cell else ''


def _key_parts(row: Row):
    try:
        displayed=row.key.startswith('display:')
        parts=json.loads(row.key.removeprefix('display:'))
        if displayed and isinstance(parts,list) and len(parts)==8 and parts[0] in {'BS_A','BS_LE','CF'}:
            cell=next(iter(row.values.values()),None)
            return parts[3],parts[4],parts[5],cell.source.basis if cell else ''
        if isinstance(parts,list) and len(parts)==9 and parts[0] in {'PL','BS_A','BS_LE','CF'}:
            return parts[3],parts[4],parts[5],parts[6]
        if isinstance(parts,list) and len(parts)>=6 and parts[0] in {'PL','BS_A','BS_LE','CF'}:
            return parts[2],parts[3],parts[4],parts[5]
    except (ValueError,TypeError):
        pass
    cell=next(iter(row.values.values()),None)
    return [],('duration' if row.statement in {'PL','CF'} else 'end'),(cell.source.unit if cell else 'JPY'),(cell.source.basis if cell else '')


def _cf_section(row: Row) -> str:
    text=''.join(_compact(s) for s in row.section)
    if '投資活動' in text:return 'investing'
    if '財務活動' in text:return 'financing'
    if '営業活動' in text:return 'operating'
    return 'cash_bridge'


def _scope(row: Row, local: str) -> tuple:
    if row.statement=='CF':return (_cf_section(row),)
    if local in {'Other','OtherAssets','OtherLiabilities'} or local.startswith('Other'):
        return tuple(_compact(s).replace('合計','計') for s in row.section)
    return ()


def _rank(cell: Cell) -> tuple[str,str]:
    return cell.source.submitted.replace('/','-'),cell.source.doc_id


def _tolerance(cells: Iterable[Cell]) -> Decimal:
    amount=Decimal(0)
    for cell in cells:
        try:amount+=Decimal(10)**(-int(cell.source.decimals))
        except (ValueError,TypeError):pass
    return max(amount,Decimal(1))


def _noncurrent_tax_kind(row: Row, standard: str):
    if standard!='J-GAAP' or not row.values:return None
    family,local,_=_concept(next(iter(row.values.values())).source.account_concept)
    rules={'BS_A':({'DeferredTaxAssetsIOA','DeferredTaxAssets'},
                   {'固定資産','投資その他の資産','非流動資産'},{'流動資産'},'DeferredTaxAssetsNoncurrent'),
           'BS_LE':({'DeferredTaxLiabilitiesNCL','DeferredTaxLiabilities'},
                    {'固定負債','非流動負債'},{'流動負債'},'DeferredTaxLiabilitiesNoncurrent')}
    if family!='jppfs_cor' or row.statement not in rules:return None
    names,allowed,excluded,canonical=rules[row.statement]
    if local not in names:return None
    active=[c for c in row.values.values()if c.value is not None]
    if not active:return None
    for cell in active:
        context={_compact(s)for s in (cell.source_section if cell.source_section is not None else row.section)}
        if context&excluded or not context&allowed:return None
    return names,canonical


def _contextual_tax_alias(row: Row, standard: str, dataset: Dataset) -> str | None:
    rule=_noncurrent_tax_kind(row,standard)
    if rule is None:return None
    names,canonical=rule;periods={name:set()for name in names}
    dims,role,unit,basis=_key_parts(row)
    if dims or role!='end' or unit!='JPY':return None
    for candidate in dataset.rows[row.statement]:
        if candidate.is_heading or not candidate.values:continue
        if _noncurrent_tax_kind(candidate,standard)!=rule:continue
        cdims,crole,cunit,_=_key_parts(candidate)
        if cdims!=dims or crole!=role or cunit!=unit:continue
        name=local_name(candidate)
        periods[name].update(k for k in candidate.values
                             if dataset.period_standards.get(k,dataset.accounting_standard)==standard)
    active=list(periods.values())
    # Every present period, including explicit nil, must be disjoint. This alias
    # never uses a different element's number to fill an explicitly nil cell.
    return canonical if all(active) and not(active[0]&active[1])else None


def _meaning(row: Row, standard: str, display_group: str='', contextual_alias: str | None=None):
    cell=next(iter(row.values.values()))
    family,local,issuer=_concept(cell.source.account_concept)
    alias=_ISSUER_ALIASES.get((issuer,row.statement,local),local)
    alias=_LOCAL_ALIASES.get(alias,alias)
    if contextual_alias:alias=contextual_alias
    dimensions,role,unit,basis=_key_parts(row)
    if not family or not local:
        return ['unidentified',row.key,standard]
    scope=(display_group,) if row.statement=='CF' and display_group else _scope(row,alias)
    return [row.statement,family,alias,dimensions,role,unit,basis,standard,scope]


def semantic_id(row: Row) -> str:
    """Return a stable local semantic identifier (not a complete row identity)."""
    local=local_name(row)
    issuer=_concept(next(iter(row.values.values())).source.account_concept)[2] if row.values else ''
    alias=_ISSUER_ALIASES.get((issuer,row.statement,local),local)
    return _LOCAL_ALIASES.get(alias,alias)


def _merge_semantic_rows(dataset: Dataset) -> Dataset:
    result=deepcopy(dataset)
    for statement,rows in dataset.rows.items():
        output=[];index={}
        for row in rows:
            if row.is_heading:
                output.append(deepcopy(row));continue
            by_standard=defaultdict(dict)
            for period,cell in row.values.items():
                standard=dataset.period_standards.get(period,dataset.accounting_standard)
                display_group=cell.display_group or row.display_group
                by_standard[(standard,display_group)][period]=cell
            for (standard,display_group),values in by_standard.items():
                contextual_alias=_contextual_tax_alias(row,standard,dataset)
                identifier=json.dumps(_meaning(row,standard,display_group,contextual_alias),ensure_ascii=False)
                if identifier not in index:
                    target=deepcopy(row);target.key=identifier;target.values={}
                    target.display_group=display_group
                    output.append(target);index[identifier]=target
                target=index[identifier]
                for period,cell in values.items():
                    old=target.values.get(period)
                    if old is None or _rank(cell)>_rank(old):
                        chosen=deepcopy(cell)
                        if old is not None and old.value is not None and cell.value is not None and old.value!=cell.value:
                            chosen.note+=(f'\n同一意味の過年度開示を統合。{old.source.doc_id}の{old.value}円より新しい{cell.source.doc_id}の{cell.value}円を採用。')
                        target.values[period]=chosen
                    latest_period=max(target.values) if target.values else ''
                    selected=target.values.get(latest_period)
                    if selected:
                        target.label=selected.source.original_label or row.label
                        target.label_period=latest_period
        result.rows[statement]=output
    return result


def _computed(label: str, cells: list[Cell], keys: list[str], *, operation='sum',
              value: Decimal | None=None, note='') -> Cell:
    if not cells:raise PresentationError('構成項目のない計算は行いません。')
    if any(c.source.unit!=cells[0].source.unit for c in cells):
        raise PresentationError('異なる通貨・単位の数値を合計しません。')
    if value is None:value=sum((c.value for c in cells if c.value is not None),Decimal(0))
    source=deepcopy(max(cells,key=_rank).source)
    source.concept='{urn:zaimu10:presentation}'+label
    source.semantic_concept='';source.table_path=''
    source.original_label=label;source.raw_value='計算値（内訳はcomponents）'
    known_sections=[tuple(c.source_section)for c in cells if c.source_section is not None]
    if len(set(known_sections))>1:
        raise PresentationError('原表の異なるBS区分に属する項目を同じ小計へ推測で合計しません。')
    section=(known_sections[0]if len(known_sections)==len(cells)else None)
    orders=[c.source_order for c in cells if c.source_order is not None]
    order=min(orders)if len(orders)==len(cells)else None
    return Cell(value,source,note=note,components=deepcopy(cells),operation=operation,component_keys=list(keys),
                source_section=section,source_order=order)


_RECEIVABLE_COMBINED={'NotesAndAccountsReceivableTrade'}
_RECEIVABLE_PARTS={'NotesReceivableTrade','AccountsReceivableTrade'}
_INVENTORY_LOCALS=[{'MerchandiseAndFinishedGoods','Merchandise','FinishedGoods'},
                   {'WorkInProcess'}, {'RawMaterialsAndSupplies','RawMaterials','Supplies'}]


def _group_components(dataset: Dataset, combined_names: set[str], part_names: set[str],
                      label: str, group_name: str) -> None:
    rows=dataset.rows['BS_A']
    applicable=[r for r in rows if not r.is_heading and local_name(r) in combined_names|part_names
                and any(c.value is not None for c in r.values.values())]
    guards=defaultdict(list)
    for row in applicable:
        dims,role,unit,basis=_key_parts(row)
        if role=='end' and unit=='JPY' and not dims:guards[basis].append(row)
    replacements=[];consumed=set()
    for basis,members in guards.items():
        group=Row(json.dumps(['BS_A',group_name,basis],ensure_ascii=False),label,'BS_A',members[0].section,members[0].indent)
        expected={local_name(r) for r in members if local_name(r) in part_names}
        for period in dataset.periods:
            combined=[];parts=[]
            for row in members:
                cell=row.values.get(period.key)
                if cell is None or cell.value is None:continue
                (combined if local_name(row) in combined_names else parts).append((row,cell))
            unique={local_name(r):(r,c) for r,c in parts}
            if combined:
                selected=deepcopy(max(combined,key=lambda rc:_rank(rc[1]))[1])
                selected.note+='\n開示合算額を採用。構成項目との二重加算は行わない。'
                if unique:
                    selected.components=deepcopy([c for _,c in unique.values()])
                    selected.component_keys=[r.key for r,_ in unique.values()]
                    selected.operation='reported_total'
                if expected and expected<=set(unique):
                    components=[c for _,c in unique.values()]
                    if abs(sum(c.value for c in components)-selected.value)>_tolerance([selected]+components):
                        raise PresentationError(f'{period.label}の{label}の構成額が開示合計と一致しません。')
                group.values[period.key]=selected
            elif unique and expected<=set(unique):
                cells=[c for _,c in unique.values()];keys=[r.key for r,_ in unique.values()]
                group.values[period.key]=_computed(label,cells,keys,
                    note='開示済みの独立した構成項目を合計。合算開示額を同時に加算しない。')
            elif unique:
                # Missing/nil is not an invented zero. Keep the requested group
                # blank, with the known components and the precise reason.
                cell=deepcopy(max((c for _,c in unique.values()),key=_rank));cell.value=None
                cell.components=deepcopy([c for _,c in unique.values()]);cell.operation='incomplete_group'
                cell.component_keys=[r.key for r,_ in unique.values()]
                cell.note+='\n構成項目が一部未開示のため合計は空白：'+','.join(sorted(expected-set(unique)))
                group.values[period.key]=cell
        if group.values:
            group.label_period=max(group.values);replacements.append(group);consumed.update(r.key for r in members)
    if replacements:
        position=min(i for i,r in enumerate(rows) if r.key in consumed)
        kept=[r for r in rows if r.key not in consumed]
        kept[position:position]=replacements;dataset.rows['BS_A']=kept


def _group_receivables(dataset: Dataset) -> None:
    _group_components(dataset,_RECEIVABLE_COMBINED,_RECEIVABLE_PARTS,'売掛金及び受取手形','trade_receivables')
    _group_components(dataset,{'MerchandiseAndFinishedGoods'},{'Merchandise','FinishedGoods'},'商品及び製品','inventory_goods')
    _group_components(dataset,{'RawMaterialsAndSupplies'},{'RawMaterials','Supplies'},'原材料及び貯蔵品','inventory_materials')


def _active_rows(rows: list[Row]) -> list[Row]:
    filtered=[r for r in rows if r.is_heading or any(c.value is not None for c in r.values.values())]
    keep=[]
    for i,row in enumerate(filtered):
        if row.is_heading:
            following=[]
            for child in filtered[i+1:]:
                if child.is_heading and child.indent<=row.indent:break
                following.append(child)
            if not any(not c.is_heading for c in following):continue
        keep.append(row)
    return keep


def _inventory_order(dataset: Dataset) -> None:
    rows=dataset.rows['BS_A']
    receivables=[r for r in rows if 'trade_receivables' in r.key]
    if not receivables:return
    inventories=[]
    for alternatives in _INVENTORY_LOCALS:
        inventories.extend(r for r in rows if not r.is_heading and (local_name(r) in alternatives or ('inventory_goods' in r.key and alternatives is _INVENTORY_LOCALS[0]) or ('inventory_materials' in r.key and alternatives is _INVENTORY_LOCALS[2])))
    selected={id(r) for r in inventories+receivables}
    rest=[r for r in rows if id(r) not in selected]
    cash=next((i for i,r in enumerate(rest) if local_name(r) in {'CashAndDeposits','CashAndCashEquivalentsIFRS'}),None)
    insert=cash+1 if cash is not None else next((i for i,r in enumerate(rest) if not r.is_heading),0)
    rest[insert:insert]=receivables+inventories
    dataset.rows['BS_A']=rest


def annotate_filing(dataset: Dataset) -> Dataset:
    """Preserve CF phase from an original single-filing statement, before merge.

    Inline source headings may not be repeated after a subtotal. Keeping the
    phase on every source cell prevents a different year's/basis's subtotal
    from changing an unknown cash-flow item's placement after merging.
    """
    result=deepcopy(dataset)
    # BS display rows can later be stitched across disjoint profiles and moved
    # into template order. Keep each original filing's hierarchy and ordinal on
    # the actual cells, not on one row shared by multiple fiscal periods.
    for statement in ['BS_A','BS_LE']:
        for ordinal,row in enumerate(result.rows[statement]):
            for cell in row.values.values():
                cell.source_section=tuple(row.section)
                cell.source_order=ordinal
    section='cash_bridge';phase='cash_bridge'
    working={'DecreaseIncreaseInNotesAndAccountsReceivableTradeOpeCF',
             'DecreaseIncreaseInInventoriesOpeCF','IncreaseDecreaseInNotesAndAccountsPayableTradeOpeCF',
             'DecreaseIncreaseInTradeAndOtherReceivablesOpeCFIFRS',
             'DecreaseIncreaseInInventoriesOpeCFIFRS','IncreaseDecreaseInTradeAndOtherPayablesOpeCFIFRS'}
    totals={'NetCashProvidedByUsedInOperatingActivities','NetCashProvidedByUsedInOperatingActivitiesIFRS',
            'NetCashProvidedByUsedInInvestmentActivities','NetCashProvidedByUsedInInvestingActivitiesIFRS',
            'NetCashProvidedByUsedInFinancingActivities','NetCashProvidedByUsedInFinancingActivitiesIFRS'}
    for ordinal,row in enumerate(result.rows['CF']):
        for cell in row.values.values():
            if cell.source_section is None:cell.source_section=tuple(row.section)
            if cell.source_order is None:cell.source_order=ordinal
        local=local_name(row)
        if row.is_heading:
            stated=_cf_section(row)
            if stated!='cash_bridge':
                section=stated;phase='operating_adjustments' if stated=='operating' else stated
            row.display_group=phase
            continue
        stated=_cf_section(row)
        if local in {'IncomeBeforeIncomeTaxes','ProfitLossBeforeTaxIFRS'}:
            section='operating';phase='operating_adjustments'
        elif stated!='cash_bridge' and stated!=section:
            section=stated;phase='operating_adjustments' if stated=='operating' else stated
        if section=='operating' and local in working:phase='operating_working'
        row.display_group=phase
        for cell in row.values.values():cell.display_group=phase
        if local in {'SubtotalOpeCF','SubtotalOpeCFIFRS'}:phase='operating_payments'
        if local in totals:section='cash_bridge';phase='cash_bridge'
    return result


def stitch_display_rows(dataset: Dataset) -> Dataset:
    """Join identical BS/CF display meanings across nonoverlapping profiles.

    This is a layout operation, not consolidation or a numeric aggregation.
    Source cells and the per-year basis/standard labels remain unchanged. Two
    profiles reporting the same year can never be added or silently selected.
    """
    result=deepcopy(dataset)
    for statement in ['BS_A','BS_LE','CF']:
        output=[];index={};headings=set()
        for original in result.rows[statement]:
            if original.is_heading:
                if original.key not in headings:output.append(original);headings.add(original.key)
                continue
            try:parts=json.loads(original.key)
            except (ValueError,TypeError):parts=None
            if isinstance(parts,list) and len(parts)==9 and parts[0]==statement:
                signature=parts[:6]+parts[7:]
            elif (isinstance(parts,list) and len(parts)==3 and parts[0]=='BS_A'
                  and parts[1] in {'trade_receivables','inventory_goods','inventory_materials'}):
                signature=parts[:2]
            else:
                output.append(original);continue
            token=json.dumps(signature,ensure_ascii=False)
            target=index.get(token)
            if target is None:
                output.append(original);index[token]=original;continue
            if set(target.values)&set(original.values):
                output.append(original);continue
            target.values.update(deepcopy(original.values))
            target.key='display:'+token
            if original.label_period>target.label_period:
                target.label=original.label;target.label_period=original.label_period
                target.section=original.section;target.indent=original.indent
                target.is_total=original.is_total
        result.rows[statement]=output
    return result


def _normalise_html_signs(dataset: Dataset) -> Dataset:
    """Project proven signed HTML expense/liability presentations as magnitudes.

    Raw cells remain components. No sign rule is applied to ordinary XBRL data.
    """
    result=deepcopy(dataset)
    for period in result.periods:
        def find(statement,name):
            found=[(r,r.values[period.key]) for r in result.rows[statement]
                   if period.key in r.values and local_name(r)==name
                   and r.values[period.key].value is not None
                   and r.values[period.key].source.semantic_concept.startswith('{urn:zaimu10:html-table:')]
            return found[0] if len(found)==1 else None
        def tolerance(*items):
            return sum((Decimal(10)**(-int(item[1].source.decimals or '0')) for item in items),Decimal(0))
        def negate(row,cell):
            original=deepcopy(cell)
            cell.value=-cell.value;cell.components=[original]
            cell.component_keys=[row.key+':signed-source'];cell.operation='negate'
            cell.note+='\n符号付きの原表を通常の費用・負債残高表示に変換。元の符号付き値はcomponentsに保持。'
        revenue=find('PL','RevenueIFRS');cost=find('PL','CostOfSalesIFRS');gross=find('PL','GrossProfitIFRS')
        if revenue and cost and gross and cost[1].value<0 and abs(revenue[1].value+cost[1].value-gross[1].value)<=tolerance(revenue,cost,gross):
            negate(*cost)
        pretax=find('PL','ProfitLossBeforeTaxIFRS');tax=find('PL','IncomeTaxExpenseIFRS');profit=find('PL','ProfitLossIFRS')
        continuing=find('PL','ProfitLossFromContinuingOperationsIFRS')
        tax_profit=next((candidate for candidate in [profit,continuing]if candidate and pretax and tax and
            abs(pretax[1].value+tax[1].value-candidate[1].value)<=tolerance(pretax,tax,candidate)),None)
        if pretax and tax and tax_profit and tax[1].value<0:
            negate(*tax)
        finance=find('PL','FinanceCostsIFRS')
        if finance and finance[1].value<0:negate(*finance)
        assets=find('BS_A','AssetsIFRS');liabilities=find('BS_LE','LiabilitiesIFRS');equity=find('BS_LE','EquityIFRS')
        if assets and liabilities and equity and liabilities[1].value<0 and abs(assets[1].value+liabilities[1].value-equity[1].value)<=tolerance(assets,liabilities,equity):
            for row in result.rows['BS_LE']:
                cell=row.values.get(period.key)
                if (cell is not None and cell.value is not None and cell.source.semantic_concept
                        and local_name(row)!='HtmlNetAssetsIFRS' and any('負債' in h for h in (cell.source_section or row.section))):
                    negate(row,cell)
            result.source_notes.append(f'{period.label}: IFRS原表の資産＋負数負債＝純資産を確認し、負債を正の残高へ表示変換。元の符号を監査記録に保持。')
        if assets and liabilities and equity and not find('BS_LE','LiabilitiesAndEquityIFRS'):
            if abs(liabilities[1].value+equity[1].value-assets[1].value)>tolerance(assets,liabilities,equity):
                raise PresentationError('HTML本表の負債と資本を資産合計へ照合できません。')
            source=deepcopy(equity[1].source)
            namespace=source.semantic_concept.split('}',1)[0]+'}'
            source.concept='{urn:zaimu10:presentation}LiabilitiesAndEquityIFRS'
            source.semantic_concept=namespace+'LiabilitiesAndEquityIFRS';source.table_path=''
            source.original_label='負債及び資本合計（計算）';source.raw_value='負債合計＋資本合計'
            value=liabilities[1].value+equity[1].value
            cell=Cell(value,source,components=[deepcopy(liabilities[1]),deepcopy(equity[1])],
                      operation='sum',component_keys=[liabilities[0].key,equity[0].key],
                      source_section=(),source_order=len(result.rows['BS_LE']),
                      note='原表が純資産表示のため負債合計と資本合計から計算。資産合計と丸め精度内で一致。')
            key=json.dumps(['BS_LE',namespace[1:-1],'LiabilitiesAndEquityIFRS',[],'end','JPY',result.period_bases.get(period.key,result.basis),result.period_standards.get(period.key,result.accounting_standard),[]],ensure_ascii=False)
            existing=next((r for r in result.rows['BS_LE'] if r.key==key),None)
            if existing is None:
                existing=Row(key,'負債及び資本合計（計算）','BS_LE',is_total=True)
                result.rows['BS_LE'].append(existing)
            existing.values[period.key]=cell;existing.label_period=max(existing.values)
    return result


def prepare_dataset(dataset: Dataset) -> Dataset:
    """Build an editable display projection, leaving original facts untouched."""
    if getattr(dataset,'_financial_presentation_prepared',False):return deepcopy(dataset)
    result=_merge_semantic_rows(_normalise_html_signs(dataset))
    _group_receivables(result)
    result=stitch_display_rows(result)
    _inventory_order(result)
    for statement in result.rows:result.rows[statement]=_active_rows(result.rows[statement])
    note='表示用に同一企業・同一意味の年度別項目を整理。元のQName・年度別開示・集計内訳は監査記録に保持。'
    if note not in result.source_notes:result.source_notes.append(note)
    result._financial_presentation_prepared=True
    return result


def detect_display_unit(dataset: Dataset) -> str:
    if not dataset.periods:return 'thousand'
    latest=max(dataset.periods,key=lambda p:p.end).key
    cells=[c for rows in dataset.rows.values() for row in rows for k,c in row.values.items()
           if k==latest and c.value is not None and c.source.unit=='JPY'
           and not c.source.concept.startswith('{urn:zaimu10:presentation}')]
    if not cells:return 'thousand'
    counts=Counter(c.source.scale for c in cells if c.source.scale in {3,6})
    if not counts:
        for c in cells:
            try:
                precision=-int(c.source.decimals)
                if precision in {3,6}:counts[precision]+=1
            except (ValueError,TypeError):pass
    return 'million' if counts[6]>counts[3] else 'thousand'


def _pick(dataset: Dataset, statement: str, period: str, names: set[str]) -> tuple[Row,Cell] | None:
    found=[(r,r.values[period]) for r in dataset.rows[statement]
           if not r.is_heading and local_name(r) in names and period in r.values
           and r.values[period].value is not None and not r.values[period].nil
           and r.values[period].source.unit=='JPY'
           and (local_name(r)!='NetSalesIFRS' or
                _concept(r.values[period].source.account_concept)[0]=='jpigp_cor')
           and not _key_parts(r)[0]]
    if not found:return None
    return max(found,key=lambda rc:_rank(rc[1]))


def _section_total(dataset: Dataset,period: str,headings: set[str]) -> Cell | None:
    candidates=[]
    for row in dataset.rows['PL']:
        if row.is_heading or period not in row.values or row.values[period].value is None:continue
        if row.values[period].source.unit!='JPY' or _key_parts(row)[0]:continue
        if any(_compact(s) in headings for s in row.section):
            candidates.append(row)
    category_labels=headings|{h+'計'for h in headings}|{h+'合計'for h in headings}
    totals=[r for r in candidates if _compact(r.label)in category_labels]
    if len(totals)==1:return deepcopy(totals[0].values[period])
    if len(totals)>1:return None
    # A nested subtotal plus its components cannot be summed blindly when no
    # complete category total was identified. Missing is safer than double-count.
    if any(r.is_total and r.label.endswith(('計','合計'))for r in candidates):return None
    items=[r.values[period] for r in candidates];keys=[r.key for r in candidates]
    return _computed('部門集計',items,keys,note='当該営業外・特別区分の開示内訳を合計。') if items else None


def pl_metrics(dataset: Dataset) -> dict[str,Row]:
    result={name:Row('metric:'+name,label,'PL',is_total=True) for name,label in PL_METRICS.items()}
    for period in dataset.periods:
        values={};blocked=set()
        for name,names in PL_CONCEPTS.items():
            found=_pick(dataset,'PL',period.key,names)
            if found:values[name]=deepcopy(found[1])
        # An explicit three-line selling/R&D/administration presentation is
        # not GP minus reported operating profit: equity-accounted earnings
        # and other operating gains/losses can also affect that profit.
        split_names={'selling':{'販売費'},'research':{'研究開発費'},
                     'administration':{'一般管理費','一般管理費等'}}
        split_roles={'SellingExpensesIFRS':'selling','ResearchAndDevelopmentExpensesIFRS':'research',
                     'ResearchAndDevelopmentExpenditureRecognizedAsExpenseDuringPeriodIFRS':'research',
                     'GeneralAndAdministrativeExpensesIFRS':'administration'}
        split={name:[]for name in split_names}
        for row in dataset.rows['PL']:
            cell=row.values.get(period.key)
            if cell is None:continue
            name=split_roles.get(local_name(row))
            html=(cell.source.semantic_concept.startswith('{urn:zaimu10:html-table:')and
                  cell.source.concept.endswith('}ConsolidatedStatementOfIncomeIFRSTextBlock'))
            standard=_concept(cell.source.account_concept)[0]=='jpigp_cor'
            if (name in split and (standard or(html and _compact(cell.source.original_label)in split_names[name]))and
                not _key_parts(row)[0]and cell.source.unit=='JPY'):
                split[name].append((row,cell))
        if 'sga'not in values and any(split.values()):
            blocked.add('sga')
            if all(len(entries)==1 for entries in split.values()):
                parts=[entries[0]for entries in split.values()]
                profile={(c.source.doc_id,c.source.basis,
                    c.source.concept.rsplit('}',1)[0]if _concept(c.source.account_concept)[0]=='jpigp_cor'else c.source.concept)
                    for _,c in parts}
                cells=[c for _,c in parts]
                available=all(c.value is not None and not c.nil for c in cells)
                one_sign=available and(all(c.value>=0 for c in cells)or all(c.value<=0 for c in cells))
                if len(profile)==1 and one_sign:
                    normalized=[]
                    for row,original in parts:
                        cell=deepcopy(original)
                        if cell.value<0:
                            cell.value=-cell.value;cell.components=[deepcopy(original)]
                            cell.component_keys=[row.key];cell.operation='negate'
                            cell.note+='\n符号付き費用の開示を費用額表示に変換。元の負数をcomponentsに保持。'
                        normalized.append(cell)
                    values['sga']=_computed(PL_METRICS['sga'],normalized,[r.key for r,_ in parts],
                        note='同一原本・年度・連結区分のIFRS本表に明示された販売費・研究開発費・一般管理費の3費用だけを合計。利益との差額から推定しない。')
        for name,heading in [('nonoperating_income','営業外収益'),('nonoperating_expense','営業外費用'),
                             ('extraordinary_income','特別利益'),('extraordinary_expense','特別損失')]:
            if name not in values:
                cell=_section_total(dataset,period.key,{heading})
                if cell:values[name]=cell
        for _ in range(3):
            rules=[('gross_profit',['revenue','cost_of_sales'],[1,-1]),
                   ('operating_profit',['gross_profit','sga'],[1,-1]),
                   ('sga',['gross_profit','operating_profit'],[1,-1]),
                   ('ordinary_profit',['operating_profit','nonoperating_income','nonoperating_expense'],[1,1,-1]),
                   ('profit_before_tax',['ordinary_profit','extraordinary_income','extraordinary_expense'],[1,1,-1]),
                   ('income_taxes',['income_tax_current','income_tax_deferred'],[1,1]),
                   ('net_profit',['profit_before_tax','income_taxes'],[1,-1]),
                   ('net_profit',['net_profit_parent','noncontrolling_profit'],[1,1])]
            for name,names,signs in rules:
                if name in values or name in blocked or not all(n in values for n in names):continue
                cells=[values[n] for n in names]
                total=sum((c.value*s for c,s in zip(cells,signs)),Decimal(0))
                values[name]=_computed(PL_METRICS[name],cells,['metric:'+n for n in names],
                    value=total,operation='sum' if all(s==1 for s in signs) else 'difference',
                    note='開示値から計算：'+' '.join(('+' if s==1 else '-')+n for n,s in zip(names,signs)))
            for name,names in {'income_tax_current':{'IncomeTaxesCurrent'},'income_tax_deferred':{'IncomeTaxesDeferred'},
                               'noncontrolling_profit':{'ProfitLossAttributableToNonControllingInterests','ProfitLossAttributableToNonControllingInterestsIFRS'}}.items():
                if name not in values:
                    found=_pick(dataset,'PL',period.key,names)
                    if found:values[name]=deepcopy(found[1])
        for name,row in result.items():
            if name in values:row.values[period.key]=values[name];row.label_period=period.key
    return result


def metric_cell(dataset: Dataset,name: str,period: str | Period) -> Cell | None:
    name=name.removeprefix('metric:')
    return pl_metrics(dataset).get(name,Row('','','PL')).values.get(period.key if isinstance(period,Period) else period)


CF_LOCAL_SLOTS = {'IncreaseDecreaseInProvisionForRetirementBenefitsOpeCF':8,'AmortizationOfGoodwillOpeCF': 5,
 'CashDividendsPaidFinCF': 61,
 'CollectionOfLoansReceivableInvCF': 52,
 'CollectionOfLoansReceivableInvCFIFRS': 52,
 'DecreaseInShortTermLoansPayableFinCF': 56,
 'DecreaseIncreaseInAccountsReceivableOtherOpeCF': 27,
 'DecreaseIncreaseInConsumptionTaxesReceivablePayableOpeCF': 32,
 'DecreaseIncreaseInConsumptionTaxesRefundReceivableOpeCF': 32,
 'DecreaseIncreaseInGuaranteeDepositsOpeCF': 29,
 'DecreaseIncreaseInInventoriesOpeCF': 24,
 'DecreaseIncreaseInInventoriesOpeCFIFRS': 24,
 'DecreaseIncreaseInNotesAndAccountsReceivableTradeOpeCF': 23,
 'DecreaseIncreaseInOtherAssetsOpeCF': 29,
 'DecreaseIncreaseInOtherCurrentAssetsOpeCF': 29,
 'DecreaseIncreaseInOtherNoncurrentAssetsOpeCF': 29,
 'DecreaseIncreaseInOtherReceivablesOpeCF': 27,
 'DecreaseIncreaseInPrepaidExpensesOpeCF': 28,
 'DecreaseIncreaseInTimeDepositsInvCF': 43,
 'DepreciationAndAmortizationOpeCF': 4,
 'DepreciationAndAmortizationOpeCFIFRS': 4,
 'DividendsPaidFinCFIFRS': 61,
 'DividendsReceivedOpeCFIFRS': 34,
 'EffectOfExchangeRateChangeOnCashAndCashEquivalents': 65,
 'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS': 65,
 'EquityInEarningsLossesOfAffiliatesOpeCF': 13,
 'ForeignExchangeLossesGainsOpeCF': 12,
 'ImpairmentLossOpeCF': 6,
 'ImpairmentLossesAndReversalsOfImpairmentLossesImpairmentLossesReversalOfImpairmentLossesIFRS': 6,
 'ImpairmentLossesReversalOfImpairmentLossesOpeCFIFRS': 6,
 'IncomeBeforeIncomeTaxes': 3,
 'IncomeTaxesPaidOpeCF': 36,
 'IncomeTaxesPaidOpeCFIFRS': 36,
 'IncomeTaxesRefundOpeCF': 37,
 'IncomeTaxesRefundOpeCFIFRS': 37,
 'IncreasDecreaseInContractLiabilitiesOpeCF': 30,
 'IncreaseDecreaseInAccountsPayableOtherOpeCF': 30,
 'IncreaseDecreaseInAccruedConsumptionTaxesOpeCF': 32,
 'IncreaseDecreaseInAdvancesReceivedOpeCF': 30,
 'IncreaseDecreaseInAllowanceForDoubtfulAccountsOpeCF': 7,
 'IncreaseDecreaseInContractLiabilitiesOpeCFIFRS': 30,
 'IncreaseDecreaseInDepositsReceivedOpeCF': 30,
 'IncreaseDecreaseInLongTermAccountsPayableOtherOpeCF': 30,
 'IncreaseDecreaseInLongTermAdvancesReceivedOpeCF': 30,
 'IncreaseDecreaseInNetDefinedBenefitAssetOrLiabilityOpeCF': 8,
 'IncreaseDecreaseInNetDefinedBenefitLiabilityOpeCF': 8,
 'IncreaseDecreaseInNotesAndAccountsPayableTradeOpeCF': 25,
 'IncreaseDecreaseInOtherCurrentLiabilitiesOpeCF': 30,
 'IncreaseDecreaseInOtherLiabilitiesOpeCF': 30,
 'IncreaseDecreaseInOtherNoncurrentLiabilitiesOpeCF': 30,
 'IncreaseDecreaseInProvisionForBonusesOpeCF': 7,
 'IncreaseDecreaseInProvisionForDirectorsBonusesOpeCF': 7,
 'IncreaseDecreaseInProvisionForDirectorsRetirementBenefitsOpeCF': 7,
 'IncreaseDecreaseInProvisionForLossOnBusinessLiquidationOpeCF': 7,
 'IncreaseDecreaseInProvisionForPointCardCertificatesOpeCF': 7,
 'IncreaseDecreaseInProvisionForProductWarrantiesOpeCF': 7,
 'IncreaseDecreaseInRetirementBenefitLiabilityOpeCF': 8,
 'IncreaseDecreaseInUnearnedRevenueOpeCF': 30,
 'IncreaseInShortTermLoansPayableFinCF': 56,
 'InterestAndDividendIncomeOpeCFIFRS': 10,
 'InterestAndDividendsIncomeOpeCF': 10,
 'InterestAndDividendsIncomeReceivedOpeCFInvCF': 34,
 'InterestExpensesOpeCF': 11,
 'InterestExpensesOpeCFIFRS': 11,
 'InterestExpensesPaidOpeCFFinCF': 35,
 'InterestIncomeOnSecuritiesOpeCF': 10,
 'InterestPaidOpeCFIFRS': 35,
 'InterestReceivedOpeCFIFRS': 34,
 'LossGainOnRetirementOfNoncurrentAssetsOpeCF': 17,
 'LossGainOnSaleOfBusinessOpeCF': 18,
 'LossGainOnSaleOfFixedAssetsOpeCFIFRS': 16,
 'LossGainOnSalesOfBusinessOpeCF': 18,
 'LossGainOnSalesOfInvestmentSecuritiesOpeCF': 15,
 'LossGainOnSalesOfNoncurrentAssetsOpeCF': 16,
 'LossGainOnTransferOfBusinessOpeCF': 18,
 'LossGainOnValuationOfDerivativeOpeCF': 19,
 'LossGainOnValuationOfDerivativesOpeCF': 19,
 'LossGainOnValuationOfInvestmentSecuritiesOpeCF': 14,
 'LossOnRetirementOfNoncurrentAssetsOpeCF': 17,
 'NetCashProvidedByUsedInFinancingActivities': 64,
 'NetCashProvidedByUsedInFinancingActivitiesIFRS': 64,
 'NetCashProvidedByUsedInInvestingActivitiesIFRS': 54,
 'NetCashProvidedByUsedInInvestmentActivities': 54,
 'NetCashProvidedByUsedInOperatingActivities': 40,
 'NetCashProvidedByUsedInOperatingActivitiesIFRS': 40,
 'NetDecreaseIncreaseInShortTermLoansReceivableInvCF': 52,
 'NetIncreaseDecreaseInCashAndCashEquivalents': 66,
 'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS': 66,
 'NetIncreaseDecreaseInShortTermBorrowingsFinCFIFRS': 56,
 'NetIncreaseDecreaseInShortTermLoansBorrowingsWithinThreeMonthsNetIncreaseDecreaseInShortTermBorrowingsIFRS': 56,
 'NetIncreaseDecreaseInShortTermLoansPayableFinCF': 56,
 'OtherChangesInWorkingCapitalOpeCFIFRS': 31,
 'OtherInvCFIFRS': 53,
 'OtherNetFinCF': 63,
 'OtherNetInvCF': 53,
 'OtherPaymentsFinCF': 63,
 'OtherPaymentsInvCF': 53,
 'OtherProceedsInvCF': 53,
 'PaymentsForLoansReceivableInvCFIFRS': 52,
 'PaymentsForPurchaseOfTreasurySharesFinCFIFRS': 60,
 'PaymentsIntoTimeDepositsInvCF': 43,
 'PaymentsIntoTimeDepositsInvCFIFRS': 43,
 'PaymentsOfLoansReceivableInvCF': 52,
 'ProceedsFromInsuranceIncomeOpeCF': 39,
 'ProceedsFromIssuanceOfBondsWithSubscriptionRightsToSharesFinCF': 62,
 'ProceedsFromIssuanceOfCommonStockFinCF': 59,
 'ProceedsFromIssuanceOfConvertibleBondsFinCF': 62,
 'ProceedsFromLongTermLoansPayableFinCF': 57,
 'ProceedsFromRedemptionOfSecuritiesInvCF': 49,
 'ProceedsFromRepaymentOfAffiliatedCompaniesLoansInvCF': 52,
 'ProceedsFromSaleOfMarketableSecuritiesInvCFIFRS': 49,
 'ProceedsFromSaleOfPropertyPlantAndEquipmentAndInvestmentPropertyInvCFIFRS': 45,
 'ProceedsFromSalesAndRedemptionOfInvestmentSecuritiesInvCF': 49,
 'ProceedsFromSalesOfIntangibleAssetsInvCF': 47,
 'ProceedsFromSalesOfInvestmentSecuritiesInvCF': 49,
 'ProceedsFromSalesOfInvestmentsInSubsidiariesResultingInChangeInScopeOfConsolidationInvCF': 51,
 'ProceedsFromSalesOfPropertyPlantAndEquipmentInvCF': 45,
 'ProceedsFromSalesOfShortTermAndLongTermInvestmentSecuritiesInvCF': 49,
 'ProceedsFromSalesOfStocksOfSubsidiariesAndAffiliatesInvCF': 51,
 'ProceedsFromShortTermBorrowingsOverThreeMonthsRepaymentsOfShortTermBorrowingsOverThreeMonthsIFRS': 56,
 'ProceedsFromSubsidyIncome2OpeCF': 38,
 'ProceedsFromSubsidyOpeCF': 38,
 'ProceedsFromWithdrawalOfTimeDepositsInvCF': 43,
 'ProceedsFromWithdrawalOfTimeDepositsInvCFIFRS': 43,
 'ProfitLossBeforeTaxIFRS': 3,
 'ProvisionForLossOnCancellationOpeCF': 7,
 'ProvisionForLossOnFactoryReconstructionCF': 7,
 'ProvisionForLossOnFireOpeCF': 7,
 'PurchaseOfIntangibleAssetsInvCF': 46,
 'PurchaseOfIntangibleAssetsInvCFIFRS': 46,
 'PurchaseOfInvestmentSecuritiesInvCF': 48,
 'PurchaseOfInvestmentsInSubsidiariesInvCF': 50,
 'PurchaseOfInvestmentsInSubsidiariesResultingInChangeInScopeOfConsolidationInvCF': 50,
 'PurchaseOfMarketableSecuritiesInvCFIFRS': 48,
 'PurchaseOfPropertyPlantAndEquipmentAndInvestmentPropertyInvCFIFRS': 44,
 'PurchaseOfPropertyPlantAndEquipmentInvCF': 44,
 'PurchaseOfShortTermAndLongTermInvestmentSecuritiesInvCF': 48,
 'PurchaseOfStocksOfSubsidiariesAndAffiliatesInvCF': 50,
 'PurchaseOfTreasuryStockFinCF': 60,
 'RedemptionOfBondsFinCF': 58,
 'RedemptionOfBondsPayableFinCF': 58,
 'RepaymentOfBondsPayableFinCF': 58,
 'RepaymentOfLongTermLoansPayableFinCF': 57,
 'RepaymentsOfLongTermBorrowingsFinCFIFRS': 57,
 'RepaymentsOfShortTermBorrowingsOverThreeMonthsInterestPaidIFRS': 56,
 'ReversalOfProvisionForBusinessRestructuringOpeCF': 7,
 'ReversalOfProvisionForLossOnCancellationOpeCF': 7,
 'ShareBasedCompensationExpensesOpeCF': 9,
 'ShareBasedCompensationOpeCF': 9,
 'ShareBasedPaymentExpenseOpeCFIFRS': 9,
 'ShareBasedPaymentExpensesOpeCFIFRS': 9,
 'ShareOfLossProfitOfInvestmentsAccountedForUsingEquityMethodOpeCFIFRS': 13,
 'StockCompensationOpeCF': 9,
 'SubsidyIncome2OpeCF': 20,
 'SubsidyIncomeOpeCF': 20,
 'SubtotalOpeCF': 33,
 'SubtotalOpeCFIFRS': 33,
 'ValuationLossGainOnDerivativesOpeCF': 19}

CF_LABELS={3:'税金等調整前当期純利益',4:'減価償却費(+)',5:'のれん償却額(+)',6:'減損損失(+)',
7:'引当金増減(+)',8:'退職給付に係る負債の増減額(+)',9:'株式報酬費用',10:'受取利息及び受取配当金(-)',
11:'支払利息(+)',12:'為替差損益(+)',13:'持分法による投資損益(+)',14:'投資有価証券評価損益(+)',
15:'投資有価証券売却損益(+)',16:'固定資産売却損益(+)',17:'固定資産除却損益(+)',18:'事業譲渡損益(+)',
19:'デリバティブ評価損益',20:'助成金収入',21:'その他',22:'小計',23:'売上債権増減額(-)',24:'棚卸資産増減額(-)',
25:'仕入債務増減額(+)',26:'運転資本増減額(-) 小計',27:'未収入金増減額(+)',28:'前払費用増減額(-)',
29:'その他の資産の増減額',30:'その他の負債の増減額',31:'その他',32:'未払消費税等の増減額(+)',33:'中計',
34:'利息及び配当金の受取額',35:'利息の支払額',36:'法人税等の支払額',37:'法人税等の還付額',
38:'助成金の受取額',39:'保険金の受取額',40:'営業活動によるキャッシュ・フロー',43:'定期預金増減額(預入で-)',
44:'有形固定資産等の取得による支出',45:'有形固定資産等の売却による収入',46:'無形固定資産の取得による支出',
47:'無形固定資産の売却による収入',48:'投資有価証券等取得による支出',49:'投資有価証券等売却・償還による収入',
50:'関係会社株式取得の支出',51:'関係会社株式売却の収入',52:'貸付による支出及び収入',53:'その他',
54:'投資活動によるキャッシュフロー',56:'短期借入及び返済',57:'長期借入及び返済',58:'社債の償還',
59:'株式発行による収入',60:'自己株式の取得による支出',61:'配当金の支払額',62:'新株予約権付社債の発行による収入',
63:'その他',64:'財務活動によるキャッシュフロー',65:'現金及び現金同等物に係る換算差額',
66:'現金及び現金同等物の増減額',67:'現金及び現金同等物の期首残高',68:'現金及び現金同等物の期末残高(調)'}

# A reported net/combined item substitutes for its explicitly named components.
# It never substitutes for a broader or a differently classified cash flow.
_CF_DOMINANCE={
43:[({'DecreaseIncreaseInTimeDepositsInvCF'}, {'PaymentsIntoTimeDepositsInvCF','ProceedsFromWithdrawalOfTimeDepositsInvCF'})],
49:[({'ProceedsFromSalesAndRedemptionOfInvestmentSecuritiesInvCF'}, {'ProceedsFromSalesOfInvestmentSecuritiesInvCF','ProceedsFromRedemptionOfSecuritiesInvCF'})],
56:[({'NetIncreaseDecreaseInShortTermLoansPayableFinCF'}, {'IncreaseInShortTermLoansPayableFinCF','DecreaseInShortTermLoansPayableFinCF'})],
}


def _cf_operating_caption(row: Row, captions: set[str]) -> bool:
    if _compact(row.label) not in captions:return False
    dimensions,role,unit,basis=_key_parts(row)
    operating=(_cf_section(row)=='operating' or row.display_group.startswith('operating') or
               any(cell.display_group.startswith('operating') for cell in row.values.values()))
    return not dimensions and unit=='JPY' and operating


def _cf_generic_subtotal(row: Row) -> bool:
    # The exact source word is a subtotal, even if a plain HTML row has no
    # numeric taxonomy tag. Never add the subtotal alongside its own details.
    return _cf_operating_caption(row,{'小計'}) and semantic_id(row) not in {'SubtotalOpeCF','SubtotalOpeCFIFRS'}


def _cf_plain_working(row: Row) -> bool:
    # This is a placement boundary, not an alias to the three trade-working
    # inputs: a broad disclosed working-capital movement keeps its own row.
    return (any(cell.source.semantic_concept.startswith('{urn:zaimu10:html-table:') for cell in row.values.values())
            and _cf_operating_caption(row,{'運転資本の減少(増加)','運転資本の増加(減少)','運転資本の増減',
                '運転資本の減少(△は増加)','運転資本の増加(△は減少)'}))


def _cf_slot(row: Row, *, index: int, first_working: int, subtotal: int, cfo: int,
             effective_section: str | None=None, subtotal_slot: int | None=None) -> int | None:
    local=semantic_id(row)
    dimensions,role,unit,basis=_key_parts(row)
    if dimensions or unit!='JPY':return None
    if subtotal_slot is not None:return subtotal_slot
    if local=='IncreaseDecreaseInNetDefinedBenefitAssetOrLiabilityOpeCF':
        # Net asset/liability changes are not globally interchangeable with a
        # liability-only change. Only the verified issuer alias above applies.
        return None
    if local in {'CashAndCashEquivalents','CashAndCashEquivalentsIFRS'}:
        role=_key_parts(row)[1]
        return 67 if role=='begin' else 68 if role=='end' else None
    section=effective_section or _cf_section(row)
    if local=='OtherNetOpeCF':return (21 if index<first_working else 31) if section=='operating' else None
    slot=CF_LOCAL_SLOTS.get(local)
    if slot is None:return None
    # Dual-classification taxonomy names need the actual displayed section.
    if slot in {34,35} and section!='operating':return None
    if slot<40 and section not in {'operating','cash_bridge'}:return None
    if 43<=slot<=53 and section!='investing':return None
    if 56<=slot<=63 and section!='financing':return None
    return slot


def _slot_cell(slot: int, members: list[tuple[Row,Cell]]) -> Cell:
    profiles=set()
    for row,cell in members:
        try:
            displayed=row.key.startswith('display:')
            parts=json.loads(row.key.removeprefix('display:'))
            standard=parts[6]if displayed and len(parts)==8 else parts[7]if len(parts)==9 else ''
            profiles.add((cell.source.basis,standard))
        except (ValueError,TypeError,IndexError):profiles.add((cell.source.basis,''))
    if len(profiles)>1:raise PresentationError('同じ年度の異なる連結区分・会計基準のCFを合計しません。')
    original=list(members)
    for totals,parts in _CF_DOMINANCE.get(slot,[]):
        reported=[rc for rc in members if local_name(rc[0]) in totals]
        components=[rc for rc in members if local_name(rc[0]) in parts]
        if reported:
            picked=max(reported,key=lambda rc:_rank(rc[1]))
            if {local_name(r) for r,_ in components}>=parts:
                if abs(sum(c.value for _,c in components)-picked[1].value)>_tolerance([picked[1]]+[c for _,c in components]):
                    raise PresentationError(f'CF {CF_LABELS[slot]}の開示純額と構成項目が一致しません。')
            members=[rc for rc in members if local_name(rc[0]) not in totals|parts]+[picked]
    # Semantically normalized versions were already deduplicated. Distinct
    # components are summed in their disclosed cash-flow signs.
    if len(members)==1:
        result=deepcopy(members[0][1])
        if len(original)>1:
            result.components=deepcopy([c for _,c in original])
            result.component_keys=[r.key for r,_ in original]
            result.operation='reported_total'
            result.note+='\n開示純額・合算額を採用し、同範囲の構成項目は重ねて加算しない。'
        return result
    cells=[c for _,c in members];keys=[r.key for r,_ in members]
    return _computed(CF_LABELS[slot],cells,keys,operation='net' if slot in {43,52,56,57} else 'sum',
                     note='同じ表示区分の独立した開示構成項目を、原文の符号のまま合計。符号の反転・絶対値化は行わない。')


def template_rows(dataset: Dataset,statement: str='CF') -> list[Row]:
    """Project each original annual CF hierarchy before building the union.

    A merged row index is not source order: an old HTML view can follow all
    newer tagged rows. Per-cell source order/section and the annual authority
    determine subtotal membership; the union changes display placement only.
    """
    if statement!='CF':return list(dataset.rows.get(statement,[]))
    working_names={'DecreaseIncreaseInNotesAndAccountsReceivableTradeOpeCF','DecreaseIncreaseInInventoriesOpeCF',
                   'IncreaseDecreaseInNotesAndAccountsPayableTradeOpeCF','DecreaseIncreaseInTradeAndOtherReceivablesOpeCFIFRS',
                   'DecreaseIncreaseInInventoriesOpeCFIFRS','IncreaseDecreaseInTradeAndOtherPayablesOpeCFIFRS'}
    section_totals={'NetCashProvidedByUsedInOperatingActivities':'operating',
                    'NetCashProvidedByUsedInOperatingActivitiesIFRS':'operating',
                    'NetCashProvidedByUsedInInvestmentActivities':'investing',
                    'NetCashProvidedByUsedInInvestingActivitiesIFRS':'investing',
                    'NetCashProvidedByUsedInFinancingActivities':'financing',
                    'NetCashProvidedByUsedInFinancingActivitiesIFRS':'financing'}
    bridge_names={'CashAndCashEquivalents','CashAndCashEquivalentsIFRS',
                  'EffectOfExchangeRateChangeOnCashAndCashEquivalents',
                  'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS',
                  'NetIncreaseDecreaseInCashAndCashEquivalents','NetIncreaseDecreaseInCashAndCashEquivalentsIFRS'}
    buckets=defaultdict(lambda:defaultdict(list));unmatched={}
    for period in sorted(dataset.periods):
        annual=[]
        for ordinal,original in enumerate(dataset.rows['CF']):
            cell=original.values.get(period.key)
            if original.is_heading or cell is None:continue
            row=deepcopy(original);row.values={period.key:deepcopy(cell)}
            row.section=tuple(cell.source_section) if cell.source_section is not None else tuple(original.section)
            row.label=cell.source.original_label or original.label
            row.display_group=cell.display_group or original.display_group
            source_order=cell.source_order if cell.source_order is not None else ordinal
            annual.append((source_order,ordinal,original,row))
        annual.sort(key=lambda item:(item[0],item[1]))
        rows=[item[3] for item in annual];end=len(rows)
        working=min((i for i,row in enumerate(rows) if semantic_id(row) in working_names or _cf_plain_working(row)),default=end)
        known_subtotals=[i for i,row in enumerate(rows) if semantic_id(row) in {'SubtotalOpeCF','SubtotalOpeCFIFRS'}]
        cfo=min((i for i,row in enumerate(rows) if semantic_id(row) in {'NetCashProvidedByUsedInOperatingActivities','NetCashProvidedByUsedInOperatingActivitiesIFRS'}),default=end)
        generic={i:(22 if working<end and i<working else 33) for i,row in enumerate(rows) if _cf_generic_subtotal(row)}
        for slot in set(generic.values()):
            if sum(value==slot for value in generic.values())>1:
                raise PresentationError('営業CFの同一区間に複数の未識別「小計」があり、内訳の重複を推測で解決できません。')
            if slot==33 and known_subtotals:
                raise PresentationError('営業CFに未識別の小計と別の開示小計が併存するため、二重加算を避け原文確認が必要です。')
        subtotal=min(known_subtotals+[i for i,slot in generic.items() if slot==33],default=end)
        current_section='cash_bridge'
        for index,(_,_,original,row) in enumerate(annual):
            local=semantic_id(row);cell=row.values[period.key]
            explicit=_cf_section(row)
            recorded=cell.display_group or original.display_group
            is_html=cell.source.semantic_concept.startswith('{urn:zaimu10:html-table:')
            # A generic subtotal was not understood by the original phase
            # annotation. Rebuild that annual operating phase from its own
            # source order, not another year's subtotal or a merged index.
            if is_html or (generic and recorded.startswith('operating')):recorded=''
            section=explicit if explicit!='cash_bridge' else current_section
            if recorded:section='operating' if recorded.startswith('operating')else recorded
            if local in {'IncomeBeforeIncomeTaxes','ProfitLossBeforeTaxIFRS'}:section='operating'
            if local in section_totals:section=section_totals[local]
            if local in bridge_names:section='cash_bridge'
            slot=_cf_slot(row,index=index,first_working=working,subtotal=subtotal,cfo=cfo,
                          effective_section=section,subtotal_slot=generic.get(index))
            if slot is not None:
                buckets[slot][period.key].append((row,cell))
            else:
                group=(recorded if recorded else
                       ('operating_payments' if index>subtotal else 'operating_working' if index>=working else 'operating_adjustments')
                       if section=='operating' else section)
                signature=(original.key,group)
                if signature not in unmatched:
                    item=deepcopy(original);item.values={};item.display_group=group;item.label_period=''
                    unmatched[signature]=item
                item=unmatched[signature];item.values[period.key]=deepcopy(cell)
                if period.key>=item.label_period:
                    item.label=row.label;item.section=row.section;item.label_period=period.key
            current_section='cash_bridge' if local in section_totals else section
    output=[];slot_rows={}
    for slot,annual in sorted(buckets.items()):
        row=Row(f'template:CF:{slot}',CF_LABELS[slot],'CF',is_total=slot in {22,26,33,40,54,64,66,68})
        for period in dataset.periods:
            members=[(r,c) for r,c in annual.get(period.key,[]) if c.value is not None]
            if members:row.values[period.key]=_slot_cell(slot,members)
        if row.values or slot in {33,40,54,64,66,67,68}:output.append(row);slot_rows[slot]=row
    # The same source identity can occupy a different phase in another year's
    # actual table. Separate its display rows rather than leaking membership.
    counts=defaultdict(int)
    for key,group in unmatched:counts[key]+=1
    extras=[]
    for (key,group),row in unmatched.items():
        if counts[key]>1:row.key=key+':display_phase:'+group
        extras.append(row)
    for slot,slots,group in [(22,range(3,22),'operating_adjustments'),(26,range(23,26),None)]:
        row=slot_rows.get(slot) or Row(f'template:CF:{slot}',CF_LABELS[slot],'CF',is_total=True)
        for period in dataset.periods:
            if period.key in row.values:continue
            members=[(slot_rows[s].key,slot_rows[s].values[period.key]) for s in slots
                     if s in slot_rows and period.key in slot_rows[s].values]
            if group:
                members.extend((r.key,r.values[period.key]) for r in extras if r.display_group==group
                               and period.key in r.values and r.values[period.key].value is not None)
            if members:row.values[period.key]=_computed(CF_LABELS[slot],[c for _,c in members],[key for key,_ in members],
                    note='表示用小計。当該年度の原文区分の項目だけを原符号のまま合計。')
        if row.values and slot not in slot_rows:output.append(row);slot_rows[slot]=row
    output.sort(key=lambda r:int(r.key.rsplit(':',1)[-1]))
    return output+extras


def cf_metrics(dataset: Dataset) -> dict[str,Row]:
    return {r.key:r for r in template_rows(dataset,'CF') if r.key.startswith('template:CF:')}
