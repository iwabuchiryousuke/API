"""Read saved financial results for charts, without fetching or executing them."""
from __future__ import annotations

from dataclasses import fields
from datetime import date
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path

from .models import Cell, Dataset, Period, Row, Source, SHEETS


class AuditError(ValueError):
    pass


def _cell(raw: dict, depth: int = 0) -> Cell:
    if depth > 24 or not isinstance(raw, dict) or not isinstance(raw.get('source'), dict):
        raise AuditError('元データの内訳または出典の形式が不正です。')
    source_keys = {f.name for f in fields(Source)}
    source = Source(**{k: v for k, v in raw['source'].items() if k in source_keys})
    value = None if raw.get('value') is None else Decimal(str(raw['value']))
    if value is not None and not value.is_finite():
        raise AuditError('金額に有限値以外が含まれています。')
    attrs = {k: v for k, v in raw.items()
             if k in {f.name for f in fields(Cell)} - {'value', 'source', 'components', 'source_section'}}
    section = raw.get('source_section')
    return Cell(value, source, components=[_cell(c, depth + 1) for c in raw.get('components', [])],
                source_section=None if section is None else tuple(section), **attrs)


def load_result(path: str | Path):
    """Load the selected audit only; never evaluate its stored Excel formulas."""
    from .service import Result, validate_code
    path = Path(path).expanduser().resolve()
    try:
        if path.stat().st_size > 100 * 1024 * 1024:
            raise AuditError('監査JSONが大きすぎます（上限100MB）。')
        payload = json.loads(path.read_text(encoding='utf-8-sig'))
        if payload.get('application') != 'Zaimu10' or payload.get('format_version') != 2:
            raise AuditError('Zaimu10の形式バージョン2の監査JSONを選択してください。')
        raw = payload['dataset']
        periods = [Period(date.fromisoformat(p['start']), date.fromisoformat(p['end']))
                   for p in raw['periods']]
        if not periods or len(periods) > 10 or len(set(periods)) != len(periods):
            raise AuditError('対象会計期間が不正です。')
        if any(p.start > p.end for p in periods):
            raise AuditError('会計期間の開始日と終了日が不正です。')
        dataset = Dataset(validate_code(raw['code']), str(raw['company']), str(raw['basis']), periods)
        for f in fields(Dataset):
            if f.name not in {'code', 'company', 'basis', 'periods', 'rows'} and f.name in raw:
                setattr(dataset, f.name, raw[f.name])
        allowed = {p.key for p in periods}
        if not isinstance(raw['rows'], dict) or any(s not in raw['rows'] for s in SHEETS):
            raise AuditError('4種類の財務諸表データが必要です。')
        for statement in SHEETS:
            for record in raw['rows'][statement]:
                attrs = {k: v for k, v in record.items()
                         if k in {f.name for f in fields(Row)} - {'values', 'section'}}
                if attrs.get('statement') != statement:
                    raise AuditError('財務諸表の種類が一致しません。')
                values = record.get('values', {})
                if not set(values) <= allowed:
                    raise AuditError('対象期間外の金額が含まれています。')
                dataset.rows[statement].append(Row(section=tuple(record.get('section', [])),
                    values={key: _cell(value) for key, value in values.items()}, **attrs))
        dataset._financial_presentation_prepared = True
        name = path.name.removesuffix('.audit.json') + '.xlsx'
        return Result(dataset, path.with_name(name), path)
    except AuditError:
        raise
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, AttributeError, InvalidOperation) as exc:
        raise AuditError(f'監査JSONを読み取れません：{path.name}（{type(exc).__name__}）') from exc
