"""The optional market stage never hides a valid financial result."""
from datetime import date
from pathlib import Path

import pytest

from zaimu10.models import Dataset, Period, Filing
from zaimu10.service import Options, _prepare_capm_market


PERIOD = Period(date(2023,4,1),date(2024,3,31))


@pytest.fixture
def acquisition(monkeypatch, tmp_path):
    import zaimu10.market as market
    import zaimu10.market_cap as capital
    import zaimu10.split_basis as basis
    import zaimu10.damodaran as risk
    calls = []
    def quotes(code, **kwargs):
        calls.append(('quotes', code, kwargs))
        return {'code': code, 'benchmark': '^N225', 'stock_rows': [], 'index_rows': [], 'warnings': []}
    def prices(code, dates, **kwargs):
        calls.append(('prices', code, dates, kwargs))
        return {'prices': {'2024-03-31': {'trading_date': '2024-03-29', 'historical_close_jpy': '100'}}}
    def shares(code, periods, filings, **kwargs):
        calls.append(('shares', code, periods, kwargs))
        return {'shares': {PERIOD.key: {'value_shares': '1000', 'fiscal_end': '2024-03-31', 'doc_id': 'S100TEST'}}}
    def risk_inputs(cache_dir, **kwargs):
        calls.append(('risk', cache_dir, kwargs))
        return {'risk_free_rate': {'available': True, 'value': '0.03', 'currency': 'JPY',
                                  'semantic': 'jpy_default_free_rate'},
                'equity_risk_premium': {'available': True, 'value': '0.05', 'country': 'Japan',
                                        'semantic': 'total_equity_risk_premium'}}
    monkeypatch.setattr(market, 'load_capm_market', quotes)
    monkeypatch.setattr(market, 'load_fiscal_prices', prices)
    monkeypatch.setattr(capital, 'load_fiscal_share_counts', shares)
    monkeypatch.setattr(risk, 'load_risk_inputs', risk_inputs)
    monkeypatch.setattr('zaimu10.edinet.fetch_filing',lambda *a,**k: [])
    monkeypatch.setattr(basis,'align_fiscal_share_basis',lambda pages,filing,period,count,quote: quote)
    ds=Dataset('6947','図研','consolidated',[PERIOD])
    options=Options('6947',tmp_path,cache_dir=tmp_path/'cache',until=date(2024,11,20),offline=True)
    return ds,options,calls,market,capital


def test_market_stage_uses_dated_horizon_and_keeps_financial_rows_unchanged(acquisition):
    ds,options,calls,_,_=acquisition
    result=_prepare_capm_market(ds,[Filing('S100TEST',code='6947',end=PERIOD.end)],options,log=lambda _:None)
    assert calls[0][2]['start_month']=='2019-12'
    assert calls[0][2]['end_month']=='2024-10'
    assert all(call[-1]['offline'] for call in calls)
    assert result['market_caps'][PERIOD.key]['value_jpy']=='100000'
    assert result['risk_inputs']['risk_free_rate']['value']=='0.03'
    assert result['risk_inputs']['equity_risk_premium']['value']=='0.05'
    assert calls[-1][0]=='risk' and calls[-1][1]==options.cache_dir
    assert ds.market_data=={} and not ds.warnings


def test_failed_monthly_prices_preserve_fiscal_market_cap_and_financial_data(acquisition,monkeypatch):
    ds,options,calls,market,_=acquisition
    def failed(*a,**k):raise market.MarketDataError('公開価格を確認できません')
    monkeypatch.setattr(market,'load_capm_market',failed)
    result=_prepare_capm_market(ds,[Filing('S100TEST',code='6947',end=PERIOD.end)],options,log=lambda _:None)
    assert result['market_caps'][PERIOD.key]['value_jpy']=='100000'
    assert len(result['warnings'])==1 and not ds.warnings


def test_failed_share_source_preserves_monthly_observations(acquisition,monkeypatch):
    ds,options,calls,_,capital=acquisition
    def failed(*a,**k):raise capital.ShareCountError('株式数を確認できません')
    monkeypatch.setattr(capital,'load_fiscal_share_counts',failed)
    result=_prepare_capm_market(ds,[],options,log=lambda _:None)
    assert result['benchmark']=='^N225' and result['market_caps']=={}
    assert len(result['warnings'])==1 and not ds.warnings


def test_cancelled_market_acquisition_does_not_continue_to_share_stage(acquisition,monkeypatch):
    ds,options,calls,market,_=acquisition
    def cancelled(*a,**k):raise InterruptedError('取得を中止')
    monkeypatch.setattr(market,'load_capm_market',cancelled)
    with pytest.raises(InterruptedError):_prepare_capm_market(ds,[],options,log=lambda _:None)
    assert calls==[]


def test_risk_source_failure_keeps_verified_financial_and_market_values(acquisition,monkeypatch):
    ds,options,calls,_,_=acquisition
    def failed(*a,**k):raise ValueError('公開リスク入力を確認できません')
    monkeypatch.setattr('zaimu10.damodaran.load_risk_inputs',failed)
    result=_prepare_capm_market(ds,[Filing('S100TEST',code='6947',end=PERIOD.end)],options,log=lambda _:None)
    assert result['market_caps'][PERIOD.key]['value_jpy']=='100000'
    assert result['risk_inputs']=={} and len(result['warnings'])==1
    assert not ds.warnings and ds.market_data=={}


def test_risk_source_cancellation_propagates(acquisition,monkeypatch):
    ds,options,*_=acquisition
    def cancelled(*a,**k):raise InterruptedError('リスク入力取得を中止')
    monkeypatch.setattr('zaimu10.damodaran.load_risk_inputs',cancelled)
    with pytest.raises(InterruptedError):
        _prepare_capm_market(ds,[],options,log=lambda _:None)
