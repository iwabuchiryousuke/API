"""EDINETの原文iXBRLから詳細財務諸表を作成します。"""
__version__ = '1.0.1'
