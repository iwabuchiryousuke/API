"""Personal-use Yahoo reference data. Never convert ex-dates into paid income."""
import math,re
from datetime import date,datetime,timedelta,timezone

def number(value):
    try:v=float(value)
    except (TypeError,ValueError):return None
    return v if math.isfinite(v) and v>=0 else None

def iso(value):
    if isinstance(value,datetime):return value.date().isoformat()
    if isinstance(value,date):return value.isoformat()
    return None

def fetch(code,year,factory=None):
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}',code):raise ValueError('国内上場銘柄コードを指定してください。')
    if factory is None:
        import yfinance as yf
        factory=yf.Ticker
    ticker=factory(code+'.T')
    history=ticker.history(start=f'{year-1}-01-01',end=f'{year+1}-01-01',auto_adjust=False,actions=True,raise_errors=True,timeout=20)
    if history.empty:raise ValueError('株価・配当履歴が取得できません。既存値は維持します。')
    calendar=ticker.calendar or {}
    # Only matched historical ex-dividend entries; these are not payment dates.
    dividends=[]
    if 'Dividends' in history:
        for stamp,value in history['Dividends'].items():
            amount=number(value)
            if amount and stamp.year==year:dividends.append({'ex_date':iso(stamp),'dps':amount})
    ex=iso(calendar.get('Ex-Dividend Date'));pay=iso(calendar.get('Dividend Date'))
    return {'source':f'https://finance.yahoo.com/quote/{code}.T/ (yfinance)',
            'fetched_at':datetime.now(timezone.utc).isoformat(),
            'reference_only':True,'historical_dividends':dividends,
            'ex_date':ex,'payment_date':pay,
            'status':'参考情報。権利落ち日と入金日は別。年間DPS・年間予定の完全性・本決算日は未確認。'}

def merge_reference(existing,reference,year):
    result=dict(existing);result['yahoo_reference']=reference
    # Do not erase verified dates, annual DPS, or per-event plans with incomplete Yahoo data.
    if not result.get('payments') and reference.get('payment_date'):
        p=reference['payment_date'];ex=reference.get('ex_date')
        if p.startswith(str(year)) or (ex and ex.startswith(str(year)) and p.startswith(str(year+1))):
            result['payments']=p
    result['status']=reference['status']
    if not result.get('source'):result['source']=reference['source']
    return result

def previous_close(code,month,factory=None):
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}',code):raise ValueError('国内コードを指定してください。')
    end=date.fromisoformat(month+'-01');start=(end-timedelta(days=1)).replace(day=1)
    if end>date.today().replace(day=1):raise ValueError('将来月は取得できません。')
    if factory is None:
        import yfinance as yf
        factory=yf.Ticker
    h=factory(code+'.T').history(start=start.isoformat(),end=end.isoformat(),auto_adjust=False,actions=False,raise_errors=True,timeout=20)
    if h.empty:raise ValueError('前月の終値を確認できません。')
    series=h['Close'].dropna()
    if series.empty:raise ValueError('前月の終値が空です。')
    value=number(series.iloc[-1]);day=series.index[-1].date()
    if value is None or not start<=day<end or (end-day).days>7:raise ValueError('月末近辺の終値を確認できません。')
    return {'close':value,'close_date':day.isoformat(),'price_source':f'Yahoo Finance via yfinance / {code}.T / unadjusted close'}


def month_closes(code,month,factory=None,now=None):
    """Prior-month close, literal day one, and the verified first trading day."""
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}',str(code)):raise ValueError('国内コードを指定してください。')
    first=date.fromisoformat(month+'-01');prior=first-timedelta(days=1);start=prior.replace(day=1)
    from jpx_calendar import first_trading_day,CALENDAR_SOURCE
    opening=first_trading_day(month)
    jst=timezone(timedelta(hours=9));moment=now or datetime.now(jst)
    if moment.tzinfo is None:raise ValueError('現在時刻にタイムゾーンを指定してください。')
    moment=moment.astimezone(jst)
    if first>moment.date():raise ValueError('将来月の終値は取得できません。')
    if factory is None:
        # Japanese historical pages expose the same explicit unadjusted close
        # column used by the user. A blocked/changed page may fall back to the
        # existing public Yahoo chart client; test-injected factories stay local.
        try:
            from public_research import yahoo_japan_month_closes
            japanese=yahoo_japan_month_closes(code,month,now=moment)
            ready=opening<moment.date() or opening==moment.date() and (moment.hour,moment.minute)>=(16,0)
            if 'close' in japanese and ('month_open_close' in japanese or not ready):
                return japanese
        except Exception:
            japanese={}
        import yfinance as yf
        factory=yf.Ticker
    else:japanese={}
    try:
        data=factory(str(code)+'.T').history(start=start.isoformat(),end=(opening+timedelta(days=1)).isoformat(),
            auto_adjust=False,actions=False,raise_errors=True,timeout=15)
    except Exception:
        if japanese:return japanese
        raise
    if data.empty or 'Close' not in data:
        if japanese:return japanese
        raise ValueError('対象月の終値を確認できません。')
    by_day={}
    for stamp,value in data['Close'].dropna().items():
        # Some chart clients expose the Tokyo session's midnight as the prior
        # UTC date. Use the exchange's JST calendar date before selecting bars.
        local=stamp.astimezone(jst) if getattr(stamp,'tzinfo',None) is not None else stamp
        day=local.date();amount=number(value)
        if not isinstance(value,bool) and amount is not None and amount>0 and start<=day<=opening:
            by_day.setdefault(day,set()).add(amount)
    bars=[(day,next(iter(values))) for day,values in by_day.items() if len(values)==1]
    result=dict(japanese);source=f'Yahoo Finance via yfinance / {code}.T / unadjusted close'
    older=[(day,amount) for day,amount in bars if day<first]
    if older:
        day,amount=max(older)
        if 0<=(prior-day).days<=7 and 'close' not in result:result.update(close=amount,close_date=day.isoformat(),price_source=source)
    # Today's unfinished bar is not a closing-price observation.
    ready=first<moment.date() or (moment.hour,moment.minute)>=(16,0)
    exact=[(day,amount) for day,amount in bars if day==first]
    if ready and len(exact)==1 and 'month_start_close' not in result:
        day,amount=exact[0]
        result.update(month_start_close=amount,month_start_close_date=day.isoformat(),month_start_price_source=source)
    # The first observed bar is insufficient: its date must equal the expected
    # JPX opening date. Missing opening bars are never replaced by later bars.
    ready=opening<moment.date() or opening==moment.date() and (moment.hour,moment.minute)>=(16,0)
    exact=[(day,amount) for day,amount in bars if day==opening]
    if ready and len(exact)==1 and 'month_open_close' not in result:
        day,amount=exact[0]
        result.update(month_open_close=amount,month_open_close_date=day.isoformat(),
                      month_open_price_source=source,month_open_calendar_source=CALENDAR_SOURCE)
    return result
