"""Verified Japan CAPM inputs from Aswath Damodaran's public datasets.

Country risk premium, total equity risk premium, and a yen default-free rate
are distinct inputs. The country page never supplies the risk-free rate.
A newer author-linked country workbook supersedes the dated country HTML.
The yen risk-free estimate is the author's inflation-based currency estimate;
it is not a current Japanese government-bond yield. No spreadsheet is executed.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from io import BytesIO
import hashlib
import json
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlparse
import warnings
import zipfile

from bs4 import BeautifulSoup
import openpyxl
import requests

from . import edinet

SCHEMA = 1
COUNTRY_URL = 'https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/ctryprem.html'
DISCOVERY_URL = 'https://aswathdamodaran.blogspot.com/feeds/posts/default?alt=json&max-results=25&q=riskfree'
JST = timezone(timedelta(hours=9))
_MONTHS = {name.lower(): i for i, name in enumerate(
    ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
     'September', 'October', 'November', 'December'), 1)}
_MAX_BYTES = 4 * 1024 * 1024


class RiskInputError(RuntimeError):
    """A risk input cannot be verified; core financial exports remain usable."""


def _now():
    return datetime.now(JST).isoformat(timespec='seconds')


def _today():
    return datetime.now(JST).date()


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':')).encode('utf-8')).hexdigest()


def _atomic(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('wb', dir=path.parent, suffix='.tmp', delete=False) as f:
            temporary = Path(f.name)
            f.write(content)
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _text(value):
    return re.sub(r'\s+', ' ', str(value or '')).strip()


def _decimal(value, *, nonnegative=False):
    if value is None or isinstance(value, bool):
        raise RiskInputError('公開金利・プレミアムの数値がありません。')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise RiskInputError('公開金利・プレミアムの数値を確認できません。') from None
    if not result.is_finite() or abs(result) > 1 or (nonnegative and result < 0):
        raise RiskInputError('公開金利・プレミアムの単位・範囲を確認できません。')
    return result


def _percent(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d+(?:\.\d+)?%', value.strip()):
        raise RiskInputError('国別プレミアムの百分率表記を確認できません。')
    return _decimal(Decimal(value.strip()[:-1]) / 100, nonnegative=True)


def _official_url(url, *, workbook=False):
    p = urlparse(url)
    if p.scheme != 'https' or p.username or p.password or p.port or p.fragment:
        raise RiskInputError('データ出典が公式の公開URLではありません。')
    if p.hostname not in {'pages.stern.nyu.edu', 'www.stern.nyu.edu'} or not p.path.startswith('/~adamodar/'):
        raise RiskInputError('データ出典がDamodaran氏の公式サイトではありません。')
    if workbook and (p.query or not re.fullmatch(
            r'/~adamodar/pc/(?:datasets/ctryprem[A-Za-z]*\d*|blog/DiffInfl[A-Za-z]*\d+)\.xlsx', p.path)):
        raise RiskInputError('公開データセットのExcelリンクを確認できません。')
    return url


def parse_country_page(content):
    """Read exactly the dated country page's rating-based total ERP column."""
    soup = BeautifulSoup(content, 'html.parser')
    text = soup.get_text(' ', strip=True)
    match = re.search(r'Last\s+updated\s*:\s*([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})', text, re.I)
    try:
        as_of = date(int(match[3]), _MONTHS[match[1].lower()], int(match[2])) if match else None
    except (KeyError, ValueError):
        as_of = None
    if as_of is None or as_of > _today() or 'Country Default Spreads and Risk Premiums' not in text:
        raise RiskInputError('国別プレミアムページの表題・更新日を確認できません。')
    matches = []
    for table in soup.find_all('table'):
        rows = [[_text(c.get_text(' ', strip=True)) for c in tr.find_all(['td', 'th'], recursive=False)]
                for tr in table.find_all('tr') if tr.find_parent('table') is table]
        for i, cells in enumerate(rows):
            if not cells or cells[0] != 'Country':
                continue
            headers = cells
            required = ['Country', 'Adj. Default Spread', 'Country Risk Premium', 'Equity Risk Premium']
            if any(headers.count(h) != 1 for h in required):
                continue
            countries = [(n + i + 2, r) for n, r in enumerate(rows[i + 1:]) if r and r[0] == 'Japan']
            if len(countries) != 1:
                raise RiskInputError('国別プレミアムのJapan行が一意ではありません。')
            rowno, row = countries[0]
            if len(row) != len(headers):
                raise RiskInputError('国別プレミアム表の列数が変更されています。')
            data = {h: row[headers.index(h)] for h in required}
            erp = _percent(data['Equity Risk Premium'])
            crp = _percent(data['Country Risk Premium'])
            spread = _percent(data['Adj. Default Spread'])
            if erp < crp:
                raise RiskInputError('総株式リスクプレミアムと国別プレミアムの関係を確認できません。')
            matches.append(dict(country='Japan', as_of=as_of.isoformat(), date_precision='day',
                equity_risk_premium=str(erp), country_premium=str(crp), default_spread=str(spread),
                rating=row[headers.index("Moody's rating")] if "Moody's rating" in headers else None,
                headers=headers, raw_row=row, source_row=rowno, method='rating_based_total_equity_risk_premium',
                risk_free_rate_present=False))
    if len(matches) != 1:
        raise RiskInputError('Japanの総株式リスクプレミアムの列を一意に確認できません。')
    return matches[0]


def discover_author_workbooks(content):
    """Discover dated, explicitly labelled author links; ignore future entries."""
    try:
        body = json.loads(content) if isinstance(content, (str, bytes)) else content
        if body['feed']['title']['$t'] != 'Musings on Markets':
            raise ValueError
        entries = body['feed'].get('entry', [])
        if not isinstance(entries, list):
            raise ValueError
        found = []
        for entry in entries:
            published = datetime.fromisoformat(entry['published']['$t'])
            if published.date() > _today():
                continue
            links = [v['href'] for v in entry.get('link', []) if v.get('rel') == 'alternate']
            if len(links) != 1 or not links[0].startswith('https://aswathdamodaran.blogspot.com/'):
                continue
            soup = BeautifulSoup(entry['content']['$t'], 'html.parser')
            for a in soup.find_all('a', href=True):
                label = _text(a.get_text(' ', strip=True))
                lower = label.lower()
                kind = ('risk_free_rate' if 'riskfree rates' in lower and 'inflation' in lower
                        else 'equity_risk_premium' if 'equity risk premiums' in lower and 'country' in lower else None)
                if kind is None:
                    continue
                period = re.search(r'\b(' + '|'.join(_MONTHS) + r')\s+(20\d{2})\b', lower)
                if not period:
                    continue
                month = f'{int(period[2]):04d}-{_MONTHS[period[1]]:02d}'
                if month > _today().strftime('%Y-%m'):
                    continue
                try:
                    url = _official_url(a['href'], workbook=True)
                except RiskInputError:
                    continue  # Old .xls and external links cannot become selected data.
                found.append(dict(kind=kind, url=url, title=label, as_of=month,
                    date_precision='month', publication_date=published.date().isoformat(),
                    publication_timestamp=published.isoformat(), article_url=links[0],
                    article_title=entry['title']['$t']))
        unique = {(r['kind'], r['url'], r['as_of']): r for r in found}
        return sorted(unique.values(), key=lambda r: (r['as_of'], r['publication_date']), reverse=True)
    except (KeyError, TypeError, ValueError, OverflowError):
        raise RiskInputError('著者公式ブログのデータセット一覧を確認できません。') from None


def _books(content):
    try:
        with zipfile.ZipFile(BytesIO(content)) as archive:
            if len(archive.infolist()) > 500 or sum(i.file_size for i in archive.infolist()) > 30 * 1024 * 1024:
                raise ValueError
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            values = openpyxl.load_workbook(BytesIO(content), data_only=True, read_only=True)
            formulas = openpyxl.load_workbook(BytesIO(content), data_only=False, read_only=True)
        return values, formulas
    except Exception as exc:
        raise RiskInputError('著者公開Excelの構造を確認できません。') from exc


def _cell_rate(cell, *, nonnegative=False):
    if '%' not in cell.number_format:
        raise RiskInputError('公開Excelの率の単位を確認できません。')
    return _decimal(cell.value, nonnegative=nonnegative)


def parse_country_workbook(content):
    values, formulas = _books(content)
    try:
        if 'ERPs by country' not in values.sheetnames:
            raise RiskInputError('公開Excelに国別ERPシートがありません。')
        s = values['ERPs by country']
        if s['A1'].value != 'Country and Equity Risk Premiums' or s['A2'].value != 'Date of update:':
            raise RiskInputError('国別ERP Excelの表題・更新日を確認できません。')
        as_of = s['B2'].value
        if not isinstance(as_of, (datetime, date)):
            raise RiskInputError('国別ERP Excelの更新日がありません。')
        as_of = as_of.date() if isinstance(as_of, datetime) else as_of
        if as_of > _today():
            raise RiskInputError('将来日付の国別ERPデータは使用しません。')
        header = next((row for row in s.iter_rows(min_row=3, max_row=20)
                       if row[0].value == 'Country' and any(c.value == 'Total Equity Risk Premium' for c in row)), None)
        if header is None:
            raise RiskInputError('総株式リスクプレミアムの見出しを確認できません。')
        names = [c.value for c in header]
        required = ['Country', 'Total Equity Risk Premium', 'Country Risk Premium', 'Rating-based Default Spread']
        if any(names.count(h) != 1 for h in required):
            raise RiskInputError('国別ERP Excelの列が一意ではありません。')
        rows = [row for row in s.iter_rows(min_row=header[0].row + 1) if row[0].value == 'Japan']
        if len(rows) != 1:
            raise RiskInputError('国別ERP ExcelのJapan行が一意ではありません。')
        row = rows[0]
        cell = lambda name: row[names.index(name)]
        erp = _cell_rate(cell('Total Equity Risk Premium'), nonnegative=True)
        crp = _cell_rate(cell('Country Risk Premium'), nonnegative=True)
        spread = _cell_rate(cell('Rating-based Default Spread'), nonnegative=True)
        mature = _cell_rate(s['E3'], nonnegative=True)
        if abs(erp - crp - mature) > Decimal('0.000000000001'):
            raise RiskInputError('Japan総ERP＝成熟市場ERP＋国別プレミアムを検証できません。')
        return dict(country='Japan', as_of=as_of.isoformat(), date_precision='day',
            sheet=s.title, row=row[0].row, equity_risk_premium=str(erp), country_premium=str(crp),
            default_spread=str(spread), mature_market_erp=str(mature),
            cells={name: cell(name).coordinate for name in required},
            raw_cells={c.coordinate: c.value for c in row[:9]},
            update_notes=_text(s['C2'].value), method='rating_based_total_equity_risk_premium',
            verification='total_erp_equals_mature_erp_plus_country_premium')
    except RiskInputError:
        raise
    except Exception as exc:
        raise RiskInputError('国別ERP Excelの内容を検証できません。') from exc
    finally:
        values.close(); formulas.close()


def parse_currency_riskfree_workbook(content):
    """Verify cached Japan rate against the author's explicit inflation formula."""
    values, formulas = _books(content)
    try:
        matches = []
        for s in values:
            if (s['A1'].value != 'Expected Inflation in US $'
                    or s['A2'].value != 'Riskfree Rate in US$'):
                continue
            header = next((row for row in s.iter_rows(min_row=3, max_row=15)
                           if row[0].value == 'Country' and len(row) >= 4
                           and row[3].value == 'Riskfree Rate'), None)
            if header is None or not re.fullmatch(r'Expected inflation \(20\d{2}-20\d{2}\)', _text(header[2].value)):
                continue
            rows = [row for row in s.iter_rows(min_row=header[0].row + 1) if row[0].value == 'Japan']
            if len(rows) != 1:
                raise RiskInputError('通貨別リスクフリーレートのJapan行が一意ではありません。')
            row = rows[0]; n = row[0].row
            japan_inflation = _cell_rate(row[2])
            usd_inflation = _cell_rate(s['B1'])
            usd_rf = _cell_rate(s['B2'])
            rate = _cell_rate(row[3])
            formula = formulas[s.title].cell(n, 4).value
            expected = f'=IF(C{n}="NA","NA",((1+$B$2)*(1+C{n})/(1+$B$1))-1)'
            if not isinstance(formula, str) or re.sub(r'\s+', '', formula).upper() != expected.upper():
                raise RiskInputError('円リスクフリーレートの公開計算式が変更されています。')
            if min(usd_rf, japan_inflation, usd_inflation) <= -1:
                raise RiskInputError('通貨別推計のインフレ率・基準金利の範囲を確認できません。')
            calculated = (1 + usd_rf) * (1 + japan_inflation) / (1 + usd_inflation) - 1
            if abs(calculated - rate) > Decimal('0.000000000001'):
                raise RiskInputError('円リスクフリーレートの保存値と原式の算術結果が一致しません。')
            matches.append(dict(country='Japan', currency='JPY', value=str(rate), sheet=s.title,
                cell=row[3].coordinate, country_cell=row[0].coordinate, country_label='Japan',
                currency_basis='Author labels this dataset as riskfree rates by currency; Japan maps to Japanese yen (JPY)',
                method='inflation_based_currency_default_free_rate',
                formula=formula, verified_formula='(1+USD riskfree)*(1+Japan expected inflation)/(1+USD expected inflation)-1',
                verification='cached_value_matches_explicit_formula_without_executing_workbook',
                formula_inputs=dict(usd_risk_free_rate=str(usd_rf), usd_expected_inflation=str(usd_inflation),
                    japan_expected_inflation=str(japan_inflation), inflation_horizon=header[2].value),
                calculated_value=str(calculated)))
        if len(matches) != 1:
            raise RiskInputError('著者の円建て通貨リスクフリーレートを一意に確認できません。')
        return matches[0]
    except RiskInputError:
        raise
    except Exception as exc:
        raise RiskInputError('通貨別リスクフリーレートExcelの内容を検証できません。') from exc
    finally:
        values.close(); formulas.close()


def _request(session, url, *, cancel=None):
    for attempt in range(2):
        edinet._check_cancel(cancel)
        with edinet._request_lock:
            edinet._pause(max(0, edinet._MIN_INTERVAL - (time.monotonic() - edinet._last_request)), cancel)
            edinet._last_request = time.monotonic()
        try:
            response = session.get(url, timeout=(5, 15), allow_redirects=False)
        except requests.RequestException:
            if attempt:
                raise RiskInputError('Damodaran氏の公開データに接続できません。') from None
            edinet._pause(2, cancel)
            continue
        if response.status_code in (edinet._RETRY_STATUSES | {500}) and not attempt:
            delay = edinet._retry_after(response.headers.get('Retry-After'))
            if delay is not None and delay > 30:
                raise RiskInputError('公開元から長時間の待機指定がありました。後で再取得してください。')
            edinet._pause(max(delay or 0, 2), cancel)
            continue
        if response.status_code != 200:
            raise RiskInputError(f'公開リスク入力を取得できません（HTTP {response.status_code}）。')
        if len(response.content) > _MAX_BYTES:
            raise RiskInputError('公開リスク入力の応答サイズが想定範囲を超えました。')
        edinet._check_cancel(cancel)
        return response.content
    raise RiskInputError('公開リスク入力を取得できません。')


def _read(path, url, parser):
    if not path.exists():
        return None
    try:
        body = json.loads(path.read_text(encoding='utf-8'))
        checksum = body.pop('payload_sha256')
        if body.get('schema') != SCHEMA or body.get('url') != url or checksum != _hash(body):
            raise ValueError
        source = body['source']; rel = source['raw_path']
        if source['source_url'] != url:
            raise ValueError
        if not re.fullmatch(r'raw/[a-z0-9_]+-[a-f0-9]{64}\.(?:html|json|xlsx)', rel):
            raise ValueError
        raw = (path.parent / rel).read_bytes()
        if hashlib.sha256(raw).hexdigest() != source['sha256'] or parser(raw) != body['data']:
            raise ValueError
        return body
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, RiskInputError):
        raise RiskInputError(f'リスク入力の保存データを検証できません。元ファイルを保持しました：{path.name}') from None


def _load_document(base, key, url, parser, *, offline, refresh, cancel, log):
    edinet._check_cancel(cancel)
    path = base / f'{key}.json'
    saved = _read(path, url, parser)
    if offline:
        if saved is None:
            raise RiskInputError(f'保存済みリスク入力がありません：{key}')
        result = deepcopy(saved); result['offline'] = True
        return result
    if saved and not refresh:
        try:
            if datetime.now(timezone.utc) - datetime.fromisoformat(saved['checked_at']) < timedelta(hours=24):
                return deepcopy(saved)
        except ValueError:
            pass
    try:
        log('Damodaran氏の公開リスク入力を確認しています：' + key)
        with requests.Session() as session:
            session.headers.update({'User-Agent': 'Mozilla/5.0 (Zaimu10 public data; source attribution retained)'})
            content = _request(session, url, cancel=cancel)
        data = parser(content)
        sha = hashlib.sha256(content).hexdigest()
        suffix = 'json' if key == 'author_discovery' else 'xlsx' if url.endswith('.xlsx') else 'html'
        relative = f'raw/{key}-{sha}.{suffix}'
        if not (base / relative).exists():
            _atomic(base / relative, content)
        source = dict(provider='Aswath Damodaran, NYU Stern', source_url=url, sha256=sha,
            raw_path=relative, retrieved_at=_now(), format=suffix)
        body = dict(schema=SCHEMA, url=url, source=source, checked_at=_now(), stale=False, warnings=[], data=data)
        record = deepcopy(body); record['payload_sha256'] = _hash(record)
        _atomic(path, json.dumps(record, ensure_ascii=False, indent=2).encode('utf-8'))
        return body
    except InterruptedError:
        raise
    except (RiskInputError, OSError, ValueError) as exc:
        if saved is None:
            raise RiskInputError(str(exc)) from None
        result = deepcopy(saved); result['stale'] = True
        result['warnings'] = [f'更新に失敗したため{saved["checked_at"]}の検証済み保存データを使用します。{exc}']
        return result


def _unavailable(semantic, reason, **extra):
    return dict(value=None, available=False, semantic=semantic, reason=reason, **extra)


def load_risk_inputs(cache_dir, *, offline=False, refresh=False, cancel=None, log=print):
    """Return Japan total ERP and JPY risk-free rate as decimal-fraction strings.

    Inputs carry independent publication/as-of dates and provenance. A failure
    yields explicit unavailable fields, or stale verified cache; it never uses
    old template constants. Cancellation raises InterruptedError. All original
    documents and selected values are retained beneath market/risk_inputs.
    """
    base = Path(cache_dir) / 'market' / 'risk_inputs'
    args = dict(offline=offline, refresh=refresh, cancel=cancel, log=log)
    result = dict(schema=SCHEMA, country='Japan', currency='JPY', checked_at=_now(), stale=False,
        warnings=[], sources=[], source_errors=[],
        risk_free_rate=_unavailable('jpy_default_free_rate', '円建てリスクフリーレート未取得', currency='JPY', country='Japan'),
        equity_risk_premium=_unavailable('total_equity_risk_premium', '日本の総株式リスクプレミアム未取得', country='Japan'),
        country_premium=_unavailable('country_risk_premium', '日本の国別リスクプレミアム未取得', country='Japan'),
        selection_policy='Latest verified author-published dataset date; total ERP is distinct from CRP and rating default spread',
        errors=[])
    page = None; discovery = None
    for key, url, parser in [('country_page', COUNTRY_URL, parse_country_page),
                              ('author_discovery', DISCOVERY_URL, discover_author_workbooks)]:
        try:
            item = _load_document(base, key, url, parser, **args)
            result['sources'].append(dict(item['source'], dataset=key, stale=item['stale']))
            result['warnings'].extend(item.get('warnings', []))
            result['stale'] |= item['stale']
            if key == 'country_page': page = item
            else: discovery = item
        except InterruptedError:
            raise
        except RiskInputError as exc:
            result['source_errors'].append(dict(dataset=key, url=url, reason=str(exc)))
    candidates = []
    if page:
        candidates.append((page, dict(as_of=page['data']['as_of'], date_precision='day',
            publication_date=page['data']['as_of'], title='Country Default Spreads and Risk Premiums',
            url=COUNTRY_URL, selection_reason='Requested country page; rating-based total ERP, not CDS alternative')))
    discovered = discovery['data'] if discovery else []
    failed_newer = set()
    for kind in ['equity_risk_premium', 'risk_free_rate']:
        choices = [r for r in discovered if r['kind'] == kind]
        if not choices:
            if kind == 'risk_free_rate':
                result['risk_free_rate']['reason'] = '著者の通貨別リスクフリーレート公開Excelを確認できません。国別プレミアムをRfに転用しません。'
            continue
        # A changed or unavailable newest URL must not erase an older verified
        # snapshot. Try at most three dated author links, marking fallback stale.
        for candidate in choices[:3]:
            if (kind == 'equity_risk_premium' and page
                    and candidate['as_of'] < page['data']['as_of'][:7]):
                continue
            key = ('country_workbook_' if kind == 'equity_risk_premium' else 'currency_riskfree_') + re.sub(r'[^a-z0-9]', '_', candidate['url'].rsplit('/', 1)[-1].lower())
            parser = parse_country_workbook if kind == 'equity_risk_premium' else parse_currency_riskfree_workbook
            try:
                item = _load_document(base, key, candidate['url'], parser, **args)
                data = item['data']
                if kind == 'equity_risk_premium' and (data['as_of'][:7] != candidate['as_of']
                        or data['as_of'] > candidate['publication_date']):
                    raise RiskInputError('国別ERP Excelの基準日と著者の公開リンクの年月・公開日が一致しません。')
                if kind in failed_newer:
                    item = deepcopy(item)
                    item['stale'] = True
                    item['warnings'].append('新しい著者公開データを確認できないため、基準日を明示した以前の検証済みデータを使用します。')
                result['sources'].append(dict(item['source'], dataset=kind, stale=item['stale'],
                    publication_date=candidate['publication_date'], dataset_as_of=data.get('as_of', candidate['as_of']),
                    article_url=candidate['article_url'], link_title=candidate['title']))
                result['warnings'].extend(item.get('warnings', [])); result['stale'] |= item['stale']
                if kind == 'equity_risk_premium':
                    candidates.append((item, dict(candidate, as_of=data['as_of'], date_precision='day',
                        selection_reason='Newer dated country workbook explicitly linked by the author supersedes the older requested HTML')))
                else:
                    result['risk_free_rate'] = dict(data, value=data['value'], available=True,
                        semantic='jpy_default_free_rate', as_of=candidate['as_of'], date_precision='month',
                        publication_date=candidate['publication_date'], source_url=candidate['url'],
                        source=item['source'], article_url=candidate['article_url'], source_title=candidate['title'],
                        stale=item['stale'], reason='', confidence='verified_author_currency_estimate',
                        limitation='著者のインフレ差に基づく円建て推計。現在の日本国債市場利回りではありません。')
                break
            except InterruptedError:
                raise
            except RiskInputError as exc:
                failed_newer.add(kind)
                result['source_errors'].append(dict(dataset=kind, url=candidate['url'], reason=str(exc)))
                if kind == 'risk_free_rate': result['risk_free_rate']['reason'] = str(exc)
    if candidates:
        chosen, info = max(candidates, key=lambda pair: pair[1]['as_of'])
        data = chosen['data']
        for field, semantic in [('equity_risk_premium', 'total_equity_risk_premium'), ('country_premium', 'country_risk_premium')]:
            result[field] = dict(value=data[field], available=True, semantic=semantic, country='Japan',
                as_of=info['as_of'], date_precision=info['date_precision'], publication_date=info['publication_date'],
                source_url=info['url'], source=chosen['source'], source_title=info['title'],
                selection_reason=info['selection_reason'], method=data['method'], stale=chosen['stale'], reason='',
                confidence='verified_author_japan_rating_based_dataset',
                evidence={k: data[k] for k in ('sheet', 'row', 'cells', 'raw_cells', 'headers', 'raw_row', 'source_row',
                    'mature_market_erp', 'default_spread', 'update_notes', 'verification') if k in data})
        result['comparison_sources'] = [dict(source_url=i['url'], as_of=i['as_of'],
            equity_risk_premium=d['data']['equity_risk_premium'], country_premium=d['data']['country_premium'],
            selected=d is chosen) for d, i in candidates]
    else:
        result['equity_risk_premium']['reason'] = 'Japanの総株式リスクプレミアムを公開原本から確認できません。'
    result['latest_publication_check_complete'] = bool(discovery) and not discovery['stale'] and not failed_newer
    if result['source_errors']:
        result['stale'] = True
        result['warnings'].extend('リスク入力の取得先確認に失敗：' + e['reason'] for e in result['source_errors'])
    for key in ['risk_free_rate', 'equity_risk_premium']:
        if not result[key]['available']:
            result['errors'].append(result[key]['reason'])
    if result['risk_free_rate']['available'] or result['equity_risk_premium']['available']:
        # Audit snapshot only; every subsequent read re-verifies raw documents.
        record = deepcopy(result); record['payload_sha256'] = _hash(record)
        _atomic(base / 'risk_inputs.json', json.dumps(record, ensure_ascii=False, indent=2).encode('utf-8'))
    return result
