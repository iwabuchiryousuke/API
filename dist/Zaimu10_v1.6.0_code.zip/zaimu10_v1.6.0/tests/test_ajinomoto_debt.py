"""Actual IFRS financing balances; cash payments never become carrying debt."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import gzip
from hashlib import sha256
import json
from pathlib import Path

from bs4 import BeautifulSoup
import pytest

from zaimu10.analysis import analyze_dataset
from zaimu10.debt_notes import extract_debt_notes,DebtNoteError
from zaimu10.models import Filing
from zaimu10.parser import parse_filing

F=Path(__file__).parent/'fixtures'/'ajinomoto_debt'
LEASE='NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock'
COMBINED='NotesBondsAndBorrowingsConsolidatedFinancialStatementsIFRSTextBlock'
FINANCING='NotesCashFlowInformationConsolidatedFinancialStatementsIFRSTextBlock'
PLAIN='NotesToConsolidatedFinancialStatementsIFRSTextBlock'


def pages(doc='S100Y992'):return json.loads(gzip.decompress((F/f'{doc}.json.gz').read_bytes()))

def parse(content,doc='S100Y992'):
    return parse_filing(Filing(doc,code='2802',edinet_code='E00436'),content)


def extract(content=None,doc='S100Y992'):
    content=pages(doc)if content is None else content
    ds=parse(content,doc);ds.analysis_inputs=extract_debt_notes(content,ds)
    return ds


def row(ds,category):return next(r for r in ds.analysis_inputs if r.key.split(':')[2]==category)
def proof(cell):return json.loads(cell.note.split('debt_note_evidence:',1)[1])


def edit_note(local,operation,doc='S100Y992'):
    content=pages(doc);changed=False
    for i,(name,markup)in enumerate(content):
        soup=BeautifulSoup(markup,'html.parser')
        blocks=[n for n in soup.find_all(attrs={'name':True})if n['name'].rsplit(':',1)[-1]==local]
        if not blocks:continue
        assert len(blocks)==1;operation(blocks[0]);content[i]=name,str(soup);changed=True
    assert changed
    return content


def change_text(block,before,after):
    candidates=[n for n in block.find_all(string=True)if before in n]
    assert candidates,before
    for n in candidates:n.replace_with(str(n).replace(before,after))


def set_cell(block,before,after,*,last=True):
    cells=[c for c in block.find_all(['td','th'])if c.get_text(' ',strip=True)==before]
    assert cells,before
    c=cells[-1]if last else cells[0];c.clear();c.append(after)


@pytest.mark.parametrize('doc,expected',[
    ('S100Y992',[496059,482670]),('S100G6V9',[344204,337020]),
    ('S100IY1B',[337020,413729]),('S100DDYF',[335981,344204]),
])
def test_actual_independent_notes_and_financing_scope_close_both_years(doc,expected):
    ds=extract(doc=doc);a=analyze_dataset(ds)
    assert [a.metrics['interest_bearing_debt'].values[p.key].value for p in ds.periods]==[Decimal(v)*1000000 for v in expected]
    assert all(a.metadata['interest_bearing_debt'][p.key]['complete']for p in ds.periods)
    coverage=row(ds,'ifrs_reference_debt_coverage')
    assert set(coverage.values)=={p.key for p in ds.periods}
    for period in ds.periods:
        e=proof(coverage.values[period.key])
        assert e['scope']=='all_reference_debt_categories'
        assert len(e['excluded_derivatives'])==1
        assert e['reconciliation']and e['main_reconciliation']
        assert Decimal(e['reported_funding_liabilities_jpy'])==sum(Decimal(r['value_jpy'])for r in e['rows'])or abs(Decimal(e['reported_funding_liabilities_jpy'])-sum(Decimal(r['value_jpy'])for r in e['rows']if r['category']or'デリバティブ'in r['label']))<=Decimal(e['rounding_tolerance_jpy'])
        assert coverage.values[period.key].value is None


def test_latest_lease_balances_are_book_values_not_interest_inclusive_maturity_flows():
    ds=extract();p=ds.periods[-1]
    assert row(ds,'current_lease').values[p.key].value==8817000000
    assert row(ds,'noncurrent_lease').values[p.key].value==52498000000
    assert sum(row(ds,c).values[p.key].value for c in ['current_lease','noncurrent_lease'])==61315000000
    assert sum(row(ds,c).values[p.key].value for c in ['current_lease','noncurrent_lease'])!=71736000000
    e=proof(row(ds,'current_lease').values[p.key])
    assert e['measurement']=='carrying_amount'and e['page_table_index']>0
    assert e['physical_row']>0 and e['physical_column']>0


def test_current_short_loan_is_narrow_component_and_cp_is_explicit_funding_zero():
    ds=extract();prior,current=ds.periods
    assert row(ds,'short_term_borrowings').values[current.key].value==6350000000
    assert row(ds,'current_long_term_borrowings').values[current.key].value==4095000000
    assert row(ds,'long_term_borrowings').values[current.key].value==206410000000
    cp=row(ds,'commercial_paper').values[prior.key]
    assert cp.value==0 and cp.operation=='explicit_no_balance'
    assert cp.source.concept.endswith('}'+FINANCING)
    assert proof(cp)['kind']=='ifrs_financing_explicit_zero'
    assert current.key not in row(ds,'commercial_paper').values  # absent is not a fabricated zero


def test_ias17_noncurrent_is_reported_pv_total_minus_current_with_true_components():
    ds=extract(doc='S100G6V9')
    for period,current,total,noncurrent in [(ds.periods[0],591,7928,7337),(ds.periods[1],114,6306,6192)]:
        c=row(ds,'noncurrent_lease').values[period.key]
        assert c.value==Decimal(noncurrent)*1000000
        assert c.operation=='difference'and c.source.raw_value==''
        assert len(c.components)==2
        assert [x.value for x in c.components]==[Decimal(total)*1000000,Decimal(current)*1000000]
        assert c.components[0].source.raw_value==f'{total:,}'
        assert c.components[0].source.original_label=='合計'
        assert proof(c.components[0])['physical_row']!=proof(c.components[1])['physical_row']
        e=proof(c);assert e['measurement']=='discounted_present_value'
        assert e['calculation']=='reported_present_value_total - current_present_value'
        assert abs(Decimal(e['reported_total_jpy'])-Decimal(e['component_sum_jpy']))<=Decimal(e['rounding_tolerance_jpy'])
        assert c.source.concept.endswith('}'+LEASE)


def test_transition_uses_prior_ias17_pv_and_current_ifrs16_without_reading_gross_flows():
    ds=extract(doc='S100IY1B');prior,current=ds.periods
    assert row(ds,'current_lease').values[prior.key].value==114000000
    assert row(ds,'noncurrent_lease').values[prior.key].value==6192000000
    assert row(ds,'current_lease').values[current.key].value==6219000000
    assert row(ds,'noncurrent_lease').values[current.key].value==50596000000
    assert all(proof(c)['balance_column']=='closing'for c in row(ds,'ifrs_reference_debt_coverage').values.values())


def test_plain_whole_note_scope_keeps_true_qname_and_exact_section_boundaries():
    ds=extract(doc='S100DDYF');prior,current=ds.periods
    c=row(ds,'noncurrent_lease').values[prior.key]
    assert c.value==1377000000 and c.operation=='difference'
    assert c.source.concept.endswith('}'+PLAIN)
    section=proof(c)['source_section']
    assert section['start_heading']=='15．リース'and section['end_heading']=='16．子会社'
    e=proof(row(ds,'ifrs_reference_debt_coverage').values[prior.key])
    assert e['balance_column']=='opening_annual_prior_close'
    assert e['source_table_period_start']=='2017-04-01'and e['target_period_end']=='2017-03-31'
    assert e['no_policy_or_transition_adjustment']is True
    assert e['physical_balance_column']==2
    assert all('Synthetic'not in r.values[prior.key].source.concept for r in ds.analysis_inputs if prior.key in r.values)


@pytest.mark.parametrize('old,new',[
    ('連結財政状態計算書上','契約上の将来キャッシュ・フロー'),
    ('8,817','108,817'),('2026年3月31日','2026年3月30日'),('百万円','米ドル'),
])
def test_missing_book_basis_bad_amount_period_or_currency_rejects_lease(old,new):
    content=edit_note(LEASE,lambda b:change_text(b,old,new))
    with pytest.raises(DebtNoteError):extract(content)


def test_discounted_pv_header_cannot_be_replaced_with_future_gross_payment_header():
    def mutate(b):
        t=b.find_all('table')[1]
        change_text(t,'将来の最低リース料総額の現在価値','将来の最低リース料総額')
    ds=extract(edit_note(LEASE,mutate,'S100G6V9'),doc='S100G6V9')
    assert not any(':current_lease:'in r.key or ':ifrs_reference_debt_coverage:'in r.key for r in ds.analysis_inputs)
    assert all(not v['complete']for v in analyze_dataset(ds).metadata['interest_bearing_debt'].values())


def test_lender_lease_cannot_be_used_as_borrower_debt():
    content=edit_note(LEASE,lambda b:change_text(b,'借手側','貸手側'),'S100G6V9')
    with pytest.raises(DebtNoteError):extract(content,doc='S100G6V9')


@pytest.mark.parametrize('local,old,new',[
    (COMBINED,'短期借入金','謎の金融負債'),(COMBINED,'6,350','106,350'),
    (COMBINED,'1年内償還予定の金額','社債額に含まない追加金額'),
    (FINANCING,'デリバティブ負債又は資産','未分類の金融負債'),
    (FINANCING,'6,350','106,350'),
])
def test_unknown_funding_rows_changed_components_or_outset_bonds_never_close_scope(local,old,new):
    content=edit_note(local,lambda b:change_text(b,old,new))
    with pytest.raises(DebtNoteError):extract(content)


def test_changed_primary_and_independent_notes_prevent_coverage_even_if_notes_agree():
    content=pages();ds=parse(content);p=ds.periods[-1]
    c=next(c for r in ds.rows['BS_LE']for k,c in r.values.items()if k==p.key and c.source.account_concept.endswith('}BorrowingsCLIFRS'))
    c.value+=Decimal(100000000)
    with pytest.raises(DebtNoteError,match='本表'):
        extract_debt_notes(content,ds)


@pytest.mark.parametrize('change',['wrong_start','adjustment','wrong_opening'])
def test_simple_annual_opening_cannot_map_to_prior_if_date_adjustment_or_amount_is_wrong(change):
    def mutate(b):
        section=False
        if change=='wrong_start':change_text(b,'2017年４月１日','2017年４月２日')
        elif change=='adjustment':
            t=next(t for t in b.find_all('table')if '期首残高'in t.get_text()and '短期借入金'in t.get_text())
            t.append(BeautifulSoup('<tr><td>会計方針変更の累積影響額</td><td>0</td></tr>','html.parser'))
        else:
            for t in b.find_all('table'):
                if '期首残高'in t.get_text()and '短期借入金'in t.get_text():
                    set_cell(t,'1,935','101,935',last=False);break
    content=edit_note(PLAIN,mutate,'S100DDYF')
    try:ds=extract(content,doc='S100DDYF')
    except DebtNoteError:return
    prior=ds.periods[0]
    assert all(prior.key not in r.values for r in ds.analysis_inputs if ':ifrs_reference_debt_coverage:'in r.key)


def test_transition_current_table_alone_does_not_authorize_a_prior_opening_mapping():
    def mutate(b):
        tables=b.find_all('table');assert len(tables)==2;tables[0].decompose()
    ds=extract(edit_note(FINANCING,mutate,'S100IY1B'),doc='S100IY1B')
    prior,current=ds.periods
    coverage=row(ds,'ifrs_reference_debt_coverage')
    assert set(coverage.values)=={current.key}
    assert proof(coverage.values[current.key])['balance_column']=='closing'


def test_public_fixture_raw_hashes_are_retained():
    for record in json.loads((F/'sources.json').read_text()):
        data=(F/record['path']).read_bytes();assert sha256(data).hexdigest()==record['sha256']
        assert [dict(filename=n,sha256=sha256(t.encode()).hexdigest())for n,t in json.loads(gzip.decompress(data))]==record['files']
