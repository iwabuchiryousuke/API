"""Independent checks of cached iXBRL facts and explicitly located HTML cells.

This module deliberately does not import the application's parser, debt-note
reader, presentation layer, or data models. Audit JSON is treated as a claim;
the cached, SHA-256 checked filing is the evidence.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal
import hashlib
import html as html_std
import json
from pathlib import Path
import re
import unicodedata

from lxml import html


DASHES = {'-', '−', '－', '―', '—', '–', 'ー', '─'}
NOTE_MARKER = 'debt_note_evidence:'
INTEREST_DEPOSIT_CAPTIONS = {'その他有利子負債預り金', 'その他の有利子負債預り金'}


def local(node):
    return node.tag.rsplit('}', 1)[-1].rsplit(':', 1)[-1].lower() if isinstance(node.tag, str) else ''


def plain(node):
    return re.sub(r'\s+', ' ', ''.join(node.itertext()).replace('\xa0', ' ')).strip()


def compact(text):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text or ''))


def visible(node):
    return not any(a.get('hidden') is not None or 'display:none' in compact(a.get('style', '')).lower()
                   or 'visibility:hidden' in compact(a.get('style', '')).lower()
                   for a in (node, *node.iterancestors()))


def own_rows(table):
    """Rows owned by this table, excluding rows of nested tables."""
    return [row for row in table.iter() if local(row) == 'tr'
            and next((a for a in row.iterancestors() if local(a) == 'table'), None) is table]


def direct_cells(row):
    return [cell for cell in row if local(cell) in {'td', 'th'}]


def table_grid(table):
    """Return expanded logical cells plus original physical coordinates."""
    rows = own_rows(table)
    grid = []
    starts = []
    coordinates = {}
    pending = {}
    for ri, row in enumerate(rows):
        current = {column: cell for column, (cell, _) in pending.items()}
        following = {column: (cell, left - 1) for column, (cell, left) in pending.items() if left > 1}
        beginning = {}
        column = 0
        for ci, cell in enumerate(direct_cells(row)):
            while column in current:
                column += 1
            width, height = int(cell.get('colspan', '1')), int(cell.get('rowspan', '1'))
            assert 1 <= width <= 1000 and 1 <= height <= 1000, 'Invalid table span'
            coordinates[cell] = (ri, ci, column)
            beginning[column] = cell
            for covered in range(column, column + width):
                assert covered not in current, 'Overlapping table cells'
                current[covered] = cell
                if height > 1:
                    following[covered] = (cell, height - 1)
            column += width
        grid.append(current)
        starts.append(beginning)
        pending = following
    assert not pending, 'Table rowspan extends beyond table'
    return rows, grid, starts, coordinates


def dates(text):
    text = compact(text)
    result = []
    for y, m, d in re.findall(r'(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})日?', text):
        result.append(date(int(y), int(m), int(d)))
    for era, y, m, d in re.findall(r'(令和|平成|昭和)(元|\d+)年(\d{1,2})月(\d{1,2})日', text):
        result.append(date({'令和': 2018, '平成': 1988, '昭和': 1925}[era] + (1 if y == '元' else int(y)), int(m), int(d)))
    return result


def printed_number(raw, *, dash_zero=False):
    text = compact(raw)
    if text in DASHES:
        return Decimal(0) if dash_zero else None
    if not text:
        return None
    assert re.fullmatch(r'[△▲−+\-(]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\)?', text), ('Unsupported printed number', raw)
    negative = text.startswith(('△', '▲', '−', '-', '('))
    value = Decimal(text.lstrip('△▲−+-(').rstrip(')').replace(',', ''))
    return -value if negative else value


def debt_category(label):
    """Only explicit borrowing/lease wording establishes a note category."""
    text = re.sub(r'\(注\d*\)$', '', compact(label))
    if text in {'短期借入金', '短期借入れ', '短期借入'}:
        return 'short_term_borrowings'
    within_year = re.search(r'1年(?:以)?内(?:に)?(?:返済|償還)予定', text)
    if '長期借入金' in text:
        if within_year and '除く' not in text:
            return 'current_long_term_borrowings'
        if text.startswith('長期借入金') and (text == '長期借入金' or '除く' in text):
            return 'long_term_borrowings'
    if 'リース債務' in text or 'リース負債' in text:
        if (within_year and '除く' not in text) or re.search(r'\(流動(?:負債)?\)', text):
            return 'current_lease'
        if '除く' in text or re.search(r'\((?:非流動|固定)(?:負債)?\)', text):
            return 'noncurrent_lease'
    if text in INTEREST_DEPOSIT_CAPTIONS:
        return 'other_interest_bearing_debt'
    return {'コマーシャル・ペーパー': 'commercial_paper', 'コマーシャルペーパー': 'commercial_paper',
            'CP': 'commercial_paper', 'その他の有利子負債': 'other_interest_bearing_debt',
            'その他有利子負債': 'other_interest_bearing_debt'}.get(text)


def fact_number(node):
    nil = node.get('xsi:nil', '').lower() in {'true', '1'}
    raw = plain(node)
    if nil:
        return None, True, raw
    fmt = node.get('format', '').rsplit(':', 1)[-1].lower()
    text = compact(raw)
    if fmt in {'numdash', 'zerodash', 'fixed-zero', 'fixedzero'}:
        value = Decimal(0)
    elif fmt in {'numcomma', 'numcommadecimal', 'num-comma-decimal'}:
        assert re.fullmatch(r'[+\-]?[\d. ]+(?:,\d+)?', text), ('Unsupported decimal-comma fact', raw)
        value = Decimal(text.replace('.', '').replace(' ', '').replace(',', '.'))
    else:
        assert fmt in {'', 'numdotdecimal', 'num-dot-decimal'}, ('Unverified XBRL transform', fmt, raw)
        value = printed_number(raw)
        assert value is not None, ('Non-nil fact has no number', raw, fmt)
    value *= Decimal(10) ** int(node.get('scale', '0'))
    if node.get('sign') == '-':
        value = -abs(value)
    return value, False, raw


def ifrs_financing_table(page,block,context,family):
    """Read exact borrowing/financial-liability carrying-amount note tables."""
    assert family in {'Borrowings','OtherFinancialLiabilities'}
    expected={date.fromisoformat(context['enddate']),date.fromisoformat(context['startdate'])-timedelta(days=1)}
    candidates=[]
    for ti,table in enumerate((n for n in block.iter()if local(n)=='table'and visible(n)),1):
        rows,grid,starts,coordinates=table_grid(table)
        for hi,cells in enumerate(grid):
            dated={col:dates(plain(c))for col,c in cells.items()if dates(plain(c))}
            if not dated:continue
            assert all(len(ds)==1 for ds in dated.values()),'IFRS financing table has ambiguous date headers'
            opening={col:ds[0]for col,ds in dated.items()if '移行日'in compact(plain(cells[col]))}
            annual={col:ds[0]for col,ds in dated.items()if col not in opening}
            assert len(annual)==2 and set(annual.values())==expected,'IFRS financing note annual columns do not match original XBRL context'
            assert len(opening)<=1 and all(day<min(expected)for day in opening.values()),'An opening column is being mixed with an annual balance'
            labels=[col for col in set(cells)-set(dated)if any(compact(plain(row[col])).rstrip(':：')in {'流動負債','非流動負債','その他の金融負債(流動)','その他の金融負債(非流動)'}for row in grid[hi+1:]if col in row)]
            assert len(labels)==1,'IFRS financing note has no unique section/label column'
            candidates.append((ti,table,rows,grid,starts,coordinates,hi,labels[0],annual,opening))
    assert len(candidates)==1,'IFRS financing note has no unique explicitly dated carrying-amount table'
    ti,table,rows,grid,starts,coordinates,hi,lc,annual,opening=candidates[0]
    units=set(re.findall(r'百万円|千円|(?<![万千])円',' '.join(plain(c)for row in grid[:hi+1]for c in set(row.values()))))
    assert len(units)==1,'IFRS financing note unit is missing or ambiguous'
    unit=next(iter(units));scale={'円':0,'千円':3,'百万円':6}[unit]
    ratecols={col for col,c in grid[hi].items()if '平均利率'in compact(plain(c))}
    duecols={col for col,c in grid[hi].items()if '返済期限'in compact(plain(c))}
    if family=='Borrowings':assert len(ratecols)==len(duecols)==1,'Borrowing note rate/repayment headers are missing'
    section=None;facts={};proof=[];totals={};sums=defaultdict(Decimal);categories=set();seen_sections=set()
    for ri in range(hi+1,len(rows)):
        cells=grid[ri]
        if not any(compact(plain(c))for c in set(cells.values())):continue
        label=plain(cells[lc]);caption=compact(label).rstrip(':：')
        if caption in {'流動負債','その他の金融負債(流動)'}:
            section='current'
            assert section not in seen_sections,'Duplicate current financing section'
            seen_sections.add(section)
            assert all(not compact(plain(cells[col]))for col in {*annual,*opening})
            continue
        if caption in {'非流動負債','その他の金融負債(非流動)'}:
            section='noncurrent'
            assert section not in seen_sections,'Duplicate noncurrent financing section'
            seen_sections.add(section)
            assert all(not compact(plain(cells[col]))for col in {*annual,*opening})
            continue
        if not any(compact(plain(cells[col]))for col in {*annual,*opening}):
            assert family=='OtherFinancialLiabilities'and caption in {'償却原価で測定される金融負債','償却原価で測定する金融負債'},('Unidentified financial note heading',label)
            continue
        assert section is not None,'A financing amount has no explicit current/noncurrent section'
        assert all(not compact(plain(c))for col,c in cells.items()if col not in {lc,*annual,*opening,*ratecols,*duecols}),'Unmapped numeric note column'
        total=caption in {'合計','計','総合計'}
        category=None;excluded_reason=None
        if not total and family=='Borrowings':
            category={('current','短期借入金'):'short_term_borrowings',('current','1年内長期借入金'):'current_long_term_borrowings',('noncurrent','長期借入金'):'long_term_borrowings'}.get((section,caption))
            assert category is not None,('Borrowing note has an unrecognized debt caption',section,label)
        elif not total:
            if caption in {'リース負債','リース負債(注)','リース債務','リース債務(注)'}:category='current_lease'if section=='current'else'noncurrent_lease'
            else:
                excluded_reason={'ヘッジ会計を適用しているデリバティブ負債':'derivative','預り敷金及び保証金':'deposit','その他':'generic_other'}.get(caption)
                assert excluded_reason is not None,('Financial liability note has an unrecognized caption',section,label)
        if category is not None:
            assert category not in categories,'Duplicate financing note debt category'
            categories.add(category)
        row={'physical_row':ri+1,'label':label,'section':section,'category':category,'excluded_reason':excluded_reason,'values':{}}
        for col,day in {**annual,**opening}.items():
            cell=cells[col];raw=plain(cell)
            assert not any(n.get('xsi:nil','').lower()in {'true','1'}or n.get('continuedat')for n in cell.iter())
            amount=printed_number(raw,dash_zero=True)
            assert amount is not None and amount>=0
            amount*=Decimal(10)**scale
            row['values'][day.isoformat()]={'raw':raw,'value_jpy':str(amount)}
            facts[(ri,col)]={'category':category,'section':section,'label':label,'raw':raw,'value':amount,'end':day,'opening':col in opening,'total':total,'excluded_reason':excluded_reason}
            if total:
                assert (section,day)not in totals,'Duplicate financing note total'
                totals[section,day]=amount
            else:sums[section,day]+=amount
        proof.append(row)
    alldates=set(annual.values())|set(opening.values())
    assert set(totals)=={(side,day)for side in ('current','noncurrent')for day in alldates},'Financing note is missing a current/noncurrent disclosed total'
    tolerance=Decimal(10)**scale*(len(proof)+1)
    assert all(abs(sums[key]-value)<=tolerance for key,value in totals.items()),'Financing note detail does not reconcile with its actual disclosed total'
    return {'table':table,'table_index':ti,'rows':rows,'grid':grid,'starts':starts,'coordinates':coordinates,'header_row':hi,'label_column':lc,
            'annual_columns':annual,'opening_columns':opening,'unit_label':unit,'scale':scale,'facts':facts,'proof':proof,'totals':totals,'sums':sums,'tolerance':tolerance}


class RawPage:
    def __init__(self, text):
        self.namespaces = defaultdict(set)
        for prefix, _, uri in re.findall(r'xmlns:([\w.-]+)\s*=\s*([\'"])(.*?)\2', text, re.S):
            self.namespaces[prefix.casefold()].add(html_std.unescape(uri))
        self.root = html.fromstring(text.lstrip('\ufeff').encode('utf-8'), parser=html.HTMLParser(encoding='utf-8', no_network=True))
        self.facts = defaultdict(list)
        self.blocks = defaultdict(list)
        self.tables = [n for n in self.root.iter() if local(n) == 'table']
        for node in self.root.iter():
            if local(node) == 'nonfraction':
                self.facts[(self.qname(node.get('name', '')), node.get('contextref', ''))].append(node)
            elif local(node) == 'nonnumeric':
                self.blocks[(self.qname(node.get('name', '')), node.get('contextref', ''))].append(node)

    def qname(self, name):
        assert ':' in name, ('Unprefixed source QName', name)
        prefix, leaf = name.split(':', 1)
        uris = self.namespaces[prefix.casefold()]
        assert len(uris) == 1, ('Ambiguous source namespace', prefix, uris)
        return '{' + next(iter(uris)) + '}' + leaf


class RawSourceVerifier:
    def __init__(self, cache: Path):
        self.cache = Path(cache)
        self.manifests = {}
        self.pages = {}
        self.contexts = {}
        self.units = {}
        self.seen = set()
        self.counts = Counter()
        self.main_totals = defaultdict(list)
        self.main_sources = defaultdict(list)

    def manifest(self, doc):
        if doc not in self.manifests:
            self.manifests[doc] = json.loads((self.cache / 'filings' / doc / 'manifest.json').read_text(encoding='utf-8'))
        return self.manifests[doc]

    def page(self, doc, filename):
        key = doc, filename
        if key not in self.pages:
            entries = [f for f in self.manifest(doc)['files'] if f['filename'] == filename]
            assert len(entries) == 1, ('Missing/duplicate cached source file', key)
            entry = entries[0]
            raw = (self.cache / 'filings' / doc / entry['path']).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == entry['sha256'], ('Source SHA-256 mismatch', key)
            self.pages[key] = RawPage(raw.decode('utf-8-sig'))
        return self.pages[key]

    def context(self, doc, context_id):
        if doc not in self.contexts:
            result = {}
            units = {}
            for entry in self.manifest(doc)['files']:
                page = self.page(doc, entry['filename'])
                for node in page.root.iter():
                    if local(node) == 'unit':
                        measures=[]
                        for measure in node.iter():
                            if local(measure) == 'measure':
                                expanded=page.qname(plain(measure))
                                uri,leaf=expanded[1:].split('}',1)
                                measures.append(leaf if uri in {'http://www.xbrl.org/2003/iso4217','http://www.xbrl.org/2003/instance'}else expanded)
                        if measures:
                            symbol=('/'if any(local(n)=='divide'for n in node.iter())else'*').join(measures)
                            uid=node.get('id','')
                            assert uid not in units or units[uid]==symbol,('Conflicting source unit',doc,uid)
                            units[uid]=symbol
                    if local(node) != 'context':
                        continue
                    period = {local(n): plain(n) for n in node.iter() if local(n) in {'startdate', 'enddate', 'instant'}}
                    dimensions = tuple(sorted((n.get('dimension', ''), plain(n)) for n in node.iter() if local(n) in {'explicitmember', 'typedmember'}))
                    identifiers = tuple(sorted(plain(n) for n in node.iter() if local(n) == 'identifier'))
                    claim = period, dimensions, identifiers
                    cid = node.get('id', '')
                    assert cid not in result or result[cid] == claim, ('Conflicting source context', doc, cid)
                    result[cid] = claim
            self.contexts[doc] = result
            self.units[doc] = units
        assert context_id in self.contexts[doc], ('Missing original context', doc, context_id)
        return self.contexts[doc][context_id]

    def block(self, source):
        page = self.page(source['doc_id'], source['filename'])
        candidates = page.blocks[(source['concept'], source['context_id'])]
        assert len(candidates) == 1, ('Original TextBlock is missing or ambiguous', source, len(candidates))
        block = candidates[0]
        assert visible(block) and not block.get('continuedat') and block.get('xsi:nil', '').lower() not in {'true', '1'}, 'Unsupported/hidden/nil TextBlock evidence'
        return page, block

    def verify_cell(self, cell, period, *, label='', row_key='', origin='raw'):
        """Verify every original leaf; calculated wrappers are never raw facts."""
        if cell.get('components'):
            for child in cell['components']:
                self.verify_cell(child, period, label=label, row_key=row_key, origin=origin)
            return
        source = cell['source']
        if not source.get('doc_id'):
            assert cell['value'] is None, ('Numeric cell has no original evidence', label, cell)
            self.counts['empty_derived_cells'] += 1
            return
        identity = json.dumps([period, cell['value'], cell['nil'], source, cell.get('note', '')], sort_keys=True, ensure_ascii=False)
        if identity in self.seen:
            return
        self.seen.add(identity)
        if NOTE_MARKER in cell.get('note', ''):
            kind = self.verify_note(cell, period)
            if row_key.startswith('notes:debt:'):
                evidence=json.loads(cell['note'].split(NOTE_MARKER,1)[1].splitlines()[0])
                assert row_key==f"notes:debt:{evidence['category']}:{source['basis']}",('Debt row identity/category differs',row_key,evidence)
        elif source.get('table_path'):
            kind = self.verify_html(cell, period)
        elif not source.get('context_id'):
            assert cell['value'] is None and not source.get('concept'), ('Untagged numeric value', label, cell)
            page = self.page(source['doc_id'], source['filename'])
            assert source.get('raw_value', '') in DASHES | {''}, ('Nonblank untagged source', source)
            assert source.get('original_label') and any(compact(source['original_label']) in compact(plain(row)) for row in page.root.iter() if local(row) == 'tr'), ('Original blank row missing', source)
            kind = 'untagged_blank'
        else:
            page = self.page(source['doc_id'], source['filename'])
            candidates = page.facts[(source['concept'], source['context_id'])]
            expected = (None if cell['value'] is None else Decimal(cell['value']), cell['nil'], source['raw_value'])
            matches = [n for n in candidates if fact_number(n) == expected and int(n.get('scale', '0')) == source.get('scale', 0)]
            assert matches, ('Original numeric QName/context/value/scale not found', label, source, expected,
                             [fact_number(n) for n in candidates])
            context,_,_=self.context(source['doc_id'],source['context_id'])
            begin,end=map(date.fromisoformat,period.split('/'))
            if 'instant'in context:
                allowed={end}
                if '期首'in source.get('original_label',''):allowed.add(begin-timedelta(days=1))
                assert date.fromisoformat(context['instant'])in allowed,('Raw instant has wrong fiscal column',source,period,context)
            else:
                assert context.get('startdate')==begin.isoformat()and context.get('enddate')==end.isoformat(),('Raw duration has wrong fiscal column',source,period,context)
            assert any(self.units[source['doc_id']].get(n.get('unitref',''))==source['unit']
                       and n.get('decimals','')==source.get('decimals','')for n in matches),('Raw unit or decimals differ',source)
            kind = 'ixbrl_fact'
            self.counts['nil_cells'] += int(cell['nil'])
        self.counts[kind] += 1
        self.counts[origin + '_source_leaves_verified'] += 1

    def verify_html(self, cell, period):
        source = cell['source']
        page, block = self.block(source)
        semantic = source.get('semantic_concept', '')
        match = re.fullmatch(r'\{urn:zaimu10:html-table:(E\d{5}):([^}]+)\}.+', semantic)
        assert match and match.group(2) == source['concept'].split('}', 1)[-1], ('HTML role must remain separate from genuine TextBlock', source)
        assert source['concept'].split('}', 1)[-1].endswith('IFRSTextBlock'), ('Not an explicit IFRS statement TextBlock', source)
        context, dims, issuers = self.context(source['doc_id'], source['context_id'])
        assert not dims and 'startdate' in context and len(issuers) == 1 and issuers[0].startswith(match.group(1)), ('Unverified HTML context/issuer', source)
        tables = [n for n in block.iter() if local(n) == 'table' and not any(local(c) == 'table' for c in n.iterdescendants())]
        path = json.loads(source['table_path'])
        assert set(path) == {'table', 'row', 'column'} and all(type(v) is int and v >= 0 for v in path.values()), ('Invalid HTML coordinate', path)
        table = tables[path['table']]
        rows, grid, starts, _ = table_grid(table)
        ri, col = path['row'], path['column']
        value_cell = starts[ri][col]
        raw = compact(plain(value_cell))
        assert raw == source['raw_value'], ('HTML raw cell text differs', source, raw)
        assert source['original_label'] in [plain(c) for ccol, c in starts[ri].items() if ccol < col], ('HTML original row label differs', source)
        start, end = map(date.fromisoformat, period.split('/'))
        headers = [dates(plain(starts[h][col])) for h in range(ri) if col in starts[h] and dates(plain(starts[h][col]))]
        assert any(ds[-1] == end and (len(ds) == 1 or ds[0] == start) for ds in headers), ('HTML fiscal column not proven by its original date header', source, period, headers)
        units = set(re.findall(r'単位\s*[:：]\s*(百万円|千円|円)', plain(block)))
        assert len(units) == 1, ('HTML monetary unit missing or ambiguous', source, units)
        scale = {'円': 0, '千円': 3, '百万円': 6}[next(iter(units))]
        if source['unit'] == 'JPY/shares':
            assert '1株当たり' in compact(source['original_label'])
            scale = 0
        else:
            assert source['unit'] == 'JPY', ('Unsupported HTML currency', source)
        assert source['scale'] == scale and source['decimals'] == str(-scale if source['unit'] == 'JPY' else -2)
        value = printed_number(raw)
        expected_nil = value is None
        assert cell['nil'] == expected_nil and (None if cell['value'] is None else Decimal(cell['value'])) == (None if value is None else value * Decimal(10) ** scale), ('HTML numeric value differs', source, cell)
        self.counts['nil_cells'] += int(cell['nil'])
        return 'html_table_cells_verified'

    def verify_note(self, cell, period):
        source = cell['source']
        evidence = json.loads(cell['note'].split(NOTE_MARKER, 1)[1].splitlines()[0])
        page, block = self.block(source)
        assert not source.get('semantic_concept') and not source.get('table_path'), 'Debt note may not fabricate a numeric QName/HTML role'
        assert (evidence['document_id'], evidence['filename'], evidence['block_qname'], evidence['block_context']) == (source['doc_id'], source['filename'], source['concept'], source['context_id'])
        assert period == evidence['period_start'] + '/' + evidence['period_end'], ('Debt note period differs', evidence, period)
        qname_match = re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpcrp/\d{4}-\d{2}-\d{2}/jpcrp_cor\}Annexed(Consolidated)?DetailedScheduleOf(Borrowings|CorporateBonds)(?:FinancialStatements)?(?:NA)?TextBlock', source['concept'])
        ifrs_match = re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpigp/\d{4}-\d{2}-\d{2}/jpigp_cor\}NotesOther(Current|NonCurrent)LiabilitiesConsolidatedFinancialStatementsIFRSTextBlock', source['concept'])
        financing_match = re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpigp/\d{4}-\d{2}-\d{2}/jpigp_cor\}Notes(Borrowings|OtherFinancialLiabilities)ConsolidatedFinancialStatementsIFRSTextBlock', source['concept'])
        risk_match = re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/jpcrp030000/asr/001/E00932-000/\d{4}-\d{2}-\d{2}/01/\d{4}-\d{2}-\d{2}\}NotesRiskManagementConsolidatedFinancialStatementsIFRSTextBlock', source['concept'])
        assert qname_match or ifrs_match or financing_match or risk_match, ('Unrecognized actual debt TextBlock QName', source)
        basis = 'consolidated' if ifrs_match or financing_match or risk_match or qname_match.group(1) else 'standalone'
        assert source['basis'] == evidence['basis'] == basis and source['unit'] == 'JPY'
        context, dims, issuers = self.context(source['doc_id'], source['context_id'])
        assert 'startdate' in context and context['startdate'] == evidence['context_period_start'] and context['enddate'] == evidence['context_period_end']
        assert len(issuers) == 1
        assert all(axis.rsplit(':', 1)[-1] == 'ConsolidatedOrNonConsolidatedAxis' and member.rsplit(':', 1)[-1] == ('NonConsolidatedMember' if basis == 'standalone' else 'ConsolidatedMember') for axis, member in dims), ('Debt note has unverified dimensions', dims)
        named_issuer = re.search(r'E\d{5}-\d{3}', source['filename'])
        if named_issuer:
            assert issuers == (named_issuer.group(),), ('Debt issuer mismatch', source)
        visible_blocks = [n for n in page.root.iter() if local(n) == 'nonnumeric' and visible(n)]
        assert visible_blocks[evidence['block_index'] - 1] is block
        if risk_match:
            return self.verify_nonlease_absence(cell,evidence,block,context,issuers)
        if ifrs_match:
            return self.verify_ifrs_note(cell,evidence,page,block,context,ifrs_match.group(1),period)
        if financing_match:
            return self.verify_ifrs_financing_note(cell,evidence,page,block,context,financing_match.group(1),period)
        title = '借入金等明細表' if qname_match.group(2) == 'Borrowings' else '社債明細表'
        assert title in compact(plain(block))
        kind = evidence['kind']
        if kind == 'explicit_none':
            text = plain(block)
            remainder = compact(text).replace('【' + title + '】', '').replace(title, '').strip('。．.')
            assert remainder in {'該当事項はありません', '該当事項がありません', '該当する事項はありません', '該当事項はございません', '該当事項なし'}, ('Not an exact applicable-none statement', text)
            assert source['raw_value'] == evidence['statement'] == text and not any(local(n) == 'nonfraction' for n in block.iter())
            assert evidence.get('table_index') is None and evidence.get('physical_row') is None and evidence.get('physical_column') is None
            assert evidence['balance_column'] == 'end' and evidence['period_start'] == context['startdate'] and evidence['period_end'] == context['enddate']
            assert source['scale'] == 0 and not cell['nil'] and cell['value'] in (None, '0')
            allowed = {'borrowings_absent', 'short_term_borrowings', 'current_long_term_borrowings', 'current_lease', 'long_term_borrowings', 'noncurrent_lease'} if qname_match.group(2) == 'Borrowings' else {'bonds_absent', 'bonds', 'current_bonds'}
            assert evidence['category'] in allowed
            return 'debt_absence_statements_verified'
        assert kind in {'borrowings_schedule', 'borrowings_schedule_coverage'} and qname_match.group(2) == 'Borrowings', ('Unsupported debt evidence kind', kind)
        tables = [n for n in block.iter() if local(n) == 'table' and visible(n)]
        table = tables[evidence['table_index'] - 1]
        assert page.tables[evidence['page_table_index'] - 1] is table
        rows, grid, starts, coordinates = table_grid(table)
        headers = []
        for ri, cells in enumerate(grid):
            texts = {col: compact(plain(c)) for col, c in cells.items()}
            begins = [col for col, text in texts.items() if re.search(r'当期首残高|前期末残高|前連結会計年度末残高|前事業年度末残高', text)]
            ends = [col for col, text in texts.items() if re.search(r'当期末残高|当連結会計年度末残高|当事業年度末残高', text)]
            labels = [col for col, text in texts.items() if text == '区分']
            rates = [col for col, text in texts.items() if '平均利率' in text]
            if begins or ends:
                assert len(begins) == len(ends) == len(labels) == len(rates) == 1, 'Ambiguous debt balance/rate header'
                headers.append((ri, labels[0], begins[0], ends[0],rates[0]))
        assert len(headers) == 1, 'Debt balance header not independently identifiable'
        hi, lc, bc, ec, rc = headers[0]
        header_units = set(re.findall(r'百万円|千円|(?<![万千])円', ' '.join(plain(c) for c in set(grid[hi].values()))))
        if not header_units:
            prefix = []
            for n in block.iter():
                if n is table:
                    break
                if n.text:
                    prefix.append(n.text)
                if n is not block and n.tail:
                    prefix.append(n.tail)
            header_units = set(re.findall(r'百万円|千円|(?<![万千])円', ' '.join(prefix)))
        assert len(header_units) == 1 and evidence['unit_label'] == next(iter(header_units)), ('Debt amount unit unproven', evidence, header_units)
        scale = {'円': 0, '千円': 3, '百万円': 6}[next(iter(header_units))]
        assert source['scale'] == evidence['scale'] == scale and source['decimals'] == str(-scale)
        balance = evidence['balance_column']
        assert balance in {'begin', 'end'}
        col = bc if balance == 'begin' else ec
        expected_end = date.fromisoformat(context['startdate']) - timedelta(days=1) if balance == 'begin' else date.fromisoformat(context['enddate'])
        assert date.fromisoformat(evidence['period_end']) == expected_end
        if balance == 'end':
            assert evidence['period_start'] == context['startdate']
        for selected, actual_end in ((bc, date.fromisoformat(context['startdate']) - timedelta(days=1)), (ec, date.fromisoformat(context['enddate']))):
            assert all(d == actual_end for d in dates(plain(grid[hi][selected]))), ('Debt header date conflicts with source context', evidence)
        if kind == 'borrowings_schedule':
            ri, ci = evidence['physical_row'] - 1, evidence['physical_column'] - 1
            value_cell = direct_cells(rows[ri])[ci]
            assert grid[ri][col] is value_cell and coordinates[value_cell][2] == evidence['expanded_column'] - 1 == col
            assert plain(value_cell) == source['raw_value'] == evidence['raw_value']
            assert plain(grid[hi][col]) == evidence['column_header'] and plain(grid[ri][lc]) == source['original_label']
            assert evidence['category']==debt_category(source['original_label']),('Debt category not established by original row caption',evidence,source)
            self.verify_interest_rate(grid,coordinates,hi,ri,rc,source['original_label'],evidence)
            assert not any(n.get('xsi:nil', '').lower() in {'true', '1'} or n.get('continuedat') for n in value_cell.iter())
            value = printed_number(plain(value_cell), dash_zero=True)
            assert value is not None and value >= 0 and not cell['nil']
            assert Decimal(cell['value']) == value * Decimal(10) ** scale
            return 'debt_numeric_cells_verified'
        assert cell['value'] is None and not cell['nil'] and source['raw_value'] == plain(block)
        actual_rows = [ri for ri in range(hi + 1, len(rows)) if any(compact(plain(c)) for c in set(grid[ri].values()))]
        assert [r['physical_row'] - 1 for r in evidence['rows']] == actual_rows, 'Debt coverage omitted or added a physical row'
        sums = {'begin': Decimal(0), 'end': Decimal(0)}
        totals = {}
        detail_count = 0
        categories = set()
        for row in evidence['rows']:
            ri = row['physical_row'] - 1
            assert plain(grid[ri][lc]) == row['label']
            total = compact(row['label']) in {'合計', '計', '総合計'}
            if not total:
                assert row['category'] and row['category'] not in categories
                assert row['category']==debt_category(row['label']),('Debt coverage category not established by original caption',row)
                self.verify_interest_rate(grid,coordinates,hi,ri,rc,row['label'])
                categories.add(row['category'])
                detail_count += 1
            for side, value_col in (('begin', bc), ('end', ec)):
                raw = plain(grid[ri][value_col])
                value = printed_number(raw, dash_zero=True)
                assert value is not None and value >= 0
                value *= Decimal(10) ** scale
                assert row['values'][side] == {'raw': raw, 'value_jpy': str(value)}
                if total:
                    assert side not in totals
                    totals[side] = value
                else:
                    sums[side] += value
        assert Decimal(evidence['component_sum_jpy']) == sums[balance]
        assert (None if evidence['reported_schedule_total_jpy'] is None else Decimal(evidence['reported_schedule_total_jpy'])) == totals.get(balance)
        tolerance = Decimal(10) ** scale * (detail_count + 1)
        assert Decimal(evidence['rounding_tolerance_jpy']) == tolerance
        assert all(abs(sums[side] - value) <= tolerance for side, value in totals.items()), 'Debt schedule total mismatch'
        return 'debt_coverage_markers_verified'

    def verify_interest_rate(self,grid,coordinates,hi,ri,rc,label,evidence=None):
        """Ordinary deposits are not debt; the compound caption needs a rate."""
        required=compact(label)in INTEREST_DEPOSIT_CAPTIONS
        if not required and (evidence is None or 'interest_rate_raw'not in evidence):return
        rate_cell=grid[ri][rc];header=plain(grid[hi][rc]);raw=plain(rate_cell)
        assert '平均利率'in compact(header)and '%'in compact(header),'Interest rate must have an explicit percent header'
        assert not any(n.get('xsi:nil','').lower()in {'true','1'}or n.get('continuedat')for n in rate_cell.iter())
        if evidence is not None:
            physical_row,physical_column,expanded_column=coordinates[rate_cell]
            assert evidence['interest_rate_raw']==raw and evidence['interest_rate_column_header']==header
            assert evidence['interest_rate_physical_row']==physical_row+1==ri+1
            assert evidence['interest_rate_physical_column']==physical_column+1
            assert evidence['interest_rate_expanded_column']==expanded_column+1==rc+1
            assert evidence['interest_rate_positive_required']is required
        if required:
            assert re.fullmatch(r'\d+(?:\.\d+)?%?',compact(raw)),('Compound interest-bearing deposit has no numeric rate',label,raw)
            assert Decimal(compact(raw).rstrip('%'))>0,('Compound interest-bearing deposit requires a strictly positive rate',label,raw)
            self.counts['compound_interest_rate_checks']+=1

    def verify_nonlease_absence(self,cell,evidence,block,context,issuers):
        """The exact Chugai sentence excludes leases; it is not all-debt zero."""
        assert evidence['kind']=='explicit_nonlease_absence'and evidence['scope']=='nonlease_only'
        assert issuers==('E00932-000',),'The issuer-specific statement belongs only to Chugai'
        paragraphs=[n for n in block.iter()if local(n)=='p']
        node=paragraphs[evidence['paragraph_index']-1]
        text=plain(node)
        statement='当社グループが保有する有利子負債及び貸付金の残高はなく、リース負債はリース契約の規模及び現在の低金利の経済状況を鑑みると当社グループにおける金利リスクは軽微です。'
        assert compact(text)==statement and cell['source']['raw_value']==evidence['statement']==text,('Exact nonlease statement not found',evidence)
        previous=node.getprevious()
        while previous is not None and not compact(plain(previous)):previous=previous.getprevious()
        assert previous is not None and compact(plain(previous))=='金利リスク'
        assert evidence['period_start']==context['startdate']and evidence['period_end']==context['enddate']
        assert evidence['balance_column']=='end'and all(evidence.get(k)is None for k in ('table_index','physical_row','physical_column'))
        assert cell['value']=='0'and not cell['nil']and cell['source']['scale']==0 and cell['source']['decimals']=='0'
        assert evidence['category']in {'nonlease_debt_absent','short_term_borrowings','current_long_term_borrowings','long_term_borrowings','bonds','current_bonds','commercial_paper'},'Nonlease absence must never establish a lease zero'
        return 'debt_nonlease_absence_statements_verified'

    def verify_ifrs_note(self,cell,evidence,page,block,context,classification,period):
        """Rebuild dated carrying-amount tables, excluding maturity schedules."""
        source=cell['source'];kind=evidence['kind']
        assert kind in {'ifrs_other_liabilities','ifrs_other_liabilities_coverage'}
        category,parent,title=('current_lease','OtherCurrentLiabilitiesCLIFRS','その他の流動負債')if classification=='Current'else('noncurrent_lease','OtherNonCurrentLiabilitiesNCLIFRS','その他の非流動負債')
        assert title in compact(plain(block))and evidence['parent_local']==parent
        assert evidence['category']==category+('_coverage'if kind.endswith('_coverage')else'')
        tables=[n for n in block.iter()if local(n)=='table'and visible(n)]
        table=tables[evidence['table_index']-1]
        assert page.tables[evidence['page_table_index']-1]is table
        rows,grid,starts,coordinates=table_grid(table)
        current=date.fromisoformat(context['enddate']);prior=date.fromisoformat(context['startdate'])-timedelta(days=1)
        candidates=[]
        for hi,cells in enumerate(grid):
            dated={col:dates(plain(c))for col,c in cells.items()if dates(plain(c))}
            if not dated:continue
            assert len(dated)==2 and all(len(ds)==1 for ds in dated.values())and {ds[0]for ds in dated.values()}=={prior,current},'IFRS carrying-amount date headers conflict with actual context'
            labels=[col for col in set(cells)-set(dated)if any(compact(plain(row[col]))for row in grid[hi+1:]if col in row)]
            assert len(labels)==1,'IFRS note has an ambiguous label column'
            candidates.append((hi,labels[0],{col:ds[0]for col,ds in dated.items()}))
        assert len(candidates)==1,'No unique explicitly dated IFRS carrying-amount table'
        hi,lc,dated=candidates[0]
        units=set(re.findall(r'百万円|千円|(?<![万千])円',' '.join(plain(c)for row in grid[:hi+1]for c in set(row.values()))))
        assert len(units)==1 and evidence['unit_label']==next(iter(units)),('IFRS note monetary unit is unproven',evidence,units)
        scale={'円':0,'千円':3,'百万円':6}[next(iter(units))]
        assert source['scale']==evidence['scale']==scale and source['decimals']==str(-scale)
        end=date.fromisoformat(evidence['period_end'])
        assert end in {prior,current}
        if end==current:assert evidence['period_start']==context['startdate']
        col=next(col for col,day in dated.items()if day==end)
        if kind=='ifrs_other_liabilities':
            ri,ci=evidence['physical_row']-1,evidence['physical_column']-1
            value_cell=direct_cells(rows[ri])[ci]
            assert grid[ri][col]is value_cell and coordinates[value_cell][2]==evidence['expanded_column']-1==col
            assert compact(plain(grid[ri][lc]))in {'リース負債','リース債務'}and plain(grid[ri][lc])==source['original_label']
            assert source['raw_value']==evidence['raw_value']==plain(value_cell)
            assert evidence['balance_column']=='closing'and evidence['column_header']==plain(grid[hi][col])
            assert not any(n.get('xsi:nil','').lower()in {'true','1'}or n.get('continuedat')for n in value_cell.iter())
            value=printed_number(plain(value_cell),dash_zero=True)
            assert value is not None and value>=0 and not cell['nil']and Decimal(cell['value'])==value*Decimal(10)**scale
            return 'debt_ifrs_numeric_cells_verified'
        assert cell['value']is None and not cell['nil']and source['raw_value']==plain(table)
        actual_rows=[ri for ri in range(hi+1,len(rows))if any(compact(plain(c))for c in set(grid[ri].values()))]
        assert [r['physical_row']-1 for r in evidence['rows']]==actual_rows,'IFRS coverage omitted or added physical rows'
        sums={day:Decimal(0)for day in dated.values()};totals={};leases=0
        for row in evidence['rows']:
            ri=row['physical_row']-1;label=plain(grid[ri][lc]);assert label==row['label']
            assert all(not compact(plain(c))for ccol,c in grid[ri].items()if ccol not in {lc,*dated}), 'Unmapped financial data in an IFRS note column'
            name=compact(label);total=name in {'合計','計','総合計'};lease=name in {'リース負債','リース債務'}
            leases+=int(lease)
            assert lease or total or not any(token in name for token in ['借入','社債','リース','有利子']),'Unclassified interest-bearing detail in IFRS coverage'
            assert set(row['values'])=={day.isoformat()for day in dated.values()}
            for ccol,day in dated.items():
                raw=plain(grid[ri][ccol]);value=printed_number(raw,dash_zero=True)
                assert value is not None and value>=0
                value*=Decimal(10)**scale
                assert row['values'][day.isoformat()]=={'raw':raw,'value_jpy':str(value)}
                if total:
                    assert day not in totals;totals[day]=value
                else:sums[day]+=value
        assert leases<=1 and evidence['lease_row_present']==bool(leases)
        assert set(totals)==set(dated.values()),'IFRS coverage lacks a disclosed total'
        tolerance=Decimal(10)**scale*(len(actual_rows)+1)
        assert Decimal(evidence['rounding_tolerance_jpy'])==tolerance
        assert all(abs(sums[day]-totals[day])<=tolerance for day in sums),'IFRS note components disagree with original totals'
        assert Decimal(evidence['reported_note_total_jpy'])==totals[end]and Decimal(evidence['component_sum_jpy'])==sums[end]
        for value in self.main_totals[(period,parent)]:
            assert abs(value-totals[end])<=tolerance,'IFRS note total disagrees with raw BS parent'
        return 'debt_ifrs_coverage_markers_verified'

    def verify_ifrs_financing_note(self,cell,evidence,page,block,context,family,period):
        source=cell['source'];table=ifrs_financing_table(page,block,context,family)
        monetary_kind='ifrs_borrowings'if family=='Borrowings'else'ifrs_financial_liabilities'
        coverage_kind='ifrs_borrowings_coverage'if family=='Borrowings'else'financial_liabilities_coverage'
        assert evidence['kind']in {monetary_kind,coverage_kind}
        assert evidence['table_index']==table['table_index']and page.tables[evidence['page_table_index']-1]is table['table']
        assert source['scale']==evidence['scale']==table['scale']and evidence['unit_label']==table['unit_label']and source['decimals']==str(-table['scale'])
        end=date.fromisoformat(evidence['period_end'])
        assert end in table['annual_columns'].values(),'An opening/nonannual note balance may not enter annual data'
        col=next(col for col,day in table['annual_columns'].items()if day==end)
        expected_exclusions=[]
        for opening_col,day in table['opening_columns'].items():
            header_cell=table['grid'][table['header_row']][opening_col]
            ri,ci,logical=table['coordinates'][header_cell]
            expected_exclusions.append({'expanded_column':logical+1,'physical_row':ri+1,'physical_column':ci+1,
                'date':day.isoformat(),'column_header':plain(header_cell),'reason':'explicit_ifrs_transition_opening_not_an_annual_period'})
        assert evidence['excluded_columns']==expected_exclusions,'Transition opening-column evidence differs from the actual header'
        parents={'current':'BorrowingsCLIFRS','noncurrent':'BorrowingsNCLIFRS'}if family=='Borrowings'else{'current':'OtherFinancialLiabilitiesCLIFRS','noncurrent':'OtherFinancialLiabilitiesNCLIFRS'}
        if evidence['kind']==monetary_kind:
            ri,ci=evidence['physical_row']-1,evidence['physical_column']-1
            value_cell=direct_cells(table['rows'][ri])[ci]
            assert table['grid'][ri][col]is value_cell and table['coordinates'][value_cell][2]==evidence['expanded_column']-1==col
            fact=table['facts'][ri,col]
            assert fact['category']is not None and fact['category']==evidence['category']and not fact['opening']and not fact['total']
            assert fact['section']==evidence['section']and evidence['parent_local']==parents[fact['section']]
            assert fact['label']==source['original_label']and fact['raw']==source['raw_value']==evidence['raw_value']
            assert evidence['balance_column']=='closing'and evidence['column_header']==plain(table['grid'][table['header_row']][col])
            assert not cell['nil']and Decimal(cell['value'])==fact['value']
            return 'debt_ifrs_financing_numeric_cells_verified'
        assert cell['value']is None and not cell['nil']and source['raw_value']==plain(table['table'])
        assert evidence['category']==coverage_kind
        assert evidence['scope']==('loans_only'if family=='Borrowings'else'classified_financial_liabilities_only')
        annual_dates={day.isoformat()for day in table['annual_columns'].values()}
        expected_rows=[{key:value for key,value in row.items()if key in {'label','section','category','physical_row'}}|
                       {'values':{day:value for day,value in row['values'].items()if day in annual_dates}}for row in table['proof']]
        assert evidence['rows']==expected_rows,'IFRS financing coverage rows/amounts differ from the complete actual table'
        assert Decimal(evidence['rounding_tolerance_jpy'])==table['tolerance']
        reconciliations={item['section']:item for item in evidence['main_reconciliation']}
        assert len(evidence['main_reconciliation'])==2 and set(reconciliations)==set(parents),'Both financing sections require a main BS reconciliation'
        for side,parent in parents.items():
            original=self.main_sources[period,parent]
            assert len(original)==1,'A financing note must reconcile to exactly one original BS parent'
            main=original[0];value=Decimal(main['value']);total=table['totals'][side,end]
            assert abs(value-total)<=table['tolerance'],'Financing note total disagrees with the original BS parent'
            assert reconciliations[side]=={'section':side,'parent_local':parent,'note_total_jpy':str(total),
                'component_sum_jpy':str(table['sums'][side,end]),'main_value_jpy':str(value),
                'main_source_concept':main['source']['concept']},'Financing reconciliation claims differ from original BS data'
        expected_excluded_rows=[]
        base_keys=('filename','block_qname','block_context','block_index','basis','document_id','context_period_start','context_period_end')
        for row in table['proof']:
            if row['excluded_reason']is None:continue
            ri=row['physical_row']-1;fact=table['facts'][ri,col];value_cell=table['grid'][ri][col]
            physical_row,physical_column,logical=table['coordinates'][value_cell]
            expected_excluded_rows.append({'label':row['label'],'value_jpy':str(fact['value']),'raw_value':fact['raw'],
                'section':row['section'],'physical_row':physical_row+1,'physical_column':physical_column+1,'expanded_column':logical+1,
                'source':{key:evidence[key]for key in base_keys},'unit_label':table['unit_label'],'scale':table['scale'],
                'reason':'outside_reference_core_and_not_explicitly_interest_bearing; interest_nature_not_inferred'})
        assert evidence['excluded_rows']==expected_excluded_rows,'Excluded deposits/derivatives/Other amounts must remain exact disclosed amounts; no interest/zero inference'
        self.counts['explicit_opening_column_exclusions_verified']+=len(expected_exclusions)
        self.counts['financial_liability_excluded_rows_verified']+=len(expected_excluded_rows)
        return 'debt_ifrs_financing_coverage_markers_verified'
