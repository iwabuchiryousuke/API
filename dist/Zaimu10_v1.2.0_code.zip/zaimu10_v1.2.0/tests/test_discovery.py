from datetime import date
from pathlib import Path
import io
import json
import zipfile

import pytest

from zaimu10.discovery import (
    DiscoveryError, _filings_from_rows, _parse_code_archive,
    _state_from_html, _request, discover_filings, normalize_code, resolve_company,
    display_company_name, search_companies, resolve_company_query,
)


@pytest.mark.parametrize('raw,expected', [('６９４７','6947'), ('69470','6947'),
                                        (' 6947.T ', '6947'), ('285a.jp', '285A')])
def test_stock_codes(raw, expected):
    assert normalize_code(raw) == expected


@pytest.mark.parametrize('raw', ['../6947', '6947;rm', '0', '', 'ABCDEFGHI'])
def test_rejects_non_stock_codes(raw):
    with pytest.raises(ValueError):
        normalize_code(raw)


def _archive():
    text = 'ダウンロード実行日,2026年11月11日現在\r\nＥＤＩＮＥＴコード,提出者名,証券コード,連結の有無,決算日\r\nE01966,株式会社図研,69470,有,3月31日\r\nE99999,テスト,285A0,無,12月31日\r\n'
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w') as archive:
        archive.writestr('EdinetcodeDlInfo.csv', text.encode('cp932'))
    return output.getvalue()


def test_official_cp932_code_map_and_offline_resolve(tmp_path):
    archive_path = tmp_path/'discovery'/'Edinetcode.zip'
    archive_path.parent.mkdir()
    archive_path.write_bytes(_archive())
    assert len(_parse_code_archive(archive_path.read_bytes())) == 2
    company = resolve_company('6947', cache_dir=tmp_path, offline=True)
    assert company['edinet_code'] == 'E01966'
    assert company['company'] == '株式会社図研'
    assert company['consolidated'] is True
    assert resolve_company('285A', cache_dir=tmp_path, offline=True)['consolidated'] is False


def _row(doc='S100W07I', kind='12001', name='有価証券報告書－第49期(2024/04/01－2025/03/31)', edinet='E01966'):
    return {'SHORUI_KANRI_NO':doc, 'SYORUI_SB_CD_ID':kind, 'SHORUI_NAME':name,
            'EDINET_CD':edinet, 'TEISHUTSU_NICHIJI':'2025/06/20 14:09',
            'TEISYUTUSYA_NAME':'株式会社図研', 'STATUS':'31'}


def test_filter_annual_only_keep_amendments_avoid_other_companies():
    rows = [_row(), _row(), _row(doc='S100YAAA', kind='13001', name='訂正有価証券報告書－第49期(2024/04/01－2025/03/31)'),
            _row(doc='S100ZAAB', kind='16001', name='半期報告書－第50期(2025/04/01－2026/03/31)'),
            _row(doc='S100ZAAC', edinet='E00001')]
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    filings = _filings_from_rows(rows, company)
    assert len(filings) == 2
    assert {f.amended for f in filings} == {False, True}
    assert all(f.start == date(2024,4,1) and f.end == date(2025,3,31) for f in filings)


def test_invalid_period_fails_without_guessing():
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    with pytest.raises(DiscoveryError, match='対象期間'):
        _filings_from_rows([_row(name='有価証券報告書－第49期')],company)


def test_offline_discovery_never_needs_session_tokens(tmp_path):
    directory=tmp_path/'discovery';directory.mkdir()
    (directory/'Edinetcode.zip').write_bytes(_archive())
    (directory/'E01966.json').write_text(json.dumps({'schema':1,'edinet_code':'E01966','rows':[_row()], 'queried_at':'2026-11-11T00:00:00Z'}),encoding='utf-8')
    filings=discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)
    assert len(filings)==1
    assert filings[0].doc_id=='S100W07I'


def test_missing_offline_cache_is_explicit(tmp_path):
    with pytest.raises(DiscoveryError, match='オフライン'):
        discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)


def test_unexpected_search_response_not_parsed_as_empty_result():
    with pytest.raises(DiscoveryError, match='検索画面'):
        _state_from_html('<html>Service unavailable</html>')


def test_unavailable_and_unknown_statuses_not_selected():
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    withdrawn=_row();withdrawn['STATUS']='99'
    unavailable=_row(doc='S100YAAA');unavailable['BIKOU']='取り下げられた書類'
    assert not _filings_from_rows([withdrawn,unavailable],company,log=lambda _:None)


def test_swapped_offline_company_cache_is_rejected(tmp_path):
    directory=tmp_path/'discovery';directory.mkdir()
    (directory/'Edinetcode.zip').write_bytes(_archive())
    (directory/'E01966.json').write_text(json.dumps({'schema':1,'edinet_code':'E00001','rows':[_row()]}),encoding='utf-8')
    with pytest.raises(DiscoveryError,match='一致'):
        discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)


def test_long_server_retry_after_stops_without_early_retry(monkeypatch):
    from zaimu10 import edinet
    class Response:
        status_code=429
        headers={'Retry-After':'301'}
    class Session:
        calls=0
        def request(self,*args,**kwargs):
            self.calls+=1
            assert kwargs['allow_redirects'] is False
            return Response()
    session=Session()
    monkeypatch.setattr(edinet,'_pause',lambda *args:None)
    with pytest.raises(DiscoveryError,match='301秒'):
        _request(session,'GET','https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx')
    assert session.calls==1


def test_redirect_cannot_forward_form_tokens(monkeypatch):
    from zaimu10 import edinet
    class Response:
        status_code=302
        headers={'Location':'https://example.com'}
    class Session:
        def request(self,*args,**kwargs):
            assert kwargs['allow_redirects'] is False
            return Response()
    monkeypatch.setattr(edinet,'_pause',lambda *args:None)
    with pytest.raises(DiscoveryError,match='HTTP 302'):
        _request(Session(),'POST','https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx')


def _search_archive(tmp_path):
    text = ('ダウンロード実行日,2026年11月18日現在\r\n'
            'ＥＤＩＮＥＴコード,提出者名,提出者名（英字）,提出者名（ヨミ）,証券コード,連結の有無,決算日\r\n'
            'E01966,株式会社図研,ZUKEN INC.,ズケン,69470,有,3月31日\r\n'
            'E00001,図研エルミック株式会社,ZUKEN ELMIC,ズケンエルミック,47700,有,3月31日\r\n'
            'E02490,株式会社　トリケミカル研究所,TRI CHEMICAL LABORATORIES INC.,トリケミカルケンキュウジョ,43690,有,1月31日\r\n'
            'E99999,テスト株式会社,TEST INC.,テスト,285A0,無,12月31日\r\n'
            'E11111,株式会社非上場,PRIVATE INC.,ヒジョウジョウ,,無,12月31日\r\n')
    directory = tmp_path/'discovery'; directory.mkdir()
    with zipfile.ZipFile(directory/'Edinetcode.zip', 'w') as archive:
        archive.writestr('EdinetcodeDlInfo.csv', text.encode('cp932'))


def test_company_search_returns_all_ambiguous_choices_without_guessing(tmp_path):
    _search_archive(tmp_path)
    results = search_companies('株式会社 図研', cache_dir=tmp_path, offline=True, log=lambda _:None)
    assert [row['code'] for row in results] == ['6947', '4770']
    assert results[0]['display_name'] == '図研'
    assert results[0]['company'] == '株式会社図研'
    with pytest.raises(DiscoveryError, match='複数'):
        resolve_company_query('図研', cache_dir=tmp_path, offline=True, log=lambda _:None)


def test_code_search_is_exact_and_name_search_handles_width_spaces_and_english(tmp_path):
    _search_archive(tmp_path)
    exact = search_companies('６９４７.T', cache_dir=tmp_path, offline=True, log=lambda _:None)
    assert [row['code'] for row in exact] == ['6947']
    found = resolve_company_query('トリ ケミカル', cache_dir=tmp_path, offline=True, log=lambda _:None)
    assert found['code'] == '4369'
    assert found['company'] == '株式会社　トリケミカル研究所'
    assert found['display_name'] == 'トリケミカル研究所'
    assert search_companies('tri chemical', cache_dir=tmp_path, offline=True, log=lambda _:None)[0]['code'] == '4369'
    assert search_companies('２８５ａ', cache_dir=tmp_path, offline=True, log=lambda _:None)[0]['code'] == '285A'
    assert search_companies('存在しない企業', cache_dir=tmp_path, offline=True, log=lambda _:None) == []


def test_corporate_designator_only_is_not_a_search_for_every_company(tmp_path):
    for query in ('', '　', '株式会社', '（株）', '㈱'):
        with pytest.raises(ValueError, match='企業名'):
            search_companies(query, cache_dir=tmp_path, offline=True, log=lambda _:None)


@pytest.mark.parametrize('official,display', [('株式会社図研','図研'), ('図研株式会社','図研'),
                                             ('株式会社　トリケミカル研究所','トリケミカル研究所'),
                                             ('㈱ＡＢＣ','ABC')])
def test_display_name_omits_corporate_marker(official, display):
    assert display_company_name(official) == display
