# Zaimu10 desktop distribution review

Reviewed `work/zaimu10_desktop` as a separate distribution from the original financial program. Inspected the uploaded family-trades ZIP only as text; none of its code was executed. The reviewed launchers use the same root `app.py` style while keeping financial acquisition in the Zaimu10 package.

## Correctness and isolation findings resolved

- An existing executable at `.venv/bin/python` or `.venv/Scripts/python.exe` initially authorized pip even if it was a system interpreter. Setup now checks `pyvenv.cfg`, the interpreter's actual `sys.prefix`/`base_prefix`, Python version, and the resolved package/script/data destinations before installation.
- A nested package-directory symlink could initially direct pip outside the app despite a legitimate venv prefix. Resolved `purelib`, `platlib`, `scripts` and `data` paths must now remain inside this application's venv. Ordinary interpreter-binary symlinks remain compatible.
- Inherited pip destination variables or configuration could direct installation outside the venv. Destination overrides are removed and pip configuration files are disabled, while ordinary proxy, index and CA settings remain available.
- The original self-check did not import all financial backend modules and did not capture unexpected initialization errors. It now checks the backend modules and returns a failed readiness result for missing modules and unexpected import errors.

## Validation

Added `tests/test_desktop.py`: **27 tests passed**. They verify:

- Actual subprocess `app.py --self-check`, CLI help, invalid-code failure, and read-only setup checking from an unrelated current directory, with a Japanese/space-containing application path.
- Fresh app-local setup, reuse of a valid environment, preservation of existing Excel/cache files, and installation using only the verified environment interpreter.
- Refusal of system/external interpreters, a linked venv root, nested external package directories, and old Python environments.
- Neutralization of inherited pip destination overrides, preservation of proxy settings, bounded/read-only checks, missing-pip repair, and honest failures for unsuccessful repair/install/readiness checks.
- CLI exit-code propagation without opening the desktop, a blocked launch before readiness, and an unexpected GUI error saved inside the app's log directory with a failure exit code.

Full suite executed from the desktop distribution directory to prioritize its local package: **191 passed in 5.00 seconds**.

Windows batch-file quoting, directory changes, setup-first dispatch, and exit-code paths were inspected. Windows and macOS launchers were not executed on their native operating systems. No unresolved blocking issue remains in the reviewed distribution state. Parent-agent native GUI and real virtual-environment installation tests provide separate end-to-end evidence.

A fresh-extraction installation subsequently exposed a POSIX standalone-Python Tcl/Tk lookup issue in copied venv executables. Setup now creates binary symlinks on POSIX and keeps Windows redirector/copy behavior. The first-setup regression is parameterized for Linux, macOS and Windows, asserting the intended `EnvBuilder.symlinks` value while preserving the same user-data and isolation checks. These platform branches are mocked tests, not native Windows/macOS execution.
