"""The reference's eight-column historical EVA/ROIC and CAGR worksheet.

Years run down the page. Inputs link to the already emitted, visible financial
model; no source-company amounts, forecasts, or valuation assumptions are used.
"""
from __future__ import annotations

from copy import copy
from decimal import Decimal, InvalidOperation, localcontext
from importlib.resources import files

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from .financial_refs import FinancialRefs

TEMPLATE_PATH = files('zaimu10').joinpath('assets').joinpath('cagr_template.xlsx')
COLUMNS = {'B': 'roic', 'C': 'invested_capital_turnover', 'D': 'aroic',
           'E': 'wacc_c', 'F': 'spread', 'G': 'invested_capital', 'H': 'eva'}


def _number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None
    return result if result.is_finite() else None


def _reference(sheet, address):
    return "'" + sheet.replace("'", "''") + "'!" + address


def _copy_style(source, target):
    target.font = copy(source.font)
    target.fill = copy(source.fill)
    target.border = copy(source.border)
    target.alignment = copy(source.alignment)
    target.number_format = source.number_format
    target.protection = copy(source.protection)


def _sheet(writer):
    if 'CAGR' in writer.book:
        writer.book.remove(writer.book['CAGR'])
    writer.cells[:] = [cell for cell in writer.cells if cell.get('sheet') != 'CAGR']
    for mapping in (writer.values, writer.cached):
        for key in list(mapping):
            if key[0] == 'CAGR':
                del mapping[key]
    ws = writer.book.create_sheet('CAGR')
    with TEMPLATE_PATH.open('rb') as stream:
        template = load_workbook(stream)
    source = template['CAGR']
    ws.sheet_format = copy(source.sheet_format)
    ws.sheet_view.showGridLines = source.sheet_view.showGridLines
    for key, dimension in source.column_dimensions.items():
        ws.column_dimensions[key] = copy(dimension)
        ws.column_dimensions[key].parent = ws
    summary = len(writer.periods) + 2
    for row in range(1, summary + 1):
        source_row = 1 if row == 1 else 12 if row == summary else 2
        ws.row_dimensions[row].height = source.row_dimensions[source_row].height
        for column in range(1, 9):
            target = ws.cell(row, column)
            _copy_style(source.cell(source_row, column), target)
            if row == 1:
                target.value = source.cell(1, column).value
            elif column > 1:
                writer.fit_number(target)
    ws['G1'] = '④投下資本（' + writer.unit_label + '）'
    ws.page_setup = copy(source.page_setup)
    ws.page_setup.id = None
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = copy(source.page_margins)
    ws.print_area = f'A1:H{summary}'
    template.close()
    return ws


def _fr_input(writer, metric, period, index):
    """Use metric identities, never a fixed FR source row or stale raw amount."""
    identities = {'supplement:FR:' + metric, 'metric:' + metric}
    matches = [cell for cell in writer.cells if cell.get('sheet') == 'FR'
               and cell.get('period') == period.key
               and (cell.get('row_key') in identities
                    or cell.get('supplemental', {}).get('metric') == metric)]
    addresses = list(dict.fromkeys(cell['address'] for cell in matches))
    if not addresses:
        rows = writer.layout_metadata.get('FR', {}).get('rows', {})
        addresses = [f'{get_column_letter(index + 2)}{row}' for row, name in rows.items()
                     if name == metric]
    if len(addresses) != 1 or 'FR' not in writer.book:
        return None, None, 'FRの対応する可視入力を一意に確認できません: ' + metric
    address = addresses[0]
    cell = writer.book['FR'][address]
    value = _number(writer.values.get(('FR', address)))
    # A cached value is trusted only while its visible financial cell exists.
    if value is None or cell.value is None:
        return None, None, 'FRの対応入力が空欄です: ' + metric
    return address, value, ''


def write_cagr(writer, dataset, refs=None):
    """Write the source's historical grid and n−1 interval EVA CAGR.

    Ordinary formulas are direct visible references and arithmetic. Missing or
    mathematically undefined source inputs remain blank with an audit reason.
    """
    if refs is None:
        refs = FinancialRefs(writer, dataset)
    ws = _sheet(writer)
    count = len(writer.periods)
    summary_row = count + 2
    metadata = {'sheet': 'CAGR', 'historical_only': True, 'forecast_generated': False,
                'source_templates': ['6947_図研 見本.xlsx'], 'columns': dict(COLUMNS),
                'periods': {}, 'summary': {}, 'missing_inputs': [],
                'definition': 'D列は見本どおりROIC×投下資本回転率。EVAは(ROIC−WACC(C))×投下資本。'}

    def emit(address, metric, period, expression, value, *, inputs=(), missing=(), note='', summary=False):
        value = _number(value)
        formula = expression if value is not None else None
        ws[address] = formula
        writer.values[('CAGR', address)] = value
        if formula is not None:
            writer.cached[('CAGR', address)] = value
        record = {'address': address, 'metric': metric, 'formula': formula,
                  'display_value': str(value) if value is not None else None,
                  'missing': list(missing), 'inputs': list(inputs), 'note': note}
        if summary:
            metadata['summary'][metric] = record
        else:
            metadata['periods'].setdefault(period.key, {})[metric] = record
        if missing:
            metadata['missing_inputs'].append({'period': period.key if period else None,
                                               'metric': metric, 'reasons': list(missing)})
        writer.cells.append({'sheet': 'CAGR', 'address': address,
            'row_key': 'supplement:CAGR:' + metric,
            'period': period.key if period else '', 'formula': formula,
            'display_value': record['display_value'], 'source': None,
            'unit': writer.unit if metric in {'invested_capital', 'eva'} else 'ratio_or_text',
            'supplemental': record, 'summary': summary})
        return value

    def arithmetic(row, column, metric, operands, expression, operation, period):
        values = [writer.values.get(('CAGR', f'{letter}{row}')) for letter in operands]
        missing = [f'CAGRの{letter}{row}入力が空欄です。'
                   for letter, value in zip(operands, values) if value is None]
        return emit(f'{column}{row}', metric, period, expression,
                    None if missing else operation(values), missing=missing,
                    inputs=[{'sheet': 'CAGR', 'address': f'{letter}{row}'} for letter in operands])

    for index, period in enumerate(writer.periods):
        row = index + 2
        ws.cell(row, 1).value = period.end.year
        for column, metric in [('B', 'roic'), ('C', 'invested_capital_turnover'), ('E', 'wacc_c')]:
            address, value, reason = _fr_input(writer, metric, period, index)
            emit(f'{column}{row}', metric, period,
                 '=' + _reference('FR', address) if address else None, value,
                 inputs=[{'sheet': 'FR', 'address': address}] if address else (),
                 missing=[reason] if reason else ())
        arithmetic(row, 'D', 'aroic', ['B', 'C'], f'=B{row}*C{row}',
                   lambda values: values[0] * values[1], period)
        arithmetic(row, 'F', 'spread', ['B', 'E'], f'=B{row}-E{row}',
                   lambda values: values[0] - values[1], period)
        capital = refs.get('invested_capital', period)
        if capital is None:
            emit(f'G{row}', 'invested_capital', period, None, None,
                 missing=[refs.reason('invested_capital', period) or '投下資本の可視入力を確認できません。'])
        else:
            emit(f'G{row}', 'invested_capital', period, '=' + capital.excel, capital.value,
                 inputs=[{'sheet': item.sheet, 'address': item.address} for item in capital.refs])
        arithmetic(row, 'H', 'eva', ['F', 'G'], f'=F{row}*G{row}',
                   lambda values: values[0] * values[1], period)

    period = writer.periods[-1] if count else None
    observations = sorted(writer.values[('CAGR', f'D{row}')] for row in range(2, count + 2)
                          if writer.values.get(('CAGR', f'D{row}')) is not None)
    if observations:
        middle = len(observations) // 2
        median = observations[middle] if len(observations) % 2 else (observations[middle - 1] + observations[middle]) / 2
        emit(f'D{summary_row}', 'aroic_median', period, f'=MEDIAN(D2:D{count + 1})', median,
             inputs=[{'sheet': 'CAGR', 'address': f'D{row}'} for row in range(2, count + 2)], summary=True,
             note='見本どおり、数値があるD列の中央値。')
    else:
        emit(f'D{summary_row}', 'aroic_median', period, None, None, summary=True,
             missing=['中央値の数値入力がありません。'])
    start = writer.values.get(('CAGR', 'H2')) if count else None
    end = writer.values.get(('CAGR', f'H{count + 1}')) if count else None
    reason = ''
    if count < 2:
        reason = '年率換算には2年度以上が必要です。'
    elif start is None or end is None:
        reason = '初年度又は最終年度のEVA入力が空欄です。'
    elif start == 0:
        reason = '初年度EVAが0のため年率換算できません。'
    elif end / start < 0:
        reason = 'EVAが正負をまたぐため、見本の累乗式を実数で計算できません。'
    result = None
    note = f'{count}年度の観測値、複利期間は{max(count - 1, 0)}年。'
    if not reason:
        with localcontext() as context:
            context.prec = 34
            ratio = end / start
            result = Decimal(-1) if ratio == 0 else ratio ** (Decimal(1) / Decimal(count - 1)) - 1
        if start < 0 and end < 0:
            note += '両端EVAが負数です。見本の同符号比率の式を保持し、改善率とは解釈しません。'
    emit(f'H{summary_row}', 'eva_cagr', period,
         f'=(H{count + 1}/H2)^(1/{count - 1})-1' if not reason else None, result,
         missing=[reason] if reason else (), note=note, summary=True,
         inputs=[{'sheet': 'CAGR', 'address': 'H2'}, {'sheet': 'CAGR', 'address': f'H{count + 1}'}] if count else ())
    metadata['summary']['eva_cagr']['intervals'] = max(count - 1, 0)
    writer.layout_metadata['CAGR'] = {'rows': {'annual': {p.key: index + 2 for index, p in enumerate(writer.periods)},
                                            'summary': summary_row},
                                      'last_row': summary_row, 'periods': [p.key for p in writer.periods],
                                      'columns': dict(COLUMNS)}
    return metadata
