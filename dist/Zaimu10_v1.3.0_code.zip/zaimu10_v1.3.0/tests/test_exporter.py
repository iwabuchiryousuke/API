"""Template fidelity, transparent calculations, signed cash-flow semantics."""
from copy import deepcopy, copy
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

from openpyxl import load_workbook
import pytest

from zaimu10.excel import export_workbook, era_date, TEMPLATE_PATH, PL_LABELS
from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source

OLD=Period(date(2023,7,1),date(2024,6,30))
NEW=Period(date(2024,7,1),date(2025,6,30))
NS='http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'


def row(statement,local,label,old,new,section=(),*,heading=False,role=None):
    role=role or ('end' if statement.startswith('BS') else 'duration')
    result=Row(json.dumps([statement,'jppfs_cor:'+local,[],role,'JPY','consolidated'],ensure_ascii=False),
               label,statement,tuple(section),len(section)+1,is_heading=heading)
    if not heading:
        for p,value in [(OLD,old),(NEW,new)]:
            if value is None:continue
            value=Decimal(str(value))*1000
            source=Source('S100TEST','statement.xbrl','https://example.jp/S100TEST',
                          submitted='2025-09-20',context_id=p.key+role,
                          concept='{'+NS+'}'+local,unit='JPY',decimals='-3',
                          original_label=label,raw_value=str(value/1000),scale=3,basis='consolidated')
            result.values[p.key]=Cell(value,source)
    return result


def dataset():
    ds=Dataset('7826','株式会社フルヤ金属','consolidated',[NEW,OLD],
               accounting_standard='J-GAAP',fetched_at='2026-11-18T10:00:00+09:00')
    ds.period_bases={p.key:'consolidated' for p in ds.periods}
    ds.period_standards={p.key:'J-GAAP' for p in ds.periods}
    pl=[('NetSales','売上高',100000,120000),('CostOfSales','売上原価',60000,70000),
        ('GrossProfit','売上総利益',40000,50000),
        ('SellingGeneralAndAdministrativeExpenses','販売費及び一般管理費',10000,12000),
        ('OperatingIncome','営業利益',30000,38000),('NonOperatingIncome','営業外収益合計',2000,3000),
        ('NonOperatingExpenses','営業外費用合計',1000,1000),('OrdinaryIncome','経常利益',31000,40000),
        ('ExtraordinaryIncome','特別利益合計',1000,0),('ExtraordinaryLoss','特別損失合計',0,1000),
        ('IncomeBeforeIncomeTaxes','税金等調整前当期純利益',32000,39000),('IncomeTaxes','法人税等合計',10000,12000),
        ('ProfitLoss','当期純利益',22000,27000),
        ('ProfitLossAttributableToOwnersOfParent','親会社株主に帰属する当期純利益',21000,26000)]
    ds.rows['PL']=[row('PL',*data) for data in pl]
    a=('資産の部',);ca=a+('流動資産',);nc=a+('固定資産',);ppe=nc+('有形固定資産',);ia=nc+('無形固定資産',);invest=nc+('投資その他の資産',)
    ds.rows['BS_A']=[row('BS_A','division','資産の部',None,None,a,heading=True),
        row('BS_A','CashAndDeposits','現金及び預金',100,150,ca),
        row('BS_A','NotesReceivableTrade','受取手形',10,10,ca),row('BS_A','AccountsReceivableTrade','売掛金',20,40,ca),
        row('BS_A','MerchandiseAndFinishedGoods','商品及び製品',20,25,ca),
        row('BS_A','WorkInProcess','仕掛品',10,12,ca),row('BS_A','RawMaterialsAndSupplies','原材料及び貯蔵品',5,8,ca),
        row('BS_A','OtherCA','その他',5,5,ca),row('BS_A','CurrentAssets','流動資産合計',170,250,ca),
        row('BS_A','BuildingsAndStructures','建物及び構築物',100,120,ppe),
        row('BS_A','AccumulatedDepreciationBuildingsAndStructures','減価償却累計額',-30,-40,ppe),
        row('BS_A','BuildingsAndStructuresNet','建物及び構築物（純額）',70,80,ppe),
        row('BS_A','Land','土地',30,30,ppe),row('BS_A','PropertyPlantAndEquipment','有形固定資産合計',100,110,ppe),
        row('BS_A','IntangibleAssets','無形固定資産合計',10,15,ia),
        row('BS_A','InvestmentSecurities','投資有価証券',20,25,invest),row('BS_A','OtherIOA','その他',5,10,invest),
        row('BS_A','InvestmentsAndOtherAssets','投資その他の資産合計',25,35,invest),
        row('BS_A','NoncurrentAssets','固定資産合計',135,160,nc),row('BS_A','Assets','資産合計',305,410,a)]
    li=('負債の部',);cl=li+('流動負債',);ncl=li+('固定負債',);eq=('純資産の部',);sh=eq+('株主資本',)
    ds.rows['BS_LE']=[row('BS_LE','division','負債の部',None,None,li,heading=True),
        row('BS_LE','AccountsPayableTrade','買掛金',50,60,cl),row('BS_LE','IncomeTaxesPayable','未払法人税等',5,10,cl),
        row('BS_LE','CurrentLiabilities','流動負債合計',55,70,cl),row('BS_LE','LongTermLoansPayable','長期借入金',20,30,ncl),
        row('BS_LE','NoncurrentLiabilities','固定負債合計',20,30,ncl),row('BS_LE','Liabilities','負債合計',75,100,li),
        row('BS_LE','eqdivision','純資産の部',None,None,eq,heading=True),
        row('BS_LE','CapitalStock','資本金',100,100,sh),row('BS_LE','RetainedEarnings','利益剰余金',130,210,sh),
        row('BS_LE','ShareholdersEquity','株主資本合計',230,310,sh),row('BS_LE','NetAssets','純資産合計',230,310,eq),
        row('BS_LE','LiabilitiesAndNetAssets','負債純資産合計',305,410,())]
    op=('営業活動によるキャッシュ・フロー',);inv=('投資活動によるキャッシュ・フロー',);fin=('財務活動によるキャッシュ・フロー',)
    cf=[('IncomeBeforeIncomeTaxes','税金等調整前当期純利益',32000,39000,op),
        ('DepreciationAndAmortizationOpeCF','減価償却費',1000,1200,op),
        ('DecreaseIncreaseInNotesAndAccountsReceivableTradeOpeCF','売上債権の増減額（△は増加）',-1000,-100,op),
        ('DecreaseIncreaseInInventoriesOpeCF','棚卸資産の増減額（△は増加）',-100,-50,op),
        ('IncreaseDecreaseInNotesAndAccountsPayableTradeOpeCF','仕入債務の増減額（△は減少）',200,300,op),
        ('SubtotalOpeCF','小計',32100,40350,op),('IncomeTaxesPaidOpeCF','法人税等の支払額',-1000,-1500,op),
        ('ProceedsFromInsuranceIncomeOpeCF','保険金の受取額',0,50,op),
        ('NetCashProvidedByUsedInOperatingActivities','営業活動によるキャッシュ・フロー',31100,38900,op),
        ('PurchaseOfPropertyPlantAndEquipmentInvCF','有形固定資産の取得による支出',-1000,-100,inv),
        ('NetCashProvidedByUsedInInvestmentActivities','投資活動によるキャッシュ・フロー',-1000,-100,inv),
        ('NetIncreaseDecreaseInShortTermLoansPayableFinCF','短期借入金の純増減額',22,100,fin),
        ('NetCashProvidedByUsedInFinancingActivities','財務活動によるキャッシュ・フロー',22,100,fin),
        ('EffectOfExchangeRateChangeOnCashAndCashEquivalents','現金及び現金同等物に係る換算差額',0,0,()),
        ('NetIncreaseDecreaseInCashAndCashEquivalents','現金及び現金同等物の増減額',30122,38900,())]
    ds.rows['CF']=[row('CF',*data) for data in cf]
    ds.rows['CF'] += [row('CF','CashAndCashEquivalents','現金及び現金同等物の期首残高',1000,31122,(),role='begin'),
                      row('CF','CashAndCashEquivalents','現金及び現金同等物の期末残高',31122,70022,(),role='end')]
    return ds


def find_row(ws,label):
    return next(c.row for row in ws for c in row[:1] if c.value==label)


def test_sanitized_template_has_styles_but_no_financial_values_or_formulas():
    with TEMPLATE_PATH.open('rb') as stream:wb=load_workbook(stream)
    assert wb.sheetnames==['PL','BS-A','BS-L&E','CF']
    assert not wb._external_links
    assert not wb.defined_names
    assert all(c.value is None for ws in wb for row in ws for c in row if c.column>1)
    assert not any(c.data_type=='f' for ws in wb for row in ws for c in row)
    wb.close()


def test_fixed_pl_template_layout_and_original_styles(tmp_path):
    ds=dataset();path=export_workbook(ds,tmp_path/'financials.xlsx','thousand')
    wb=load_workbook(path);ws=wb['PL']
    with TEMPLATE_PATH.open('rb') as stream:template=load_workbook(stream)
    assert wb.sheetnames==['PL','BS-A','BS-L,E','CF']
    for sheet in wb:
        assert sheet['A1'].value and '単位:千円' in sheet['A1'].value
        assert sheet['B1'].value=='R6-2024\n6/30'
        assert sheet['C1'].value=='R7-2025\n6/30'
    assert ws['A1'].value=='連結損益計算書\n単位:千円'
    assert ws['B1'].value=='R6-2024\n6/30'
    assert ws['C1'].value=='R7-2025\n6/30'
    assert ws.max_row==22
    for number,label in PL_LABELS.items():
        assert ws.cell(number,1).value==label
        for col in [1,2,3]:
            actual,original=ws.cell(number,col),template['PL'].cell(number,col)
            assert copy(actual.font)==copy(original.font)
            assert copy(actual.fill)==copy(original.fill)
            assert copy(actual.border)==copy(original.border)
            alignment=copy(actual.alignment)
            if col>1:
                assert alignment.shrink_to_fit is True and alignment.wrap_text is not True
                alignment.shrink_to_fit=original.alignment.shrink_to_fit
                alignment.wrap_text=original.alignment.wrap_text
            assert alignment==copy(original.alignment)
        assert ws.row_dimensions[number].height==template['PL'].row_dimensions[number].height
    assert ws.column_dimensions['A'].width==template['PL'].column_dimensions['A'].width
    assert ws.column_dimensions['B'].width==template['PL'].column_dimensions['B'].width
    assert ws.freeze_panes=='B1'
    assert '7826 フルヤ金属 2025-06-30'==wb.properties.title
    wb.close();template.close()


def test_pl_formulas_cached_values_and_total_profit_not_parent_profit(tmp_path):
    ds=dataset();path=export_workbook(ds,tmp_path/'formulas.xlsx','thousand')
    wb=load_workbook(path);cache=load_workbook(path,data_only=True)
    ws=wb['PL'];v=cache['PL']
    assert ws['B5'].value=='=B2-B4'
    assert ws['C14'].value=='=C9+C12-C13'
    assert ws['C17'].value=='=C14+C15-C16'
    assert ws['C19'].value=='=C17-C18'
    assert v['B19'].value==22000 and v['C19'].value==27000
    assert abs(v['C3'].value-0.2)<1e-12
    assert v['B3'].value is None
    assert abs(Decimal(str(v['C6'].value))-Decimal(5)/12)<Decimal('1e-12')
    assert abs(Decimal(str(v['C22'].value))-Decimal(12)/39)<Decimal('1e-12')
    assert 'S100TEST' in ws['C19'].comment.text
    assert ds.export_metadata['cells'] and any(item['formula'] for item in ds.export_metadata['cells'])
    wb.close();cache.close()


def test_bs_receivables_grouped_once_inventory_order_colors_and_subtotal_formulas(tmp_path):
    ds=dataset();path=export_workbook(ds,tmp_path/'bs.xlsx','thousand')
    wb=load_workbook(path);cache=load_workbook(path,data_only=True);ws=wb['BS-A'];v=cache['BS-A']
    assert ws['A2'].value.strip()=='資産の部'
    assert [ws.cell(i,1).value for i in range(3,8)]==['現金及び預金','売掛金及び受取手形','商品及び製品','仕掛品','原材料及び貯蔵品']
    assert ws['A4'].fill.fgColor.rgb=='FFF4EDC2'
    assert all(ws.cell(i,1).fill.fgColor.rgb=='FFC7FFD8' for i in [5,6,7])
    assert ws['B4'].data_type=='n' and v['B4'].value==30  # proven normalized source group stays directly editable
    assert '受取手形' in ws['B4'].comment.text and '売掛金' in ws['B4'].comment.text
    current=find_row(ws,'流動資産計');ppe=find_row(ws,'有形固定資産計');assets=find_row(ws,'資産合計')
    assert 'SUM(B3:B8)' in ws.cell(current,2).value
    assert v.cell(current,2).value==170
    assert v.cell(ppe,3).value==110
    assert v.cell(assets,3).value==410
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    payable=find_row(wb['BS-L,E'],'買掛金')
    assert wb['BS-L,E'].cell(payable,1).fill.fgColor.rgb=='FFFFEAF6'
    wb.close();cache.close()


def test_absent_bs_and_cf_items_removed_but_fixed_pl_rows_stay(tmp_path):
    path=export_workbook(dataset(),tmp_path/'omit.xlsx','thousand');wb=load_workbook(path)
    assert 'のれん償却額(+)' not in [r[0].value for r in wb['CF']]
    assert 'デリバティブ債権' not in [r[0].value for r in wb['BS-A']]
    assert wb['PL']['A15'].value=='特別利益'
    assert wb['PL']['A16'].value=='特別損失'
    summary=find_row(wb['CF'],'営業CF')
    assert wb['CF'].cell(summary+3,1).value=='営業CF対投資CF比率'
    assert summary<70
    assert all(cell.fill.patternType is None for row in wb['CF'] for cell in row[:1]
               if cell.value is None)
    wb.close()


def test_cf_signed_values_formula_totals_source_colors_and_actual_comparison_arrows(tmp_path):
    ds=dataset();path=export_workbook(ds,tmp_path/'cf.xlsx','thousand');wb=load_workbook(path);cached=load_workbook(path,data_only=True)
    ws=wb['CF'];v=cached['CF']
    assets=find_row(ws,'有形固定資産の取得による支出');dep=find_row(ws,'減価償却費(+)')
    assert v.cell(assets,2).value==-1000
    assert ws.cell(assets,1).fill.fgColor.rgb=='FFCFFF00'
    assert ws.cell(dep,1).fill.fgColor.type=='theme' and ws.cell(dep,1).fill.fgColor.theme==7
    cfo=find_row(ws,'営業活動によるキャッシュ・フロー');cfi=find_row(ws,'投資活動によるキャッシュフロー')
    assert ws.cell(cfo,2).data_type=='f' and ws.cell(cfi,2).data_type=='f'
    assert v.cell(cfo,3).value==38900  # includes insurance receipt, unlike the source template's mistaken formula
    summary=find_row(ws,'営業CF');ratio=summary+3
    assert v.cell(summary,3).value=='+↗'
    assert v.cell(summary+1,3).value=='－↗'  # -1000 -> -100 increases in real signed values
    assert v.cell(summary+2,3).value=='+↗'
    assert v.cell(summary,2).value=='+'
    assert v.cell(ratio,3).value==389
    assert 'COUNT' in ws.cell(ratio,3).value and '>0' in ws.cell(ratio,3).value and '<0' in ws.cell(ratio,3).value
    with TEMPLATE_PATH.open('rb') as stream:template=load_workbook(stream)
    assert ws.cell(ratio,3).number_format==template['CF']['C73'].number_format=='0.00%;[White]\\-0.00%'
    assert wb['PL']['C6'].number_format=='0.00%;[Red]\\-0.00%'
    template.close()
    closing=find_row(ws,'現金及び現金同等物の期末残高(調)')
    assert v.cell(closing,3).value==70022
    wb.close();cached.close()


@pytest.mark.parametrize('before,after,expected',[(-1000,-100,'－↗'),(-50,30,'+↗'),(22,100,'+↗'),(0,0,'0→'),(5,5,'+→'),(100,-10,'－↘')])
def test_cashflow_arrows_compare_signed_amounts_and_conditional_ratio(tmp_path,before,after,expected):
    ds=dataset();ds.rows['CF']=[row('CF','NetCashProvidedByUsedInOperatingActivities','営業活動によるキャッシュ・フロー',before,after,('営業活動によるキャッシュ・フロー',)),
                               row('CF','NetCashProvidedByUsedInInvestmentActivities','投資活動によるキャッシュ・フロー',10,10,('投資活動によるキャッシュ・フロー',))]
    wb=load_workbook(export_workbook(ds,tmp_path/'arrows.xlsx','thousand'),data_only=True)
    summary=find_row(wb['CF'],'営業CF');ratio=summary+3
    assert wb['CF'].cell(summary,3).value==expected
    assert wb['CF'].cell(ratio,2).value is None and wb['CF'].cell(ratio,3).value is None
    assert wb['CF'].cell(ratio,3).number_format=='0.00%;[White]\\-0.00%'
    wb.close()


def test_rounding_tolerance_and_material_difference_recorded_in_audit(tmp_path):
    ds=dataset()
    current=next(r for r in ds.rows['BS_A'] if 'CurrentAssets' in r.key)
    current.values[OLD.key].value+=1000
    current.values[NEW.key].value+=1000000
    export_workbook(ds,tmp_path/'rounding.xlsx','thousand')
    checks=[c for c in ds.checks if c['check']=='presentation_total' and c['sheet']=='BS-A']
    assert any(c['period']==OLD.key and c['ok'] and abs(Decimal(c['difference_jpy']))==1000 for c in checks)
    assert any(c['period']==NEW.key and c['ok'] is False for c in checks)
    assert ds.warnings


def test_parent_formula_cache_uses_calculated_children_and_preserves_rounding_trace(tmp_path):
    ds=dataset()
    stock=next(r for r in ds.rows['BS_A'] if 'WorkInProcess' in r.key)
    stock.values[OLD.key].value-=1000
    wb=load_workbook(export_workbook(ds,tmp_path/'nested-rounding.xlsx','thousand'),data_only=True)
    ws=wb['BS-A'];current=find_row(ws,'流動資産計');fixed=find_row(ws,'固定資産合計');total=find_row(ws,'資産合計')
    assert ws.cell(current,2).value==169
    assert ws.cell(total,2).value==ws.cell(current,2).value+ws.cell(fixed,2).value==304
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    wb.close()


def test_auto_unit_and_mixed_basis_standard_headers_use_source_metadata(tmp_path):
    ds=dataset();ds.basis='mixed';ds.accounting_standard='mixed'
    ds.period_bases={OLD.key:'standalone',NEW.key:'consolidated'}
    ds.period_standards={OLD.key:'J-GAAP',NEW.key:'IFRS'}
    for rows in ds.rows.values():
        for record in rows:
            if NEW.key in record.values:record.values[NEW.key].source.scale=6
    wb=load_workbook(export_workbook(ds,tmp_path/'auto.xlsx','auto'))
    assert '単位:百万円' in wb['PL']['A1'].value
    assert wb['PL']['B1'].value.endswith('個別\n日本基準')
    assert wb['PL']['C1'].value.endswith('連結\nIFRS')
    assert wb['PL'].row_dimensions[1].height==50
    wb.close()


def test_formula_like_untrusted_label_is_literal_text(tmp_path):
    ds=dataset();ds.rows['BS_A'].append(row('BS_A','Unknown','="injection"',1,2,('資産の部','その他区分')))
    wb=load_workbook(export_workbook(ds,tmp_path/'literal.xlsx','thousand'))
    cells=[r[0] for r in wb['BS-A'] if r[0].value=='="injection"']
    assert len(cells)==1 and cells[0].data_type=='s'
    wb.close()


def test_actual_zuken_original_filing_exports_with_reconciled_totals(tmp_path):
    from zaimu10.parser import parse_filing
    fixture=Path(__file__).parent/'fixtures'/'zuken_2025_ixbrl.json.gz'
    with gzip.open(fixture,'rt',encoding='utf-8') as stream:pages=json.load(stream)
    ds=parse_filing(Filing('S100W07I',code='6947',company='図研',submitted='2025-06-20'),pages)
    path=export_workbook(ds,tmp_path/'actual.xlsx','auto');wb=load_workbook(path,data_only=True)
    assert wb['PL']['C2'].value==40736294
    assert abs(wb['PL']['C19'].value-5247956)<=5
    assets=find_row(wb['BS-A'],'資産合計')
    assert abs(wb['BS-A'].cell(assets,3).value-63274260)<=20
    failed=[c for c in ds.checks if c['check']=='presentation_total' and c['ok'] is False]
    assert failed==[]
    assert wb['CF'].cell(find_row(wb['CF'],'営業CF対投資CF比率'),3).value is None  # investment CF is positive
    wb.close()


def test_actual_ifrs_preserves_sga_operating_adjustments_and_current_noncurrent_boundaries(tmp_path):
    from zaimu10.parser import parse_filing
    fixture=Path(__file__).parent/'fixtures'/'nitori_2026_ixbrl.json.gz'
    with gzip.open(fixture,'rt',encoding='utf-8') as stream:pages=json.load(stream)
    ds=parse_filing(Filing('S100TEST',code='9843',company='ニトリ'),pages)
    path=export_workbook(ds,tmp_path/'ifrs.xlsx','auto')
    wb=load_workbook(path);cached=load_workbook(path,data_only=True)
    assert cached['PL']['B8'].value==348576  # original SGA, not an invented balancing amount
    assert abs(cached['PL']['B9'].value-117665)<=5
    assert '+(4051)' in wb['PL']['B9'].value and '-(14998)' in wb['PL']['B9'].value
    assert 'OtherIncomeIFRS' in wb['PL']['B9'].comment.text
    assert 'ShareOfProfitLossOfInvestmentsAccountedForUsingEquityMethodIFRS' in wb['PL']['B9'].comment.text
    assert cached['PL']['B12'].value==3019 and cached['PL']['B13'].value==3236
    le=cached['BS-L,E'];noncurrent=find_row(le,'Ⅱ 固定負債計');total=find_row(le,'負債純資産合計')
    assert abs(le.cell(noncurrent,2).value-270019)<=5
    assert abs(le.cell(total,2).value-1529421)<=10
    cfo=find_row(cached['CF'],'営業活動によるキャッシュ・フロー')
    ending=find_row(cached['CF'],'現金及び現金同等物の期末残高(調)')
    assert abs(cached['CF'].cell(cfo,2).value-144384)<=10
    assert abs(cached['CF'].cell(ending,2).value-136001)<=10
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    wb.close();cached.close()


def test_unknown_ifrs_operating_adjustment_keeps_disclosed_profit_without_balancing_plug(tmp_path):
    from zaimu10.parser import parse_filing
    fixture=Path(__file__).parent/'fixtures'/'nitori_2026_ixbrl.json.gz'
    with gzip.open(fixture,'rt',encoding='utf-8') as stream:pages=json.load(stream)
    ds=parse_filing(Filing('S100TEST',code='9843',company='ニトリ'),pages)
    ds.rows['PL']=[r for r in ds.rows['PL'] if not any(c.source.concept.endswith('}OtherIncomeIFRS') for c in r.values.values())]
    path=export_workbook(ds,tmp_path/'ifrs-unknown.xlsx','auto');wb=load_workbook(path)
    assert wb['PL']['B9'].value==117665 and wb['PL']['B9'].data_type!='f'
    assert '差額を推測で補いません' in wb['PL']['B9'].comment.text
    assert any(c['check']=='presentation_formula_not_applicable' and c['ok'] is None for c in ds.checks)
    wb.close()


def test_late_formula_warning_is_visible_in_header_comment_without_metadata_rows(tmp_path):
    ds=dataset();next(r for r in ds.rows['BS_A'] if 'CurrentAssets' in r.key).values[NEW.key].value+=1000000
    wb=load_workbook(export_workbook(ds,tmp_path/'warning.xlsx','thousand'))
    for ws in wb:
        assert '要確認:' in ws['A1'].comment.text
        assert '差額' in ws['A1'].comment.text
    assert wb['PL']['A2'].value=='売上高'
    wb.close()


def test_unknown_working_adjustments_after_old_basis_block_are_included_once_before_subtotal(tmp_path):
    ds=dataset();ds.basis='mixed';ds.period_bases={OLD.key:'standalone',NEW.key:'consolidated'}
    operating=[r for r in ds.rows['CF'] if r.section==('営業活動によるキャッシュ・フロー',)]
    blocks=[]
    for period,basis in [(OLD,'standalone'),(NEW,'consolidated')]:
        for original in operating:
            copy_row=deepcopy(original)
            copy_row.values={period.key:copy_row.values[period.key]}
            parts=json.loads(copy_row.key);parts[-1]=basis;copy_row.key=json.dumps(parts,ensure_ascii=False)
            copy_row.values[period.key].source.basis=basis
            if period==NEW and 'SubtotalOpeCF' in copy_row.key:
                a=row('CF','TransferFromInventoriesToFixedAssetsOpeCF','棚卸資産から固定資産への振替',None,-1384,copy_row.section)
                b=row('CF','TransferFromFixedAssetsToInventoriesOpeCF','固定資産から棚卸資産への振替',None,468,copy_row.section)
                blocks.extend([a,b])
                copy_row.values[period.key].value-=916000
            if period==NEW and 'NetCashProvidedByUsedInOperatingActivities' in copy_row.key:
                copy_row.values[period.key].value-=916000
            blocks.append(copy_row)
    ds.rows['CF']=blocks
    path=export_workbook(ds,tmp_path/'basis-working.xlsx','thousand');wb=load_workbook(path,data_only=True)
    cf=wb['CF'];mid=find_row(cf,'中計');cfo=find_row(cf,'営業活動によるキャッシュ・フロー')
    assert cf.cell(mid,3).value==39434
    assert cf.cell(cfo,3).value==37984
    assert len([r for r in cf if r[0].value=='棚卸資産から固定資産への振替'])==1
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total' and c['sheet']=='CF')
    wb.close()


def test_original_filing_annotation_preserves_unknown_cf_group_through_merge(tmp_path):
    from zaimu10.presentation import annotate_filing
    ds=dataset()
    transfer=row('CF','TransferFromInventoriesToFixedAssetsOpeCF','棚卸資産から固定資産への振替',-100,-200,
                 ('営業活動によるキャッシュ・フロー',))
    subtotal=next(i for i,r in enumerate(ds.rows['CF']) if 'SubtotalOpeCF' in r.key)
    ds.rows['CF'].insert(subtotal,transfer)
    for record in ds.rows['CF']:
        if 'SubtotalOpeCF' in record.key or 'NetCashProvidedByUsedInOperatingActivities' in record.key:
            record.values[OLD.key].value-=100000
            record.values[NEW.key].value-=200000
    ds=annotate_filing(ds)
    assert transfer.values[NEW.key].display_group==''  # the original dataset remains untouched
    saved=next(r for r in ds.rows['CF'] if 'TransferFromInventoriesToFixedAssetsOpeCF' in r.key)
    assert saved.values[NEW.key].display_group=='operating_working'
    wb=load_workbook(export_workbook(ds,tmp_path/'annotated.xlsx','thousand'),data_only=True)
    mid=find_row(wb['CF'],'中計')
    assert wb['CF'].cell(mid,3).value==40150
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total' and c['sheet']=='CF')
    wb.close()


@pytest.mark.parametrize('combined',[False,True])
def test_net_asset_includes_impairment_and_never_double_counts_combined_contra(tmp_path,combined):
    ds=dataset();net=next(i for i,r in enumerate(ds.rows['BS_A']) if 'BuildingsAndStructuresNet' in r.key)
    section=ds.rows['BS_A'][net].section
    impairment=row('BS_A','AccumulatedImpairmentLossBuildingsAndStructures','減損損失累計額',-5,-8,section)
    ds.rows['BS_A'].insert(net,impairment)
    if combined:
        ds.rows['BS_A'].insert(net+1,row('BS_A','AccumulatedDepreciationAndImpairmentLossBuildingsAndStructures',
                                       '減価償却及び減損損失累計額',-35,-48,section))
    reduce={'BS_A':{'BuildingsAndStructuresNet','PropertyPlantAndEquipment','NoncurrentAssets','Assets'},
            'BS_LE':{'RetainedEarnings','ShareholdersEquity','NetAssets','LiabilitiesAndNetAssets'}}
    for statement,names in reduce.items():
        for record in ds.rows[statement]:
            if any(c.source.concept.rsplit('}',1)[-1] in names for c in record.values.values()):
                record.values[OLD.key].value-=5000
                record.values[NEW.key].value-=8000
    path=export_workbook(ds,tmp_path/f'contra-{combined}.xlsx','thousand')
    wb=load_workbook(path);cached=load_workbook(path,data_only=True);ws=wb['BS-A']
    netrow=find_row(ws,'建物及び構築物（純額）');pperow=find_row(ws,'有形固定資産計')
    assert cached['BS-A'].cell(netrow,2).value==65
    assert cached['BS-A'].cell(netrow,3).value==72
    assert cached['BS-A'].cell(pperow,2).value==95
    assert cached['BS-A'].cell(pperow,3).value==102
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    formula=ws.cell(netrow,2).value
    if combined:
        combo=find_row(ws,'減価償却及び減損損失累計額')
        assert combo<netrow
        saved=next(item for item in ds.export_metadata['layout']['BS-A']['sum_rows'] if item['row']==netrow)
        assert saved['modes'][OLD.key]=='calculated'
        assert combo in saved['periods'][OLD.key]['rows']
        assert find_row(ws,'減損損失累計額') not in saved['periods'][OLD.key]['rows']
        assert '合算された償却・減損累計' in saved['periods'][OLD.key]['reason']
    else:
        saved=next(item for item in ds.export_metadata['layout']['BS-A']['sum_rows'] if item['row']==netrow)
        assert saved['range'][0]<=find_row(ws,'減損損失累計額')<=saved['range'][1]
        assert saved['modes'][OLD.key]=='calculated'
    wb.close();cached.close()


def test_contra_with_asset_class_suffix_and_source_spelling_variation_after_net_row(tmp_path):
    ds=dataset()
    changes={'BuildingsAndStructures':'RightOfUseAssetsPPE',
             'AccumulatedDepreciationBuildingsAndStructures':'AccumulatedDepreclationRightOfUseAssets',
             'BuildingsAndStructuresNet':'RightOfUseAssetsNetPPE'}
    contra=None
    for record in ds.rows['BS_A']:
        for fact in record.values.values():
            local=fact.source.concept.rsplit('}',1)[-1]
            if local in changes:fact.source.concept='{'+NS+'}'+changes[local]
        if 'AccumulatedDepreciationBuildingsAndStructures' in record.key:contra=record
    ds.rows['BS_A'].remove(contra)
    target=next(i for i,r in enumerate(ds.rows['BS_A']) if 'BuildingsAndStructuresNet' in r.key)
    ds.rows['BS_A'].insert(target+1,contra)  # authentic merged-year ordering case
    path=export_workbook(ds,tmp_path/'suffix-contra.xlsx','thousand')
    wb=load_workbook(path,data_only=True)
    netrow=find_row(wb['BS-A'],'建物及び構築物（純額）')
    assert wb['BS-A'].cell(netrow,2).value==70
    assert wb['BS-A'].cell(find_row(wb['BS-A'],'有形固定資産計'),3).value==110
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    wb.close()


def test_mixed_history_title_uses_latest_period_basis(tmp_path):
    ds=dataset();ds.basis='mixed';ds.period_bases={OLD.key:'consolidated',NEW.key:'standalone'}
    wb=load_workbook(export_workbook(ds,tmp_path/'latest-basis.xlsx','thousand'))
    for ws in wb:
        assert ws['A1'].value.startswith('個別')
        assert ws['B1'].value.endswith('連結')
        assert ws['C1'].value.endswith('個別')
    wb.close()


def test_stitched_parent_before_later_profile_children_uses_original_per_year_hierarchy(tmp_path):
    from zaimu10.presentation import annotate_filing
    base=dataset();annual=[]
    for period,basis in [(OLD,'standalone'),(NEW,'consolidated')]:
        one=deepcopy(base);one.periods=[period];one.basis=basis
        one.period_bases={period.key:basis};one.period_standards={period.key:'J-GAAP'}
        for records in one.rows.values():
            for record in records:
                record.values={period.key:record.values[period.key]} if period.key in record.values else {}
                if record.is_heading:
                    record.key='heading:'+record.statement+record.label
                else:
                    key=json.loads(record.key);key[-1]=basis;record.key=json.dumps(key,ensure_ascii=False)
                for fact in record.values.values():fact.source.basis=basis
        if period==OLD:
            at=next(i for i,r in enumerate(one.rows['BS_A']) if 'IntangibleAssets' in r.key)
            section=one.rows['BS_A'][at].section
            software=row('BS_A','Software','ソフトウエア',4,None,section)
            other=row('BS_A','OtherIA','その他',6,None,section)
            for record in [software,other]:
                record.values[OLD.key].source.basis=basis
                key=json.loads(record.key);key[-1]=basis;record.key=json.dumps(key,ensure_ascii=False)
            one.rows['BS_A'][at:at]=[software,other]
        else:
            at=next(i for i,r in enumerate(one.rows['BS_A']) if 'CurrentAssets' in r.key)
            one.rows['BS_A'].insert(at,row('BS_A','DerivativesCA','デリバティブ債権',None,20,
                                          ('資産の部','流動資産')))
            for statement,names in {'BS_A':{'CurrentAssets','Assets'},
                                    'BS_LE':{'RetainedEarnings','ShareholdersEquity','NetAssets','LiabilitiesAndNetAssets'}}.items():
                for record in one.rows[statement]:
                    if any(c.source.concept.rsplit('}',1)[-1] in names for c in record.values.values()):
                        record.values[NEW.key].value+=20000
            # The newer filing has no separate intangible section heading.
            next(r for r in one.rows['BS_A'] if 'IntangibleAssets' in r.key).section=('資産の部','固定資産')
        annual.append(annotate_filing(one))
    merged=deepcopy(base);merged.basis='mixed';merged.period_bases={OLD.key:'standalone',NEW.key:'consolidated'}
    merged.rows={statement:annual[0].rows[statement]+annual[1].rows[statement]
                 for statement in base.rows}
    path=export_workbook(merged,tmp_path/'source-hierarchy.xlsx','thousand')
    wb=load_workbook(path);cached=load_workbook(path,data_only=True);ws=wb['BS-A']
    current=find_row(ws,'流動資産計');derivative=find_row(ws,'デリバティブ債権')
    assert derivative<current  # every year's source child now precedes its common parent
    interval=next(item['range'] for item in merged.export_metadata['layout']['BS-A']['sum_rows'] if item['row']==current)
    assert interval[0]<=derivative<=interval[1]
    assert ws.cell(derivative,2).value is None
    assert cached['BS-A'].cell(current,2).value==170
    assert cached['BS-A'].cell(current,3).value==270
    fixed=find_row(ws,'固定資産合計');total=find_row(ws,'資産合計')
    assert cached['BS-A'].cell(fixed,2).value==135  # old IA details aren't added to the IA subtotal twice
    assert cached['BS-A'].cell(total,3).value==430
    assert not any(c['ok'] is False for c in merged.checks if c['check']=='presentation_total')
    assert '原文区分:' in ws.cell(current,3).comment.text
    wb.close();cached.close()


@pytest.mark.parametrize('total_inside_subsection',[True,False])
def test_plain_equity_subtotals_cover_their_details_once_without_summing_other_capital(total_inside_subsection,tmp_path):
    from zaimu10.presentation import annotate_filing
    ds=dataset();root=('純資産の部','株主資本');capital=root+('資本剰余金',);retained=root+('利益剰余金',)
    at=next(i for i,r in enumerate(ds.rows['BS_LE']) if 'RetainedEarnings' in r.key)
    ds.rows['BS_LE'][at:at]=[
        row('BS_LE','LegalCapitalSurplus','資本準備金',20,25,capital),
        row('BS_LE','CapitalSurplus','資本剰余金',20,25,capital if total_inside_subsection else root),
        row('BS_LE','LegalRetainedEarnings','利益準備金',10,10,retained),
        row('BS_LE','GeneralReserve','別途積立金',120,200,retained+('その他利益剰余金',))]
    next(r for r in ds.rows['BS_LE'] if any(c.source.concept.endswith('}RetainedEarnings') for c in r.values.values())).section=retained if total_inside_subsection else root
    updates={'BS_LE':{'ShareholdersEquity','NetAssets','LiabilitiesAndNetAssets'},
             'BS_A':{'OtherCA','CurrentAssets','Assets'}}
    for statement,names in updates.items():
        for record in ds.rows[statement]:
            if any(c.source.concept.rsplit('}',1)[-1] in names for c in record.values.values()):
                record.values[OLD.key].value+=20000
                record.values[NEW.key].value+=25000
    ds=annotate_filing(ds)
    path=export_workbook(ds,tmp_path/f'equity-{total_inside_subsection}.xlsx','thousand')
    wb=load_workbook(path);cached=load_workbook(path,data_only=True);ws=wb['BS-L,E']
    retained_row=find_row(ws,'利益剰余金');capital_row=find_row(ws,'資本剰余金');total=find_row(ws,'Ⅰ 株主資本計')
    assert cached['BS-L,E'].cell(retained_row,2).value==130
    assert cached['BS-L,E'].cell(capital_row,3).value==25
    assert cached['BS-L,E'].cell(total,2).value==250
    assert cached['BS-L,E'].cell(total,3).value==335
    assert wb['BS-L,E'].cell(retained_row,2).data_type=='f'
    assert not any(c['ok'] is False for c in ds.checks if c['check']=='presentation_total')
    wb.close();cached.close()


def test_era_transitions():
    assert era_date(date(2012,6,30))=='H24-2012\n6/30'
    assert era_date(date(2019,3,31))=='H31-2019\n3/31'
    assert era_date(date(2019,6,30))=='R1-2019\n6/30'


def test_empty_periods_rejected_without_replacing_existing_output(tmp_path):
    path=tmp_path/'old.xlsx';path.write_bytes(b'existing')
    with pytest.raises(ValueError,match='年度'):
        export_workbook(Dataset('6947','図研','consolidated',[]),path)
    assert path.read_bytes()==b'existing'


def test_visible_direct_sum_formulas_are_simple_and_consistent_when_disclosures_match(tmp_path):
    from openpyxl.formula.translate import Translator
    from openpyxl.formula.tokenizer import Tokenizer
    ds=dataset();wb=load_workbook(export_workbook(ds,tmp_path/'simple.xlsx','thousand'))
    assert ds.export_metadata['formula_policy']=='simple_visible_references'
    for sheet,layout in ds.export_metadata['layout'].items():
        for entry in layout.get('sum_rows',[]):
            number=entry['row'];first=wb[sheet].cell(number,2)
            assert first.data_type=='f'
            assert len(first.value)<180 and not any(name in first.value for name in ['IF','COUNT','ISNUMBER'])
            functions=[token.value for token in Tokenizer(first.value).items if token.type=='FUNC' and token.subtype=='OPEN']
            assert all(name=='SUM(' for name in functions)
            assert all(r<number for r in entry['periods'][OLD.key]['rows'])
            for column in range(3,len(ds.periods)+2):
                cell=wb[sheet].cell(number,column)
                assert Translator(first.value,origin=first.coordinate).translate_formula(cell.coordinate)==cell.value
        for entry in layout.get('analysis_rows',[]):
            first=wb[sheet].cell(entry['row'],2);second=wb[sheet].cell(entry['row'],3)
            assert first.data_type=='f' and not any(name in first.value for name in ['IF','COUNT','ISNUMBER'])
            assert Translator(first.value,origin=first.coordinate).translate_formula(second.coordinate)==second.value
    assets=find_row(wb['BS-A'],'資産合計')
    current=find_row(wb['BS-A'],'流動資産計');fixed=find_row(wb['BS-A'],'固定資産合計')
    assert wb['BS-A'].cell(assets,2).value==f'=B{current}+B{fixed}'
    assert not [check for check in ds.checks if check.get('ok') is False]
    wb.close()


def test_missing_working_capital_inputs_stay_three_consecutive_editable_blanks(tmp_path):
    ds=dataset()
    omitted=('DecreaseIncreaseInInventoriesOpeCF','IncreaseDecreaseInNotesAndAccountsPayableTradeOpeCF')
    ds.rows['CF']=[r for r in ds.rows['CF'] if not any(local in r.key for local in omitted)]
    # The disclosed source subtotal is adjusted to this deliberately smaller
    # statement; the removed inputs remain unknown rather than synthetic zero.
    for record in ds.rows['CF']:
        local=next(iter(record.values.values())).source.concept.rsplit('}',1)[-1]
        if local in {'SubtotalOpeCF','NetCashProvidedByUsedInOperatingActivities','NetIncreaseDecreaseInCashAndCashEquivalents'} or record.label.endswith('期末残高'):
            record.values[OLD.key].value-=100000
            record.values[NEW.key].value-=250000
    wb=load_workbook(export_workbook(ds,tmp_path/'working.xlsx','thousand'))
    rows=ds.export_metadata['layout']['CF']['working_capital_rows']
    assert rows==list(range(rows[0],rows[0]+3))
    assert all(wb['CF'].cell(number,column).value is None for number in rows[1:] for column in [2,3])
    subtotal=next(item for item in ds.export_metadata['layout']['CF']['sum_rows'] if item['range']==[rows[0],rows[-1]])
    assert f'SUM(B{rows[0]}:B{rows[-1]})' in wb['CF'].cell(subtotal['row'],2).value
    wb.close()


def test_no_hidden_helpers_and_cf_summary_and_analysis_are_visible_inside_print(tmp_path):
    ds=dataset();wb=load_workbook(export_workbook(ds,tmp_path/'print.xlsx','thousand'))
    assert ds.export_metadata['helpers']==[]
    for ws in wb:
        assert ws.max_row<1000 and not any(d.hidden for d in ws.row_dimensions.values())
        end=int(str(ws.print_area).split('$')[-1].rstrip("'"))
        for entry in ds.export_metadata['layout'].get(ws.title,{}).get('analysis_rows',[]):
            assert ds.export_metadata['layout'][ws.title]['main_end_row']<entry['row']<=end
            assert not ws.row_dimensions[entry['row']].hidden
            assert ws.cell(entry['row'],1).value
    layout=ds.export_metadata['layout']['CF'];ws=wb['CF']
    assert layout['summary_start_row']==layout['main_end_row']+2
    assert ws.cell(layout['main_end_row']+1,1).value is None
    assert [ws.cell(layout['summary_start_row']+n,1).value for n in range(4)]==['営業CF','投資CF','財務CF','営業CF対投資CF比率']
    assert layout['summary_start_row']<70
    assert sum(len(layout.get('analysis_rows',[])) for layout in ds.export_metadata['layout'].values())==6
    wb.close()


def test_subtotal_borders_long_cf_labels_and_equity_roman_numerals(tmp_path):
    ds=dataset();eq=('純資産の部',)
    at=next(i for i,r in enumerate(ds.rows['BS_LE']) if any(c.source.concept.endswith('}NetAssets') for c in r.values.values()))
    ds.rows['BS_LE'][at:at]=[row('BS_LE','NonControllingInterests','非支配株主持分',0,0,eq),
        row('BS_LE','SubscriptionRightsToShares','新株予約権',0,0,eq)]
    wb=load_workbook(export_workbook(ds,tmp_path/'rules.xlsx','thousand'))
    cf=ds.export_metadata['layout']['CF'];ws=wb['CF']
    structural={cf['roles'][str(n)] for n in [33,40,54,64,68]}
    for number in range(2,cf['main_end_row']+1):
        for column in [1,2,3]:
            border=ws.cell(number,column).border
            top=border.top.style if border.top else None
            bottom=border.bottom.style if border.bottom else None
            if number in structural:assert top=='thin' and bottom in {'thin','medium'}
            elif number not in {cf['roles']['41'],cf['roles']['42']}:assert top is None and bottom is None
    for sheet in ['BS-A','BS-L,E']:
        for item in ds.export_metadata['layout'][sheet]['analysis_rows']:
            for column in [1,2,3]:
                cell=wb[sheet].cell(item['row'],column)
                assert not cell.font.bold and cell.fill.patternType is None
                assert not any(side and side.style for side in [cell.border.top,cell.border.bottom])
    cf=ds.export_metadata['layout']['CF'];ws=wb['CF']
    for number in [cf['roles'][str(n)] for n in [40,54,64,68]]+[cf['summary_end_row']]:
        assert ws.cell(number,1).alignment.wrap_text is not True  # XML omits the default false value
        assert ws.cell(number,1).alignment.shrink_to_fit is True
        assert ws.cell(number,1).font.sz<=8
        assert ws.row_dimensions[number].height<=12
    assert find_row(wb['BS-L,E'],'Ⅲ 非支配株主持分')<find_row(wb['BS-L,E'],'Ⅳ 新株予約権')<find_row(wb['BS-L,E'],'純資産合計')
    wb.close()


def test_reported_only_year_is_a_literal_disclosure_with_reason_not_a_guard_formula(tmp_path):
    ds=dataset()
    for record in ds.rows['BS_A']:
        if record.section==('資産の部','流動資産') and not any(c.source.concept.endswith('}CurrentAssets') for c in record.values.values()):
            record.values.pop(OLD.key,None)
    wb=load_workbook(export_workbook(ds,tmp_path/'reported-only.xlsx','thousand'));ws=wb['BS-A']
    current=find_row(ws,'流動資産計')
    entry=next(item for item in ds.export_metadata['layout']['BS-A']['sum_rows'] if item['row']==current)
    assert entry['modes'][OLD.key]=='reported_only'
    assert ws.cell(current,2).data_type=='n' and ws.cell(current,2).value==170
    assert entry['periods'][OLD.key]['reason'] and '直接内訳' in ws.cell(current,2).comment.text
    assert ds.export_metadata['helpers']==[]
    assert ws.cell(current,3).data_type=='f' and ws.cell(current,3).value.startswith('=SUM(')
    wb.close()


def test_analysis_optional_blank_is_linked_to_visible_input_and_new_value_has_signed_effect(tmp_path):
    ds=dataset();ca=('資産の部','流動資産')
    at=next(i for i,r in enumerate(ds.rows['BS_A']) if any(c.source.concept.endswith('}CurrentAssets') for c in r.values.values()))
    ds.rows['BS_A'].insert(at,row('BS_A','DeferredTaxAssetsCA','繰延税金資産',None,0,ca))
    wb=load_workbook(export_workbook(ds,tmp_path/'analysis-edit.xlsx','thousand'));ws=wb['BS-A']
    dta=find_row(ws,'繰延税金資産');assert ws.cell(dta,2).value is None
    item=next(item for item in ds.export_metadata['layout']['BS-A']['analysis_rows'] if item['metric']=='net_current_assets')
    assert {'sheet':'BS-A','row':dta,'sign':-1} in item['inputs']
    assert ds.export_metadata['helpers']==[]
    formula=ws.cell(item['row'],2).value
    assert f'-B{dta}' in formula or f'SUM(B{dta}:' in formula
    assert not any(name in formula for name in ['IF','COUNT','ISNUMBER'])
    ws.cell(dta,2).value=1000
    assert ws.cell(dta,2).value*(-1)==-1000  # the directly referenced operand's signed effect
    wb.close()


def test_contradictory_assets_disclosure_is_a_failure_not_a_reported_value_fallback(tmp_path):
    ds=dataset()
    assets=next(record for record in ds.rows['BS_A'] if any(c.source.concept.endswith('}Assets') for c in record.values.values()))
    assets.values[OLD.key].value+=1000000
    path=export_workbook(ds,tmp_path/'contradictory-assets.xlsx','thousand')
    wb=load_workbook(path,data_only=True);number=find_row(wb['BS-A'],'資産合計')
    assert wb['BS-A'].cell(number,2).value==305  # 170 + 135, not the contradictory 1305 disclosure
    checks=[item for item in ds.checks if item.get('sheet')=='BS-A' and item.get('row')==number and item.get('period')==OLD.key and item.get('check')=='presentation_total']
    assert checks and any(item['ok'] is False and abs(Decimal(item['difference_jpy']))==1000000 for item in checks)
    entry=next(item for item in ds.export_metadata['layout']['BS-A']['sum_rows'] if item['row']==number)
    assert entry['modes'][OLD.key]=='calculated' and entry['periods'][OLD.key]['rows']
    assert ds.warnings
    wb.close()


def test_analysis_missing_required_total_never_reports_a_partial_negative_exclusion(tmp_path):
    ds=dataset()
    ds.rows['BS_A']=[record for record in ds.rows['BS_A'] if not any(c.source.concept.endswith('}NoncurrentAssets') for c in record.values.values())]
    ds.rows['BS_A'].insert(-1,row('BS_A','DeferredTaxAssetsIOA','繰延税金資産',1,2,('資産の部','固定資産','投資その他の資産')))
    wb=load_workbook(export_workbook(ds,tmp_path/'missing-total.xlsx','thousand'),data_only=True)
    number=find_row(wb['BS-A'],'正味固定資産')
    assert wb['BS-A'].cell(number,2).value is None and wb['BS-A'].cell(number,3).value is None
    assert not ds.export_metadata['analysis']['net_noncurrent_assets'][OLD.key]['complete']
    assert '開示残高がありません' in ds.export_metadata['analysis']['net_noncurrent_assets'][OLD.key]['reason']
    wb.close()


def test_latest_k_large_negative_amount_and_blank_body_cells_shrink_without_widening(tmp_path):
    from openpyxl.utils import get_column_letter
    ds=dataset()
    historical=[Period(date(y-1,7,1),date(y,6,30)) for y in range(2016,2024)]
    for records in ds.rows.values():
        for record in records:
            first=record.values.get(OLD.key)
            if first:
                for period in historical:record.values[period.key]=deepcopy(first)
    ds.periods=historical+[OLD,NEW]
    ds.period_bases={p.key:'consolidated' for p in ds.periods}
    ds.period_standards={p.key:'J-GAAP' for p in ds.periods}
    cash=next(r for r in ds.rows['BS_A'] if any(c.source.concept.endswith('}CashAndDeposits') for c in r.values.values()))
    cash.values[NEW.key].value=Decimal('-123456789012345')
    path=export_workbook(ds,tmp_path/'large.xlsx','thousand');wb=load_workbook(path)
    number=find_row(wb['BS-A'],'現金及び預金')
    assert wb['BS-A'].cell(number,11).value==-123456789012.345
    with TEMPLATE_PATH.open('rb') as stream:template=load_workbook(stream)
    for ws in wb:
        original=template['BS-L&E' if ws.title=='BS-L,E' else ws.title]
        for column in range(2,12):
            letter=get_column_letter(column)
            assert ws.column_dimensions[letter].width==original.column_dimensions[letter].width
        assert ws['K1'].alignment.wrap_text==original['K1'].alignment.wrap_text
        visible_end=ds.export_metadata['layout'].get(ws.title,{}).get('summary_end_row') or max(
            [22 if ws.title=='PL' else 1]+[item['row'] for item in ds.export_metadata['layout'].get(ws.title,{}).get('nodes',[])])
        for line in range(2,visible_end+1):
            if ws.cell(line,1).value is not None:
                assert ws.cell(line,11).alignment.shrink_to_fit is True
                assert ws.cell(line,11).alignment.wrap_text is not True
        assert any(ws.cell(line,2).value is None and ws.cell(line,2).alignment.shrink_to_fit is True
                   for line in range(2,visible_end+1))
    # A missing earlier-year numeric input is ready for a large manual entry.
    empty_cf=ds.export_metadata['layout']['CF']['working_capital_rows'][1]
    wb['CF'].cell(empty_cf,2).value=None
    assert wb['CF'].cell(empty_cf,2).alignment.shrink_to_fit is True
    template.close();wb.close()


def test_long_cashflow_extra_label_wraps_with_enough_height_without_font_shrinking(tmp_path):
    ds=dataset();label='連結の範囲の変更を伴わない子会社株式の取得による支出'
    before=next(i for i,r in enumerate(ds.rows['CF']) if 'NetCashProvidedByUsedInFinancingActivities' in r.key)
    ds.rows['CF'].insert(before,row('CF','OtherSubsidiaryAcquisitionCustomFinCF',label,0,0,('財務活動によるキャッシュ・フロー',)))
    wb=load_workbook(export_workbook(ds,tmp_path/'long-extra.xlsx','thousand'));ws=wb['CF']
    number=find_row(ws,label);cell=ws.cell(number,1)
    assert cell.alignment.wrap_text is True and cell.alignment.shrink_to_fit is not True
    assert cell.font.sz==8
    assert 24<=ws.row_dimensions[number].height<=48
    assert ws.cell(number,3).alignment.shrink_to_fit is True
    wb.close()


def test_cf_cash_bridge_uses_only_visible_activity_subtotals_and_working_capital_sum(tmp_path):
    from openpyxl.formula.tokenizer import Tokenizer
    from openpyxl.utils.cell import range_boundaries
    ds=dataset();wb=load_workbook(export_workbook(ds,tmp_path/'cash-bridge.xlsx','thousand'));ws=wb['CF']
    layout=ds.export_metadata['layout']['CF'];roles=layout['roles']
    def references(formula):
        numbers=set()
        for token in Tokenizer(formula).items:
            if token.type=='OPERAND' and token.subtype=='RANGE':
                first_col,first_row,last_col,last_row=range_boundaries(token.value)
                assert first_col==last_col==2 and last_row<1000
                numbers.update(range(first_row,last_row+1))
        return numbers
    net=ws.cell(roles['66'],2).value
    assert references(net)=={roles[str(slot)] for slot in [40,54,64,65]}
    assert not any(name in net for name in ['IF','COUNT','ISNUMBER'])
    middle=ws.cell(roles['33'],2).value
    assert roles['22'] in references(middle) and roles['26'] in references(middle)
    assert not references(middle)&set(layout['working_capital_rows'])
    first,last=layout['working_capital_rows'][0],layout['working_capital_rows'][-1]
    assert ws.cell(roles['26'],2).value==f'=SUM(B{first}:B{last})'
    ratio=ws.cell(layout['summary_end_row'],2).value
    assert ratio.startswith('=IF(AND(COUNT(') and 'IFERROR' not in ratio and ratio.count('IF(')==1
    wb.close()
