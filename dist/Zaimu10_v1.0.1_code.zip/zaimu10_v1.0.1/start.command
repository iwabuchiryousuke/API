#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! .venv/bin/python setup_app.py --check >/dev/null 2>&1; then
  python3 setup_app.py
fi
.venv/bin/python app.py
