"""Read specifically identified EDINET borrowing schedules as audit inputs.

These rows supplement balance-sheet disclosures; they are not new BS totals.
In particular a borrowing-schedule total must never replace interest-bearing
debt: some published schedules omit a short-term balance shown in the BS.
Every extracted amount retains its real TextBlock, context and physical cell.
"""
from __future__ import annotations

from datetime import timedelta
from copy import deepcopy
from decimal import Decimal, InvalidOperation
import json
import re
import unicodedata

from lxml import etree, html

from .models import Cell, Dataset, Row, Source
from .parser import Page, ParseError, _contexts, _expanded, _local, _namespaces, _text


class DebtNoteError(ValueError):
    """Recognized debt evidence is malformed, ambiguous, or unsupported."""

    def __init__(self, message: str, *, periods: list[str] | None = None):
        super().__init__(message)
        self.periods = periods


_BORROWING_CATEGORIES = (
    'short_term_borrowings', 'current_long_term_borrowings', 'current_lease',
    'long_term_borrowings', 'noncurrent_lease',
)
_LABELS = {
    'short_term_borrowings': '短期借入金',
    'current_long_term_borrowings': '1年内返済予定の長期借入金',
    'current_lease': '1年内返済予定のリース債務',
    'long_term_borrowings': '長期借入金', 'noncurrent_lease': 'リース債務（非流動）',
    'bonds': '社債', 'current_bonds': '1年内償還予定の社債',
    'commercial_paper': 'コマーシャル・ペーパー',
    'other_interest_bearing_debt': 'その他の有利子負債',
    'borrowings_coverage': '借入金等明細表（検証済み対象範囲）',
    'borrowings_absent': '借入金等明細表（該当事項なし）',
    'bonds_absent': '社債明細表（該当事項なし）',
    'bonds_coverage': '社債明細表（当期末残高・内書の検証）',
    'ifrs_reference_debt_coverage': 'IFRS財務活動負債変動表（参照有利子負債範囲の照合）',
    'current_lease_coverage': 'その他の流動負債注記（検証済み対象範囲）',
    'noncurrent_lease_coverage': 'その他の非流動負債注記（検証済み対象範囲）',
    'nonlease_debt_absent': '非リース有利子負債（残高なしの明示）',
    'ifrs_borrowings_coverage': 'IFRS借入金注記（借入範囲の検証）',
    'financial_liabilities_coverage': 'IFRSその他金融負債注記（分類残高の検証）',
}
_DASHES = {'-', '−', '－', '―', '—', '–', 'ー', '─'}
_INTEREST_DEPOSIT_CAPTIONS = {'その他有利子負債預り金', 'その他の有利子負債預り金'}
_STANDARD_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpcrp/\d{4}-\d{2}-\d{2}/jpcrp_cor\Z')
_BLOCK_NAME = re.compile(
    r'Annexed(?P<consolidated>Consolidated)?DetailedScheduleOf'
    r'(?P<kind>Borrowings|CorporateBonds)(?:FinancialStatements)?(?:NA)?TextBlock\Z')
_IFRS_LIABILITY_NOTES = {
    'NotesOtherCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('current_lease','その他の流動負債','OtherCurrentLiabilitiesCLIFRS'),
    'NotesOtherNonCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('noncurrent_lease','その他の非流動負債','OtherNonCurrentLiabilitiesNCLIFRS'),
}
_IFRS_SECTION_NOTES = {
    'NotesBorrowingsConsolidatedFinancialStatementsIFRSTextBlock':
        ('ifrs_borrowings','借入金','ifrs_borrowings_coverage','ifrs_borrowings_complete'),
    'NotesOtherFinancialLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('ifrs_financial_liabilities','その他の金融負債','financial_liabilities_coverage','financial_liabilities_complete'),
}
_IFRS_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpigp/\d{4}-\d{2}-\d{2}/jpigp_cor\Z')
_RISK_LOCAL = 'NotesRiskManagementConsolidatedFinancialStatementsIFRSTextBlock'
_CHUGAI_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/jpcrp030000/asr/001/E00932-000/\d{4}-\d{2}-\d{2}/\d+/\d{4}-\d{2}-\d{2}\Z')
_NONLEASE_OPENING = '当社グループが保有する有利子負債及び貸付金の残高はなく、リース負債は'
_NONLEASE_STATEMENT = _NONLEASE_OPENING + 'リース契約の規模及び現在の低金利の経済状況を鑑みると当社グループにおける金利リスクは軽微です。'


def _compact(value: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or ''))


def _visible(element) -> bool:
    for ancestor in [element, *element.iterancestors()]:
        style = _compact(ancestor.get('style', '')).lower()
        if ancestor.get('hidden') is not None or 'display:none' in style or 'visibility:hidden' in style:
            return False
    return True


def _own_rows(table):
    def owner(node, name):
        return next((a for a in node.iterancestors() if _local(a.tag) == name), None)
    return [node for node in table.iter() if isinstance(node.tag, str)
            and _local(node.tag) == 'tr' and owner(node, 'table') is table]


def _grid(table):
    rows = _own_rows(table)
    grid, remaining = [], {}
    physical = {}
    for ri, tr in enumerate(rows, 1):
        cells = [node for node in tr if isinstance(node.tag, str) and _local(node.tag) in {'td', 'th'}]
        current, next_remaining = {}, {}
        for col, (cell, count) in remaining.items():
            current[col] = cell
            if count > 1:
                next_remaining[col] = (cell, count - 1)
        column = 0
        for ci, cell in enumerate(cells, 1):
            physical[cell] = (ri, ci)
            while column in current:
                column += 1
            try:
                colspan = int(cell.get('colspan', '1'))
                rowspan = int(cell.get('rowspan', '1'))
            except (TypeError, ValueError):
                raise DebtNoteError('借入金等明細表のセル結合を読めません。') from None
            if not (1 <= colspan <= 30 and 1 <= rowspan <= 100):
                raise DebtNoteError('借入金等明細表のセル結合が対応範囲外です。')
            for offset in range(colspan):
                if column + offset in current:
                    raise DebtNoteError('借入金等明細表のセル範囲が重複しています。')
                current[column + offset] = cell
                if rowspan > 1:
                    next_remaining[column + offset] = (cell, rowspan - 1)
            column += colspan
        grid.append(current)
        remaining = next_remaining
    if remaining:
        raise DebtNoteError('借入金等明細表の結合セルが表の外へ続いています。')
    return rows, grid, physical


def _category(label: str) -> str | None:
    label = _compact(label)
    label = re.sub(r'[（(]注\d*[)）]$', '', label)
    if label in {'短期借入金', '短期借入れ', '短期借入'}:
        return 'short_term_borrowings'
    if label in {'1年内長期借入金','1年以内長期借入金'}:
        return 'current_long_term_borrowings'
    current = bool(re.search(r'1年(?:以)?内(?:に)?(?:返済|償還)予定', label))
    excludes = '除く' in label
    if '長期借入金' in label:
        if current and not excludes:
            return 'current_long_term_borrowings'
        if label.startswith('長期借入金') and (label == '長期借入金' or excludes):
            return 'long_term_borrowings'
    if 'リース債務' in label or 'リース負債' in label:
        if current and not excludes:
            return 'current_lease'
        if re.search(r'[（(]流動(?:負債)?[)）]', label):
            return 'current_lease'
        if excludes or re.search(r'[（(](?:非流動|固定)(?:負債)?[)）]', label):
            return 'noncurrent_lease'
    if label in {'コマーシャル・ペーパー', 'コマーシャルペーパー', 'CP'}:
        return 'commercial_paper'
    if label in {'その他の有利子負債', 'その他有利子負債',
                 'その他有利子負債預り金', 'その他の有利子負債預り金'}:
        return 'other_interest_bearing_debt'
    return None


def _amount(raw: str) -> tuple[Decimal, str]:
    value = _compact(raw)
    if value in _DASHES:
        return Decimal(0), 'explicit_no_balance'
    if not re.fullmatch(r'\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?', value):
        raise DebtNoteError(f'借入金等明細表の残高を確定できません: {raw!r}')
    try:
        parsed = Decimal(value.replace(',', ''))
    except InvalidOperation:
        raise DebtNoteError(f'借入金等明細表の残高が数値ではありません: {raw!r}') from None
    if not parsed.is_finite() or parsed < 0:
        raise DebtNoteError('借入金等明細表の残高が非有限値または負数です。')
    return parsed, ''


def _dates(value: str):
    from datetime import date
    value = _compact(value)
    result = []
    for year, month, day in re.findall(r'(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})日?', value):
        try:
            result.append(date(int(year), int(month), int(day)))
        except ValueError:
            raise DebtNoteError('借入金等明細表の列見出しの日付が不正です。') from None
    for era, year, month, day in re.findall(r'(令和|平成|昭和)(元|\d+)年(\d{1,2})月(\d{1,2})日', value):
        try:
            number = 1 if year == '元' else int(year)
            result.append(date({'令和':2018, '平成':1988, '昭和':1925}[era] + number,
                               int(month), int(day)))
        except ValueError:
            raise DebtNoteError('借入金等明細表の和暦日付が不正です。') from None
    return result


def _unit(headers: list[str], block, table) -> tuple[str, int]:
    known = {'千円':3, '百万円':6, '円':0}
    def found(text):
        return set(re.findall(r'百万円|千円|(?<![万千])円', _compact(text)))
    units = found(' '.join(headers))
    if not units:
        prefix = []
        for node in block.iter():
            if node is table:
                break
            if node.text:
                prefix.append(node.text)
            if node is not block and node.tail:
                prefix.append(node.tail)
        units = found(' '.join(prefix))
    if len(units) != 1:
        raise DebtNoteError('借入金等明細表の円・千円・百万円の単位を一意に確認できません。')
    name = next(iter(units))
    return name, known[name]


def _source(base: Source, filename: str, qname: str, context: str, label: str,
            raw: str, basis: str, scale: int) -> Source:
    return Source(base.doc_id, filename, base.url, submitted=base.submitted,
                  context_id=context, concept=qname, unit='JPY', decimals=str(-scale),
                  original_label=label, raw_value=raw, scale=scale, basis=basis)


def _note(evidence: dict, message: str) -> str:
    return message + '\ndebt_note_evidence:' + json.dumps(evidence, ensure_ascii=False, separators=(',', ':'))


def _corporate_bonds_note(block, page_tables, current, context, put):
    """Read the current closing bond balance and its explicitly defined inset.

    Parenthesized values are current portions only when the note explicitly
    says so. The prior opening balance is never used to infer a missing inset.
    The bond total is split into current/noncurrent once, not added twice.
    """
    scoped = [current[0].key]
    def fail(message):
        raise DebtNoteError('社債明細表: ' + message, periods=scoped)
    text = _text(block); compact = _compact(text)
    semantic = re.search(r'\(\)内書は、?1年以内の償還予定額(?:であります|です)', compact)
    if not semantic:
        fail('括弧内が1年以内の償還予定額の内書である明示注記を確認できません。')
    tables = [n for n in block.iter() if isinstance(n.tag,str) and _local(n.tag)=='table' and _visible(n)]
    if not tables or any(any(_local(a.tag)=='table' for a in t.iterancestors() if isinstance(a.tag,str)) for t in tables):
        fail('独立した対応済み残高表を確認できません。')
    candidates = []; others = []
    for ti, table in enumerate(tables,1):
        rows, grid, physical = _grid(table)
        headers = [(hi,{col:_compact(_text(c)) for col,c in cells.items()})
                   for hi,cells in enumerate(grid) if any('当期末残高' in _compact(_text(c)) for c in cells.values())]
        if headers:
            if len(headers)!=1:
                fail('当期末残高の見出しが一意ではありません。')
            hi, names = headers[0]
            endings = [col for col,v in names.items() if v.startswith('当期末残高')]
            beginnings = [col for col,v in names.items() if v.startswith('当期首残高')]
            expected = ['会社名','銘柄','発行年月日',None,None,'利率(%)','担保','償還期限']
            if (set(names)!=set(range(8)) or len(endings)!=1 or len(beginnings)!=1
                    or endings[0]!=4 or beginnings[0]!=3
                    or any(value is not None and names[col]!=value for col,value in enumerate(expected))):
                fail('会社・銘柄・期首期末・利率・担保・償還期限の8列形式ではありません。')
            if any(day!=context.end for day in _dates(_text(grid[hi][4]))):
                fail('当期末列の日付がXBRL年度末と一致しません。')
            candidates.append((ti,table,grid,physical,hi))
        elif any(_compact(_text(c)) for cells in grid for c in set(cells.values())):
            others.append((ti,table,grid,physical))
    if len(candidates)!=1:
        fail('社債残高表を一意に確認できません。')
    ti, table, grid, physical, hi = candidates[0]
    unit,scale = _unit([_text(c) for c in grid[hi].values()],block,table)
    for column in (3,4):
        header=_compact(_text(grid[hi][column]))
        currencies=re.findall(r'百万円|千円|(?<![万千])円',header)
        if currencies!=[unit] or re.search(r'ドル|USD|EUR|ユーロ|人民元|通貨',header,re.I):
            fail('期首・期末それぞれの列の円建て単位を一意に確認できません。')
    factor = Decimal(10)**scale
    def balance(cell):
        if any(n.get('xsi:nil','').lower()in{'true','1'} or n.get('continuedat') for n in cell.iter()):
            fail('当期末残高がnilまたは継続参照です。')
        raw = _text(cell); value = _compact(raw)
        match = re.fullmatch(r'([^()]+)(?:\(([^()]+)\))?',value)
        if not match:
            fail('残高と1年内償還予定内書の数値形式を確認できません。')
        total,operation = _amount(match[1])
        portion = _amount(match[2])[0] if match[2]is not None else None
        if portion is not None and portion>total:
            fail('1年内償還予定額が社債残高を上回っています。')
        # An explicit zero total also proves that its nonnegative current
        # component is zero. An absent inset on a positive amount proves none.
        if total==0 and portion is None:portion=Decimal(0)
        return total*factor,portion*factor if portion is not None else None,raw,operation
    details=[];reported=None;seen=set();total_seen=False
    for ri in range(hi+1,len(grid)):
        cells=grid[ri]
        if not any(_compact(_text(c)) for c in set(cells.values())):continue
        if set(cells)!=set(range(8)):
            fail('残高明細に欠けた列・未対応の追加列があります。')
        if len({id(c) for c in cells.values()})!=8:
            fail('残高明細の横結合列を確定できません。')
        labels=[_compact(_text(cells[col])) for col in [0,1,2,7]]
        amount,portion,raw,operation=balance(cells[4])
        row,column=physical[cells[4]]
        proof=dict(company=_text(cells[0]),security=_text(cells[1]),issue_date=_text(cells[2]),
            redemption_date=_text(cells[7]),physical_row=row,physical_column=column,
            raw_value=raw,total_jpy=str(amount),current_portion_jpy=str(portion) if portion is not None else None)
        if labels[0] in {'合計','計','総合計'}:
            if reported is not None:fail('合計行が複数あります。')
            if any(v and v not in _DASHES for v in labels[1:]):fail('合計行の銘柄・発行日・償還期限に未分類の値があります。')
            reported=(amount,portion,raw,operation,proof);total_seen=True
        else:
            if total_seen:fail('合計後に追加の社債明細があります。')
            if not labels[0] or '社債'not in labels[1] or not labels[2]:
                fail('会社名・社債銘柄・発行年月日を確認できない残高行があります。')
            key=tuple(labels)
            if key in seen:fail('同一銘柄・発行日・償還期限の明細が重複しています。')
            seen.add(key);details.append((amount,portion,proof))
    if not details or reported is None:fail('全銘柄明細と合計行が揃っていません。')
    total,portion,raw,operation,proof=reported
    if portion is None:fail('正の当期末合計について1年内償還予定額の内書が明示されていません。')
    tolerance=factor*Decimal(len(details)+1)
    detail_total=sum((a for a,_,_ in details),Decimal(0))
    if abs(detail_total-total)>tolerance:fail('全銘柄の期末残高合計と報告合計が丸め許容差内で一致しません。')
    known_portion=sum((v for _,v,_ in details if v is not None),Decimal(0))
    unknown=[p for amount,v,p in details if amount>0 and v is None]
    if portion>0 and unknown:fail('正の償還予定額に対して内書のない正の銘柄残高があります。')
    if abs(known_portion-portion)>tolerance:fail('全銘柄の内書合計と報告償還予定額が一致しません。')
    redemption=[]
    for other_ti,other,other_grid,other_physical in others:
        nonempty=[(r,cells) for r,cells in enumerate(other_grid)if any(_compact(_text(c)) for c in set(cells.values()))]
        if len(nonempty)!=2 or set(nonempty[0][1])!=set(range(5)) or set(nonempty[1][1])!=set(range(5)):
            fail('未対応の追加表があり、償還予定表と一意に確認できません。')
        _,head=nonempty[0];_,values=nonempty[1]
        names=[_compact(_text(head[c])) for c in range(5)]
        expected=['1年以内']+[f'{n}年超{n+1}年以内'for n in range(1,5)]
        if (not all(names[c].startswith(expected[c]+'(') for c in range(5))
                or '決算日後5年間の償還予定額'not in compact):
            fail('追加表が決算日後5年間の償還予定額ではありません。')
        other_unit,other_scale=_unit([_text(head[c])for c in range(5)],block,other)
        if (other_unit,other_scale)!=(unit,scale):fail('残高表と償還予定表で単位が一致しません。')
        amounts=[_amount(_text(values[c]))[0]*factor for c in range(5)]
        if abs(amounts[0]-portion)>tolerance or sum(amounts)>total+tolerance:
            fail('1年以内償還予定表と括弧内数・当期末合計が一致しません。')
        redemption.append(dict(table_index=other_ti,page_table_index=page_tables.index(other)+1,
            headers=[_text(head[c])for c in range(5)],amounts_jpy=[str(a)for a in amounts],
            current_physical_row=other_physical[values[0]][0],current_physical_column=other_physical[values[0]][1]))
    if len(redemption)>1:fail('償還予定表が複数あり、対応を確定できません。')
    common=dict(kind='bonds_schedule',table_index=ti,page_table_index=page_tables.index(table)+1,
        physical_row=proof['physical_row'],physical_column=proof['physical_column'],expanded_column=5,
        balance_column='end',column_header=_text(grid[hi][4]),unit_label=unit,scale=scale,raw_value=raw,
        parentheses_semantics=semantic.group(),reported_total_jpy=str(total),reported_current_jpy=str(portion),
        component_sum_jpy=str(detail_total),current_component_sum_jpy=str(known_portion),
        rounding_tolerance_jpy=str(tolerance),details=[p for _,_,p in details],
        positive_details_without_inset=unknown,current_zero_proven_by_reported_aggregate=bool(unknown and portion==0),
        redemption_crosscheck=redemption,scope='current_fiscal_year_end_only',
        noncurrent_formula='reported_total_jpy - reported_current_jpy')
    put('current_bonds',current[0],portion,raw,'explicit_no_balance'if portion==0 else'bonds_schedule_current_inset',
        dict(common,selected_component='current'),scale=scale)
    put('bonds',current[0],total-portion,raw,'explicit_no_balance'if total==portion else'bonds_schedule_noncurrent_difference',
        dict(common,selected_component='noncurrent'),scale=scale)
    put('bonds_coverage',current[0],None,text,'bonds_schedule_complete',
        dict(common,kind='bonds_schedule_coverage'),scale=scale)


class _NoteScope:
    """A bounded view of original nodes; no synthetic financial QName or cell."""
    def __init__(self,nodes,evidence):self.nodes=nodes;self.scope_evidence=evidence
    def iter(self):return iter(self.nodes)
    def itertext(self):
        for node in self.nodes:
            if node.text:yield node.text
            if node.tail:yield node.tail


def _numbered_note_scope(block,title,page_tables):
    nodes=list(block.iter());position={id(n):i for i,n in enumerate(nodes)};heads=[]
    for n in nodes:
        if not isinstance(n.tag,str)or _local(n.tag)not in {'p','h1','h2','h3','h4','h5','h6'}:continue
        if any(_local(a.tag)=='table'for a in n.iterancestors()if isinstance(a.tag,str)):continue
        m=re.fullmatch(r'(\d+)\.(.+)',_compact(_text(n)))
        if m:heads.append((n,int(m[1]),m[2]))
    matches=[(i,h)for i,h in enumerate(heads)if h[2]==title]
    if len(matches)!=1:return None
    i,(start,number,_)=matches[0]
    endings=[h for h in heads[i+1:]if h[1]==number+1]
    if len(endings)!=1:raise DebtNoteError('IFRS全注記の番号付き区間を一意に区切れません。')
    end=endings[0][0];a,b=position[id(start)],position[id(end)]
    section=nodes[a:b]
    return _NoteScope(section,dict(kind='exact_numbered_note_section',start_heading=_text(start),
        end_heading=_text(end),start_node_index=a,end_node_index=b,
        page_table_indexes=[page_tables.index(n)+1 for n in section if n in page_tables]))


def _ifrs_balance_columns(grid,context,*,single=False):
    expected={context.start-timedelta(days=1),context.end};found=[]
    for hi,cells in enumerate(grid):
        dated={c:_dates(_text(v))for c,v in cells.items()}
        if not any(dated.values()):continue
        if any(len(v)>1 for v in dated.values()):continue  # Duration P&L tables are not closing balances.
        dates={c:v[0]for c,v in dated.items()if v}
        if set(dates.values())<=expected and len(dates)==len(set(dates.values())) and (single or set(dates.values())==expected):
            found.append((hi,dates))
    if len(found)!=1:raise DebtNoteError('IFRS補足残高の基準日列が本表の2期末と一意に対応しません。')
    return found[0]


def _ifrs_note_amount(cell,scale):
    if any(n.get('xsi:nil','').lower()in{'true','1'}or n.get('continuedat')for n in cell.iter()):
        raise DebtNoteError('IFRS補足残高がnilまたは継続参照です。')
    amount,operation=_amount(_text(cell))
    return amount*Decimal(10)**scale,operation


def _ifrs_combined_bonds_borrowings(block,page_tables,dataset,current,previous,context,put):
    """All rows of a bounded loan/CP table, plus the separate bond inset table."""
    tables=[n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='table'and _visible(n)]
    scoped=[p.key for p in previous+current];loans=[];bonds=[]
    if re.search(r'単位[:：]?(?:米ドル|ドル|USD|EUR|ユーロ)',_compact(_text(block)),re.I):
        raise DebtNoteError('IFRS借入・社債表の円建て単位を確認できません。',periods=scoped)
    for ti,t in enumerate(tables,1):
        _,g,physical=_grid(t);labels={_compact(_text(c.get(0)))for c in g if c.get(0)is not None}
        if {'短期借入金','長期借入金','合計'}<=labels:loans.append((ti,t,g,physical))
        elif '会社名'in labels and any('銘柄'in _compact(_text(c))for row in g for c in row.values()):bonds.append((ti,t,g,physical))
    if len(loans)!=1 or len(bonds)!=1:raise DebtNoteError('IFRS社債及び借入金等の社債表・借入表を各1表に限定できません。',periods=scoped)
    ti,t,g,physical=loans[0];hi,annual=_ifrs_balance_columns(g,context)
    header=g[hi];rates=[c for c,v in header.items()if '平均利率'in _compact(_text(v))];dues=[c for c,v in header.items()if _compact(_text(v))=='返済期限']
    if len(rates)!=1 or len(dues)!=1 or set(header)!={0,*annual,*rates,*dues}:
        raise DebtNoteError('IFRS借入金表の項目・年次残高・利率・期限の5列が未対応です。',periods=scoped)
    unit,scale=_unit([_text(c)for c in header.values()],block,t);totals={};sums={c:Decimal(0)for c in annual};proof=[];seen=set()
    for ri in range(hi+1,len(g)):
        cells=g[ri]
        if not any(_compact(_text(c))for c in cells.values()):continue
        if set(cells)!=set(header):raise DebtNoteError('IFRS借入表の列が欠けています。',periods=scoped)
        label=_text(cells[0]);name=_compact(label);category=_category(label);total=name=='合計'
        if not total and category not in {'short_term_borrowings','current_long_term_borrowings','long_term_borrowings','commercial_paper'}:
            raise DebtNoteError('IFRS借入表に未知の負債区分があります。',periods=scoped)
        if category in seen:raise DebtNoteError('IFRS借入表の負債カテゴリが重複しています。',periods=scoped)
        if category:seen.add(category)
        rowproof=dict(label=label,category=category,values={})
        for col,day in annual.items():
            amount,operation=_ifrs_note_amount(cells[col],scale);raw=_text(cells[col]);pr,pc=physical[cells[col]]
            if total:
                if col in totals:raise DebtNoteError('IFRS借入表の合計が複数あります。',periods=scoped)
                totals[col]=amount
            else:sums[col]+=amount
            rowproof['values'][day.isoformat()]=dict(value_jpy=str(amount),raw=raw,physical_row=pr,physical_column=pc)
            if category:
                for p in previous+current:
                    if p.end==day:put(category,p,amount,raw,operation,dict(kind='ifrs_combined_borrowings',table_index=ti,page_table_index=page_tables.index(t)+1,
                        physical_row=pr,physical_column=pc,expanded_column=col+1,column_header=_text(header[col]),balance_column='closing',unit_label=unit,scale=scale,
                        scope='loans_and_cp_only',source_section=getattr(block,'scope_evidence',None)),label,scale)
        proof.append(rowproof)
    tolerance=Decimal(10)**scale*Decimal(len(proof)+1)
    if set(totals)!=set(annual)or not {'short_term_borrowings','current_long_term_borrowings','long_term_borrowings'}<=seen:
        raise DebtNoteError('IFRS借入表の全分類と各期合計が揃っていません。',periods=scoped)
    for col,day in annual.items():
        if abs(sums[col]-totals[col])>tolerance:raise DebtNoteError('IFRS借入表の全内訳と合計が一致しません。',periods=scoped)
        for p in previous+current:
            if p.end==day:put('ifrs_borrowings_coverage',p,None,_text(t),'ifrs_borrowings_complete',dict(kind='ifrs_borrowings_coverage',scope='loans_and_cp_only',table_index=ti,page_table_index=page_tables.index(t)+1,
                unit_label=unit,scale=scale,rows=proof,reported_total_jpy=str(totals[col]),component_sum_jpy=str(sums[col]),rounding_tolerance_jpy=str(tolerance),source_section=getattr(block,'scope_evidence',None)),scale=scale)
    ti,t,g,physical=bonds[0];hi,annual=_ifrs_balance_columns(g,context)
    h=g[hi]
    if set(h)!=set(range(8)) or _compact(_text(h[0]))!='会社名'or _compact(_text(h[1]))!='銘柄':raise DebtNoteError('IFRS社債表の8列形式が未対応です。',periods=scoped)
    compact=_compact(_text(block))
    if not re.search(r'\(\)内は1年内償還予定の金額です',compact):raise DebtNoteError('IFRS社債表の括弧内数の償還区分が不明です。',periods=scoped)
    unit,scale=_unit([_text(c)for c in h.values()],block,t);factor=Decimal(10)**scale;reported={};sums={c:Decimal(0)for c in annual};insets={c:Decimal(0)for c in annual};details=[]
    for ri in range(hi+1,len(g)):
        cells=g[ri]
        if not any(_compact(_text(c))for c in cells.values()):continue
        total=_compact(_text(cells[0]))=='合計'
        if not set(annual)<=set(cells):raise DebtNoteError('IFRS社債残高列が欠けています。',periods=scoped)
        if not total and (not _compact(_text(cells[0]))or '社債'not in _compact((_text(cells[1])if 1 in cells else ''))):raise DebtNoteError('IFRS社債表に未知の銘柄行があります。',periods=scoped)
        proofrow=dict(label=(_text(cells[1])if 1 in cells else ''),total=total,values={})
        for col,day in annual.items():
            raw=_text(cells[col]);m=re.fullmatch(r'([^()]+)\(([^()]+)\)',_compact(raw))
            if not m:raise DebtNoteError('IFRS社債表の全残高と内書を独立して確認できません。',periods=scoped)
            amount=_amount(m[1])[0]*factor;part=_amount(m[2])[0]*factor
            if part>amount:raise DebtNoteError('IFRS社債の内書が残高を超えています。',periods=scoped)
            pr,pc=physical[cells[col]];proofrow['values'][day.isoformat()]=dict(total_jpy=str(amount),current_jpy=str(part),raw=raw,physical_row=pr,physical_column=pc)
            if total:
                if col in reported:raise DebtNoteError('IFRS社債合計が複数あります。',periods=scoped)
                reported[col]=(amount,part,raw,pr,pc)
            else:sums[col]+=amount;insets[col]+=part
        details.append(proofrow)
    tolerance=factor*Decimal(len(details)+1)
    if set(reported)!=set(annual):raise DebtNoteError('IFRS社債の各期合計がありません。',periods=scoped)
    for col,day in annual.items():
        amount,part,raw,pr,pc=reported[col]
        if abs(sums[col]-amount)>tolerance or abs(insets[col]-part)>tolerance:raise DebtNoteError('IFRS社債の全銘柄・内数と合計が一致しません。',periods=scoped)
        for p in previous+current:
            if p.end!=day:continue
            ev=dict(kind='ifrs_combined_bonds',table_index=ti,page_table_index=page_tables.index(t)+1,physical_row=pr,physical_column=pc,expanded_column=col+1,
                balance_column='closing',column_header=_text(h[col]),unit_label=unit,scale=scale,rows=details,reported_total_jpy=str(amount),reported_current_jpy=str(part),
                component_sum_jpy=str(sums[col]),current_sum_jpy=str(insets[col]),rounding_tolerance_jpy=str(tolerance),source_section=getattr(block,'scope_evidence',None))
            c=put('current_bonds',p,part,raw,'ifrs_bonds_current_inset',dict(ev,calculation='parenthesized_current_inset'),scale=scale)
            n=put('bonds',p,amount-part,'','difference',dict(ev,calculation='reported_bond_total - reported_current_inset'),scale=scale)
            gross=deepcopy(c);gross.value=amount;gross.operation='';gross.source.raw_value=raw;gross.source.original_label='社債期末残高合計（内書を含む）';gross.components=[]
            gross_evidence=json.loads(gross.note.split('debt_note_evidence:',1)[1]);gross_evidence.update(component_role='reported_bond_total',category='bonds_total_component')
            gross.note=_note(gross_evidence,'社債残高総額の原文セル。内書償還予定額を差し引く独立した構成要素。')
            inset=deepcopy(c);inset.components=[]
            n.components=[gross,inset]
            put('bonds_coverage',p,None,_text(t),'ifrs_bonds_complete',dict(ev,kind='ifrs_bonds_coverage'),scale=scale)


def _ifrs_lease_containment_proof(block,table,context,period):
    """Optional exact parent mapping; absence never guesses a containing row.

    The original measured balances are already verified by the lease reader.
    This separate proof affects only their placement in the upper BS display.
    Older whole-note HTML and IAS17 present-value tables retain memo display.
    """
    if isinstance(block,_NoteScope) or block.get('name','').rsplit(':',1)[-1]!=            'NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock':
        return None
    nodes=list(block.iter());positions={id(n):i for i,n in enumerate(nodes)}
    paragraphs=[n for n in nodes if isinstance(n.tag,str)and _local(n.tag)=='p'
                and _visible(n)and not any(_local(a.tag)=='table'for a in n.iterancestors()if isinstance(a.tag,str))]
    candidates=[]
    for index,node in enumerate(paragraphs,1):
        statement=_text(node);normalized=_compact(statement)
        if positions[id(node)]>=positions[id(table)]:continue
        if not normalized.startswith('リース負債は'):continue
        candidates.append((index,node,statement,normalized))
    if len(candidates)!=1:return None
    index,node,statement,normalized=candidates[0]
    pattern=(r'リース負債は、リース料の支払期日が(?P<prior>前連結会計年度末及び)?'
        r'当連結会計年度末より1年以内に到来する負債額は流動負債、それ以外を非流動負債とし、'
        r'それぞれ、連結財政状態計算書上、その他の金融負債\(流動負債\)及び'
        r'その他の金融負債\(非流動負債\)に含まれております。')
    matched=re.fullmatch(pattern,normalized)
    if not matched:return None
    expected={context.end,context.start-timedelta(days=1)}if matched['prior']else{context.end}
    if period.end not in expected:return None
    return dict(rule='exact_current_noncurrent_other_financial_liabilities_sentence',
        statement=statement,normalized_statement=normalized,paragraph_index=index,
        block_node_index=positions[id(node)]+1,paragraph_xpath=node.getroottree().getpath(node),
        source_raw_qname=block.get('name'),source_context=block.get('contextref'),
        source_table_node_index=positions[id(table)]+1,target_period_end=period.end.isoformat(),
        applies_to='current_and_prior_annual_closing'if matched['prior']else'current_annual_closing_only',
        current_parent_caption='その他の金融負債（流動負債）',
        noncurrent_parent_caption='その他の金融負債（非流動負債）')


def _ifrs_lease_balances(block,page_tables,dataset,current,previous,context,put):
    """Only carrying balances or the explicitly discounted IAS17 PV table."""
    text=_compact(_text(block));tables=[n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='table'and _visible(n)]
    if re.search(r'単位[:：]?(?:米ドル|ドル|USD|EUR|ユーロ)',text,re.I):
        raise DebtNoteError('リース帳簿残高の円建て単位を確認できません。')
    modern=[];legacy=[]
    for ti,t in enumerate(tables,1):
        _,g,physical=_grid(t)
        labels=[_compact(_text(row[0]))for row in g if 0 in row]
        if {'支払期日が1年以内','支払期日が1年超','合計'}<=set(labels):modern.append((ti,t,g,physical))
        if {'1年以内','1年超5年以内','5年超','合計'}<=set(labels):
            try:hi,annual=_ifrs_balance_columns(g,context,single=True)
            except DebtNoteError:continue
            prefix=''.join(_compact(_text(c))for row in g[:hi+1]for c in set(row.values()))
            if '将来の最低リース料総額の現在価値'in prefix:legacy.append((ti,t,g,physical))
    if not modern and not legacy:return
    if len(modern)>1 or len(legacy)>1:raise DebtNoteError('IFRSリース帳簿残高・現在価値表が重複しています。')
    if modern and not all(v in text for v in ['リース負債は','流動負債','非流動負債','その他の金融負債','連結財政状態計算書上']):
        raise DebtNoteError('リース支払期日別表がBS帳簿負債の内訳である明示説明がありません。')
    if legacy and ('ファイナンス・リース(借手側)'not in text or '将来の最低リース料総額及びそれらの現在価値の内訳'not in text):
        raise DebtNoteError('IAS17表の借手ファイナンスリース現在価値の対象範囲を確認できません。')
    seen=set()
    for mode,candidates in [('carrying',modern),('present_value',legacy)]:
        for ti,t,g,physical in candidates:
            hi,annual=_ifrs_balance_columns(g,context,single=True)
            unit,scale=_unit([_text(c)for row in g[:hi+1]for c in set(row.values())],block,t);factor=Decimal(10)**scale
            expected=['支払期日が1年以内','支払期日が1年超','合計']if mode=='carrying'else['1年以内','1年超5年以内','5年超','合計']
            body=[]
            for ri in range(hi+1,len(g)):
                cells=g[ri]
                if not any(_compact(_text(c))for c in cells.values()):continue
                if set(cells)!={0,*annual}:raise DebtNoteError('リース帳簿残高の列又はスペーサーが未対応です。')
                body.append((ri,cells))
            if [_compact(_text(c[0]))for _,c in body]!=expected:raise DebtNoteError('リース帳簿残高の全満期区分・合計が対応形式ではありません。')
            for col,day in annual.items():
                if day in seen:raise DebtNoteError('同じ期末に複数のリース残高測定基準があります。')
                seen.add(day);amounts=[];leaf_sources=[]
                for ri,cells in body:
                    amount,op=_ifrs_note_amount(cells[col],scale);pr,pc=physical[cells[col]]
                    amounts.append(amount);leaf_sources.append(dict(label=_text(cells[0]),raw=_text(cells[col]),physical_row=pr,physical_column=pc,value_jpy=str(amount),operation=op))
                tolerance=factor*Decimal(len(body)+1)
                if amounts[0]>amounts[-1]:raise DebtNoteError('流動リース現在価値が全現在価値を上回っています。')
                if abs(sum(amounts[:-1],Decimal(0))-amounts[-1])>tolerance:raise DebtNoteError('リース帳簿残高の全満期内訳と合計が丸め許容差内で一致しません。')
                for p in previous+current:
                    if p.end!=day:continue
                    ev=dict(kind='ifrs_lease_carrying'if mode=='carrying'else'ifrs_lease_present_value',table_index=ti,page_table_index=page_tables.index(t)+1,
                        column_header=_text(g[hi][col]),balance_column='closing',unit_label=unit,scale=scale,rows=leaf_sources,measurement='carrying_amount'if mode=='carrying'else'discounted_present_value',
                        reported_total_jpy=str(amounts[-1]),component_sum_jpy=str(sum(amounts[:-1],Decimal(0))),rounding_tolerance_jpy=str(tolerance),source_section=getattr(block,'scope_evidence',None))
                    containment=_ifrs_lease_containment_proof(block,t,context,p)if mode=='carrying'else None
                    def placement(evidence,category):
                        result=dict(evidence)
                        if containment:
                            result.update(parent_local='OtherFinancialLiabilitiesCLIFRS'if category=='current_lease'else'OtherFinancialLiabilitiesNCLIFRS',
                                parent_containment=dict(containment,selected_scope='current'if category=='current_lease'else'noncurrent'))
                        return result
                    a=leaf_sources[0];c=put('current_lease',p,amounts[0],a['raw'],a['operation'],placement(dict(ev,physical_row=a['physical_row'],physical_column=a['physical_column'],expanded_column=col+1),'current_lease'),a['label'],scale)
                    if mode=='carrying':
                        a=leaf_sources[1];n=put('noncurrent_lease',p,amounts[1],a['raw'],a['operation'],placement(dict(ev,physical_row=a['physical_row'],physical_column=a['physical_column'],expanded_column=col+1),'noncurrent_lease'),a['label'],scale)
                    else:
                        a=leaf_sources[-1];n=put('noncurrent_lease',p,amounts[-1]-amounts[0],'','difference',dict(ev,physical_row=a['physical_row'],physical_column=a['physical_column'],expanded_column=col+1,calculation='reported_present_value_total - current_present_value'),scale=scale)
                        total=deepcopy(c);total.value=amounts[-1];total.source.raw_value=a['raw'];total.source.original_label=a['label'];total.operation='';total.components=[]
                        total_evidence=json.loads(total.note.split('debt_note_evidence:',1)[1])
                        total_evidence.update(physical_row=a['physical_row'],physical_column=a['physical_column'],raw_value=a['raw'],component_role='reported_present_value_total')
                        total.note=_note(total_evidence,'現在価値合計の原文セル。差引計算の独立した構成要素。')
                        inset=deepcopy(c);inset.components=[];n.components=[total,inset]
                    for status in ['current_lease_coverage','noncurrent_lease_coverage']:
                        put(status,p,None,_text(t),'lease_note_complete',placement(dict(ev,kind='ifrs_lease_carrying_coverage',scope='lease_only'),status.removesuffix('_coverage')),scale=scale)


def _ifrs_financing_closure(block,page_tables,dataset,current,previous,context,put,output):
    """IAS7 funding-liability closing balances close the reference debt scope.

    Every funding line is classified; derivatives are separately excluded.
    Interest-inclusive future contractual cash-flow tables are never eligible.
    """
    text=_compact(_text(block))
    if '財務活動から生じる負債の変動は、以下のとおりです'not in text:return
    if '1年内返済'in text and '予定の残高を含んでおります'not in text and '償還予定の残高を含んでおります'not in text:return
    tables=[n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='table'and _visible(n)]
    candidates=[]
    for ti,t in enumerate(tables,1):
        _,g,physical=_grid(t)
        seen_headers=set()
        for hi,row in enumerate(g):
            end=[col for col,c in row.items()if _compact(_text(c))=='期末残高']
            begin=[col for col,c in row.items()if _compact(_text(c))=='期首残高']
            if len(end)==len(begin)==1 and any(_compact(_text(c))=='キャッシュ・フローから生じる変動'for c in row.values()):
                signature=(id(row[begin[0]]),id(row[end[0]]))
                if signature in seen_headers:continue
                seen_headers.add(signature)
                candidates.append((ti,t,g,physical,hi,begin[0],end[0]))
    if len(candidates)not in {1,2}:return
    work=[(c,'closing')for c in candidates]
    if len(candidates)==1:work.append((candidates[0],'opening_annual_prior_close'))
    # Table-local preceding dated duration text proves prior/current; positions
    # alone are never a fiscal label.
    block_nodes=list(block.iter());positions={id(n):i for i,n in enumerate(block_nodes)};seen=set()
    for candidate,balance_mode in work:
        ti,t,g,physical,hi,begin,end=candidate
        prefix=''.join((n.text or '')+(n.tail or '')for n in block_nodes[:positions[id(t)]])
        matches=re.findall(r'(?:自)?\s*(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日\s*(?:至|~|～)\s*(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日',unicodedata.normalize('NFKC',prefix))
        if not matches:raise DebtNoteError('財務活動負債変動表の年次期間を確認できません。')
        from datetime import date
        try:
            y,m,d,ey,em,ed=map(int,matches[-1]);start=date(y,m,d);day=date(ey,em,ed)
        except ValueError:
            raise DebtNoteError('財務活動負債変動表の期間の日付が不正です。')from None
        table_start,table_end=start,day
        balance_col=end
        if balance_mode=='opening_annual_prior_close':
            # A simple annual opening is coverage evidence only. Transition
            # restatements and cumulative policy effects never map to prior.
            if (start!=context.start or day!=context.end or
                    any(token in _compact(_text(t))for token in ['会計方針','移行','遡及','累積','再表示','適用'])):
                continue
            day=context.start-timedelta(days=1);balance_col=begin
            selected=[p for p in previous if p.end==day]
        else:
            selected=[p for p in previous+current if p.start==start and p.end==day]
        if not selected:raise DebtNoteError('財務活動負債変動表の期間が本表年度と対応しません。')
        if day in seen:raise DebtNoteError('財務活動負債変動表の年度が重複しています。')
        seen.add(day);p=selected[0]
        unit,scale=_unit([_text(c)for row in g[:hi+1]for c in set(row.values())],block,t);factor=Decimal(10)**scale
        classified={};derivatives=[];reported=None;proof=[]
        for ri in range(hi+1,len(g)):
            cells=g[ri]
            label=_compact(_text(cells[0]))if 0 in cells else ''
            if not label:continue
            if begin not in cells or end not in cells:raise DebtNoteError('財務活動負債変動表の期末残高列が欠けています。')
            name=re.sub(r'\(注\)\d+$','',label)
            category=({'短期借入金':'short','コマーシャル・ペーパー':'cp','長期借入金':'long','社債':'bonds','リース負債':'leases','リース債務':'leases'}).get(name)
            total=label=='財務活動によるキャッシュ・フローから生じる負債合計額'
            derivative=bool(re.fullmatch(r'デリバティブ負債又は資産\(△\)(?:\(注\)\d+)?',label))
            if not category and not total and not derivative:raise DebtNoteError('財務活動負債変動表に未識別の資金調達項目があります: '+label)
            raw=_compact(_text(cells[balance_col]));negative=raw.startswith(('△','▲','-','−'))and raw not in _DASHES
            amount=_amount(raw[1:]if negative else raw)[0]*factor
            if negative:amount=-amount
            if (category or total)and amount<0:raise DebtNoteError('資金調達負債残高の符号が対応範囲外です。')
            pr,pc=physical[cells[balance_col]];item=dict(label=_text(cells[0]),category=category,value_jpy=str(amount),raw_value=_text(cells[balance_col]),physical_row=pr,physical_column=pc)
            proof.append(item)
            if category:
                if category in classified:raise DebtNoteError('財務活動負債変動表の資金調達区分が重複しています。')
                classified[category]=amount
            elif derivative:derivatives.append(item)
            else:
                if reported is not None:raise DebtNoteError('財務活動負債変動表の合計が複数あります。')
                reported=amount
        if not {'short','long','bonds','leases'}<=set(classified)or reported is None or len(derivatives)!=1:return
        tolerance=factor*Decimal(len(proof)+1)
        if abs(sum(classified.values(),Decimal(0))+sum(Decimal(d['value_jpy'])for d in derivatives)-reported)>tolerance:raise DebtNoteError('財務活動負債変動表の期末全内訳・デリバティブと合計が一致しません。')
        groups={'short':['short_term_borrowings'],'cp':['commercial_paper'],'long':['current_long_term_borrowings','long_term_borrowings'],'bonds':['current_bonds','bonds'],'leases':['current_lease','noncurrent_lease']};reconciled=[]
        complete=True;main_reconciliation=[]
        from .analysis import debt_category
        for group,categories in groups.items():
            members=[output.get(f'notes:debt:{c}:consolidated')for c in categories]
            values=[r.values.get(p.key)if r else None for r in members]
            if group=='cp'and group not in classified:
                if any(c is not None and c.value not in {None,Decimal(0)}for c in values):raise DebtNoteError('借入内訳のCPと財務活動変動表の範囲が一致しません。')
                continue
            if group=='cp' and classified.get(group)==0 and all(c is None for c in values):
                source_row=next(item for item in proof if item['category']=='cp')
                created=put('commercial_paper',p,Decimal(0),source_row['raw_value'],'explicit_no_balance',
                    dict(kind='ifrs_financing_explicit_zero',scope='commercial_paper_only',balance_column=balance_mode,
                         table_index=ti,page_table_index=page_tables.index(t)+1,
                         physical_row=source_row['physical_row'],physical_column=source_row['physical_column'],
                         unit_label=unit,scale=scale,source_section=getattr(block,'scope_evidence',None)),
                    source_row['label'],scale)
                values=[created]
            if any(c is None or c.value is None or c.nil for c in values):complete=False;break
            total=sum((c.value for c in values),Decimal(0))
            if group not in classified or abs(total-classified[group])>tolerance:raise DebtNoteError('財務活動負債変動表と独立した借入・社債・リース残高が一致しません: '+group)
            reconciled.append(dict(group=group,categories=categories,note_sum_jpy=str(total),funding_closing_jpy=str(classified[group])))
            for category,note_cell in zip(categories,values):
                primary=[]
                for row in dataset.rows['BS_LE']:
                    main_cell=row.values.get(p.key)
                    if main_cell is None:continue
                    main_category=debt_category(row,main_cell)
                    if (category=='short_term_borrowings'and main_category=='current_borrowings'
                            and _compact(main_cell.source.original_label or row.label)=='短期借入金'):
                        main_category='short_term_borrowings'
                    if main_category==category and main_cell.value is not None and not main_cell.nil:
                        primary.append(main_cell)
                if len(primary)>1:
                    # Independent convertible and plain bond components can
                    # legitimately sum to the note's total bond category.
                    if category not in {'bonds','current_bonds'}:complete=False;break
                if primary:
                    main_total=sum((c.value for c in primary),Decimal(0))
                    precision=sum((Decimal(10)**-int(c.source.decimals)for c in primary+[note_cell]
                        if re.fullmatch(r'-?\d+',str(c.source.decimals))),Decimal(0))
                    if abs(main_total-note_cell.value)>precision:
                        raise DebtNoteError('財務活動負債の独立注記と本表の同じ分類残高が開示精度内で一致しません: '+category,periods=[p.key])
                    main_reconciliation.append(dict(category=category,main_value_jpy=str(main_total),note_value_jpy=str(note_cell.value),
                        precision_jpy=str(precision),main_sources=[dict(doc_id=c.source.doc_id,concept=c.source.account_concept,context=c.source.context_id)for c in primary]))
                else:
                    main_reconciliation.append(dict(category=category,main_value_jpy=None,note_value_jpy=str(note_cell.value),
                        reason='本表に数値のある同区分残高がないため、独立した原文注記の期末残高を保持。nilをゼロとは扱わない。'))
        if not complete:continue
        if balance_mode=='opening_annual_prior_close'and seen!={context.end,context.start-timedelta(days=1)}:continue
        put('ifrs_reference_debt_coverage',p,None,_text(t),'ifrs_reference_debt_complete',dict(kind='ifrs_reference_debt_coverage',scope='all_reference_debt_categories',
            table_index=ti,page_table_index=page_tables.index(t)+1,unit_label=unit,scale=scale,period_start=p.start.isoformat(),period_end=p.end.isoformat(),
            balance_column=balance_mode,source_table_period_start=table_start.isoformat(),source_table_period_end=table_end.isoformat(),
            physical_balance_column=balance_col+1,target_period_end=p.end.isoformat(),
            mapping_rule='context.start_minus_one_day_is_same_original_prior_note_closing'if balance_mode=='opening_annual_prior_close'else'explicit_annual_closing',
            no_policy_or_transition_adjustment=True if balance_mode=='opening_annual_prior_close'else None,
            rows=proof,excluded_derivatives=derivatives,reported_funding_liabilities_jpy=str(reported),reference_debt_jpy=str(sum(classified.values(),Decimal(0))),
            reconciliation=reconciled,main_reconciliation=main_reconciliation,rounding_tolerance_jpy=str(tolerance),source_section=getattr(block,'scope_evidence',None)),scale=scale)



def _ifrs_liability_note(block, page_tables, dataset, current, previous, context,
                         specification, put):
    """Read carrying amounts, never undiscounted lease maturity cash flows."""
    category,title,parent_local=specification
    scoped=[p.key for p in previous+current]
    tables=[n for n in block.iter() if isinstance(n.tag,str) and _local(n.tag)=='table' and _visible(n)]
    candidates=[]
    expected_dates={context.end,context.start-timedelta(days=1)}
    for ti,table in enumerate(tables,1):
        rows,grid,physical=_grid(table)
        for hi,cells in enumerate(grid):
            dates={col:_dates(_text(cell)) for col,cell in cells.items()}
            dated={col:values[0] for col,values in dates.items() if len(values)==1}
            if not dated:
                continue
            if len(dated)!=2 or set(dated.values())!=expected_dates:
                raise DebtNoteError('その他負債注記の年度列が本表と一致しないか、既知の3列形式ではありません。',periods=scoped)
            # EDINET often inserts physically blank spacer columns. They are
            # not financial columns, and every later value in them is checked.
            label_cols={col for col in set(cells)-set(dated)
                        if any(_compact(_text(row[col]))for row in grid[hi+1:]if col in row)}
            if len(label_cols)!=1:
                raise DebtNoteError('その他負債注記の項目列を一意に識別できません。',periods=scoped)
            candidates.append((ti,table,grid,physical,hi,label_cols.pop(),dated))
    if len(candidates)!=1:
        raise DebtNoteError('その他負債注記の残高表を一意に識別できません。',periods=scoped)
    ti,table,grid,physical,hi,label_col,dated=candidates[0]
    header_texts=[_text(c) for row in grid[:hi+1] for c in set(row.values())]
    unit_name,scale=_unit(header_texts,block,table)
    proof=[];sums={col:Decimal(0) for col in dated};totals={};lease_seen=False
    for ri in range(hi+1,len(grid)):
        cells=grid[ri]
        if not any(_compact(_text(c)) for c in set(cells.values())):
            continue
        semantic_columns={label_col,*dated}
        if not semantic_columns<=set(cells) or any(_compact(_text(cell))for col,cell in cells.items()if col not in semantic_columns):
            raise DebtNoteError('その他負債注記の明細列が欠けています。',periods=scoped)
        label=_text(cells[label_col]);name=_compact(label)
        total=name in {'合計','計','総合計'}
        lease=name in {'リース負債','リース債務'}
        if lease and lease_seen:
            raise DebtNoteError('その他負債注記に同じリース残高が複数行あります。',periods=scoped)
        if lease:lease_seen=True
        if not lease and not total and any(t in name for t in ['借入','社債','リース','有利子']):
            raise DebtNoteError('その他負債注記に未識別の有利子残高があります: '+label,periods=scoped)
        row_proof={'label':label,'physical_row':ri+1,'values':{}}
        for col,end in dated.items():
            cell=cells[col]
            if any(n.get('xsi:nil','').lower() in {'true','1'}or n.get('continuedat')for n in cell.iter()):
                raise DebtNoteError('その他負債注記の残高にnil・継続参照があります。',periods=scoped)
            raw=_text(cell);amount,operation=_amount(raw);amount*=Decimal(10)**scale
            row_proof['values'][end.isoformat()]={'raw':raw,'value_jpy':str(amount)}
            if total:
                if col in totals:raise DebtNoteError('その他負債注記に複数の合計があります。',periods=scoped)
                totals[col]=amount
            else:sums[col]+=amount
            if lease:
                pri=[p for p in previous+current if p.end==end]
                physical_row,physical_col=physical[cell]
                for period in pri:
                    put(category,period,amount,raw,operation,
                        {'kind':'ifrs_other_liabilities','table_index':ti,
                         'page_table_index':page_tables.index(table)+1,
                         'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                         'balance_column':'closing','column_header':_text(grid[hi][col]),
                         'unit_label':unit_name,'scale':scale,'raw_value':raw,'parent_local':parent_local},label,scale)
        proof.append(row_proof)
    if set(totals)!=set(dated):
        raise DebtNoteError('その他負債注記の各年度の合計を確認できません。',periods=scoped)
    tolerance=Decimal(10)**scale*Decimal(len(proof)+1)
    for col,reported in totals.items():
        if abs(sums[col]-reported)>tolerance:
            raise DebtNoteError('その他負債注記の内訳と合計が丸め許容差を超えています。',periods=scoped)
        for period in [p for p in previous+current if p.end==dated[col]]:
            parents=[c for row in dataset.rows['BS_LE'] for key,c in row.values.items()
                     if key==period.key and c.source.concept.rsplit('}',1)[-1]==parent_local]
            if any(c.value is not None and not c.nil and abs(c.value-reported)>tolerance for c in parents):
                raise DebtNoteError('その他負債注記の合計と本表の同区分残高が一致しません。',periods=[period.key])
            put(category+'_coverage',period,None,_text(table),'lease_note_complete',
                {'kind':'ifrs_other_liabilities_coverage','table_index':ti,
                 'page_table_index':page_tables.index(table)+1,'unit_label':unit_name,'scale':scale,
                 'rows':proof,'parent_local':parent_local,'lease_row_present':lease_seen,
                 'reported_note_total_jpy':str(reported),'component_sum_jpy':str(sums[col]),
                 'rounding_tolerance_jpy':str(tolerance)},scale=scale)


def _chugai_nonlease_absence(block, current, put):
    """A narrow issuer-specific explicit claim, not a fuzzy no-debt search."""
    paragraphs=[n for n in block.iter() if isinstance(n.tag,str) and _local(n.tag)=='p']
    statements=[]
    for pi,node in enumerate(paragraphs,1):
        text=_text(node);normalized=_compact(text)
        if not normalized.startswith(_NONLEASE_OPENING):continue
        previous=node.getprevious()
        while previous is not None and not _compact(_text(previous)):
            previous=previous.getprevious()
        if previous is None or _compact(_text(previous))!='金利リスク':continue
        if normalized==_NONLEASE_STATEMENT:
            statements.append((pi,text))
    if not statements:return
    if len(statements)!=1:
        raise DebtNoteError('非リース有利子負債なしの限定文が複数あります。',periods=[p.key for p in current])
    pi,text=statements[0]
    ev={'kind':'explicit_nonlease_absence','statement':text,'paragraph_index':pi,
        'scope':'nonlease_only','table_index':None,'physical_row':None,'physical_column':None,
        'balance_column':'end'}
    for period in current:
        put('nonlease_debt_absent',period,Decimal(0),text,'explicit_no_nonlease_debt',ev)
        for category in ['short_term_borrowings','current_long_term_borrowings','long_term_borrowings',
                         'bonds','current_bonds','commercial_paper']:
            put(category,period,Decimal(0),text,'explicit_no_balance',ev)


def _ifrs_sectioned_note(block,page_tables,dataset,current,previous,context,specification,evidence_source,put):
    """Classified loan/lease balances with explicit current/noncurrent groups.

    Other financial lines are fully reconciled but never reclassified as debt.
    A transition opening column is excluded only when it says 移行日 and has a
    dated balance earlier than the prior annual closing balance.
    """
    kind,_,status,operation=specification
    scoped=[p.key for p in previous+current]
    expected_dates={context.end,context.start-timedelta(days=1)}
    tables=[n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='table'and _visible(n)]
    candidates=[]
    for ti,table in enumerate(tables,1):
        _,grid,physical=_grid(table)
        for hi,cells in enumerate(grid):
            raw_dates={col:_dates(_text(cell))for col,cell in cells.items()}
            if not any(raw_dates.values()):continue
            annual={};excluded=[]
            for col,dates in raw_dates.items():
                if not dates:continue
                if len(dates)!=1:
                    raise DebtNoteError('IFRS負債注記の残高列に複数の日付があります。',periods=scoped)
                day=dates[0];header=_text(cells[col])
                if day in expected_dates:
                    if '移行日'in _compact(header):
                        raise DebtNoteError('IFRS移行日を年次残高列として扱いません。',periods=scoped)
                    annual[col]=day
                elif '移行日'in _compact(header)and day<min(expected_dates):
                    ri,ci=physical[cells[col]]
                    excluded.append({'expanded_column':col+1,'physical_row':ri,'physical_column':ci,
                                     'date':day.isoformat(),'column_header':header,
                                     'reason':'explicit_ifrs_transition_opening_not_an_annual_period'})
                else:
                    raise DebtNoteError('IFRS負債注記に対象外又は未識別の日付列があります。',periods=scoped)
            if len(annual)!=2 or set(annual.values())!=expected_dates or len(excluded)>1:
                raise DebtNoteError('IFRS負債注記の2年次残高列を一意に識別できません。',periods=scoped)
            rates=[col for col,c in cells.items()if '平均利率'in _compact(_text(c))]
            dues=[col for col,c in cells.items()if _compact(_text(c))=='返済期限']
            if kind=='ifrs_borrowings'and(len(rates)!=1 or len(dues)!=1):
                raise DebtNoteError('IFRS借入金注記の利率・期限列を確認できません。',periods=scoped)
            if kind!='ifrs_borrowings'and(rates or dues):
                raise DebtNoteError('IFRSその他金融負債注記に未知の追加列があります。',periods=scoped)
            dated=set(annual)|{e['expanded_column']-1 for e in excluded}
            other=set(rates+dues)
            labels={col for col in set(cells)-dated-other
                    if any(_compact(_text(row[col]))for row in grid[hi+1:]if col in row)}
            if len(labels)!=1:
                raise DebtNoteError('IFRS負債注記の項目列を一意に識別できません。',periods=scoped)
            candidates.append((ti,table,grid,physical,hi,labels.pop(),annual,excluded,other))
    if len(candidates)!=1:
        raise DebtNoteError('IFRS負債注記の残高表を一意に識別できません。',periods=scoped)
    ti,table,grid,physical,hi,label_col,annual,excluded,other=candidates[0]
    unit_name,scale=_unit([_text(c)for row in grid[:hi+1]for c in set(row.values())],block,table)
    excluded_cols={e['expanded_column']-1 for e in excluded}
    semantic={label_col,*annual,*excluded_cols,*other}
    headers=({'流動負債':'current','非流動負債':'noncurrent'}if kind=='ifrs_borrowings'else
             {'その他の金融負債(流動)':'current','その他の金融負債(非流動)':'noncurrent'})
    parent_names=({'current':'BorrowingsCLIFRS','noncurrent':'BorrowingsNCLIFRS'}if kind=='ifrs_borrowings'else
                  {'current':'OtherFinancialLiabilitiesCLIFRS','noncurrent':'OtherFinancialLiabilitiesNCLIFRS'})
    group=None;seen_groups=set();totals={};sums={};proof=[];excluded_rows={p.key:[]for p in previous+current};seen_categories=set()
    for ri in range(hi+1,len(grid)):
        cells=grid[ri]
        if not any(_compact(_text(c))for c in set(cells.values())):continue
        if not semantic<=set(cells)or any(_compact(_text(c))for col,c in cells.items()if col not in semantic):
            raise DebtNoteError('IFRS負債注記の明細列が欠けるか、スペーサーに未知の値があります。',periods=scoped)
        label=_text(cells[label_col]);name=_compact(label).rstrip(':：')
        if name in headers:
            group=headers[name]
            if group in seen_groups or any(_compact(_text(cells[c]))and cells[c]is not cells[label_col]for c in annual):
                raise DebtNoteError('IFRS負債注記の流動・非流動見出しが重複するか残高と混在しています。',periods=scoped)
            seen_groups.add(group);continue
        if kind!='ifrs_borrowings'and name=='償却原価で測定される金融負債':
            if any(_compact(_text(cells[c]))for c in annual):
                raise DebtNoteError('金融負債の分類見出しに未識別の残高があります。',periods=scoped)
            continue
        if group is None:
            raise DebtNoteError('IFRS負債注記の残高行の流動・非流動区分が不明です。',periods=scoped)
        total=name in {'合計','計','総合計'}
        stripped=re.sub(r'\(注\d*\)$','',name)
        if kind=='ifrs_borrowings':
            category=_category(label)
            allowed={'short_term_borrowings','current_long_term_borrowings'}if group=='current'else{'long_term_borrowings'}
            if category not in allowed and not total:
                raise DebtNoteError('IFRS借入金注記に未識別又は区分外の借入残高があります: '+label,periods=scoped)
        else:
            category=('current_lease'if group=='current'else'noncurrent_lease')if stripped in {'リース負債','リース債務'}else None
            if not category and not total and any(t in name for t in ['借入','社債','リース','有利子']):
                raise DebtNoteError('IFRSその他金融負債注記に未識別の有利子項目があります: '+label,periods=scoped)
        if category:
            if category in seen_categories:
                raise DebtNoteError('IFRS負債注記の同一カテゴリが重複しています: '+label,periods=scoped)
            seen_categories.add(category)
        rowproof={'label':label,'section':group,'category':category,'physical_row':ri+1,'values':{}}
        for col,day in annual.items():
            cell=cells[col]
            if any(n.get('xsi:nil','').lower()in{'true','1'}or n.get('continuedat')for n in cell.iter()):
                raise DebtNoteError('IFRS負債注記の残高にnil・継続参照があります。',periods=scoped)
            raw=_text(cell);amount,zero_operation=_amount(raw);amount*=Decimal(10)**scale
            rowproof['values'][day.isoformat()]={'raw':raw,'value_jpy':str(amount)}
            pair=group,col
            if total:
                if pair in totals:raise DebtNoteError('IFRS負債注記の同一区分合計が重複しています。',periods=scoped)
                totals[pair]=amount
            else:sums[pair]=sums.get(pair,Decimal(0))+amount
            for period in [p for p in previous+current if p.end==day]:
                physical_row,physical_col=physical[cell]
                ev={'kind':kind,'table_index':ti,'page_table_index':page_tables.index(table)+1,
                    'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                    'balance_column':'closing','column_header':_text(grid[hi][col]),'section':group,
                    'unit_label':unit_name,'scale':scale,'raw_value':raw,'excluded_columns':excluded,
                    'parent_local':parent_names[group]}
                if category:
                    put(category,period,amount,raw,zero_operation,ev,label,scale)
                elif not total:
                    excluded_rows[period.key].append({'label':label,'value_jpy':str(amount),'raw_value':raw,
                        'section':group,'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                        'source':evidence_source,'unit_label':unit_name,'scale':scale,
                        'reason':'outside_reference_core_and_not_explicitly_interest_bearing; interest_nature_not_inferred'})
        proof.append(rowproof)
    required={(group,col)for group in ['current','noncurrent']for col in annual}
    if seen_groups!={'current','noncurrent'}or set(totals)!=required:
        raise DebtNoteError('IFRS負債注記の流動・非流動の両合計を確認できません。',periods=scoped)
    tolerance=Decimal(10)**scale*Decimal(len(proof)+1)
    reconciled={p.key:[]for p in previous+current}
    for (group,col),reported in totals.items():
        if abs(sums.get((group,col),Decimal(0))-reported)>tolerance:
            raise DebtNoteError('IFRS負債注記の明細と区分合計が一致しません。',periods=scoped)
        for period in [p for p in previous+current if p.end==annual[col]]:
            parents=[c for row in dataset.rows['BS_LE']for key,c in row.values.items()
                     if key==period.key and c.source.concept.rsplit('}',1)[-1]==parent_names[group]]
            if len(parents)!=1 or parents[0].value is None or parents[0].nil:
                raise DebtNoteError('IFRS負債注記に対応する本表の区分残高を一意に確認できません。',periods=[period.key])
            if abs(parents[0].value-reported)>tolerance:
                raise DebtNoteError('IFRS負債注記の区分合計と本表の残高が一致しません。',periods=[period.key])
            reconciled[period.key].append({'section':group,'parent_local':parent_names[group],
                'note_total_jpy':str(reported),'component_sum_jpy':str(sums[group,col]),
                'main_value_jpy':str(parents[0].value),'main_source_concept':parents[0].source.concept})
    for period in previous+current:
        put(status,period,None,_text(table),operation,
            {'kind':status,'scope':'loans_only'if kind=='ifrs_borrowings'else'classified_financial_liabilities_only',
             'table_index':ti,'page_table_index':page_tables.index(table)+1,'unit_label':unit_name,'scale':scale,
             'rows':proof,'excluded_columns':excluded,'excluded_rows':excluded_rows[period.key],
             'main_reconciliation':reconciled[period.key],'rounding_tolerance_jpy':str(tolerance)},scale=scale)


def extract_debt_notes(pages: list[tuple[str, str]], parsed_dataset: Dataset) -> list[Row]:
    """Return source-evidenced categories and coverage/status audit rows.

    Only known EDINET appendix TextBlocks are interpreted. Unknown notes are
    never mined by loose wording. Absence of a category row creates no zero.
    An explicitly printed dash, or an explicit applicable-none statement, can
    establish zero while retaining that exact original evidence.
    """
    dataset = parsed_dataset
    if dataset.basis not in {'consolidated', 'standalone'}:
        raise DebtNoteError('借入注記は年度・連結区分を選択した単一原本から取得してください。')
    parsed = []
    context_entities = {}
    try:
        for filename, markup in pages:
            if isinstance(markup, bytes):
                markup = markup.decode('utf-8-sig')
            if markup.strip():
                root = html.fromstring(markup.lstrip('\ufeff').encode('utf-8'),
                                       parser=html.HTMLParser(encoding='utf-8', no_network=True))
                parsed.append(Page(filename, root, _namespaces(markup)))
        contexts = _contexts(parsed)
        for page in parsed:
            for node in page.root.iter():
                if isinstance(node.tag,str) and _local(node.tag)=='context':
                    identifiers={_text(e) for e in node.iter() if isinstance(e.tag,str)
                                 and _local(e.tag)=='identifier' and _text(e)}
                    context_entities.setdefault(node.get('id',''),set()).update(identifiers)
    except (ValueError, etree.ParserError, ParseError) as exc:
        raise DebtNoteError(f'借入注記のXBRLコンテキストを読めません: {exc}') from exc
    source_candidates = [cell.source for rows in dataset.rows.values() for row in rows
                         for period, cell in row.values.items() if period in {p.key for p in dataset.periods}
                         and cell.source.basis == dataset.basis]
    output = {}
    closure_tasks=[]
    combined_local='NotesBondsAndBorrowingsConsolidatedFinancialStatementsIFRSTextBlock'
    lease_local='NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock'
    financing_local='NotesCashFlowInformationConsolidatedFinancialStatementsIFRSTextBlock'
    plain_local='NotesToConsolidatedFinancialStatementsIFRSTextBlock'
    has_combined=any(n.get('name','').rsplit(':',1)[-1]==combined_local for pg in parsed for n in pg.root.iter()if isinstance(n.tag,str))
    for page in parsed:
        blocks = [node for node in page.root.iter() if isinstance(node.tag, str)
                  and _local(node.tag) == 'nonnumeric' and _visible(node)]
        page_tables = [node for node in page.root.iter() if isinstance(node.tag, str) and _local(node.tag) == 'table']
        for block_index, block in enumerate(blocks, 1):
            raw_qname = block.get('name', '')
            local = raw_qname.rsplit(':', 1)[-1]
            match = _BLOCK_NAME.fullmatch(local)
            ifrs_note=_IFRS_LIABILITY_NOTES.get(local)
            section_note=_IFRS_SECTION_NOTES.get(local)
            risk=local==_RISK_LOCAL
            combined=local==combined_local
            lease=local==lease_local and has_combined
            financing=local==financing_local and has_combined
            plain=local==plain_local and dataset.accounting_standard=='IFRS'
            if plain:
                plain_scopes={title:_numbered_note_scope(block,title,page_tables)for title in ['リース','社債及び借入金等','キャッシュ・フロー情報']}
                if not all(plain_scopes.values()):continue
            if not match and not ifrs_note and not section_note and not risk and not combined and not lease and not financing and not plain:
                continue
            basis = 'consolidated' if ifrs_note or section_note or risk or combined or lease or financing or plain or match.group('consolidated') else 'standalone'
            if basis != dataset.basis:
                continue
            try:
                qname = _expanded(raw_qname, page.namespaces)
            except ParseError as exc:
                raise DebtNoteError(str(exc)) from exc
            uri = qname[1:].split('}', 1)[0]
            if risk and not _CHUGAI_URI.fullmatch(uri):
                continue
            if ((ifrs_note or section_note or combined or lease or financing) and not _IFRS_URI.fullmatch(uri)) or ((match or plain) and not _STANDARD_URI.fullmatch(uri)):
                raise DebtNoteError('借入注記の標準タクソノミを確認できません。')
            context_id = block.get('contextref', '')
            context = contexts.get(context_id)
            if context is None or context.instant or context.start is None or context.dimensions:
                raise DebtNoteError('借入注記の年度・次元コンテキストを確認できません。')
            if context.basis is not None and context.basis != basis:
                raise DebtNoteError('借入注記の見出しと連結区分が一致しません。')
            current = [p for p in dataset.periods if p.start == context.start and p.end == context.end]
            previous = [p for p in dataset.periods if p.end == context.start - timedelta(days=1)]
            if len(current) != 1:
                raise DebtNoteError('借入注記の年度が本表の対象年度と一致しません。', periods=[p.key for p in dataset.periods])
            scoped_periods = [p.key for p in previous + current]
            if block.get('continuedat') or block.get('xsi:nil', '').lower() in {'true', '1'}:
                raise DebtNoteError('継続参照・nilの借入注記から残高を確定できません。', periods=scoped_periods)
            if len({s.doc_id for s in source_candidates}) != 1:
                raise DebtNoteError('借入注記の元書類を一意に確認できません。', periods=scoped_periods)
            base = source_candidates[0]
            issuers=context_entities.get(context_id,set())
            if len(issuers)!=1:
                raise DebtNoteError('借入注記の提出者コンテキストを一意に確認できません。',periods=scoped_periods)
            original_issuer=re.search(r'E\d{5}-\d{3}',base.filename)
            note_issuer=re.search(r'E\d{5}-\d{3}',page.filename)
            if original_issuer and (next(iter(issuers))!=original_issuer.group()
                                    or note_issuer and note_issuer.group()!=original_issuer.group()):
                raise DebtNoteError('借入注記と本表の提出者が一致しません。',periods=scoped_periods)
            text = _text(block)
            title = '社債及び借入金等' if combined else 'リース' if lease else 'キャッシュ・フロー情報' if financing else '注記' if plain else ifrs_note[1] if ifrs_note else section_note[1]if section_note else 'リスクマネジメント' if risk else '借入金等明細表' if match.group('kind') == 'Borrowings' else '社債明細表'
            if not plain and title not in _compact(text):
                raise DebtNoteError('借入注記の標準要素と実際の見出しが一致しません。', periods=scoped_periods)
            evidence_base = {'filename':page.filename, 'block_qname':qname, 'block_context':context_id,
                             'block_index':block_index, 'basis':basis, 'document_id':base.doc_id,
                             'context_period_start':context.start.isoformat(), 'context_period_end':context.end.isoformat()}
            statement = _compact(text).replace('【' + title + '】', '').replace(title, '').strip('。．.')
            no_items = statement in {'該当事項はありません', '該当事項がありません', '該当する事項はありません',
                                     '該当事項はございません', '該当事項なし'}
            def put(category, period, amount, raw, operation, evidence, label=None, scale=0,
                    _basis=basis,_base=base,_filename=page.filename,_qname=qname,
                    _context_id=context_id,_evidence_base=evidence_base):
                key = f'notes:debt:{category}:{_basis}'
                row = output.setdefault(key, Row(key, _LABELS[category], 'BS_LE', section=('借入金等明細表',)))
                if period.key in row.values:
                    raise DebtNoteError('同じ年度の借入注記カテゴリが複数あります: ' + category, periods=[period.key])
                source = _source(_base, _filename, _qname, _context_id, label or _LABELS[category], raw, _basis, scale)
                cell = Cell(amount, source, operation=operation,
                    note=_note({**_evidence_base, **evidence, 'category':category,
                                'period_start':period.start.isoformat(), 'period_end':period.end.isoformat()},
                               '原文注記の独立した残高。BS本表の同じ対象残高と重ねて加算しない。'))
                row.values[period.key] = cell
                return cell
            if plain:
                _ifrs_combined_bonds_borrowings(plain_scopes['社債及び借入金等'],page_tables,dataset,current,previous,context,put)
                _ifrs_lease_balances(plain_scopes['リース'],page_tables,dataset,current,previous,context,put)
                closure_tasks.append((plain_scopes['キャッシュ・フロー情報'],page_tables,dataset,current,previous,context,put))
                continue
            if combined:
                _ifrs_combined_bonds_borrowings(block,page_tables,dataset,current,previous,context,put)
                continue
            if lease:
                _ifrs_lease_balances(block,page_tables,dataset,current,previous,context,put)
                continue
            if financing:
                closure_tasks.append((block,page_tables,dataset,current,previous,context,put))
                continue
            if ifrs_note:
                _ifrs_liability_note(block,page_tables,dataset,current,previous,context,ifrs_note,put)
                continue
            if section_note:
                _ifrs_sectioned_note(block,page_tables,dataset,current,previous,context,section_note,evidence_base,put)
                continue
            if risk:
                _chugai_nonlease_absence(block,current,put)
                continue
            if no_items:
                kind = 'borrowings' if match.group('kind') == 'Borrowings' else 'bonds'
                category = kind + '_absent'
                operation = 'explicit_no_borrowings' if kind == 'borrowings' else 'explicit_no_bonds'
                ev = {'kind':'explicit_none', 'statement':text, 'table_index':None,
                      'physical_row':None, 'physical_column':None, 'balance_column':'end'}
                # A prose-only current-year statement does not silently prove
                # the prior comparative year's closing balances were zero.
                put(category, current[0], Decimal(0), text, operation, ev)
                for covered in _BORROWING_CATEGORIES if kind == 'borrowings' else ('bonds', 'current_bonds'):
                    put(covered, current[0], Decimal(0), text, 'explicit_no_balance', ev)
                continue
            if match.group('kind') != 'Borrowings':
                _corporate_bonds_note(block,page_tables,current,context,put)
                continue
            tables = [node for node in block.iter() if isinstance(node.tag, str) and _local(node.tag) == 'table' and _visible(node)]
            candidates = []
            for table_index, table in enumerate(tables, 1):
                rows, grid, physical = _grid(table)
                for header_index, cells in enumerate(grid):
                    texts = {col:_compact(_text(cell)) for col,cell in cells.items()}
                    beginnings = [col for col,t in texts.items() if any(s in t for s in ['当期首残高','前期末残高','前連結会計年度末残高','前事業年度末残高'])]
                    endings = [col for col,t in texts.items() if any(s in t for s in ['当期末残高','当連結会計年度末残高','当事業年度末残高'])]
                    if beginnings or endings:
                        if len(beginnings) != 1 or len(endings) != 1:
                            raise DebtNoteError('借入金等明細表の期首・期末列が一意ではありません。', periods=scoped_periods)
                        labels = [col for col,t in texts.items() if t == '区分']
                        rates = [col for col,t in texts.items() if '平均利率' in t]
                        dues = [col for col,t in texts.items() if t == '返済期限']
                        if len(labels) != 1 or len(rates) != 1 or len(dues) != 1 or len(set(texts)) != 5:
                            raise DebtNoteError('借入金等明細表の区分・残高・利率・期限の列形式が未対応です。', periods=scoped_periods)
                        columns = labels[0], beginnings[0], endings[0], rates[0], dues[0]
                        if len(set(columns)) != 5:
                            raise DebtNoteError('借入金等明細表の列区分が重複しています。', periods=scoped_periods)
                        candidates.append((table_index,table,rows,grid,physical,header_index,columns))
            if len(candidates) != 1:
                raise DebtNoteError('借入金等明細表の残高表を一意に確認できません。', periods=scoped_periods)
            table_index,table,rows,grid,physical,header_index,columns = candidates[0]
            label_col,begin_col,end_col,rate_col,_ = columns
            header_texts = [_text(grid[header_index][col]) for col in columns]
            unit_name,scale = _unit(header_texts,block,table)
            for col, expected in [(begin_col,context.start-timedelta(days=1)),(end_col,context.end)]:
                if any(day != expected for day in _dates(_text(grid[header_index][col]))):
                    raise DebtNoteError('借入金等明細表の列の日付とXBRL年度が一致しません。', periods=scoped_periods)
            amounts, totals, categories = {'begin':[],'end':[]}, {}, set()
            proof_rows=[]
            for row_index in range(header_index+1,len(grid)):
                cells=grid[row_index]
                if not any(_compact(_text(cell)) for cell in set(cells.values())):
                    continue
                if any(col not in cells for col in columns):
                    raise DebtNoteError('借入金等明細表の明細列が欠けています。', periods=scoped_periods)
                label=_text(cells[label_col]);normalized=_compact(label)
                total = normalized in {'合計','計','総合計'}
                category = _category(label)
                if not total and category is None:
                    raise DebtNoteError('借入金等明細表に未識別の残高行があります: '+label, periods=scoped_periods)
                if normalized in _INTEREST_DEPOSIT_CAPTIONS:
                    rate_raw=_text(cells[rate_col])
                    try:
                        rate,_=_amount(rate_raw.rstrip('%％').strip())
                    except DebtNoteError:
                        raise DebtNoteError('その他有利子負債の預り金について正の平均利率を確認できません。',periods=scoped_periods) from None
                    if rate<=0:
                        raise DebtNoteError('その他有利子負債の預り金について正の平均利率を確認できません。',periods=scoped_periods)
                if category is not None and category in categories:
                    raise DebtNoteError('借入金等明細表に同一カテゴリの複数行があります: '+label, periods=scoped_periods)
                if category is not None:
                    categories.add(category)
                proof_row={'label':label,'category':category,'physical_row':row_index+1,'values':{}}
                for balance,col,period_list in [('begin',begin_col,previous),('end',end_col,current)]:
                    value_cell=cells[col]
                    if any(node.get('xsi:nil','').lower() in {'true','1'} or node.get('continuedat') for node in value_cell.iter()):
                        raise DebtNoteError('借入金等明細表の残高にnil・継続参照があります。', periods=scoped_periods)
                    raw=_text(value_cell);amount,operation=_amount(raw);amount*=Decimal(10)**scale
                    proof_row['values'][balance]={'raw':raw,'value_jpy':str(amount)}
                    ri,ci=physical[value_cell]
                    rate_row,rate_column=physical[cells[rate_col]]
                    ev={'kind':'borrowings_schedule','table_index':table_index,
                        'page_table_index':page_tables.index(table)+1,'physical_row':ri,'physical_column':ci,
                        'expanded_column':col+1,'balance_column':balance,'column_header':_text(grid[header_index][col]),
                        'unit_label':unit_name,'scale':scale,'raw_value':raw,
                        'interest_rate_raw':_text(cells[rate_col]),
                        'interest_rate_column_header':_text(grid[header_index][rate_col]),
                        'interest_rate_physical_row':rate_row,'interest_rate_physical_column':rate_column,
                        'interest_rate_expanded_column':rate_col+1,
                        'interest_rate_positive_required':normalized in _INTEREST_DEPOSIT_CAPTIONS}
                    if total:
                        if balance in totals:
                            raise DebtNoteError('借入金等明細表に複数の合計行があります。', periods=scoped_periods)
                        totals[balance]=amount
                    else:
                        amounts[balance].append(amount)
                        for period in period_list:
                            put(category,period,amount,raw,operation,ev,label,scale)
                proof_rows.append(proof_row)
            if not categories:
                raise DebtNoteError('借入金等明細表の独立した残高行がありません。', periods=scoped_periods)
            tolerance=Decimal(10)**scale*Decimal(len(categories)+1)
            for balance,reported in totals.items():
                calculated=sum(amounts[balance],Decimal(0))
                if abs(calculated-reported)>tolerance:
                    raise DebtNoteError('借入金等明細表の内訳と合計が丸め許容差を超えて一致しません。', periods=scoped_periods)
            for period,balance in [(p,'begin')for p in previous]+[(p,'end')for p in current]:
                put('borrowings_coverage',period,None,text,'debt_schedule_complete',
                    {'kind':'borrowings_schedule_coverage','table_index':table_index,
                     'page_table_index':page_tables.index(table)+1,'balance_column':balance,
                     'unit_label':unit_name,'scale':scale,'rows':proof_rows,
                     'reported_schedule_total_jpy':str(totals[balance])if balance in totals else None,
                     'component_sum_jpy':str(sum(amounts[balance],Decimal(0))),
                     'rounding_tolerance_jpy':str(tolerance)},scale=scale)
    for task in closure_tasks:
        _ifrs_financing_closure(*task,output)
    return list(output.values())
