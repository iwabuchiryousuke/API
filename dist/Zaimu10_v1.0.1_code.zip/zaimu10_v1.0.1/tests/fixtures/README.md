# Original EDINET iXBRL fixtures

These gzip JSON files contain lists of `[original_filename, original_html]`
pairs returned by EDINET's public document viewer. They contain publicly filed
company reports, without viewer session state, cookies, or tokens. Preservation
of namespace declarations and QName spelling is intentional.

Source URL pattern:
`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{document_id}`

| Fixture | Document | Financial period | Regression purpose |
| --- | --- | --- | --- |
| `zuken_2025_ixbrl.json.gz` | S100W07I | 図研, 2025/03 | Consolidated and standalone chapters, negative facts, nil facts, CF beginning/end contexts |
| `dawn_2026_ixbrl.json.gz` | S100YXLE | ドーン, 2026/05 | Standalone reports with twelve-column colspan indentation |
| `torichemical_2017_ixbrl.json.gz` | S100A4D9 | トリケミカル研究所, 2017/01 | Early taxonomy and standalone financial statements |
| `nitori_2026_ixbrl.json.gz` | S100YIMF | ニトリホールディングス, 2026/03 | IFRS, separate note columns, repeated total, EPS in yen per share |
| `nitori_2025_transition_ixbrl.json.gz` | S100W5DK | ニトリホールディングス, 2025/03 | Three BS columns including explicitly dated IFRS transition opening balances |

Independent source oracles used in the tests:

- 図研2025: BS 61 monetary rows / 122 facts, PL 34 / 68, CF 35 / 70;
  260 facts including 12 `xsi:nil=true`. Assets JPY 63,274,260,000,
  sales JPY 40,736,294,000, operating income JPY 5,392,252,000,
  operating cash flow JPY 4,861,697,000, closing cash JPY 27,224,029,000.
- ドーン2026: 216 facts including 6 nil facts. Assets JPY 3,343,042,000,
  sales JPY 1,734,668,000, operating income JPY 655,128,000,
  operating cash flow JPY 653,462,000.
- ニトリ2026: original BS 84 facts, PL 36 facts (including two repeated
  ProfitLoss facts), and CF 92 facts. Assets JPY 1,571,284,000,000;
  revenue JPY 912,248,000,000; operating cash flow JPY 148,911,000,000.
  Basic and diluted EPS are both JPY 157.98 per share, with scale zero.

Source rows and fact counts were inspected independently from parser output.
