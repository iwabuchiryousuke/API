from datetime import date
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
import json

from openpyxl import Workbook,load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.formula import ArrayFormula
import pytest

from zaimu10.capm import calibration_window,linest,market_horizon,write_capm,TEMPLATE_PATH
from zaimu10.models import Dataset,Period,Cell,Source,Row

D=Decimal
TEST_RF=D('.025')
TEST_ERP=D('.055')

class Refs:
    def __init__(self, writer, *, debt=D(300), interest=D(-30), shareholder=D(1000), parent_profit=D(80)):
        self.writer=writer;self.debt=debt;self.interest=interest;self.shareholder=shareholder
        self.parent_profit=parent_profit
    def parent_profit_input(self,period):
        raise AssertionError('CAPM must use the visible PL22 parent profit, not add a helper')
    def register_parent_profit(self,*args):
        raise AssertionError('CAPM must not register a duplicated parent-profit input')
    def get(self,name,period):
        column=get_column_letter(self.writer.periods.index(period)+2)
        source={'interest_bearing_debt':('BS-le',35,self.debt),
                'interest_paid':('CF',27,self.interest),
                'net_profit':('PL',19,D(100)),
                'net_profit_parent':('PL',22,self.parent_profit),
                'shareholders_equity':('BS-le',24,self.shareholder)}.get(name)
        if source is None or source[2] is None:return None
        sheet,row,value=source
        self.writer.book[sheet][f'{column}{row}']=float(value)
        return SimpleNamespace(sheet=sheet,address=f'{column}{row}',value=value,
                               excel=f"'{sheet}'!{column}{row}")


def example(*,code='7826',years=(2023,2024),end_month='2024-08',**kwargs):
    periods=[Period(date(y,1,1),date(y,12,31)) for y in years]
    ds=Dataset(code,'株式会社テスト','consolidated',periods)
    book=Workbook();book.active.title='PL'
    for name in ['BS-a','BS-le','CF','DCF']:book.create_sheet(name)
    writer=SimpleNamespace(book=book,periods=periods,factor=D(1000),unit='thousand',unit_label='千円',
        values={},cached={},cells=[],layout_metadata={})
    for col,period in enumerate(periods,2):
        address=f'{get_column_letter(col)}13';writer.values['DCF',address]=D('.3');book['DCF'][address]=.3
    refs=Refs(writer,**kwargs)
    stock=[];index=[];end_year,end_m=map(int,end_month.split('-'));n=0
    for year in range(min(years)-5,end_year+1):
        for month in range(1,13):
            if year==min(years)-5 and month<12 or year==end_year and month>end_m:continue
            n+=1;stamp=f'{year}-{month:02d}'
            stock.append(dict(month=stamp,date=f'{stamp}-28',close=str(1000+13*n+(n%7)*9)+'.75'))
            index.append(dict(month=stamp,date=f'{stamp}-28',close=str(30000+71*n+(n%5)*30)+'.99'))
    market={'code':code,'benchmark':'^N225','stock_symbol':code+'.T',
            'stock_rows':stock,'index_rows':index,'end_month':end_month,
            'market_caps':{p.key:dict(value_jpy=str(1000000+100000*i*i),date=p.end.isoformat())for i,p in enumerate(periods)},
            'source_provenance':{'stock':{'source_url':'https://example.test/stock'},'index':{'source_url':'https://example.test/index'}},
            'risk_inputs':{
                'risk_free_rate':dict(value=str(TEST_RF),available=True,currency='JPY',semantic='jpy_default_free_rate',source_url='https://pages.stern.nyu.edu/~adamodar/official-currency.xlsx',as_of='2026-07-01',method='Synthetic test input with correct semantics'),
                'equity_risk_premium':dict(value=str(TEST_ERP),available=True,country='Japan',semantic='total_equity_risk_premium',source_url='https://pages.stern.nyu.edu/~adamodar/official-country.html',as_of='2026-07-01'),
            }}
    return writer,ds,refs,market


def test_original_linest_cached_betas_and_intercepts_independent_references():
    samples=json.loads((Path(__file__).parent/'fixtures/capm_reference.json').read_text())
    samples.append(json.loads((Path(__file__).parent/'fixtures/capm_reference_v160.json').read_text()))
    for sample in samples:
        rows={row['row']:row for row in sample['rows']}
        for regression in sample['regressions']:
            ys=[];xs=[]
            for n in range(regression['first_row'],regression['last_row']+1):
                ys.append(D(rows[n]['stock'])/D(rows[n+1]['stock'])-1)
                xs.append(D(rows[n]['index'])/D(rows[n+1]['index'])-1)
            beta,intercept=linest(ys,xs)
            assert float(beta)==pytest.approx(regression['beta'],abs=2e-14)
            assert float(intercept)==pytest.approx(regression['intercept'],abs=2e-14)


def test_historical_windows_do_not_copy_future_2014_beta():
    periods=[Period(date(2011,1,1),date(2011,12,31)),Period(date(2026,1,1),date(2026,12,31))]
    assert market_horizon(periods,today=date(2026,11,25))==('2006-12','2026-10')
    assert calibration_window(2011,2026,'2026-10')==('2007-01','2011-12')
    assert calibration_window(2026,2026,'2026-10')==('2022-01','2026-10')


def test_new_reference_top_formulas_and_array_linest_preserved():
    writer,ds,refs,market=example()
    metadata=write_capm(writer,ds,market,refs);ws=writer.book['CAPM']
    assert ws['B2'].value=="='BS-le'!B35"
    assert ws['B3'].value=="=-'CF'!B27/B2"
    assert ws['B5'].value=='=B4' and ws['C5'].value=='=(B4+C4)/2'
    assert ws['B6'].value=='=I18' and ws['C6'].value=='=I17'
    assert ws['B7'].value=='=H14+B6*J14' and ws['C7'].value=='=H14+I17*J14'
    assert ws['B9'].value=="='PL'!B22/'BS-le'!B24"
    assert writer.cached['CAPM','B9']==D('.08')
    assert ws['B10'].value=='=B9*30%'
    assert ws['B8'].value=="=(B3*(1-'DCF'!B13)*B2+B7*B5)/(B2+B5)"
    assert ws['B11'].value=="=(B3*(1-'DCF'!B13)*B2+B10*B5)/(B2+B5)"
    assert isinstance(ws['I17'].value,ArrayFormula)
    assert ws['I17'].value.ref=='I17:J17'
    assert ws['I17'].value.text=='=LINEST(O14:O69,P14:P69,,FALSE)'
    assert writer.cached['CAPM','J17'] is not None
    assert metadata['calibrations'][0]['observations']==56
    assert metadata['calibrations'][1]['observations']==60
    assert ws['N13'].value=='日経平均終値'
    assert D(str(ws['H14'].value))==TEST_RF and D(str(ws['J14'].value))==TEST_ERP
    assert ws['A14'].value is None
    assert writer.values['CAPM','B4']==1000 and writer.values['CAPM','C5']==1050


def test_raw_precision_is_preserved_but_truncated_for_model_inputs():
    writer,ds,refs,market=example();metadata=write_capm(writer,ds,market,refs)
    assert metadata['monthly_inputs'][0]['stock_close_raw'].endswith('.75')
    assert metadata['monthly_inputs'][0]['index_close_raw'].endswith('.99')
    assert not metadata['monthly_inputs'][0]['stock_input'].endswith('.75')
    assert writer.book['CAPM']['O14'].value=='=M14/M15-1'
    note=next(c['note']for c in writer.cells if c['address']=='M14')
    assert 'TRUNC' in note and '.75' in note
    assert all(c.comment is None for row in writer.book['CAPM']for c in row)


def test_missing_month_does_not_shorten_window_or_interpolate():
    writer,ds,refs,market=example();market['stock_rows']=[r for r in market['stock_rows']if r['month']!='2023-07']
    metadata=write_capm(writer,ds,market,refs)
    assert all(not r['complete']for r in metadata['calibrations'])
    assert writer.book['CAPM']['B6'].value is None and writer.book['CAPM']['C7'].value is None
    assert '2023-07' in metadata['calibrations'][0]['missing_months']


def test_unknown_market_cap_and_shareholder_capital_stay_blank():
    writer,ds,refs,market=example(shareholder=None);market.pop('market_caps');write_capm(writer,ds,market,refs)
    assert all(writer.book['CAPM'][a].value is None for a in ['B4','B8','B9','B11'])
    assert writer.book['CAPM']['B7'].value is not None


def test_zero_debt_does_not_create_division_or_conditional_guards():
    writer,ds,refs,market=example(debt=D(0),interest=D(0));write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['B3'].value is None
    assert writer.book['CAPM']['B8'].value is not None
    assert writer.cached['CAPM','B8']==writer.cached['CAPM','B7']
    for row in writer.book['CAPM']:
        for cell in row:
            expression=getattr(cell.value,'text',cell.value)
            if isinstance(expression,str)and expression.startswith('='):
                assert not any(word+'('in expression.upper()for word in ['IF','IFERROR','COUNT','ISNUMBER'])


def test_zero_index_variance_does_not_invent_beta():
    with pytest.raises(ValueError,match='分散がゼロ'):linest([.1,.2,.3],[0,0,0])


@pytest.mark.parametrize('code',['6947','7826','9843'])
def test_new_reference_layout_applies_to_every_company(code):
    writer,ds,refs,market=example(code=code);write_capm(writer,ds,market,refs);ws=writer.book['CAPM']
    assert ws['N13'].value=='日経平均終値'
    assert ws['I17'].value.ref=='I17:J17' and ws['H17'].value==2024
    assert ws['H14'].value==pytest.approx(float(TEST_RF))
    assert ws.freeze_panes=='E1'
    assert ws['A8'].value=='WACC(C) ' and ws['A11'].value=='WACC(R) '


def test_packaged_template_contains_only_styles_and_static_labels():
    book=load_workbook(TEMPLATE_PATH);assert book.sheetnames==['reference']
    for ws in book:
        for row in ws:
            for cell in row:
                assert not isinstance(cell.value,(int,float,date,ArrayFormula))
                assert cell.data_type!='f' and cell.comment is None
                assert not isinstance(cell.value,str)or '図研'not in cell.value
        assert ws.sheet_state=='visible' and not any(d.hidden for d in ws.row_dimensions.values())
    assert not book._external_links


@pytest.mark.parametrize('field,value',[('code','6947'),('benchmark','^TOPX'),('stock_symbol','6947.T')])
def test_foreign_stock_or_benchmark_never_used(field,value):
    writer,ds,refs,market=example();market[field]=value;metadata=write_capm(writer,ds,market,refs)
    assert metadata['warnings']and not metadata['monthly_inputs']
    assert all(writer.book['CAPM'][a].value is None for a in ['B4','B6','B8'])
    assert writer.book['CAPM']['B2'].value is not None


def test_array_beta_and_intercept_are_both_cached_on_saved_workbook(tmp_path):
    from zaimu10.excel import _write_cached
    writer,ds,refs,market=example();write_capm(writer,ds,market,refs)
    path=tmp_path/'CAPM.xlsx';writer.book.save(path);_write_cached(path,writer.cached)
    formulas=load_workbook(path,data_only=False);cached=load_workbook(path,data_only=True)
    assert formulas['CAPM']['I17'].value.ref=='I17:J17'
    for key in ['I17','J17','B7','B8','B9','B11']:
        assert cached['CAPM'][key].value==pytest.approx(float(writer.cached['CAPM',key]),abs=1e-14)
    assert cached['CAPM'].max_row<100
    assert not any(c.comment for row in formulas['CAPM']for c in row)


def test_explicit_average_ignores_blank_years_without_changing_range():
    writer,ds,refs,market=example();original=refs.get
    refs.get=lambda n,p:None if n=='interest_paid'and p.end.year==2023 else original(n,p)
    write_capm(writer,ds,market,refs);ws=writer.book['CAPM']
    assert ws['B8'].value is None and ws['C8'].value is not None
    assert ws['L8'].value=='=AVERAGE(B8:C8)' and writer.cached['CAPM','L8']==writer.cached['CAPM','C8']
    assert ws['L11'].value=='=AVERAGE(B11:C11)' and writer.cached['CAPM','L11']==writer.cached['CAPM','C11']
    assert ws['L8'].comment is None
    assert '数値1期' in next(c['note']for c in writer.cells if c['address']=='L8')


def test_both_wacc_rows_use_past_ten_and_past_five_arithmetic_averages():
    writer,ds,refs,market=example(years=tuple(range(2017,2027)),end_month='2026-10')
    write_capm(writer,ds,market,refs);ws=writer.book['CAPM']
    for row in (8,11):
        assert ws[f'L{row}'].value==f'=AVERAGE(B{row}:K{row})'
        assert ws[f'M{row}'].value==f'=AVERAGE(G{row}:K{row})'
        expected=sum(writer.values['CAPM',f'{get_column_letter(c)}{row}']for c in range(2,12))/10
        assert writer.cached['CAPM',f'L{row}']==expected
        expected5=sum(writer.values['CAPM',f'{get_column_letter(c)}{row}']for c in range(7,12))/5
        assert writer.cached['CAPM',f'M{row}']==expected5


def test_all_missing_wacc_average_stays_blank_with_audit_reason():
    writer,ds,refs,market=example();market.pop('market_caps');write_capm(writer,ds,market,refs)
    for row in (8,11):
        assert writer.book['CAPM'][f'L{row}'].value is None
        assert 'すべて空欄'in next(c['note']for c in writer.cells if c['address']==f'L{row}')


def test_missing_parent_profit_is_not_substituted_by_consolidated_total():
    writer,ds,refs,market=example(parent_profit=None);write_capm(writer,ds,market,refs)
    assert all(writer.book['CAPM'][a].value is None for a in ['A14','B9','B10','B11'])
    assert writer.book['CAPM']['B8'].value is not None


def test_missing_risk_inputs_do_not_reuse_reference_constants_or_block_roe_wacc():
    writer,ds,refs,market=example();market.pop('risk_inputs');metadata=write_capm(writer,ds,market,refs)
    assert all(writer.book['CAPM'][a].value is None for a in ['H14','J14','B7','B8','L8'])
    assert writer.book['CAPM']['B11'].value is not None
    assert metadata['risk_input_missing_reasons']['risk_free_rate']


@pytest.mark.parametrize('name,change',[
    ('risk_free_rate',{'semantic':'country_risk_premium'}),
    ('risk_free_rate',{'currency':'USD'}),
    ('risk_free_rate',{'source_url':''}),
    ('risk_free_rate',{'as_of':''}),
    ('equity_risk_premium',{'semantic':'country_risk_premium'}),
    ('equity_risk_premium',{'country':'United States'}),
    ('equity_risk_premium',{'value':'5.14'}),
])
def test_incompatible_risk_semantics_units_or_missing_provenance_stay_blank(name,change):
    writer,ds,refs,market=example();market['risk_inputs'][name].update(change)
    metadata=write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['H14'if name=='risk_free_rate'else'J14'].value is None
    assert writer.book['CAPM']['B8'].value is None
    assert writer.book['CAPM']['B11'].value is not None
    assert metadata['risk_input_missing_reasons'][name]


def actual_parent_dataset(code):
    import gzip
    from dataclasses import fields
    payload=json.loads(gzip.decompress((Path(__file__).parent/'fixtures/capm_parent_sources.json.gz').read_bytes()))
    raw=next(item for item in payload if item['code']==code)
    periods=[Period(date.fromisoformat(p['start']),date.fromisoformat(p['end']))for p in raw['periods']]
    ds=Dataset(code,raw['company'],raw['basis'],periods)
    ds.period_bases=raw['period_bases'];ds.accounting_standard=raw['accounting_standard'];ds.period_standards=raw['period_standards']
    for statement,rows in raw['rows'].items():
        for record in rows:
            values={}
            for key,c in record['values'].items():
                source=Source(**{k:v for k,v in c['source'].items()if k in{f.name for f in fields(Source)}})
                values[key]=Cell(D(c['value'])if c['value']is not None else None,source,nil=c['nil'])
            attrs={k:v for k,v in record.items()if k in{f.name for f in fields(Row)}-{'values','section'}}
            ds.rows[statement].append(Row(**attrs,values=values,section=tuple(record['section'])))
    return ds


def actual_parent_writer(ds):
    book=Workbook();book.active.title='PL'
    for name in ['BS-a','BS-le','CF','DCF']:book.create_sheet(name)
    writer=SimpleNamespace(book=book,periods=sorted(ds.periods),factor=D(1000),unit='thousand',unit_label='千円',
        values={},cached={},cells=[],layout_metadata={},source_addresses={},sources={},bs_metrics={})
    for col,period in enumerate(writer.periods,2):
        letter=get_column_letter(col)
        for row in ds.rows['PL']:
            cell=row.values.get(period.key)
            if cell is None or cell.nil or cell.value is None:continue
            name=cell.source.concept.rsplit('}',1)[-1]
            if name in {'ProfitLoss','ProfitLossIFRS','NetIncomeLoss'}:target=19;metric='net_profit'
            elif name in {'ProfitLossAttributableToOwnersOfParent','ProfitLossAttributableToOwnersOfParentIFRS'}:target=22;metric='net_profit_parent'
            else:continue
            address=f'{letter}{target}';value=cell.value/writer.factor;writer.values['PL',address]=value;book['PL'][address]=float(value)
            writer.cells.append(dict(sheet='PL',address=address,row_key='metric:'+metric,period=period.key,display_value=str(value),source=cell))
            writer.source_addresses.setdefault(row.key,{})[period.key]=dict(sheet='PL',address=address)
        for row in ds.rows['BS_LE']:
            cell=row.values.get(period.key)
            if cell is not None and not cell.nil and cell.value is not None:
                value=cell.value/writer.factor;address=letter+'24';writer.values['BS-le',address]=value;book['BS-le'][address]=float(value)
                writer.source_addresses.setdefault(row.key,{})[period.key]=dict(sheet='BS-le',address=address)
    return writer


def test_actual_zuken_ten_year_nci_never_used_as_parent_profit_and_direct_pl22():
    from zaimu10.financial_refs import FinancialRefs
    ds=actual_parent_dataset('6947');writer=actual_parent_writer(ds);refs=FinancialRefs(writer,ds)
    write_capm(writer,ds,None,refs);checked=0;different_from_total=0
    for col,period in enumerate(writer.periods,2):
        by_name={cell.source.concept.rsplit('}',1)[-1]:cell.value for row in ds.rows['PL']if(cell:=row.values.get(period.key))is not None and not cell.nil}
        parent=by_name['ProfitLossAttributableToOwnersOfParent'];total=by_name['ProfitLoss'];nci=by_name.get('ProfitLossAttributableToNonControllingInterests')
        if nci is not None:assert abs(parent-(total-nci))<=1000
        letter=get_column_letter(col);shareholder=next(r.values[period.key].value for r in ds.rows['BS_LE']if period.key in r.values)
        assert writer.cached['CAPM',letter+'9']==parent/shareholder
        assert writer.book['CAPM'][letter+'9'].value==f"='PL'!{letter}22/'BS-le'!{letter}24"
        if letter not in ('H','J'):assert writer.book['CAPM'][letter+'14'].value is None
        checked+=1;different_from_total+=parent!=total
    assert checked==10 and different_from_total>=8


def test_actual_nitori_ifrs_parent_role_keeps_genuine_parent_qname():
    from zaimu10.financial_refs import FinancialRefs
    ds=actual_parent_dataset('9843');writer=actual_parent_writer(ds);refs=FinancialRefs(writer,ds);checked=0
    for period in writer.periods:
        rows=[r for r in ds.rows['PL']if period.key in r.values and r.values[period.key].source.concept.endswith('}ProfitLossAttributableToOwnersOfParentIFRS')]
        if not rows:continue
        source=refs.parent_profit_input(period)
        assert source is not None and source.fact.value==rows[0].values[period.key].value
        assert source.fact.source.concept.endswith('}ProfitLossAttributableToOwnersOfParentIFRS')
        visible=refs.get('net_profit_parent',period);assert visible is not None and visible.value==source.fact.value/writer.factor
        checked+=1
    assert checked>=2


@pytest.mark.parametrize('payload',[None,True,'country premium',[]])
def test_malformed_risk_payload_does_not_block_verified_financial_model(payload):
    writer,ds,refs,market=example();market['risk_inputs']=payload
    write_capm(writer,ds,market,refs)
    assert writer.book['CAPM']['H14'].value is None
    assert writer.book['CAPM']['J14'].value is None
    assert writer.book['CAPM']['B8'].value is None
    assert writer.book['CAPM']['B11'].value is not None
