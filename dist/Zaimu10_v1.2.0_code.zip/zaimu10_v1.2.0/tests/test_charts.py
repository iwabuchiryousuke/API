from decimal import Decimal
import pytest

from zaimu10.charts import (axis_ticks,contiguous_segments,format_value,
    series_for_view,comparability_label,axis_label)


def model():
    def series(label,values,kind='money'):return {'label':label,'values':[None if v is None else Decimal(str(v))for v in values],'kind':kind}
    return {'code':'6947','company':'図研','unit_label':'百万円','periods':[
        {'label':f'{year}/03','basis':'consolidated','accounting_standard':'J-GAAP'}for year in(2024,2025,2026)],
        'PL':{'revenue':series('売上高',[1000,None,1200]),'gross_profit':series('粗利益',[500,None,600]),
            'operating_profit':series('営業利益',[100,0,-50]),'net_profit':series('当期利益',[70,80,None]),
            'gross_margin':series('粗利率',[.5,None,.5],'ratio'),'operating_margin':series('営業利益率',[.1,0,-.04],'ratio'),'net_margin':series('純利益率',[.07,.08,None],'ratio')},
        'CF':{'operating':series('営業CF',[100,120,110]),'investing':series('投資CF',[-60,None,40]),'financing':series('財務CF',[-10,-50,0]),'cash':series('期末現金',[300,320,470])},
        'BS':{'assets':series('総資産',[1000,1100,1200]),'liabilities':series('負債',[400,450,500]),'equity':series('純資産',[600,650,700])}}


def test_missing_values_break_lines_but_zero_is_a_real_point():
    assert contiguous_segments([1,None,0,-2,None,3])==[[(0,1.0)],[(2,0.0),(3,-2.0)],[(5,3.0)]]


def test_pl_uses_explicit_dual_axes_without_rescaling_source_values():
    specs=series_for_view(model(),'PL')
    assert [(s.key,s.style,s.axis)for s in specs]==[('revenue','bar','left'),('operating_profit','line','right'),('net_profit','line','right')]
    assert specs[0].values==(Decimal(1000),None,Decimal(1200))
    assert specs[1].values[-1]==Decimal(-50)
    assert axis_label(specs,'left','百万円')=='売上高（百万円）'
    assert axis_label(specs,'right','百万円')=='利益（百万円）'


def test_profit_only_does_not_show_empty_revenue_axis():
    specs=series_for_view(model(),'PL',['operating_profit','net_profit'])
    assert all(s.axis=='left'for s in specs)


def test_profit_ratio_mode_is_fraction_not_money_divided_twice():
    specs=series_for_view(model(),'PL',income_mode='利益率')
    op=next(s for s in specs if s.key=='operating_margin')
    assert op.kind=='ratio'and op.values[0]==Decimal('.1')
    assert format_value(op.values[0],kind=op.kind)=='10.00%'
    assert axis_label(specs,'right','百万円')=='利益率（%）'


def test_cashflows_keep_negative_positive_and_missing_values():
    specs=series_for_view(model(),'CF')
    investing=next(s for s in specs if s.key=='investing')
    assert investing.values==(Decimal(-60),None,Decimal(40))
    assert all(s.style=='bar'for s in specs)
    assert all(s.style=='line'for s in series_for_view(model(),'CF',cash_style='折れ線'))


def test_signed_axes_always_include_zero_and_all_points():
    low,high,ticks=axis_ticks([-100,-50,22,100,None])
    assert low<=-100 and high>=100 and 0 in ticks
    assert len(ticks)<12
    low,high,ticks=axis_ticks([-20,-10])
    assert low<=-20 and high==0 and 0 in ticks
    low,high,ticks=axis_ticks([0,None,0])
    assert low==0 and high>0 and 0 in ticks


def test_exact_hover_format_and_no_fake_zero_for_missing():
    assert format_value(Decimal('1234567.125'),unit_label='千円')=='1,234,567.125 千円'
    assert format_value(Decimal(0),unit_label='百万円')=='0 百万円'
    assert format_value(None)=='データなし'


def test_nonfinite_and_misaligned_chart_data_cannot_render_plausibly():
    with pytest.raises(ValueError,match='有限'):
        axis_ticks([Decimal('Infinity')])
    broken=model();broken['PL']['revenue']['values']=[Decimal(1)]
    with pytest.raises(ValueError,match='期間数'):
        series_for_view(broken,'PL')


def test_actual_comparability_changes_are_visible():
    m=model();assert comparability_label(m)=='連結・J-GAAP'
    m['periods'][0]['basis']='standalone';m['periods'][-1]['accounting_standard']='IFRS'
    note=comparability_label(m)
    assert '変更あり' in note and '個別' in note and '連結' in note and 'J-GAAP → IFRS' in note
