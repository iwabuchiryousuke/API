"""A separately sourced current-bond zero may supplement a fully matched BS."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest

from zaimu10.analysis import analyze_dataset
from zaimu10.debt_notes import extract_debt_notes
from zaimu10.models import Filing
from zaimu10.parser import parse_filing
from zaimu10.service import _supplementary_na_fallback,_explicit_bond_current_zero_groups

F=Path(__file__).parent/'fixtures'/'jes_bonds'


def load(doc,end,submitted):
    pages=json.loads(gzip.decompress((F/f'{doc}.json.gz').read_bytes()))
    filing=Filing(doc,code='6544',start=date(end-1,4,1),end=date(end,3,31),submitted=submitted)
    ds=parse_filing(filing,pages);ds.analysis_inputs=extract_debt_notes(pages,ds)
    return ds,filing


@pytest.fixture
def case():
    original,fo=load('S100ASMM',2017,'2017-06-30 10:00')
    authority,fa=load('S100DFWJ',2018,'2018-06-27 10:00')
    period=original.periods[-1]
    merged=deepcopy(authority);merged.periods=[period]
    for rows in merged.rows.values():
        for row in rows:row.values={k:c for k,c in row.values.items()if k==period.key}
    for row in merged.analysis_inputs:row.values={k:c for k,c in row.values.items()if k==period.key}
    merged.analysis_inputs=[r for r in merged.analysis_inputs if r.values]
    return merged,authority,original,{id(authority):fa,id(original):fo},period


def apply(case,amendments=()):
    merged,authority,original,filings,period=case
    return _supplementary_na_fallback(merged,[authority,original],{period.key:authority},filings,list(amendments),lambda _:None)


def current_zero(case):
    _,_,original,_,period=case
    return next(r for r in original.analysis_inputs if ':current_bonds:'in r.key).values[period.key]


def mutate_proof(cell,**changes):
    proof=json.loads(cell.note.split('debt_note_evidence:',1)[1]);proof.update(changes)
    cell.note='debt_note_evidence:'+json.dumps(proof,ensure_ascii=False)


def test_actual_jes_2017_nil_stays_nil_while_original_current_inset_zero_completes_debt(case):
    merged,authority,original,filings,period=case
    primary_before=asdict(merged)['rows']
    main=[c for r in merged.rows['BS_LE']for k,c in r.values.items()
          if k==period.key and c.source.concept.endswith('}CurrentPortionOfBonds')]
    assert len(main)==1 and main[0].nil and main[0].value is None
    assert not analyze_dataset(merged).metadata['interest_bearing_debt'][period.key]['complete']
    [check]=apply(case)
    assert check['ok']is True and check['status']=='applied'
    assert check['evidence_kinds']==['bonds_schedule_current_inset_zero']
    assert check['supplementary_doc_id']=='S100ASMM'and check['authority_doc_id']=='S100DFWJ'
    assert check['balance_match']['line_count']>20
    assert len(check['added_note_keys'])==2
    assert all(':current_bonds:'in k or ':bonds_coverage:'in k for k in check['added_note_keys'])
    assert asdict(merged)['rows']==primary_before
    assert main[0].nil and main[0].value is None
    out=analyze_dataset(merged)
    assert out.metadata['interest_bearing_debt'][period.key]['complete']
    assert out.metrics['interest_bearing_debt'].values[period.key].value==analyze_dataset(original).metrics['interest_bearing_debt'].values[period.key].value
    assert '償還予定額ゼロ' in merged.source_notes[-1]
    assert '該当事項なし' not in merged.source_notes[-1]
    assert next(r for r in merged.analysis_inputs if ':current_bonds:'in r.key).values[period.key].source.doc_id=='S100ASMM'


@pytest.mark.parametrize('field,value',[
    ('physical_row',0),('expanded_column',4),('balance_column','begin'),
    ('scope','prior_comparative'),('kind','borrowings_schedule'),('unit_label','円'),
    ('category','bonds'),('reported_current_jpy','1'),('reported_total_jpy','-1'),
    ('context_period_end','2018-03-31'),('block_context','Prior1YearDuration'),
    ('filename','different.xhtml'),('parentheses_semantics','括弧は外数です'),
])
def test_altered_note_proof_is_not_eligible(case,field,value):
    mutate_proof(current_zero(case),**{field:value})
    assert apply(case)==[]


@pytest.mark.parametrize('change',['currency','qname','operation','context','value','nil','doc_id','coverage_missing','maturity'])
def test_source_identity_zero_and_coverage_are_strict(case,change):
    cell=current_zero(case)
    if change=='currency':cell.source.unit='USD'
    elif change=='qname':cell.source.concept=cell.source.concept.replace('jpcrp_cor}', 'custom}')
    elif change=='operation':cell.operation='analysis_zero_proven'
    elif change=='context':cell.source.context_id='Prior1YearDuration'
    elif change=='value':cell.value=Decimal(1)
    elif change=='nil':cell.nil=True
    elif change=='doc_id':cell.source.doc_id='S100OTHER'
    elif change=='coverage_missing':case[2].analysis_inputs=[r for r in case[2].analysis_inputs if ':bonds_coverage:'not in r.key]
    else:
        proof=json.loads(cell.note.split('debt_note_evidence:',1)[1]);proof['redemption_crosscheck'][0]['amounts_jpy'][0]='1'
        mutate_proof(cell,redemption_crosscheck=proof['redemption_crosscheck'])
    assert apply(case)==[]


@pytest.mark.parametrize('change',['numeric_bs','nil_to_zero','basis','standard','amended','wrong_year','source_error'])
def test_full_bs_original_basis_year_and_no_error_guards_are_preserved(case,change):
    merged,authority,original,filings,period=case
    if change=='numeric_bs':
        c=next(c for r in original.rows['BS_LE']for k,c in r.values.items()if k==period.key and c.value is not None);c.value+=Decimal(100000000)
    elif change=='nil_to_zero':
        c=next(c for r in original.rows['BS_LE']for k,c in r.values.items()if k==period.key and c.source.concept.endswith('}CurrentPortionOfBonds'));c.nil=False;c.value=Decimal(0)
    elif change=='basis':original.basis='standalone'
    elif change=='standard':original.accounting_standard='IFRS'
    elif change=='amended':filings[id(original)].amended=True
    elif change=='wrong_year':filings[id(original)].end=date(2018,3,31)
    else:merged.analysis_input_errors[period.key]=['原本注記が不明確']
    result=apply(case)
    assert not any(c.get('ok')is True for c in result)


def test_relevant_unknown_or_debt_amendment_blocks_the_original_zero(case):
    [check]=apply(case,[dict(doc_id='S100CHANGE',status='financial_notes_only',analysis_inputs_affected=True,
        period=case[-1].key,affected_periods=[case[-1].key])])
    assert check['status']=='not_applied'and check['blocking_amendment_doc_id']=='S100CHANGE'


def test_existing_authority_note_even_nil_is_never_overwritten(case):
    merged,_,original,_,period=case
    row=deepcopy(next(r for r in original.analysis_inputs if ':current_bonds:'in r.key))
    row.values[period.key].value=None;row.values[period.key].nil=True;row.values[period.key].source.doc_id='S100DFWJ'
    merged.analysis_inputs.append(row)
    assert apply(case)==[]
    assert row.values[period.key].value is None and row.values[period.key].nil


def test_nonzero_current_bond_amount_cannot_use_zero_only_fallback():
    original,filing=load('S100DFWJ',2018,'2018-06-27 10:00')
    assert _explicit_bond_current_zero_groups(original,original.periods[-1],filing)==[]
