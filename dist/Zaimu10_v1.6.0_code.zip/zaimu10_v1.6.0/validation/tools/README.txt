出力の構造・数式・配色・元取得データとの整合性を検査します。
実行例：python validation/tools/validate_outputs.py results --expected-companies 9 --report check.json
Excelと同名のaudit.jsonを同じフォルダーへ置いてください。
公開原本キャッシュ実体との直接照合結果はactual_cached_original_sources.jsonを参照。
この検査は保存されたExcel式を任意のPythonコードとして実行しません。
