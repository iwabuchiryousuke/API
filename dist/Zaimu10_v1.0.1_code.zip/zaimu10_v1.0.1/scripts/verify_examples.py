"""Verify exported cells independently against raw official iXBRL and Excel.

No acquisition/parser implementation is imported. This checks every exported
fact's original QName/context/value against the hash-checked saved source, then
checks the numeric value written into its actual Excel cell.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from decimal import Decimal
import hashlib
import html as html_std
import json
from pathlib import Path
import re
import unicodedata

from lxml import html
from openpyxl import load_workbook

SHEETS = {'PL':'損益計算書','BS_A':'BS_資産','BS_LE':'BS_負債純資産','CF':'キャッシュフロー'}


def plain(node):
    return re.sub(r'\s+',' ',''.join(node.itertext()).replace('\xa0',' ')).strip()


def raw_facts(cache: Path, doc: str, filename: str):
    directory=cache/'filings'/doc
    manifest=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    matches=[f for f in manifest['files'] if f['filename']==filename]
    assert len(matches)==1,(doc,filename)
    raw=(directory/matches[0]['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==matches[0]['sha256'],doc
    text=raw.decode('utf-8')
    namespaces=defaultdict(set)
    for prefix,_,uri in re.findall(r'xmlns:([\w.-]+)\s*=\s*([\'"])(.*?)\2',text,re.S):
        namespaces[prefix.casefold()].add(html_std.unescape(uri))
    root=html.fromstring(text.lstrip('\ufeff').encode('utf-8'),parser=html.HTMLParser(encoding='utf-8',no_network=True))
    facts=defaultdict(list)
    for node in root.iter():
        if not isinstance(node.tag,str) or node.tag.rsplit(':',1)[-1].lower()!='nonfraction':continue
        prefix,local=node.get('name','').split(':',1)
        uris=namespaces[prefix.casefold()]
        assert len(uris)==1,(doc,prefix,uris)
        concept='{'+next(iter(uris))+'}'+local
        context=node.get('contextref','')
        nil=node.get('xsi:nil','').lower() in {'true','1'}
        original=plain(node)
        if nil:value=None
        else:
            fmt=node.get('format','').split(':')[-1].lower()
            value_text=unicodedata.normalize('NFKC',original).replace(',','')
            value_text=re.sub(r'\s+','',value_text)
            if fmt in {'numdash','zerodash','fixed-zero','fixedzero'}:value=Decimal(0)
            else:
                negative=value_text.startswith(('△','▲','−','-')) or value_text.startswith('(')
                value=Decimal(value_text.lstrip('△▲−-+').strip('()'))
                if negative:value=-value
            value*=Decimal(10)**int(node.get('scale','0'))
            if node.get('sign')=='-':value=-abs(value)
        facts[(concept,context)].append((value,nil,original))
    return facts


def verify(samples: Path, cache: Path):
    summaries=[]
    fact_cache={}
    for audit in sorted(samples.glob('*.audit.json')):
        payload=json.loads(audit.read_text(encoding='utf-8'));ds=payload['dataset']
        workbook=audit.with_name(audit.name.removesuffix('.audit.json')+'.xlsx')
        assert workbook.exists(),workbook
        wb=load_workbook(workbook,data_only=False)
        assert wb.sheetnames==list(SHEETS.values())
        assert not wb._external_links
        unit=payload['options']['unit'];factor={'yen':Decimal(1),'thousand':Decimal(1000),'million':Decimal(1000000)}[unit]
        periods=sorted(ds['periods'],key=lambda p:(p['end'],p['start']))
        count=0;verified_raw=0;nil_count=0
        for statement,title in SHEETS.items():
            ws=wb[title]
            assert ws.freeze_panes=='B7'
            assert all(c.data_type!='f' for row in ws for c in row)
            for j,p in enumerate(periods,start=2):
                assert p['end'].replace('-','/') in ws.cell(6,j).value,(workbook,title,p)
            for i,row in enumerate(ds['rows'][statement],start=7):
                assert ws.cell(i,1).value==row['label']
                for j,p in enumerate(periods,start=2):
                    key=p['start']+'/'+p['end'];fact=row['values'].get(key);cell=ws.cell(i,j)
                    if fact is None or fact['value'] is None:
                        assert cell.value is None,(workbook,title,i,j,cell.value)
                        if fact and fact['nil']:nil_count+=1
                    else:
                        expected=Decimal(fact['value'])/(factor if fact['source']['unit']=='JPY' else Decimal(1))
                        assert cell.value is not None
                        tolerance=max(Decimal('0.000000001'),abs(expected)*Decimal('0.00000000000001'))
                        assert abs(Decimal(str(cell.value))-expected)<=tolerance,(workbook,title,i,j,cell.value,expected)
                        count+=1
                    if fact is None:continue
                    src=fact['source']
                    assert cell.comment and src['doc_id'] in cell.comment.text
                    if not src['context_id']:
                        assert fact['value'] is None
                        continue
                    cache_key=(src['doc_id'],src['filename'])
                    if cache_key not in fact_cache:fact_cache[cache_key]=raw_facts(cache,*cache_key)
                    original=fact_cache[cache_key][(src['concept'],src['context_id'])]
                    expected=(None if fact['value'] is None else Decimal(fact['value']),fact['nil'],src['raw_value'])
                    assert expected in original,(workbook,title,row['label'],expected,original)
                    verified_raw+=1
        assert not ds['warnings'],(workbook,ds['warnings'])
        assert all(c['ok'] is not False for c in ds['checks'])
        summaries.append({'code':ds['code'],'company':ds['company'],'periods':len(periods),
                          'first':periods[0]['end'],'last':periods[-1]['end'],
                          'basis':ds['basis'],'standard':ds.get('accounting_standard'),
                          'numeric_excel_cells':count,'raw_facts_verified':verified_raw,
                          'nil_cells':nil_count,'checks_passed':sum(c['ok'] is True for c in ds['checks']),
                          'checks_unverified':sum(c['ok'] is None for c in ds['checks']),
                          'workbook':workbook.name})
        wb.close()
    assert summaries,'No sample audits found'
    return summaries


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=Path,default=Path('examples'))
    parser.add_argument('--cache',type=Path,default=Path('.cache/zaimu10'))
    parser.add_argument('--json',type=Path)
    args=parser.parse_args()
    results=verify(args.samples,args.cache)
    output=json.dumps(results,ensure_ascii=False,indent=2)
    print(output)
    if args.json:args.json.write_text(output+'\n',encoding='utf-8')
