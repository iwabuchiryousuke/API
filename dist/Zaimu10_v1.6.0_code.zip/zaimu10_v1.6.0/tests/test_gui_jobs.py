"""Concurrency and calendar-selection regressions for the desktop UI.

No network or display is needed. Workers use real threads/events, and only the
main test thread drains their private queues and invokes UI callbacks.
"""
from datetime import date
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import threading

import pytest

from zaimu10.gui import App, GuiJob


class Var:
    def __init__(self,value=''):self.value=value
    def get(self):return self.value
    def set(self,value):self.value=value


class Control:
    def __init__(self):self.options={};self.starts=0;self.stops=0
    def configure(self,**kwargs):self.options.update(kwargs)
    def start(self,*_):self.starts+=1
    def stop(self):self.stops+=1


@pytest.fixture
def app():
    value=App.__new__(App)
    value.jobs={name:GuiJob(name)for name in('financial','earnings','search')}
    value.closing=False;value.result=None
    value.status=Var();value.financial_state=Var('待機中');value.earnings_state=Var('待機中');value.result_notice=Var()
    value._sync_controls=Mock();value._append=Mock();value._refresh_registry=Mock()
    value.financial_charts=Mock();value.registry=Mock();value.registry.update_result.return_value=None
    value.root=Mock();value.market_events=[]
    return value


def result(notice=''):
    return SimpleNamespace(dataset=SimpleNamespace(warnings=[],code='6947'),
        workbook=Path('/tmp/6947.xlsx'),audit=Path('/tmp/6947.audit.json'),basis_notice=notice)


def wait_thread(job):
    job.thread.join(timeout=5)
    assert not job.thread.is_alive(),'test worker did not terminate'


def test_two_slots_run_at_the_same_time_and_block_duplicate_same_type():
    financial,earnings=GuiJob('financial'),GuiJob('earnings')
    barrier=threading.Barrier(3);release_fin=threading.Event();release_earn=threading.Event()
    def work(gate,label):
        def call(cancel,log):
            barrier.wait(timeout=5);gate.wait(timeout=5);log(label);return label
        return call
    try:
        assert financial.start(work(release_fin,'financial'),'done')
        assert earnings.start(work(release_earn,'earnings'),'earnings_done')
        barrier.wait(timeout=5)
        assert financial.busy and earnings.busy
        assert financial.cancel_event is not earnings.cancel_event
        assert financial.events is not earnings.events
        assert not financial.start(lambda *_:'duplicate','done')
        assert not earnings.start(lambda *_:'duplicate','earnings_done')
        release_earn.set();wait_thread(earnings)
        assert list(earnings.pending())==[('log','earnings'),('earnings_done','earnings')]
        assert financial.thread.is_alive()
        release_fin.set();wait_thread(financial)
        assert list(financial.pending())==[('log','financial'),('done','financial')]
    finally:
        release_fin.set();release_earn.set()


def test_cancelling_excel_does_not_cancel_or_finish_earnings(app):
    started_fin=threading.Event();started_earn=threading.Event();release_earn=threading.Event()
    def export(cancel,log):
        started_fin.set();cancel.wait(timeout=5)
        if cancel.is_set():raise InterruptedError('Excelを中止しました。')
        raise AssertionError('export should have been cancelled')
    def announcements(cancel,log):
        started_earn.set();release_earn.wait(timeout=5)
        assert not cancel.is_set()
        return {'count':7,'warnings':[],'market':None}
    try:
        assert app._worker('financial',export,'done')
        assert app._worker('earnings',announcements,'earnings_done')
        assert started_fin.wait(5)and started_earn.wait(5)
        app._cancel_financial();wait_thread(app.jobs['financial']);app._drain_jobs()
        assert not app.jobs['financial'].busy and app.jobs['earnings'].busy
        assert not app.jobs['earnings'].cancel_event.is_set()
        assert app.financial_state.get()=='中止'and app.earnings_state.get()=='更新中'
        release_earn.set();wait_thread(app.jobs['earnings']);app._drain_jobs()
        assert app.earnings_state.get()=='完了'and app.result is None
    finally:
        release_earn.set();app.jobs['financial'].cancel()


def test_cancelling_earnings_does_not_cancel_or_replace_excel_result(app):
    started_fin=threading.Event();started_earn=threading.Event();release_fin=threading.Event();expected=result()
    def export(cancel,log):
        started_fin.set();release_fin.wait(timeout=5)
        assert not cancel.is_set()
        return expected
    def announcements(cancel,log):
        started_earn.set();cancel.wait(timeout=5)
        if cancel.is_set():raise InterruptedError('発表日を中止しました。')
        raise AssertionError('earnings should have been cancelled')
    try:
        app._worker('financial',export,'done');app._worker('earnings',announcements,'earnings_done')
        assert started_fin.wait(5)and started_earn.wait(5)
        app._cancel_earnings();wait_thread(app.jobs['earnings']);app._drain_jobs()
        assert app.jobs['financial'].busy and not app.jobs['financial'].cancel_event.is_set()
        assert app.earnings_state.get()=='中止'
        release_fin.set();wait_thread(app.jobs['financial']);app._drain_jobs()
        assert app.result is expected and app.financial_state.get()=='完了'
        assert app.earnings_state.get()=='中止'
        app.financial_charts.set_dataset.assert_called_once_with(expected.dataset)
    finally:
        release_fin.set();app.jobs['earnings'].cancel()


def test_error_and_foreign_completion_cannot_finish_the_other_slot(app):
    app.jobs['financial'].busy=True;app.jobs['financial'].message='6947を取得中'
    app.jobs['earnings'].busy=True
    app._handle_event('done',result(),job_name='earnings')
    assert app.jobs['financial'].busy and app.jobs['earnings'].busy and app.result is None
    app._handle_event('error','source unavailable',job_name='earnings')
    assert app.jobs['financial'].busy and not app.jobs['earnings'].busy
    assert not app.jobs['financial'].cancel_event.is_set()
    assert '6947を取得中'in app.status.get() and app.earnings_state.get()=='エラー'
    with pytest.raises(ValueError,match='結果種別'):
        app._worker('financial',lambda *_:None,'earnings_done')


def test_cancel_events_are_per_run_and_late_generation_messages_are_ignored():
    job=GuiJob('financial');callbacks=[];release=threading.Event()
    assert job.start(lambda cancel,log:callbacks.append(log)or'old','done')
    wait_thread(job);old_generation=job.generation;old_cancel=job.cancel_event
    assert list(job.pending())==[('done','old')]
    job.finish();old_cancel.set()
    try:
        assert job.start(lambda cancel,log:release.wait(5)and'new','done')
        assert job.cancel_event is not old_cancel and not job.cancel_event.is_set()
        callbacks[0]('late old log')
        job.events.put((old_generation,'done','late old result'))
        assert list(job.pending())==[]
        release.set();wait_thread(job)
        assert list(job.pending())==[('done','new')]
    finally:release.set()


def test_workers_emit_messages_but_all_ui_callbacks_run_on_main_thread(app):
    main=threading.get_ident();worker_threads=[];ui_threads=[]
    actual_handle=app._handle_event
    def handle(kind,value,**kwargs):
        ui_threads.append(threading.get_ident());return actual_handle(kind,value,**kwargs)
    app._handle_event=handle
    app._worker('earnings',lambda cancel,log:(worker_threads.append(threading.get_ident()),log('verified'),{'count':1,'warnings':[],'market':None})[-1],'earnings_done')
    wait_thread(app.jobs['earnings']);assert ui_threads==[]
    app._drain_jobs()
    assert worker_threads[0]!=main and set(ui_threads)=={main}


def test_financial_log_volume_cannot_starve_earnings_completion(app):
    f,e=app.jobs['financial'],app.jobs['earnings'];f.busy=e.busy=True
    for i in range(300):f.events.put((f.generation,'log',str(i)))
    e.events.put((e.generation,'earnings_done',{'count':1,'warnings':[],'market':None}))
    app._drain_jobs()
    assert f.busy and f.events.qsize()==200
    assert not e.busy and app.earnings_state.get()=='完了'


def install_controls(app):
    for name in ['code_entry','register_button','use_search_button','use_registered_button','search_button',
        'start_button','calendar_button','all_calendar_button','calendar_refresh_button','market_check',
        'cancel_button','calendar_cancel_button','calendar_stop_button','open_button','progress','earnings_progress',
        'remove_registered_button']:
        setattr(app,name,Control())
    app.inputs=[app.code_entry,app.register_button,app.use_registered_button,app.remove_registered_button,
                app.calendar_button,app.all_calendar_button,app.calendar_refresh_button,app.market_check]
    # Exercise the real state synchronization, not the fixture stub.
    app._sync_controls=App._sync_controls.__get__(app)


def test_registration_and_calendar_stay_enabled_while_excel_runs(app):
    install_controls(app);app.jobs['financial'].busy=True
    app._sync_controls()
    assert app.start_button.options['state']=='disabled'
    assert app.cancel_button.options['state']=='normal'
    for widget in [app.register_button,app.use_registered_button,app.remove_registered_button,
                   app.calendar_button,app.all_calendar_button,app.calendar_refresh_button]:
        assert widget.options['state']=='normal'
    app.jobs['financial'].busy=False;app.jobs['earnings'].busy=True;app._sync_controls()
    assert app.start_button.options['state']=='normal'
    assert app.all_calendar_button.options['state']=='disabled'
    assert app.calendar_cancel_button.options['state']=='normal'


def test_close_cancels_all_slots_and_waits_for_all_threads(app):
    for job in app.jobs.values():job.busy=True
    app._close()
    assert app.closing and all(job.cancel_event.is_set()for job in app.jobs.values())
    app.root.destroy.assert_not_called()
    app._drain_jobs=Mock()
    app.jobs['financial'].thread=Mock();app.jobs['financial'].thread.is_alive.return_value=True
    app._poll();app.root.destroy.assert_not_called()
    app.jobs['financial'].thread.is_alive.return_value=False
    app._poll();app.root.destroy.assert_called_once()


def test_basis_fallback_is_visible_without_changing_requested_combo(app):
    app.basis=Var('個別');notice='個別CF未掲載のため9期を連結へ切り替えました。'
    app._handle_event('done',result(notice))
    assert app.basis.get()=='個別'and app.result_notice.get()==notice
    assert app.financial_state.get()=='完了・区分切替'
    assert '取得区分を切替'in app.status.get()


def test_missing_capm_inputs_are_visible_after_successful_financial_export(app):
    value=result()
    value.dataset.export_metadata={'supplemental':{'CAPM':{
        'periods':{'2024/2025':{'missing_inputs':['market_cap']}},
        'calibrations':[{'period':'2024/2025','complete':False}]}}}
    app._handle_event('done',value)
    assert app.result is value
    assert app.financial_state.get()=='完了・CAPM一部未算出'
    assert '1期' in app.result_notice.get() and '監査JSON' in app.result_notice.get()
    assert 'セルのメモ' not in app.result_notice.get()


def calendar_app(app):
    app.calendar_year,app.calendar_month=2026,12
    app.calendar_list_year,app.calendar_list_month=2026,11
    app.calendar_scope=Var('すべて');app.calendar_selected_date=date(2027,7,8)
    app._refresh_calendar_grid=Mock();app._render_calendar=Mock()
    return app


def test_month_prev_next_and_today_do_not_reset_lower_scope_date_or_selection(app,monkeypatch):
    from zaimu10 import gui
    calendar_app(app);sentinel=object();app.events_tree=sentinel
    app._move_calendar(1)
    assert(app.calendar_year,app.calendar_month)==(2027,1)
    assert app.calendar_scope.get()=='すべて'and app.calendar_selected_date==date(2027,7,8)
    assert(app.calendar_list_year,app.calendar_list_month)==(2026,11)
    assert app.events_tree is sentinel
    monkeypatch.setattr(gui,'japan_today',lambda:date(2030,5,7));app._calendar_today()
    assert(app.calendar_year,app.calendar_month)==(2030,5)
    assert app.calendar_scope.get()=='すべて'and app.calendar_selected_date==date(2027,7,8)
    app._render_calendar.assert_not_called()


def test_month_list_and_day_filters_change_only_by_explicit_actions(app):
    calendar_app(app)
    app._apply_calendar_month()
    assert app.calendar_scope.get()=='表示中の月'and app.calendar_selected_date is None
    assert(app.calendar_list_year,app.calendar_list_month)==(2026,12)
    app.calendar_scope.set('今後の予定');app.calendar_selected_date=date(2027,7,8)
    app._clear_calendar_date()
    assert app.calendar_scope.get()=='今後の予定'and app.calendar_selected_date is None
    app.calendar_scope.set('すべて');app._calendar_day_at=Mock(return_value=date(2027,7,8))
    app._calendar_click(object())
    assert app.calendar_selected_date==date(2027,7,8)and app.calendar_scope.get()=='すべて'


def test_destroying_window_cancels_poll_timer_instead_of_leaving_tcl_callback(app):
    app._poll_after_id='timer-42'
    app._root_destroyed(SimpleNamespace(widget=app.root))
    app.root.after_cancel.assert_called_once_with('timer-42')
    assert app._poll_after_id is None and app.closing
    app._stop_ui_poll()
    app.root.after_cancel.assert_called_once()
