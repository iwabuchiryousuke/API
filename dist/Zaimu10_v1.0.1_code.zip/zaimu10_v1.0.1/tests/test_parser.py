"""Tests with an actual 260-fact EDINET filing and targeted hostile/edge cases."""
import gzip
import json
from datetime import date
from decimal import Decimal
from pathlib import Path

from lxml import html
import pytest

from zaimu10.models import Filing
from zaimu10.parser import ParseError, _number, concept_identity, parse_filing

FIXTURE = Path(__file__).parent / 'fixtures' / 'zuken_2025_ixbrl.json.gz'

@pytest.fixture(scope='module')
def pages():
    with gzip.open(FIXTURE, 'rt', encoding='utf-8') as f:
        return json.load(f)

@pytest.fixture(scope='module')
def financials(pages):
    return parse_filing(Filing('S100W07I', code='6947', company='図研', submitted='2025-06-20'), pages)


def fact_rows(dataset, statement):
    return [r for r in dataset.rows[statement] if not r.is_heading]


def by_concept(dataset, statement, local):
    return [r for r in fact_rows(dataset, statement) if any(c.source.concept.endswith('}' + local) for c in r.values.values())]


def test_actual_filing_all_260_facts_and_12_nil_preserved(financials):
    d = financials
    assert d.basis == 'consolidated'
    assert [(p.start, p.end) for p in d.periods] == [(date(2023,4,1),date(2024,3,31)),(date(2024,4,1),date(2025,3,31))]
    assert {s: len(fact_rows(d,s)) for s in d.rows} == {'PL':34,'BS_A':37,'BS_LE':24,'CF':35}
    cells = [c for rows in d.rows.values() for row in rows for c in row.values.values()]
    assert len(cells) == 260
    assert sum(c.nil for c in cells) == 12
    assert all(c.value is None for c in cells if c.nil)
    assert d.complete and not d.warnings


def test_actual_main_values_match_source(financials):
    current = financials.periods[-1].key
    expected = [('BS_A','Assets','63274260000'),('BS_LE','LiabilitiesAndNetAssets','63274260000'),('PL','NetSales','40736294000'),('PL','OperatingIncome','5392252000'),('PL','ProfitLoss','5247956000'),('CF','NetCashProvidedByUsedInOperatingActivities','4861697000'),('CF','NetCashProvidedByUsedInInvestmentActivities','1076175000'),('CF','NetCashProvidedByUsedInFinancingActivities','-5957838000')]
    for statement, local, amount in expected:
        [row] = by_concept(financials, statement, local)
        assert row.values[current].value == Decimal(amount)
        assert row.values[current].source.unit == 'JPY'
        assert row.values[current].source.doc_id == 'S100W07I'
    # EDINET original says annual net profit. Third-party misleading labels must
    # never leak into the workbook.
    assert by_concept(financials,'PL','ProfitLoss')[0].label == '当期純利益'
    assert by_concept(financials,'PL','OperatingIncome')[0].label == '営業利益'


def test_cash_begin_end_same_qname_different_context_role(financials):
    rows = by_concept(financials, 'CF', 'CashAndCashEquivalents')
    assert len(rows) == 2 and rows[0].key != rows[1].key
    current = financials.periods[-1].key
    assert rows[0].label == '現金及び現金同等物の期首残高'
    assert rows[1].label == '現金及び現金同等物の期末残高'
    assert rows[0].values[current].value == Decimal('27295903000')
    assert rows[1].values[current].value == Decimal('27224029000')
    assert rows[0].values[current].source.context_id == 'Prior1YearInstant'
    assert rows[1].values[current].source.context_id == 'CurrentYearInstant'


def test_identical_labels_stay_separate_and_extension_namespace_exact(financials):
    others = [r for r in fact_rows(financials,'BS_A') if r.label == 'その他']
    depreciation = [r for r in fact_rows(financials,'BS_A') if r.label == '減価償却累計額']
    assert len(others) == 3 and len({r.key for r in others}) == 3
    assert len(depreciation) == 4 and len({r.key for r in depreciation}) == 4
    standard1 = '{http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2016-02-29/jppfs_cor}NetSales'
    standard2 = '{http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor}NetSales'
    assert concept_identity(standard1) == concept_identity(standard2) == 'jppfs_cor:NetSales'
    ext1 = '{http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E01966-000/2024-03-31/01/2024-06-20}Other'
    ext2 = ext1.replace('2024-03-31','2025-03-31')
    assert concept_identity(ext1) != concept_identity(ext2)


def test_source_nil_is_not_zero(financials):
    current = financials.periods[-1].key
    [row] = by_concept(financials,'BS_A','ConstructionInProgress')
    assert row.values[current].nil and row.values[current].value is None
    assert row.values[financials.periods[0].key].value == Decimal('3360000')


def test_standalone_does_not_borrow_consolidated_cf(pages):
    d = parse_filing(Filing('S100W07I'), pages, 'standalone')
    assert d.basis == 'standalone'
    assert d.rows['CF'] == []
    assert not d.complete
    assert any('CF' in w for w in d.warnings)
    assert by_concept(d,'PL','NetSales')[0].values[d.periods[-1].key].value == Decimal('13384767000')


def test_cover_resources_required(pages):
    with pytest.raises(ParseError, match='コンテキスト'):
        parse_filing(Filing('S100W07I'), pages[1:])


@pytest.mark.parametrize('attrs,text,expected,nil',[
    ('scale="3" sign="-" format="ixt:numdotdecimal"','1,234.5','-1234500',False),
    ('scale="6" format="ixt:numcommadecimal"','1.234,5','1234500000',False),
    ('scale="3" format="ixt:zerodash"','－','0',False),
    ('xsi:nil="true" scale="3"','','',True),
    ('scale="0"','(100)','-100',False),
])
def test_numeric_transform_exact(attrs,text,expected,nil):
    fact = html.fromstring(f'<ix:nonfraction {attrs}>{text}</ix:nonfraction>')
    value, actual_nil, _ = _number(fact)
    assert actual_nil == nil
    assert value is None if nil else value == Decimal(expected)


def test_plain_dash_never_guessed_zero():
    fact = html.fromstring('<ix:nonfraction scale="3">－</ix:nonfraction>')
    with pytest.raises(ParseError, match='数値を確定'):
        _number(fact)


def test_unsupported_numeric_format_fails():
    fact = html.fromstring('<ix:nonfraction format="ixt:unknown">123</ix:nonfraction>')
    with pytest.raises(ParseError, match='未対応'):
        _number(fact)


def test_duplicate_conflicting_fact_fails(pages):
    mutated = [(name,markup.replace('>40,736,294</ix:nonfraction>', '>40,736,295</ix:nonfraction>')) for name,markup in pages]
    # Add an exact second main chapter with a different value to make conflict.
    with pytest.raises(ParseError, match='重複して不一致'):
        parse_filing(Filing('S100W07I'), pages + mutated[1:2])


def test_same_standard_concept_different_basis_keys_separate(pages, financials):
    standalone = parse_filing(Filing('S100W07I'), pages, 'standalone')
    cons = by_concept(financials, 'PL', 'NetSales')[0]
    parent = by_concept(standalone, 'PL', 'NetSales')[0]
    assert cons.key != parent.key
    assert all(value == 'consolidated' for value in financials.period_bases.values())
    assert all(value == 'standalone' for value in standalone.period_bases.values())


def fixture_pages(name):
    with gzip.open(FIXTURE.parent / f'{name}_ixbrl.json.gz','rt',encoding='utf-8') as f:
        return json.load(f)


def test_real_dawn_colspan_grid_preserves_standalone_all_facts():
    d = parse_filing(Filing('S100YXLE'), fixture_pages('dawn_2026'))
    assert d.basis == 'standalone' and d.complete and not d.warnings
    assert {s:len(fact_rows(d,s))for s in d.rows} == {'PL':20,'BS_A':26,'BS_LE':27,'CF':35}
    cells = [c for rows in d.rows.values()for r in rows for c in r.values.values()]
    assert len(cells) == 216 and sum(c.nil for c in cells) == 6
    k = d.periods[-1].key
    expected = [('BS_A','Assets','3343042000'),('PL','NetSales','1734668000'),('PL','OperatingIncome','655128000'),('CF','NetCashProvidedByUsedInOperatingActivities','653462000')]
    for stmt,local,value in expected:
        assert by_concept(d,stmt,local)[0].values[k].value == Decimal(value)
    assert by_concept(d,'BS_A','CashAndDeposits')[0].label == '現金及び預金'
    assert by_concept(d,'BS_A','CashAndDeposits')[0].indent > 0


def test_real_ifrs_nitori_notes_eps_and_reprinted_total():
    d = parse_filing(Filing('S100YIMF'), fixture_pages('nitori_2026'))
    assert d.basis == 'consolidated' and d.complete and not d.warnings
    assert {s:len(fact_rows(d,s))for s in d.rows} == {'PL':17,'BS_A':17,'BS_LE':25,'CF':46}
    # Source repeats ProfitLossIFRS in attribution subtotal. Same context/value
    # is one concept-row, not a spurious duplicate amount or additional period.
    assert len(by_concept(d,'PL','ProfitLossIFRS')) == 1
    k = d.periods[-1].key
    for stmt,local,value in [('BS_A','AssetsIFRS','1571284000000'),('PL','RevenueIFRS','912248000000'),('PL','OperatingProfitLossIFRS','125526000000'),('CF','NetCashProvidedByUsedInOperatingActivitiesIFRS','148911000000')]:
        assert by_concept(d,stmt,local)[0].values[k].value == Decimal(value)
    assert by_concept(d,'PL','RevenueIFRS')[0].label == '売上収益'
    assert by_concept(d,'BS_A','CashAndCashEquivalentsIFRS')[0].label == '現金及び現金同等物'
    eps = [r for r in fact_rows(d,'PL') if any(c.source.unit=='JPY/shares' for c in r.values.values())]
    assert len(eps) == 2
    assert all(r.values[k].value == Decimal('157.98') for r in eps)
    assert all('31' not in r.label for r in eps)
    assert by_concept(d,'BS_A','CashAndCashEquivalentsIFRS')[0].indent > next(r.indent for r in d.rows['BS_A'] if r.label=='流動資産')


def test_torichemical_old_standalone_remains_a_separate_basis():
    d = parse_filing(Filing('S100A4D9'), fixture_pages('torichemical_2017'))
    assert d.basis == 'standalone' and d.complete and not d.warnings
    assert [p.end for p in d.periods] == [date(2016,1,31),date(2017,1,31)]
    assert {s:len(fact_rows(d,s))for s in d.rows} == {'PL':29,'BS_A':42,'BS_LE':29,'CF':40}


def test_physical_column_grid_honors_rowspan_and_colspan():
    from zaimu10.parser import _grid
    table = html.fromstring('<table><tr><td rowspan="2">account</td><td colspan="2">heading</td></tr><tr><td>A</td><td>B</td></tr><tr><td colspan="2">label</td><td>C</td></tr></table>')
    rows = table.xpath('.//tr')
    grid = _grid(rows)
    assert [c for c,_ in grid[rows[0]]] == [0,1]
    assert [c for c,_ in grid[rows[1]]] == [1,2]
    assert [c for c,_ in grid[rows[2]]] == [0,2]


def test_first_ifrs_year_explicit_transition_bs_is_not_a_fiscal_period():
    d = parse_filing(Filing('S100W5DK'), fixture_pages('nitori_2025_transition'))
    assert d.complete and not d.warnings
    assert d.accounting_standard == 'IFRS'
    assert [p.key for p in d.periods] == ['2023-04-01/2024-03-31','2024-04-01/2025-03-31']
    assert len(d.source_notes) == 1 and '移行日(2023年4月1日)' in d.source_notes[0]
    assert all('Prior2YearInstant' != c.source.context_id for statement in ['BS_A','BS_LE'] for r in d.rows[statement] for c in r.values.values())
    assert d.period_standards == {p.key:'IFRS' for p in d.periods}


@pytest.mark.parametrize('fmt,raw',[('ixt:numcomma','123,45'),('ixt:num-unit-decimal','3000円5'),('ixt:numunitdecimal','3円5')])
def test_untested_legacy_transform_fails_instead_of_misreading(fmt,raw):
    fact=html.fromstring(f'<ix:nonfraction format="{fmt}">{raw}</ix:nonfraction>')
    with pytest.raises(ParseError,match='未対応'):
        _number(fact)


def test_nested_table_cannot_silently_drop_main_statement_facts(pages):
    # A nested formatting table in one BS label cell previously made the outer
    # financial table disappear while PL and CF could still look plausible.
    mutated=[]
    for name,markup in pages:
        if '0105010' in name:
            markup=markup.replace('>現金及び預金</p>','>現金及び預金<table><tr><td>formatting</td></tr></table></p>',1)
        mutated.append((name,markup))
    with pytest.raises(ParseError,match='XBRLファクト.*対応付け'):
        parse_filing(Filing('S100W07I'),mutated)


def test_selected_main_statement_continuation_fails_explicitly(pages):
    mutated=[(name,markup.replace('name="jpcrp_cor:ConsolidatedBalanceSheetTextBlock"','continuedAt="restOfStatement" name="jpcrp_cor:ConsolidatedBalanceSheetTextBlock"',1))for name,markup in pages]
    with pytest.raises(ParseError,match='継続参照'):
        parse_filing(Filing('S100W07I'),mutated)


def test_multiple_concepts_do_not_hide_untagged_third_year_value():
    # A real financial row may change XBRL concepts across years. The third
    # numeric cell still needs validation even when no single row identity can
    # claim it. Other tagged rows establish the explicit three-period grid.
    ns='http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'
    contexts=''.join(f'<xbrli:context id="Y{year}"><xbrli:period><xbrli:startDate>{year}-01-01</xbrli:startDate><xbrli:endDate>{year}-12-31</xbrli:endDate></xbrli:period></xbrli:context><xbrli:context id="I{year}"><xbrli:period><xbrli:instant>{year}-12-31</xbrli:instant></xbrli:period></xbrli:context>'for year in (2023,2024,2025))
    def tagged(concept,year,instant=False):
        context=('I'if instant else'Y')+str(year)
        return f'<td><ix:nonFraction name="jppfs_cor:{concept}" contextRef="{context}" unitRef="JPY">123</ix:nonFraction></td>'
    pl='<ix:nonNumeric name="jpcrp_cor:ConsolidatedStatementOfIncomeTextBlock"><table><tr><td>売上高</td>'+''.join(tagged('NetSales',y)for y in(2023,2024,2025))+'</tr></table></ix:nonNumeric>'
    bs='<ix:nonNumeric name="jpcrp_cor:ConsolidatedBalanceSheetTextBlock"><table><tr><td>資産合計</td>'+''.join(tagged('Assets',y,True)for y in(2023,2024,2025))+'</tr><tr><td>概念変更科目</td>'+tagged('OtherCA',2023,True)+tagged('OtherNCA',2024,True)+'<td>999</td></tr></table></ix:nonNumeric>'
    markup=f'<html xmlns:ix="http://www.xbrl.org/2008/inlineXBRL" xmlns:xbrli="http://www.xbrl.org/2003/instance" xmlns:iso4217="http://www.xbrl.org/2003/iso4217" xmlns:jppfs_cor="{ns}" xmlns:jpcrp_cor="http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor"><body>{contexts}<xbrli:unit id="JPY"><xbrli:measure>iso4217:JPY</xbrli:measure></xbrli:unit>{pl}{bs}</body></html>'
    with pytest.raises(ParseError,match='XBRLタグのない値.*999'):
        parse_filing(Filing('S1234567'),[('test.xhtml',markup)])
