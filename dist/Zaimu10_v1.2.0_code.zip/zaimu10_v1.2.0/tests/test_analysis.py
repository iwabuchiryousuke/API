"""Reference definitions, missing-data safeguards, and chart/table agreement."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest

from zaimu10.analysis import analyze_dataset, bs_metrics, chart_data, metric_terms
from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source
from zaimu10.parser import parse_filing
from zaimu10.presentation import annotate_filing, prepare_dataset

P = Period(date(2024, 4, 1), date(2025, 3, 31))
O = Period(date(2023, 4, 1), date(2024, 3, 31))
STD = 'http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'
EXT = 'http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E01966-000/2025-03-31/01/2025-06-20'
FIXTURES = Path(__file__).parent / 'fixtures'


def fact(name, value, *, period=P, statement='BS_A', section=(), nil=False,
         basis='consolidated', dims=(), role='end', unit='JPY', label=None, namespace=STD):
    source = Source('S100TEST', 'original.xhtml', 'https://disclosure2.edinet-fsa.go.jp/',
                    concept=f'{{{namespace}}}{name}', basis=basis, unit=unit,
                    original_label=label or name, decimals='-3', scale=3)
    key = json.dumps([statement, name, list(dims), role, unit, basis])
    return Row(key, label or name, statement, section=section,
               values={period.key: Cell(None if value is None else Decimal(value), source, nil=nil,
                                         source_section=section)})


def dataset(*rows, periods=None):
    ds = Dataset('6947', '図研', 'consolidated', periods or [P], accounting_standard='J-GAAP')
    for row in rows:
        ds.rows[row.statement].append(row)
    return ds


def actual(name='zuken_2025', code='6947'):
    content = json.load(gzip.open(FIXTURES / f'{name}_ixbrl.json.gz', 'rt', encoding='utf-8'))
    return prepare_dataset(annotate_filing(parse_filing(Filing('S100FIXTURE', code=code), content)))


def value(result, name, p=P):
    return result.metrics[name].values[p.key].value


def basic_rows():
    return [fact('CurrentAssets', '1000', section=('資産の部', '流動資産')),
            fact('NoncurrentAssets', '800', section=('資産の部', '固定資産')),
            fact('CurrentLiabilities', '600', statement='BS_LE', section=('負債の部', '流動負債'))]


def test_zuken_reference_equations_preserve_signed_allowance_and_cross_sheet_inputs():
    rows = basic_rows() + [
        fact('DeferredTaxAssetsCA', '20', section=('資産の部', '流動資産')),
        fact('DeferredTaxAssets', '30', section=('資産の部', '固定資産', '投資その他の資産')),
        fact('AllowanceForDoubtfulAccountsCA', '-7', section=('資産の部', '流動資産')),
        fact('AllowanceForDoubtfulAccountsIOAByGroup', '-999', section=('資産の部', '固定資産', '投資その他の資産')),
        fact('OtherCA', '888', section=('資産の部', '流動資産')),
        fact('ProvisionForBonuses', '40', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('ProvisionForDirectorsBonuses', '10', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('OtherProvisionCL', '5', statement='BS_LE', section=('負債の部', '流動負債')),
        fact('ShortTermLoansPayable', '100', statement='BS_LE', section=('負債の部', '流動負債'))]
    ds = dataset(*rows)
    before = asdict(ds)
    result = analyze_dataset(ds)
    assert value(result, 'net_noncurrent_assets') == 770
    assert value(result, 'net_current_assets') == 987
    assert value(result, 'net_current_liabilities') == 545  # no debt deduction
    assert value(result, 'net_working_capital') == 442
    assert value(result, 'invested_capital') == 1212
    terms = metric_terms(result.metrics['net_current_assets'].values[P.key])
    assert [sign for sign, _, _ in terms] == [1, -1, -1]
    assert [cell.value for _, _, cell in terms] == [1000, 20, -7]
    assert asdict(ds) == before


def test_real_zuken_source_balances_match_exact_restored_reference_definition():
    ds = actual()
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'net_noncurrent_assets', p) == Decimal('13739027000')
    assert value(result, 'net_current_assets', p) == Decimal('48527222000')
    assert value(result, 'net_current_liabilities', p) == Decimal('18028620000')
    assert value(result, 'net_working_capital', p) == Decimal('30498602000')
    assert value(result, 'invested_capital', p) == Decimal('44237629000')
    assert value(result, 'interest_bearing_debt', p) is None  # absent is not explicit zero
    assert '0とは推定' in result.metadata['interest_bearing_debt'][p.key]['reason']
    for name in ['net_noncurrent_assets', 'net_current_assets', 'net_current_liabilities']:
        assert all(cell.source.doc_id == 'S100FIXTURE' for _, _, cell in metric_terms(result.metrics[name].values[p.key]))


def test_furuya_other_current_assets_and_long_other_payable_are_not_adopted_as_zuken_terms():
    ds = actual('furuya_2017', '7826')
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'net_current_assets', p) == Decimal('11290000000')  # 11,605-315; not -OtherCA34
    assert value(result, 'interest_bearing_debt', p) == Decimal('2489000000')
    debt_sources = [c.source.concept for _, _, c in metric_terms(result.metrics['interest_bearing_debt'].values[p.key])]
    assert not any('LongTermAccountsPayableOther' in c for c in debt_sources)


def test_nil_known_operand_propagates_without_becoming_zero_but_numeric_zero_is_valid():
    ds = dataset(*basic_rows(), fact('AllowanceForDoubtfulAccountsCA', None, nil=True, section=('資産の部', '流動資産')))
    result = analyze_dataset(ds)
    assert value(result, 'net_current_assets') is None
    assert value(result, 'net_working_capital') is None
    assert value(result, 'invested_capital') is None
    assert 'nil' in result.metadata['net_current_assets'][P.key]['reason']
    ds.rows['BS_A'][-1].values[P.key] = Cell(Decimal(0), ds.rows['BS_A'][-1].values[P.key].source)
    assert value(analyze_dataset(ds), 'net_current_assets') == 1000
    ds = actual('furuya_2026', '7826')
    p = ds.periods[-1]
    result = analyze_dataset(ds)
    assert value(result, 'interest_bearing_debt', p) is None
    assert 'nil' in result.metadata['interest_bearing_debt'][p.key]['reason']


def test_absent_optional_exclusion_is_omitted_with_proof_and_note_not_a_synthetic_zero():
    result = analyze_dataset(dataset(*basic_rows()))
    cell = result.metrics['net_current_assets'].values[P.key]
    assert cell.value == 1000
    assert len(cell.components) == 1 and cell.components[0].value == 1000
    assert result.metadata['net_current_assets'][P.key]['omitted_absent_inputs'] == ['流動の繰延税金資産', '流動の貸倒引当金']
    assert value(analyze_dataset(dataset()), 'net_current_assets') is None


def test_current_and_noncurrent_tax_with_generic_name_use_original_cell_section():
    current = fact('DeferredTaxAssets', '20', section=('資産の部', '流動資産'))
    noncurrent = fact('DeferredTaxAssets', '30', section=('資産の部', '固定資産', '投資その他の資産'))
    noncurrent.key += ':noncurrent'
    result = analyze_dataset(dataset(*basic_rows(), current, noncurrent))
    assert value(result, 'net_current_assets') == 980
    assert value(result, 'net_noncurrent_assets') == 770
    unknown = fact('DeferredTaxAssets', '50')
    result = analyze_dataset(dataset(*basic_rows(), unknown))
    assert value(result, 'net_current_assets') is None
    assert value(result, 'net_noncurrent_assets') is None


def test_extension_tax_exact_original_label_and_section_are_auditable_not_ignored():
    extension = fact('CustomDeferredTax', '12', namespace=EXT, label='繰延税金資産', section=('資産の部', '固定資産', '投資その他の資産'))
    result = analyze_dataset(dataset(*basic_rows(), extension))
    assert value(result, 'net_noncurrent_assets') == 788
    assert metric_terms(result.metrics['net_noncurrent_assets'].values[P.key])[-1][2].source.concept.endswith('CustomDeferredTax')


def test_provision_subtotal_replaces_breakdown_and_noncurrent_provisions_stay_excluded():
    rows = basic_rows() + [fact('ProvisionsCLIFRS', '70', statement='BS_LE'),
                          fact('ProvisionForBonuses', '50', statement='BS_LE', section=('負債の部', '流動負債')),
                          fact('ProvisionForRetirementBenefits', '999', statement='BS_LE', section=('負債の部', '固定負債'))]
    result = analyze_dataset(dataset(*rows))
    assert value(result, 'net_current_liabilities') == 530
    assert len(metric_terms(result.metrics['net_current_liabilities'].values[P.key])) == 2


def test_opaque_financial_liability_blocks_full_debt_and_no_debt_nil_inference():
    rows = [fact('BorrowingsCLIFRS', '100', statement='BS_LE'),
            fact('OtherFinancialLiabilitiesCLIFRS', '5', statement='BS_LE')]
    result = analyze_dataset(dataset(*rows))
    assert value(result, 'interest_bearing_debt') is None
    assert 'その他の金融負債' in result.metadata['interest_bearing_debt'][P.key]['reason']
    rows[1].values[P.key].value = Decimal(0)
    assert value(analyze_dataset(dataset(*rows)), 'interest_bearing_debt') == 100
    zero = fact('ShortTermLoansPayable', '0', statement='BS_LE')
    assert value(analyze_dataset(dataset(zero)), 'interest_bearing_debt') == 0
    assert value(analyze_dataset(dataset()), 'interest_bearing_debt') is None


def test_totals_refuse_wrong_basis_dimensions_currency_beginning_and_ambiguous_values():
    for kwargs in [{'basis':'standalone'}, {'dims':(('axis','member'),)}, {'role':'begin'}, {'unit':'USD'}]:
        assert bs_metrics(dataset(fact('CurrentAssets', '100', **kwargs)))['current_assets'].values == {}
    conflicting = fact('CurrentAssets', '200'); conflicting.key += ':conflict'
    assert bs_metrics(dataset(fact('CurrentAssets', '100'), conflicting))['current_assets'].values == {}


def test_chart_period_order_missing_zero_negative_ratio_and_public_sources():
    rows = [fact('NetSales', '1000000', statement='PL', role='duration'),
            fact('GrossProfit', '-50000', statement='PL', role='duration'),
            fact('OperatingIncome', '0', statement='PL', role='duration'),
            fact('NetSales', '0', statement='PL', role='duration', period=O)]
    chart = chart_data(dataset(*rows, periods=[P, O]), 'thousand')
    assert [p['label'] for p in chart['periods']] == ['2024/03', '2025/03']
    assert chart['PL']['revenue']['values'] == [Decimal(0), Decimal(1000)]
    assert chart['PL']['gross_profit']['values'] == [None, Decimal(-50)]
    assert chart['PL']['gross_margin']['values'] == [None, Decimal('-0.05')]
    assert chart['PL']['operating_margin']['values'] == [None, Decimal(0)]
    assert chart['PL']['gross_profit']['cells'][1].source.url.startswith('https://')
    assert chart['BS']['equity']['values'] == [None, None]
    assert chart['CF']['cash']['values'] == [None, None]
    with pytest.raises(ValueError):
        chart_data(dataset(), 'arbitrary')


def test_chart_prefers_exported_final_table_values_with_unit_conversion_and_explicit_blank():
    ds = dataset(fact('NetSales', '1000000', statement='PL', role='duration'),
                 fact('GrossProfit', '499000', statement='PL', role='duration'),
                 fact('CurrentAssets', '1000000'))
    ds.export_metadata = {'unit':'million', 'cells':[
        {'sheet':'PL', 'row_key':'metric:revenue', 'period':P.key, 'display_value':'1', 'unit':'million'},
        {'sheet':'PL', 'row_key':'metric:gross_profit', 'period':P.key, 'display_value':'0.5', 'unit':'million'},
        {'sheet':'BS-A', 'row_key':ds.rows['BS_A'][0].key, 'period':P.key, 'display_value':None, 'unit':'million'}]}
    chart = chart_data(ds, 'thousand')
    assert chart['PL']['gross_profit']['values'] == [Decimal(500)]
    assert chart['PL']['gross_margin']['values'] == [Decimal('0.5')]
    assert chart['BS']['current_assets']['values'] == [None]
    assert chart['PL']['gross_profit']['cells'][0].value == 499000  # source evidence retained


def test_real_ifrs_chart_does_not_replace_total_equity_with_parent_equity():
    ds = actual('nitori_2026', '9843')
    chart = chart_data(ds, 'million')
    assert chart['BS']['equity']['values'][-1] == Decimal('988570')
    assert chart['BS']['equity']['values'][-1] != Decimal('988559')
    result = analyze_dataset(ds)
    assert value(result, 'interest_bearing_debt', ds.periods[-1]) is None


def test_chart_resolves_original_bs_source_key_to_canonical_exported_address():
    row = fact('CurrentAssets', '999000')
    ds = dataset(row)
    ds.export_metadata = {'unit':'thousand', 'source_addresses':{
        row.key: {P.key:{'sheet':'BS-A', 'address':'B20', 'row_key':'canonical:current_assets'}}},
        'cells':[{'sheet':'BS-A', 'address':'B20', 'row_key':'canonical:current_assets',
                  'period':P.key, 'display_value':'1000', 'unit':'thousand'}]}
    assert chart_data(ds, 'million')['BS']['current_assets']['values'] == [Decimal(1)]


def test_same_period_other_framework_total_is_refused_even_with_same_currency_and_basis():
    row = fact('CurrentAssets', '100')
    row.key = json.dumps(['BS_A', 'jppfs_cor', 'CurrentAssets', [], 'end', 'JPY',
                          'consolidated', 'IFRS', []])
    ds = dataset(row)
    assert bs_metrics(ds)['current_assets'].values == {}
    assert value(analyze_dataset(ds), 'net_current_assets') is None
