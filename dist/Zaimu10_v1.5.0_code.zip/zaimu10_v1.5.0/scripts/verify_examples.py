"""Verify exported cells independently against raw official iXBRL and Excel.

No acquisition/parser implementation is imported. This checks every exported
fact's original QName/context/value against the hash-checked saved source, then
checks the numeric value written into its actual Excel cell.
"""
from __future__ import annotations
import argparse
from decimal import Decimal
from datetime import date, datetime
import json
from pathlib import Path
import re

from openpyxl import load_workbook

try:
    from .verify_table_sources import RawSourceVerifier, fact_number, plain
except ImportError:
    from verify_table_sources import RawSourceVerifier, fact_number, plain

SHEETS = {'PL':'PL','BS_A':'BS-A','BS_LE':'BS-L,E','CF':'CF'}


def raw_facts(cache: Path, doc: str, filename: str):
    """Backwards-compatible raw-fact view, with the same strict SHA check."""
    page=RawSourceVerifier(cache).page(doc,filename)
    return {key:[fact_number(node)for node in nodes]for key,nodes in page.facts.items()}


def verify_audit_sources(payload: dict, cache: Path):
    """Verify raw rows, supplementary inputs, and every exported source leaf."""
    verifier=RawSourceVerifier(cache)
    ds=payload['dataset'];raw=payload.get('raw_dataset')or ds
    for row in raw['rows'].get('BS_LE',[]):
        for period,cell in row['values'].items():
            if cell['value']is not None and not cell['nil']:
                leaf=cell['source']['concept'].rsplit('}',1)[-1]
                if leaf in {'OtherCurrentLiabilitiesCLIFRS','OtherNonCurrentLiabilitiesNCLIFRS',
                            'BorrowingsCLIFRS','BorrowingsNCLIFRS','OtherFinancialLiabilitiesCLIFRS','OtherFinancialLiabilitiesNCLIFRS'}:
                    verifier.main_totals[(period,leaf)].append(Decimal(cell['value']))
                    verifier.main_sources[(period,leaf)].append(cell)
    def rows(dataset,origin):
        groups=list(dataset['rows'].values())+[dataset.get('analysis_inputs',[])]
        for group in groups:
            for row in group:
                for period,cell in row['values'].items():
                    try:
                        verifier.verify_cell(cell,period,label=row['label'],row_key=row['key'],origin=origin)
                    except (AssertionError,KeyError,IndexError,ValueError)as exc:
                        raise AssertionError(f"{ds['code']} {origin} {row['label']} {period}: {exc}")from exc
    rows(raw,'raw')
    raw_facts_count=verifier.counts['ixbrl_fact']
    rows(ds,'prepared')
    for item in ds.get('export_metadata',{}).get('cells',[]):
        if item.get('source'):
            try:
                verifier.verify_cell(item['source'],item['period'],label=item.get('row_key',''),
                                     row_key=item.get('row_key',''),origin='exported')
            except (AssertionError,KeyError,IndexError,ValueError)as exc:
                raise AssertionError(f"{ds['code']} exported {item['sheet']}!{item['address']}: {exc}")from exc
    return {'raw_facts_verified':raw_facts_count,**dict(verifier.counts),
            'source_pages_hash_checked':len(verifier.pages),
            'analysis_input_rows':len(raw.get('analysis_inputs',[])),
            'analysis_input_error_periods':len(raw.get('analysis_input_errors',{}))}


def verify(samples: Path, cache: Path):
    summaries=[]
    for audit in sorted(samples.glob('*.audit.json')):
        payload=json.loads(audit.read_text(encoding='utf-8'));ds=payload['dataset']
        workbook=audit.with_name(audit.name.removesuffix('.audit.json')+'.xlsx')
        assert workbook.exists(),workbook
        wb=load_workbook(workbook,data_only=False);values=load_workbook(workbook,data_only=True)
        assert wb.sheetnames==list(SHEETS.values())+['DCF','FR','CAPM'] and not wb._external_links
        periods=sorted(ds['periods'],key=lambda p:(p['end'],p['start']))
        for sheet in wb:
            assert sheet.sheet_state=='visible'
            assert not any(d.hidden for d in sheet.row_dimensions.values()),(workbook,sheet.title,'hidden row')
            assert not any(d.hidden for d in sheet.column_dimensions.values()),(workbook,sheet.title,'hidden column')
            assert sheet['A1'].value
            if sheet.title in SHEETS.values():assert '単位' in sheet['A1'].value
            for j,period in enumerate(periods,2):
                assert period['end'][:4] in str(sheet.cell(1,j).value),(workbook,sheet.title,period)
            assert all('#REF!' not in str(c.value) for row in sheet for c in row)
            assert all(c.data_type!='e' for row in values[sheet.title] for c in row)
            for row in sheet:
                for cell in row:
                    if cell.data_type=='f':
                        expression=getattr(cell.value,'text',cell.value)
                        functions=re.findall(r'(?<![\w.])([A-Za-z_][A-Za-z0-9_.]*)\s*\(',expression)
                        allowed={'SUM','LINEST','MEDIAN'} if sheet.title=='CAPM' else {'SUM'}
                        assert all(name.upper()in allowed for name in functions),(workbook,sheet.title,cell.coordinate,'unsupported function',functions)
                        assert '['not in expression and ']'not in expression,(workbook,sheet.title,cell.coordinate,'external/structured reference')
        assert wb['PL'].max_row==22 and wb['PL']['A2'].value=='売上高'
        source_checks=verify_audit_sources(payload,cache)
        # Only the final emitted record for a cell is authoritative; an earlier
        # disclosed literal can subsequently be replaced by an audited formula.
        emitted={(c['sheet'],c['address']):c for c in ds['export_metadata']['cells']}
        count=0;formulas=0
        for (sheet,address),item in emitted.items():
            actual=values[sheet][address].value;expected=item.get('display_value')
            if expected is None or expected=='':
                assert actual in (None,''),(workbook,sheet,address,expected,actual)
            else:
                if isinstance(actual,(date,datetime)):
                    assert actual.isoformat()[:10]==str(expected)[:10],(workbook,sheet,address,expected,actual)
                    continue
                try:a,b=Decimal(str(expected)),Decimal(str(actual))
                except Exception:
                    assert str(actual)==str(expected),(workbook,sheet,address,expected,actual)
                else:
                    assert abs(a-b)<=max(Decimal('0.00000001'),abs(a)*Decimal('1e-12')),(workbook,sheet,address,expected,actual)
                    count+=1
            if item.get('formula'):
                assert wb[sheet][address].data_type=='f'
                assert getattr(wb[sheet][address].value,'text',wb[sheet][address].value)==item['formula']
                formulas+=1
        assert not ds['warnings'],(workbook,ds['warnings'])
        assert all(c.get('ok') is not False for c in ds['checks'])
        summaries.append({'code':ds['code'],'company':ds['company'],'periods':len(periods),
                          'unit':ds['export_metadata']['unit'],'numeric_excel_cells':count,
                          'formula_cells':formulas,**source_checks,
                          'checks_passed':sum(c.get('ok') is True for c in ds['checks']),
                          'checks_unverified':sum(c.get('ok') is None for c in ds['checks']),
                          'workbook':workbook.name})
        wb.close();values.close()
    assert summaries,'No sample audits found'
    return summaries


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=Path,default=Path('examples'))
    parser.add_argument('--cache',type=Path,default=Path('.cache/zaimu10'))
    parser.add_argument('--json',type=Path)
    args=parser.parse_args()
    results=verify(args.samples,args.cache)
    output=json.dumps(results,ensure_ascii=False,indent=2)
    print(output)
    if args.json:args.json.write_text(output+'\n',encoding='utf-8')
