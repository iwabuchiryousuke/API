# データ・書式・ライブラリの出典 — v1.6.0

各資料の権利は提供元・作成者に帰属します。財務資料、株価、ウェブ画面、利用者提供の見本書式へ、本プログラムやPythonライブラリのライセンスを適用するものではありません。

実際に採用した原本URL、対象期間、取得日時、価格方式、原文SHA256、計算材料は、出力Excelと同名の **`.audit.json`** に保存します。Excel内のセルコメント・メモには出典を表示しません。

## 金融庁EDINET：財務・注記・株式数

- [EDINETトップ](https://disclosure2.edinet-fsa.go.jp/)
- [公式書類検索画面](https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx)
- [公式EDINETコードリスト](https://disclosure2dl.edinet-fsa.go.jp/searchdocument/codelist/Edinetcode.zip)
- 原文閲覧URL：`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?書類ID`

提出会社が作成した有価証券報告書・訂正報告書の公式公開原文を使用します。通常の財務数値は勘定別inline XBRL、借入・リース等の補足は実在するTextBlock内の明細表から取得します。タグのない古いIFRS本表では、明示的な年度列・単位・物理セル位置を確認し、実在のTextBlock QNameと表示上の合成した役割を区別します。

銘柄コードと提出者の対応だけに、公式コードリスト内のCSVを使用します。財務数値を市販CSVへ置き換えません。有料API、バフェットコードAPI、EDINET APIキーは使用しません。

期末時価総額用の株式数は、有報「株式等の状況」の当該事業年度末の発行済株式数を使います。提出日現在の株式数やEPSの期中平均では代用しません。古い年度のTextBlockでも、年月日・株単位・普通株式行・合計行を照合します。株式分割の効力日等は原文注記でも確認します。

リースは「借入金等明細表」等にある期末帳簿残高を取得します。将来の未割引支払額やCF支払額をBS残高として使いません。本表の「その他」に内包されると証明できるものだけを別掲し、元の「その他」から控除して二重加算を防ぎます。

代表例：

- [図研 S100W07I](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100W07I)：2025年3月期有報、提出2025年6月20日。
- [図研 S100YD7O](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100YD7O)：2026年3月期有報。リース内数の実例を計算説明書に掲載。
- [フルヤ金属 S100Z403](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100Z403)：2026年6月期有報。長期借入金を含め、長期未払金を有利子負債から除く実例。
- 各フィクスチャの書類ID・期間・保存形式・照合目的：[tests/fixtures/README.md](tests/fixtures/README.md)

回帰検証には図研、ドーン、トリケミカル研究所、シマノ、ニトリホールディングス、フルヤ金属、中外製薬等の公開原文と訂正報告書を使用します。同梱原文フィクスチャは解析・訂正分類・表示整理の検証用です。閲覧セッションのCookieやトークンは含めず、元の名前空間・QNameを保持します。

## 決算発表実績・公式予定と、アプリの予想日

- [JPX上場会社情報サービス](https://www2.jpx.co.jp/tseHpFront/JJK010010Action.do?Show=Show)：個社の適時開示にある本決算短信のタイトル・発表日・PDFリンク。
- [JPX決算発表予定日](https://www.jpx.co.jp/listing/event-schedules/financial-announcement/index.html)：公表済み日程。本決算・四半期の種別と対象期を確認。
- 各社公式IRカレンダー：会社が明示した予定日。各イベントに実際のURL・タイトルを保存。

有報の提出日を決算発表日として使いません。第三者の推測日を公式予定として取り込みません。

**「予想日」はアプリが生成する表示で、JPXや会社から取得した公式予定ではありません。** 次期の公式予定がない登録企業に、直近の本決算発表実績の1年後を表示します。2月29日は翌年2月28日とし、休日等は調整しません。元の実績・生成規則を区別し、公式予定・実績があればそれを優先します。予想で公式日付のキャッシュや登録履歴を上書きしません。

## 市場データ

### 国内の月次・日次株価

- Yahoo!ファイナンス日本の公開時系列：例 `https://finance.yahoo.co.jp/quote/6947.T/history`。月次の調整後終値をCAPMの収益率、日次の名目終値を期末時価総額に使用します。同サイトは国内時系列の提供元をNRIと説明しています。
- 公式説明：[調整後終値](https://support.yahoo-net.jp/PccFinance/s/article/H000006678)、[四本値](https://support.yahoo-net.jp/PccFinance/s/article/H000006682)、[時系列データの提供元](https://support.yahoo-net.jp/PccFinance/s/article/H000006667)。
- [株探の公開月足](https://kabutan.jp/stock/kabuka?code=4519&ashi=mon)：国内履歴の取得失敗時、同一銘柄のβ用月次系列全体を切り替えます。公表された修正株価の表示精度を使い、元資料にない小数を推定しません。
- [96UT公開株価履歴](https://96ut.com/)：必要な場合、会社コード・年度・日付が明示された日足から期末の名目終値を取得。具体的なURLは監査JSONに保存します。

年月日、項目、単位、URL、SHAを保存し、HTML内のスクリプトや閲覧トークンは市場キャッシュに含めません。現在の分割換算後株価を、過去当日の名目終値と混同しません。原文の株式数・分割注記と組み合わせて基準をそろえます。中外製薬の2020年分割は[会社公式発表](https://www.chugai-pharm.co.jp/news/detail/20200121170000_931.html)でも確認しています。

### 指数・実取引日・分割等の補助確認

Yahoo Finance公開Chart：`https://query1.finance.yahoo.com/v8/finance/chart/6947.T`（銘柄部分を置換）、日経平均は `^N225` です。日経平均、実取引日、権利落ち・分割等の確認、国内配信値との照合に使用します。原応答にハッシュと取得日時を付けて保存し、APIキーは使いません。

配信元ごとの公表精度・分割調整方法は同一とは限りません。国内価格と異なる海外配信値を無条件に混ぜず、採用方式・切替理由・差額を記録します。CAPMは配当込みの収益率ではなく、見本に合わせた分割換算後終値の整数部から計算します。

## Damodaran教授：円建てRfと日本の総ERP

提供元はAswath Damodaran教授（NYU Stern）です。**円建てリスクフリーレート、総株式リスク・プレミアム、国リスク・プレミアムは別の量として扱います。**

|資料|正式URL・採用範囲|対象時点|
|---|---|---|
|国別リスクのHTML|[ctryprem.html](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/ctryprem.html)。利用者指定の確認先。より新しい資料を探す際の比較元も保持|取得時のHTMLは2026年1月5日基準|
|通貨別インフレ換算の無リスク金利|[DiffInflationRiskfree26.xlsx](https://pages.stern.nyu.edu/~adamodar/pc/blog/DiffInflationRiskfree26.xlsx)、Sheet1のJapan行D89|2026年7月。日付の精度は月|
|国別の総株式リスク・プレミアム|[ctrypremJuly26.xlsx](https://pages.stern.nyu.edu/~adamodar/pc/datasets/ctrypremJuly26.xlsx)、「ERPs by country」のJapan行E81|2026年7月1日基準、7月9日にデフォルト・スプレッドを改訂|
|著者による公表・リンク|[2026年7月の著者解説](https://aswathdamodaran.blogspot.com/2026/07/country-risk-drivers-measures-and.html)|2026年7月15日公表|
|著者の公開記事検索|[riskfree記事の公開フィード](https://aswathdamodaran.blogspot.com/feeds/posts/default?alt=json&max-results=25&q=riskfree)|新しい公式資料への公開リンクの確認用|

2026年11月26日（日本時間）の確認では、円建てRfは **3.958435108％**、日本の総ERPは **5.072785840％** でした。Rfは `(1＋米ドルRf)×(1＋日本の期待インフレ率)÷(1＋米国の期待インフレ率)−1` による著者の円建て推計で、直近の日本国債市場利回りではありません。対象「2026年7月」と公表日「7月15日」を混同しません。

日本の総ERPは成熟市場ERP4.2％と国リスク・プレミアム約0.872785840％の合計です。国リスク部分をRfや総ERPの代わりに使いません。指定HTMLの旧総ERP5.14％も比較用に保存し、より新しい7月資料の選択理由を記録します。

資料の国・通貨・列の意味・値・対象時点を確認し、著者が公表した新しい資料を優先します。出典URL、記事URL、元セル、対象時点の精度、取得日、検証方法、原文SHAを監査JSONとキャッシュに保持します。検証済みの保存資料を再利用した場合は、その状態も記録します。

CAPMでは取得時点の最新確認値を過去年度列にも共通で使います。過去当時のRf・ERPを復元したものではありません。見本にあった固定Rf・ERPを現在値として転用しません。

## 利用者提供の書式テンプレート

主な参照は今回の **「6947_図研 見本.xlsx」** です。次の4ファイルへ、表示に必要な書式・ラベルを抽出しています。

|同梱asset|対応する表示|
|---|---|
|`zaimu10/assets/financial_template.xlsx`|PL・BS-a・BS-le・CFの列幅、行高、罫線、色、フォント、行構成|
|`zaimu10/assets/supplementary_template.xlsx`|FR・DCFの実績モデルの配置と書式|
|`zaimu10/assets/capm_template.xlsx`|CAPMの配置・罫線・校正表の書式|
|`zaimu10/assets/cagr_template.xlsx`|CAGRの8列、年度縦配置、集計行の書式|

過去のフルヤ金属・図研等の見本も科目配置と式の照合に使用しています。今回追加の味の素・Japan Elevatorは補助参照であり、将来予測値・目標値・予測期間を他社の実績に転用しません。

見本の会社別財務数値・過去株価・将来予測値を対象企業の値として使いません。財務入力は公開原文、市場入力は上記の取得元から読み、Excel式は確認した項目対応に基づいて生成します。表の過年度の誤記までコピーせず、今回指定された算術平均等を優先します。元の外部ブックリンクを出力へ持ち込みません。

## Pythonライブラリ

ライブラリ本体は初回準備で通常のPythonパッケージとして導入します。各ライブラリにはそれぞれのライセンスが適用されます。導入された正確な版は `python -m pip freeze` で確認できます。

|ライブラリ|用途|公開元・ライセンス|
|---|---|---|
|requests|HTTPS通信|[プロジェクト](https://github.com/psf/requests)・Apache-2.0|
|lxml|HTML／XML／inline XBRLの解析|[プロジェクト](https://lxml.de/)・BSD系。詳細は配布物のLICENSESを参照|
|cryptography|公式閲覧画面の応答処理|[プロジェクト](https://cryptography.io/)・Apache-2.0／BSD-3-Clause|
|openpyxl|Excel生成|[プロジェクト](https://openpyxl.readthedocs.io/)・MIT|
|Beautiful Soup 4|公開検索結果のHTML解析|[プロジェクト](https://www.crummy.com/software/BeautifulSoup/)・MIT|
|pytest（テスト用）|回帰テスト|[プロジェクト](https://pytest.org/)・MIT|

Python標準ライブラリとTkinterも使用します。Python・Tcl/Tkのライセンスは、それぞれの公式配布物を参照してください。
