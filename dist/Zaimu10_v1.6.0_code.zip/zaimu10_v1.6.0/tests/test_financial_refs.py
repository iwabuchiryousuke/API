"""Visible-cell analytical references, exact scopes and aggregate dominance."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip,json
from pathlib import Path
from types import SimpleNamespace

from openpyxl import Workbook
import pytest

from zaimu10.financial_refs import FinancialRefs
from zaimu10.models import Cell,Dataset,Filing,Period,Row,Source

P=Period(date(2024,4,1),date(2025,3,31))
J='http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor'
I='http://disclosure.edinet-fsa.go.jp/taxonomy/jpigp/2024-11-01/jpigp_cor'


def setup():
    book=Workbook();book.active.title='PL'
    for name in ['BS-A','BS-L,E','CF']:book.create_sheet(name)
    ds=Dataset('6947','図研','consolidated',[P],accounting_standard='J-GAAP')
    writer=SimpleNamespace(book=book,periods=[P],factor=Decimal(1000),unit_label='千円',
        values={},sources={},cells=[],source_addresses={},layout_metadata={},bs_metrics={})
    return ds,writer


def add(ds,w,statement,local,number,value,*,label=None,section=(),namespace=J,
        key=None,map_address=True,raw_value=None):
    sheet={'PL':'PL','BS_A':'BS-A','BS_LE':'BS-L,E','CF':'CF'}[statement]
    if sheet=='BS-A'and 'BS-a'in w.book:sheet='BS-a'
    if sheet=='BS-L,E'and 'BS-le'in w.book:sheet='BS-le'
    key=key or json.dumps([statement,local,[],'end'if statement.startswith('BS')else'duration','JPY','consolidated'])
    source=Source('S100TEST','statement.xhtml','https://example.jp/S100TEST',concept='{'+namespace+'}'+local,
        context_id='CurrentYearInstant'if statement.startswith('BS')else'CurrentYearDuration',unit='JPY',
        basis='consolidated',original_label=label or local,decimals='-3')
    fact=Cell(None if value is None else Decimal(str(raw_value if raw_value is not None else value))*1000,source,
              nil=value is None,source_section=tuple(section))
    record=Row(key,label or local,statement,tuple(section),values={P.key:fact})
    ds.rows[statement].append(record)
    address='B'+str(number);w.book[sheet].cell(number,1).value=label or local
    w.book[sheet][address].value=value
    w.values[sheet,address]=None if value is None else Decimal(str(value))
    w.sources[sheet,address]=fact
    w.cells.append({'sheet':sheet,'address':address,'row_key':key,'period':P.key,
        'display_value':None if value is None else str(value),'source':asdict(fact)})
    if map_address:w.source_addresses.setdefault(key,{})[P.key]={'sheet':sheet,'address':address,'row_key':key}
    return record


def test_final_display_value_wins_and_lookup_never_creates_or_changes_financial_cells():
    ds,w=setup();add(ds,w,'BS_A','CashAndDeposits',9,7,raw_value=999999)
    before=[(s.title,[(key,c.value)for key,c in s._cells.items()])for s in w.book]
    refs=FinancialRefs(w,ds);cash=refs.get('cash',P)
    assert cash.value==7 and cash.excel=="'BS-A'!B9"
    assert cash.refs[0].source is w.sources['BS-A','B9']
    assert refs.get('current_securities',P)is None and refs.reason('current_securities',P)
    assert before==[(s.title,[(key,c.value)for key,c in s._cells.items()])for s in w.book]


def test_zero_is_known_but_hidden_and_blank_are_not_raw_fallbacks():
    ds,w=setup();add(ds,w,'BS_A','CashAndDeposits',7,0)
    assert FinancialRefs(w,ds).get('cash',P).value==0
    w.book['BS-A'].row_dimensions[7].hidden=True
    assert FinancialRefs(w,ds).get('cash',P)is None
    w.book['BS-A'].row_dimensions[7].hidden=False;w.values['BS-A','B7']=None
    assert FinancialRefs(w,ds).get('cash',P)is None


def test_pl_ratio_labels_are_resolved_relative_to_revenue_without_fixed_row_numbers():
    ds,w=setup();add(ds,w,'PL','NetSales',12,100,key='metric:revenue')
    add(ds,w,'PL','CostOfSales',15,50,key='metric:cost_of_sales')
    for number,label,value in [(13,'(増加率）',Decimal('.2')),(20,'(増加率）',Decimal('.8')),(40,'実効税率',Decimal('.32'))]:
        w.book['PL'].cell(number,1).value=label;w.book['PL'].cell(number,2).value=value;w.values['PL','B'+str(number)]=value
    refs=FinancialRefs(w,ds)
    assert refs.get('revenue',P).excel=="'PL'!B12"
    assert refs.get('sales_growth',P).excel=="'PL'!B13"
    assert refs.get('effective_tax_rate',P).value==Decimal('.32')


def test_posted_receivable_and_inventory_aggregates_dominate_parts():
    ds,w=setup();scope=('資産の部','流動資産')
    add(ds,w,'BS_A','NotesAndAccountsReceivableTrade',4,30,section=scope)
    add(ds,w,'BS_A','NotesReceivableTrade',5,10,section=scope)
    add(ds,w,'BS_A','AccountsReceivableTrade',6,20,section=scope)
    add(ds,w,'BS_A','InventoriesIFRS',7,80,section=scope,namespace=I)
    add(ds,w,'BS_A','MerchandiseAndFinishedGoods',8,40,section=scope)
    refs=FinancialRefs(w,ds)
    assert refs.get('trade_receivables',P).value==30 and len(refs.get('trade_receivables',P).refs)==1
    assert refs.get('inventory',P).value==80 and refs.get('inventory',P).excel=="'BS-A'!B7"


def test_normalized_inventory_components_form_only_contiguous_visible_sum():
    ds,w=setup();scope=('資産の部','流動資産')
    add(ds,w,'BS_A','ComputedGoods',6,20,section=scope,key='["BS_A","inventory_goods","consolidated"]')
    add(ds,w,'BS_A','WorkInProcess',7,10,section=scope)
    add(ds,w,'BS_A','ComputedMaterials',8,5,section=scope,key='["BS_A","inventory_materials","consolidated"]')
    result=FinancialRefs(w,ds).get('inventory',P)
    assert result.value==35 and result.excel=="SUM('BS-A'!B6:B8)"


def test_broad_ifrs_trade_other_and_noncurrent_securities_are_not_substitutes():
    ds,w=setup();ds.accounting_standard='IFRS'
    add(ds,w,'BS_A','TradeAndOtherReceivablesCAIFRS',4,90,namespace=I,section=('流動資産',))
    add(ds,w,'BS_LE','TradeAndOtherPayablesCLIFRS',5,80,namespace=I,section=('流動負債',))
    add(ds,w,'BS_A','InvestmentSecurities',6,70,section=('固定資産','投資その他の資産'))
    add(ds,w,'BS_A','Securities',7,60,section=('固定資産',))
    refs=FinancialRefs(w,ds)
    assert refs.get('trade_receivables',P)is None
    assert refs.get('trade_payables',P)is None
    assert refs.get('current_securities',P)is None
    assert 'TradeAndOther' in refs.reason('trade_receivables',P)


def test_payable_aggregate_dominates_independent_parts_and_nil_is_not_filled():
    ds,w=setup();scope=('負債の部','流動負債')
    add(ds,w,'BS_LE','NotesAndAccountsPayableTrade',4,50,section=scope)
    add(ds,w,'BS_LE','NotesPayableTrade',5,20,section=scope)
    add(ds,w,'BS_LE','AccountsPayableTrade',6,30,section=scope)
    assert FinancialRefs(w,ds).get('trade_payables',P).value==50
    w.book['BS-L,E']['B4'].value=None;w.values['BS-L,E','B4']=None
    assert FinancialRefs(w,ds).get('trade_payables',P)is None


def test_cf_components_keep_signed_values_interest_cash_excludes_adjustment_and_fallback_is_visible():
    ds,w=setup()
    add(ds,w,'CF','DepreciationAndAmortizationOpeCF',4,10)
    add(ds,w,'CF','InterestExpensesOpeCF',11,100)  # adjustment, not cash
    add(ds,w,'CF','InterestPaidOpeCFIFRS',35,-2)
    add(ds,w,'CF','InterestPaidFinCFIFRS',60,-3,section=('財務活動によるキャッシュ・フロー',))
    add(ds,w,'CF','PurchaseOfPropertyPlantAndEquipmentInvCFIFRS',70,-40,map_address=False)
    add(ds,w,'CF','ProceedsFromSalesOfIntangibleAssetsInvCFIFRS',72,5,map_address=False)
    w.layout_metadata['CF']={'roles':{'4':4,'35':35}}
    refs=FinancialRefs(w,ds)
    assert refs.get('interest_paid',P).value==-5
    assert {r.address for r in refs.get('interest_paid',P).refs}=={'B35','B60'}
    assert refs.get('noncash',P).value==10
    assert refs.get('capex',P).value==-35 and refs.get('capex',P).excel=="'CF'!B70+'CF'!B72"
    assert FinancialRefs(setup()[1],setup()[0]).get('capex',P)is None


def test_roles_and_analysis_follow_actual_metadata_addresses():
    ds,w=setup();add(ds,w,'BS_A','CurrentAssets',17,120)
    add(ds,w,'BS_A','InvestedCapital',45,300,key='analysis:invested_capital')
    w.layout_metadata['BS-A']={'nodes':[{'role':'current_assets','row':17,'row_key':'layout:ca'}]}
    w.bs_metrics['invested_capital']={P.key:{'sheet':'BS-A','address':'B45','row_key':'analysis:invested_capital'}}
    refs=FinancialRefs(w,ds)
    assert refs.get('current_assets',P).excel=="'BS-A'!B17"
    assert refs.get('invested_capital',P).value==300


def test_ifrs_owners_total_alone_is_not_shareholders_equity():
    ds,w=setup();ds.accounting_standard='IFRS'
    add(ds,w,'BS_LE','EquityAttributableToOwnersOfParentIFRS',30,100,namespace=I)
    add(ds,w,'BS_LE','EquityIFRS',31,110,namespace=I)
    assert FinancialRefs(w,ds).get('shareholders_equity',P)is None


def test_ifrs_four_components_need_proven_complete_owner_decomposition():
    ds,w=setup();ds.accounting_standard='IFRS'
    for local,number,value in [('ShareCapitalIFRS',3,10),('CapitalSurplusIFRS',4,20),
        ('RetainedEarningsIFRS',5,80),('TreasurySharesIFRS',6,-10),('OtherComponentsOfEquityIFRS',7,5),
        ('EquityAttributableToOwnersOfParentIFRS',8,105)]:
        add(ds,w,'BS_LE',local,number,value,namespace=I,section=('資本',))
    w.layout_metadata['BS-L,E']={'nodes':[{'row':8,'children':[3,4,5,6,7]}]}
    result=FinancialRefs(w,ds).get('shareholders_equity',P)
    assert result.value==100 and result.excel=="SUM('BS-L,E'!B3:B6)"
    assert {r.address for r in result.refs}=={'B3','B4','B5','B6'}
    w.values['BS-L,E','B8']=Decimal(999)
    assert FinancialRefs(w,ds).get('shareholders_equity',P)is None


def test_actual_nitori_four_components_resolve_from_final_writer_cells():
    from zaimu10.parser import parse_filing
    from zaimu10.presentation import prepare_dataset
    from zaimu10.excel import Writer,_pl,_bs,_cf,_analysis
    pages=json.load(gzip.open(Path(__file__).parent/'fixtures'/'nitori_2026_ixbrl.json.gz','rt',encoding='utf8'))
    ds=prepare_dataset(parse_filing(Filing('S100TEST',code='9843'),pages))
    w=Writer(ds,'million')
    try:
        _pl(w,ds);_bs(w,ds,'BS_A');_bs(w,ds,'BS_LE');_cf(w,ds);_analysis(w,ds)
        refs=FinancialRefs(w,ds);result=refs.get('shareholders_equity',max(ds.periods))
        assert result is not None,refs.reason('shareholders_equity',max(ds.periods))
        assert result.value==Decimal(967854)
        assert all('OtherComponents' not in r.row_key for r in result.refs)
    finally:w.book.close();w.template.close()


@pytest.mark.parametrize('name,local,scope',[
    ('construction_in_progress','ConstructionInProgress',('固定資産','有形固定資産')),
    ('current_securities','Securities',('流動資産',)),
])
def test_optional_status_distinguishes_absence_nil_zero_and_unresolved_visible_cell(name,local,scope):
    ds,w=setup()
    assert FinancialRefs(w,ds).status(name,P)=='absent'
    record=add(ds,w,'BS_A',local,9,None,section=scope)
    refs=FinancialRefs(w,ds)
    assert refs.get(name,P)is None and refs.status(name,P)=='disclosed_blank'
    record.values[P.key].nil=False;record.values[P.key].value=Decimal(0)
    w.book['BS-A']['B9']=0;w.values['BS-A','B9']=Decimal(0)
    refs=FinancialRefs(w,ds)
    assert refs.status(name,P)=='available'and refs.get(name,P).value==0
    w.book['BS-A'].row_dimensions[9].hidden=True
    refs=FinancialRefs(w,ds)
    assert refs.get(name,P)is None and refs.status(name,P)=='unresolved'


def test_optional_presence_is_per_period_not_union_row_presence():
    ds,w=setup();future=Period(date(2025,4,1),date(2026,3,31))
    ds.periods=[P,future];w.periods=[P,future]
    record=add(ds,w,'BS_A','ConstructionInProgress',9,None,section=('固定資産','有形固定資産'))
    fact=record.values.pop(P.key);fact.value=Decimal(10000);fact.nil=False
    record.values[future.key]=fact
    w.sources.clear();w.cells.clear();w.source_addresses={record.key:{future.key:{'sheet':'BS-A','address':'C9','row_key':record.key}}}
    w.book['BS-A']['B9']=None;w.book['BS-A']['C9']=10
    w.values['BS-A','B9']=None;w.values['BS-A','C9']=Decimal(10)
    w.sources['BS-A','C9']=fact
    w.cells.append({'sheet':'BS-A','address':'C9','row_key':record.key,'period':future.key,'display_value':'10','source':asdict(fact)})
    refs=FinancialRefs(w,ds)
    assert refs.get('construction_in_progress',P)is None and refs.status('construction_in_progress',P)=='absent'
    assert refs.status('construction_in_progress',future)=='available'
    # Adding an actual nil cell to the earlier source changes only that year.
    unknown=deepcopy(fact);unknown.value=None;unknown.nil=True;record.values[P.key]=unknown
    refs=FinancialRefs(w,ds)
    assert refs.status('construction_in_progress',P)=='disclosed_blank'
    assert refs.status('construction_in_progress',future)=='available'


def _unshow(w,sheet,address):
    w.book[sheet][address]=None;w.values[sheet,address]=None


def test_parent_profit_is_distinct_from_total_and_requires_a_visible_registered_input():
    ds,w=setup()
    add(ds,w,'PL','ProfitLoss',19,120,key='metric:net_profit')
    parent=add(ds,w,'PL','ProfitLossAttributableToOwnersOfParent',28,100)
    _unshow(w,'PL','B28')
    refs=FinancialRefs(w,ds);typed=refs.parent_profit_input(P)
    assert typed.fact is parent.values[P.key] and typed.fact.value==100000
    assert typed.visible is None and refs.get('net_profit_parent',P)is None
    w.book.create_sheet('CAPM');w.book['CAPM']['B14']=100
    w.values['CAPM','B14']=Decimal(100);w.sources['CAPM','B14']=typed.fact
    resolved=refs.register_parent_profit(P,'B14')
    assert resolved.value==100 and resolved.excel=="'CAPM'!B14"
    assert refs.get('net_profit_parent',P)is resolved
    assert resolved.refs[0].source is parent.values[P.key]
    # A wrong support amount cannot be registered as the original parent fact.
    w.values['CAPM','B14']=Decimal(120)
    assert refs.register_parent_profit(P,'B14')is None


def test_equal_disclosed_parent_can_reference_visible_total_but_absent_nci_is_not_zero():
    ds,w=setup();add(ds,w,'PL','ProfitLoss',19,100,key='metric:net_profit')
    assert FinancialRefs(w,ds).parent_profit_input(P)is None
    add(ds,w,'PL','ProfitLossAttributableToOwnersOfParent',28,100);_unshow(w,'PL','B28')
    refs=FinancialRefs(w,ds);typed=refs.parent_profit_input(P)
    assert typed.visible.excel=="'PL'!B19"and refs.get('net_profit_parent',P).value==100


def test_explicit_nil_parent_is_not_filled_from_total_or_noncontrolling_profit():
    ds,w=setup();add(ds,w,'PL','ProfitLoss',19,120,key='metric:net_profit')
    add(ds,w,'PL','ProfitLossAttributableToOwnersOfParent',28,None)
    add(ds,w,'PL','ProfitLossAttributableToNonControllingInterests',29,20)
    refs=FinancialRefs(w,ds)
    assert refs.parent_profit_input(P)is None and refs.get('net_profit_parent',P)is None
    assert 'nil' in refs.reason('net_profit_parent',P)


def test_parent_derivation_retains_exact_total_and_nci_lineage_and_same_source_scope():
    ds,w=setup();total=add(ds,w,'PL','ProfitLoss',19,120,key='metric:net_profit')
    nci=add(ds,w,'PL','ProfitLossAttributableToNonControllingInterests',29,-5)
    refs=FinancialRefs(w,ds);typed=refs.parent_profit_input(P)
    assert typed.fact.value==125000 and typed.fact.operation=='difference'
    assert [c.value for c in typed.fact.components]==[120000,-5000]
    assert typed.fact.component_keys==[total.key,nci.key]
    assert typed.fact.source.concept=='{urn:zaimu10:analysis}ParentProfit'
    nci.values[P.key].source.doc_id='OTHER'
    assert FinancialRefs(w,ds).parent_profit_input(P)is None


def test_standalone_total_is_parent_but_company_extension_spelling_cannot_prove_parent():
    ds,w=setup();ds.basis='standalone'
    total=add(ds,w,'PL','ProfitLoss',19,100,key='metric:net_profit')
    total.values[P.key].source.basis='standalone'
    typed=FinancialRefs(w,ds).parent_profit_input(P)
    assert typed.fact is total.values[P.key]and typed.visible.value==100
    ds,w=setup()
    add(ds,w,'PL','ProfitLossAttributableToOwnersOfParent',28,100,namespace='https://example.jp/issuer_extension')
    assert FinancialRefs(w,ds).parent_profit_input(P)is None


def _html_disposal(ds,w,slot=45,value=-91):
    ds.code='4519';ds.accounting_standard='IFRS'
    caption,local={45:('有形固定資産の処分','HtmlRow_e91ca8b8c278f493ef'),
                   47:('無形資産の処分','HtmlRow_8d2a562025f959eb08')}[slot]
    row=add(ds,w,'CF',local,28 if slot==45 else 29,value,label=caption,
        namespace='http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2017-02-28/jpcrp_cor',
        section=('投資活動によるキャッシュ・フロー',))
    fact=row.values[P.key];source=fact.source
    source.concept='{http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2017-02-28/jpcrp_cor}ConsolidatedStatementOfCashFlowsIFRSTextBlock'
    source.semantic_concept='{urn:zaimu10:html-table:E00932:ConsolidatedStatementOfCashFlowsIFRSTextBlock}'+local
    source.filename='0105040_honbun_jpcrp030000-asr-001_E00932-000_2017-12-31_01_2018-03-22_ixbrl.htm'
    source.table_path=json.dumps({'table':0,'column':4,'row':15 if slot==45 else 16})
    row.display_group=fact.display_group='investing'
    return row


@pytest.mark.parametrize('slot,value',[(45,-91),(45,64),(47,452)])
def test_exact_chugai_html_disposal_capex_ref_preserves_signed_cash_and_does_not_change_sheets(slot,value):
    ds,w=setup();_html_disposal(ds,w,slot,value)
    before=[(sheet.title,[(key,cell.value)for key,cell in sheet._cells.items()])for sheet in w.book]
    resolved=FinancialRefs(w,ds).get('capex',P)
    assert resolved.value==value and len(resolved.refs)==1
    assert resolved.refs[0].sheet=='CF' and resolved.refs[0].address==('B28'if slot==45 else'B29')
    assert before==[(sheet.title,[(key,cell.value)for key,cell in sheet._cells.items()])for sheet in w.book]


@pytest.mark.parametrize('alter',[
    lambda ds,row:setattr(ds,'code','9999'),
    lambda ds,row:setattr(ds,'accounting_standard','J-GAAP'),
    lambda ds,row:setattr(row.values[P.key].source,'original_label','投資有価証券の処分'),
    lambda ds,row:setattr(row.values[P.key].source,'semantic_concept',row.values[P.key].source.semantic_concept.replace('E00932','E99999')),
    lambda ds,row:setattr(row.values[P.key].source,'filename','another_issuer.htm'),
    lambda ds,row:setattr(row.values[P.key].source,'basis','standalone'),
    lambda ds,row:setattr(row.values[P.key].source,'unit','shares'),
    lambda ds,row:setattr(row.values[P.key].source,'concept','{https://example.jp}ConsolidatedStatementOfCashFlowsIFRSTextBlock'),
    lambda ds,row:setattr(row.values[P.key].source,'table_path','{}'),
    lambda ds,row:setattr(row.values[P.key],'source_section',('営業活動によるキャッシュ・フロー',)),
    lambda ds,row:setattr(row.values[P.key],'display_group','operating_adjustments'),
])
def test_html_disposal_caption_alone_cannot_cross_issuer_statement_or_original_investing_scope(alter):
    ds,w=setup();row=_html_disposal(ds,w);alter(ds,row)
    assert FinancialRefs(w,ds).get('capex',P)is None


def test_actual_chugai_html_disposal_capex_both_years_in_ten_period_union():
    from zaimu10.audit import _cell
    from zaimu10.excel import Writer,_cf
    fixture=Path(__file__).parent/'fixtures'/'chugai_cf_merged_2016_2025.json.gz'
    data=json.load(gzip.open(fixture,'rt',encoding='utf8'))
    periods=[Period(date.fromisoformat(p['start']),date.fromisoformat(p['end']))for p in data['periods']]
    ds=Dataset(data['code'],data['company'],data['basis'],periods,
        accounting_standard=data['accounting_standard'],period_bases=data['period_bases'],period_standards=data['period_standards'])
    for item in data['rows']:
        record=dict(item);record['section']=tuple(record['section'])
        record['values']={key:_cell(value)for key,value in record['values'].items()}
        ds.rows['CF'].append(Row(**record))
    ds._financial_presentation_prepared=True
    w=Writer(ds,'million')
    try:
        _cf(w,ds);refs=FinancialRefs(w,ds)
        values={period.end.year:refs.get('capex',period)for period in periods}
        assert values[2016].value==Decimal(-36422)
        assert values[2017].value==Decimal(-44010)
        interest={period.end.year:refs.get('interest_paid',period)for period in periods}
        assert [interest[year].value for year in range(2016,2026)]==[
            Decimal(value)for value in [-8,-5,-5,-27,-34,-48,-58,-81,-94,-429]]
        assert all(ref.source.source.original_label=='利息の支払'for year in [2016,2017]
            for ref in interest[year].refs)
        # The genuine negative disposal cost is retained; the next year's
        # positive PPE/intangible proceeds are included exactly once.
        assert any(getattr(getattr(ref.source,'source',None),'original_label','')=='有形固定資産の処分'for ref in values[2016].refs)
        assert {'有形固定資産の処分','無形資産の処分'}<={getattr(getattr(ref.source,'source',None),'original_label','')for ref in values[2017].refs}
        assert all('投資有価証券'not in getattr(getattr(ref.source,'source',None),'original_label','')
            for result in values.values()for ref in result.refs)
        assert not any(check.get('ok')is False for check in ds.checks)
    finally:w.book.close();w.template.close()


def test_standard_ifrs_current_marketablesecurity_requires_standard_family_current_scope_and_preserves_nil():
    ds,w=setup();ds.accounting_standard='IFRS'
    row=add(ds,w,'BS_A','MarketableSecuritiesCAIFRS',8,102533,namespace=I,section=('流動資産：',))
    refs=FinancialRefs(w,ds)
    assert refs.get('current_securities',P).value==102533 and refs.status('current_securities',P)=='available'
    row.values[P.key].value=None;row.values[P.key].nil=True;_unshow(w,'BS-A','B8')
    refs=FinancialRefs(w,ds)
    assert refs.get('current_securities',P)is None and refs.status('current_securities',P)=='disclosed_blank'
    row.values[P.key].source_section=('非流動資産',)
    assert FinancialRefs(w,ds).status('current_securities',P)=='absent'
    row.values[P.key].source_section=('流動資産',)
    row.values[P.key].source.concept='{https://example.jp/issuer}MarketableSecuritiesCAIFRS'
    assert FinancialRefs(w,ds).get('current_securities',P)is None


def test_marketablesecurity_source_reaches_both_fr_liquidity_and_quick_ratios():
    from zaimu10.excel import Writer
    from zaimu10.supplemental import write_fr
    ds=Dataset('9999','テスト会社','consolidated',[P],accounting_standard='IFRS')
    w=Writer(ds,'thousand')
    try:
        add(ds,w,'PL','RevenueIFRS',2,1000,key='metric:revenue',namespace=I)
        add(ds,w,'BS_A','CashAndCashEquivalentsIFRS',3,50,namespace=I,section=('流動資産',))
        add(ds,w,'BS_A','MarketableSecuritiesCAIFRS',4,20,namespace=I,section=('流動資産：',))
        add(ds,w,'BS_A','TradeReceivablesCAIFRS',5,100,namespace=I,section=('流動資産',))
        add(ds,w,'BS_LE','CurrentLiabilitiesIFRS',7,150,namespace=I,section=('流動負債',))
        write_fr(w,ds,FinancialRefs(w,ds))
        assert w.values['FR','B14']==Decimal(70)/(Decimal(1000)/12)
        assert w.values['FR','B16']==Decimal(170)/150
        sheet='BS-a'if 'BS-a'in w.book else'BS-A'
        assert f"'{sheet}'!B4"in w.book['FR']['B14'].value and f"'{sheet}'!B4"in w.book['FR']['B16'].value
    finally:w.book.close();w.template.close()


def test_actual_ten_year_chugai_liquidity_includes_exact_current_securities_but_not_broad_receivables():
    from zaimu10.audit import _cell
    from zaimu10.excel import Writer
    from zaimu10.supplemental import write_fr
    fixture=Path(__file__).parent/'fixtures'/'chugai_fr_liquidity_2016_2025.json.gz'
    data=json.load(gzip.open(fixture,'rt',encoding='utf8'))
    periods=sorted(Period(date.fromisoformat(p['start']),date.fromisoformat(p['end']))for p in data['periods'])
    ds=Dataset(data['code'],data['company'],data['basis'],periods,
        accounting_standard=data['accounting_standard'],period_bases=data['period_bases'],period_standards=data['period_standards'])
    roles={};positions={'revenue':('PL',2),'cash':('BS-A',3),'securities':('BS-A',4),
        'broad_receivables':('BS-A',5),'current_assets':('BS-A',6),'current_liabilities':('BS-L,E',7)}
    for item in data['rows']:
        record=dict(item);role=record.pop('input_role');record['section']=tuple(record['section'])
        record['values']={key:_cell(value)for key,value in record['values'].items()}
        row=Row(**record);ds.rows[row.statement].append(row);roles[row.key]=role
    w=Writer(ds,'million')
    try:
        for rows in ds.rows.values():
            for row in rows:
                role=roles[row.key];sheet,number=positions[role]
                if sheet=='BS-A'and 'BS-a'in w.book:sheet='BS-a'
                if sheet=='BS-L,E'and 'BS-le'in w.book:sheet='BS-le'
                for column,period in enumerate(periods,2):
                    fact=row.values.get(period.key)
                    if fact is None:continue
                    w.source(sheet,number,column,row,fact,period)
                    if role=='revenue':w.cells[-1]['row_key']='metric:revenue'
                    w.source_addresses.setdefault(row.key,{})[period.key]={'sheet':sheet,'address':w.book[sheet].cell(number,column).coordinate,'row_key':row.key}
        refs=FinancialRefs(w,ds);metadata=write_fr(w,ds,refs)
        expected_securities=[110176,104018,102533,129117,166287,204217,280938,280308,456143,553094]
        for column,(period,securities)in enumerate(zip(periods,expected_securities),2):
            address=w.book['FR'].cell(14,column).coordinate
            assert refs.get('current_securities',period).value==securities
            cash=refs.get('cash',period).value;revenue=refs.get('revenue',period).value
            assert w.values['FR',address]==(cash+securities)/(revenue/12)
            # Broad other receivables cannot make the original trade-only
            # quick ratio complete, even though cash/securities are proven.
            assert refs.get('trade_receivables',period)is None
            assert w.book['FR'].cell(16,column).value is None
            assert metadata['periods'][period.key]['liquidity_months']['optional_input_status']=={'current_securities':'available'}
        assert abs(w.values['FR','D14']-Decimal('5.16175078089'))<Decimal('.00000000001')
    finally:w.book.close();w.template.close()


def test_new_sheet_names_parent_pl22_and_effective_tax24_resolve_without_capm_helper():
    ds,w=setup();asset=w.book['BS-A'];asset.title='temporary_assets';asset.title='BS-a';w.book['BS-L,E'].title='BS-le'
    add(ds,w,'PL','ProfitLoss',19,120,key='metric:net_profit')
    add(ds,w,'PL','ProfitLossAttributableToOwnersOfParent',22,100,key='metric:net_profit_parent')
    add(ds,w,'BS_A','CashAndDeposits',3,50,section=('流動資産',))
    w.book['PL']['A24']='実効税率';w.book['PL']['B24']=.3;w.values['PL','B24']=Decimal('.3')
    refs=FinancialRefs(w,ds)
    assert refs.get('net_profit_parent',P).excel=="'PL'!B22"
    assert refs.get('net_profit_parent',P).value==100
    assert refs.get('effective_tax_rate',P).excel=="'PL'!B24"
    assert refs.get('cash',P).excel=="'BS-a'!B3"
    assert 'CAPM'not in w.book


def test_new_dcf_noncash_and_ebitda_addback_have_distinct_exact_visible_components():
    ds,w=setup()
    for local,row,value in [('DepreciationAndAmortizationOpeCF',4,10),('AmortizationOfGoodwillOpeCF',5,2),
            ('ImpairmentLossOpeCF',6,3),('IncreaseDecreaseInProvisionForBonusesOpeCF',7,4)]:
        add(ds,w,'CF',local,row,value)
    w.layout_metadata['CF']={'roles':{str(row):row for row in range(4,8)}}
    refs=FinancialRefs(w,ds)
    assert refs.get('noncash',P).value==15 and refs.get('noncash',P).excel=="SUM('CF'!B4:B6)"
    assert refs.get('ebitda_addback',P).value==12 and refs.get('ebitda_addback',P).excel=="SUM('CF'!B4:B5)"


def test_condensed_asset_mapping_does_not_misrepresent_net_as_an_original_gross_or_contra_amount():
    ds,w=setup()
    gross=add(ds,w,'BS_A','Buildings',14,10)
    contra=add(ds,w,'BS_A','AccumulatedDepreciationBuildings',15,-4)
    net=add(ds,w,'BS_A','BuildingsNet',16,6)
    for row,role in [(gross,'gross'),(contra,'accumulated_depreciation')]:
        w.source_addresses[row.key][P.key]={'sheet':'BS-A','address':'B16','net_display':True,
            'net_source_role':role,'original_value_jpy':str(row.values[P.key].value),'display_value_jpy':'6000'}
    refs=FinancialRefs(w,ds)
    assert refs._row_ref(gross,P.key)is None and refs._row_ref(contra,P.key)is None
    assert refs._row_ref(net,P.key).value==6


@pytest.mark.parametrize('alter',[
    None,
    lambda ds,row:setattr(ds,'code','9999'),
    lambda ds,row:setattr(row.values[P.key].source,'original_label','利息の受取'),
    lambda ds,row:setattr(row.values[P.key].source,'semantic_concept',row.values[P.key].source.semantic_concept.replace('E00932','E99999')),
    lambda ds,row:setattr(row.values[P.key],'source_section',('営業活動によるキャッシュ・フロー',)),
    lambda ds,row:setattr(row.values[P.key],'display_group','operating_adjustments'),
    lambda ds,row:setattr(row.values[P.key].source,'table_path','{}'),
])
def test_old_html_cash_interest_requires_exact_issuer_original_caption_and_financing_scope(alter):
    ds,w=setup();row=_html_disposal(ds,w,45,-8);row.label='利息の支払'
    fact=row.values[P.key];fact.source.original_label='利息の支払'
    fact.source.semantic_concept='{urn:zaimu10:html-table:E00932:ConsolidatedStatementOfCashFlowsIFRSTextBlock}HtmlRow_cbd37ad74075e2cf7b'
    fact.source_section=row.section=('財務活動によるキャッシュ・フロー',)
    fact.display_group=row.display_group='financing'
    if alter:alter(ds,row)
    resolved=FinancialRefs(w,ds).get('interest_paid',P)
    if alter:assert resolved is None
    else:
        assert resolved.value==-8 and len(resolved.refs)==1
        assert resolved.excel=="'CF'!B28"


def test_standard_ifrs_related_share_cash_combines_existing_slot_and_extra_rows_once():
    ds,w=setup();ds.accounting_standard='IFRS'
    scope=('投資活動によるキャッシュ・フロー',)
    add(ds,w,'CF','PaymentsForAcquisitionOfSubsidiariesInvCFIFRS',50,-40,
        namespace=I,label='連結の範囲の変更を伴う子会社株式の取得による支出',section=scope)
    add(ds,w,'CF','PurchaseOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS',80,-6,
        namespace=I,label='持分法で処理される投資の株式の取得による支出',section=scope)
    add(ds,w,'CF','ProceedsFromSaleOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS',81,4,
        namespace=I,label='持分法で処理される投資の株式の売却による収入',section=scope)
    # The subsidiary amount is already in the displayed acquisition slot.
    # Both discovery paths reach B50; it must enter CAPEX exactly once.
    w.layout_metadata['CF']={'roles':{'50':50}}
    result=FinancialRefs(w,ds).get('capex',P)
    assert result.value==-42
    assert {r.address for r in result.refs}=={'B50','B80','B81'}


@pytest.mark.parametrize('alter',[
    lambda ds,row:setattr(row.values[P.key].source,'concept','{https://example.jp/company}PurchaseOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS'),
    lambda ds,row:setattr(row.values[P.key],'source_section',('営業活動によるキャッシュ・フロー',)),
    lambda ds,row:setattr(row.values[P.key].source,'original_label','持分法で処理される投資の取得による支出'),
])
def test_related_share_alias_does_not_absorb_broad_investments_extensions_or_operating_adjustments(alter):
    ds,w=setup();ds.accounting_standard='IFRS'
    row=add(ds,w,'CF','PurchaseOfInvestmentsAccountedForUsingEquityMethodInvCFIFRS',80,-6,
        namespace=I,label='持分法で処理される投資の株式の取得による支出',section=('投資活動によるキャッシュ・フロー',))
    alter(ds,row)
    assert FinancialRefs(w,ds).get('capex',P)is None


def test_actual_ajinomoto_related_share_scope_includes_old_html_and_distinct_subsidiary_disposal():
    from zaimu10.excel import Writer,_cf
    from zaimu10.presentation import _concept
    data=json.load(gzip.open(Path(__file__).parent/'fixtures'/'ajinomoto_share_capex_scope.json.gz','rt',encoding='utf8'))
    periods=sorted({Period(date.fromisoformat(x['period'].split('/')[0]),date.fromisoformat(x['period'].split('/')[1]))for x in data['records']})
    ds=Dataset('2802','味の素','consolidated',periods,accounting_standard='IFRS');grouped={};expected={}
    for item in data['records']:
        source=Source(**item['source']);local=_concept(source.account_concept)[1]
        key=json.dumps(['CF',_concept(source.account_concept)[0],local,[],'duration','JPY','consolidated','IFRS',item['source_section']],ensure_ascii=False)
        record=grouped.get(key)
        if record is None:
            record=Row(key,source.original_label,'CF',tuple(item['source_section']),display_group='investing'if '投資活動' in ''.join(item['source_section'])else'operating_adjustments')
            grouped[key]=record;ds.rows['CF'].append(record)
        record.values[item['period']]=Cell(None if item['value_jpy']is None else Decimal(item['value_jpy']),source,
            nil=item['nil'],source_section=tuple(item['source_section']),display_group=record.display_group)
        if '投資活動' in ''.join(item['source_section'])and item['value_jpy']is not None:
            expected[item['period']]=expected.get(item['period'],Decimal(0))+Decimal(item['value_jpy'])/1000000
    ds._financial_presentation_prepared=True
    w=Writer(ds,'million')
    try:
        _cf(w,ds);refs=FinancialRefs(w,ds)
        for period in periods:
            result=refs.get('capex',period)
            assert (result.value if result else None)==expected.get(period.key)
        old=next(p for p in periods if p.end.year==2017);result=refs.get('capex',old)
        assert result.value==Decimal(-60828)  # −63979 associate buy +916 sale +2235 subsidiary sale
        assert {r.source.source.original_label for r in result.refs}=={
            '持分法で処理される投資の株式の取得による支出','持分法で処理される投資の株式の売却による収入',
            '連結の範囲の変更を伴う子会社株式の売却による収入'}
        assert not any('売却益'in r.source.source.original_label for r in result.refs)
    finally:w.book.close();w.template.close()


def test_equity_method_share_impairment_is_not_silently_folded_into_generic_noncash_loss():
    ds,w=setup();ds.accounting_standard='IFRS'
    add(ds,w,'CF','DepreciationAndAmortizationOpeCFIFRS',4,10,namespace=I)
    add(ds,w,'CF','ImpairmentLossesReversalOfImpairmentLossesOpeCFIFRS',6,2,namespace=I)
    add(ds,w,'CF','ImpairmentLossesOfSharesOfInvestmentsAccountedForUsingEquityMethodOpeCFIFRSIFRS',80,100,
        namespace='https://example.jp/company',label='持分法株式に係る減損損失')
    w.layout_metadata['CF']={'roles':{'4':4,'6':6}}
    assert FinancialRefs(w,ds).get('noncash',P).value==12


def _ajinomoto_html_capital_fixture():
    data=json.load(gzip.open(Path(__file__).parent/'fixtures'/'ajinomoto_2017_shareholder_equity.json.gz','rt',encoding='utf8'))
    period=Period(date(2016,4,1),date(2017,3,31));ds,w=setup()
    ds.code='2802';ds.accounting_standard='IFRS';ds.periods=[period];w.periods=[period];w.factor=Decimal(1000000)
    w.book['BS-L,E'].title='BS-le';records={}
    for number,item in enumerate(data,3):
        source=Source(**item['source']);local=source.account_concept.rsplit('}',1)[-1]
        fact=Cell(Decimal(item['value'])if item['value']is not None else None,source,nil=item['nil'],
            source_section=tuple(item['source_section']),source_order=item['source_order'])
        key=json.dumps(['BS_LE','issuer:html:E00436',local,[],'end','JPY','consolidated','IFRS',['資本']],ensure_ascii=False)
        row=Row(key,item['label'],'BS_LE',('資本',),values={period.key:fact});ds.rows['BS_LE'].append(row)
        address=f'B{number}';w.book['BS-le'].cell(number,1).value=item['label']
        display=fact.value/w.factor if fact.value is not None else None
        w.book['BS-le'][address]=float(display)if display is not None else None
        w.values['BS-le',address]=display;w.sources['BS-le',address]=fact
        w.cells.append({'sheet':'BS-le','address':address,'row_key':key,'period':period.key,
            'display_value':str(display)if display is not None else None,'source':asdict(fact)})
        w.source_addresses.setdefault(key,{})[period.key]={'sheet':'BS-le','address':address,'row_key':key}
        records[local]=row
    w.layout_metadata['BS-le']={'nodes':[{'row':8,'children':[3,4,5,6,7]}]}
    return ds,w,period,records


def test_actual_ajinomoto_html_four_core_capital_proves_visible_roe_denominator_without_qname_rewrite():
    ds,w,period,rows=_ajinomoto_html_capital_fixture()
    before=[(s.title,[(key,c.value)for key,c in s._cells.items()])for s in w.book]
    refs=FinancialRefs(w,ds);result=refs.get('shareholders_equity',period)
    assert result is not None,refs.reason('shareholders_equity',period)
    assert result.value==Decimal(661614)and result.excel=="SUM('BS-le'!B3:B6)"
    assert abs(Decimal(53065)/result.value-Decimal('0.0802053765483'))<Decimal('1e-12')
    assert {ref.source.source.original_label for ref in result.refs}=={'資本金','資本剰余金','利益剰余金','自己株式'}
    assert all(ref.source.source.concept.endswith('}ConsolidatedStatementOfFinancialPositionIFRSTextBlock')for ref in result.refs)
    assert before==[(s.title,[(key,c.value)for key,c in s._cells.items()])for s in w.book]


@pytest.mark.parametrize('alter',[
    lambda ds,w,p,rows:setattr(ds,'code','9999'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'doc_id','ANOTHER'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'context_id','Prior1YearInstant'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'unit','shares'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'basis','standalone'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'table_path','{}'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'table_path','{"table":1,"row":27,"column":3}'),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key],'source_section',('負債',)),
    lambda ds,w,p,rows:setattr(rows['ShareCapitalIFRS'].values[p.key].source,'concept','{https://example.jp/unknown}ConsolidatedStatementOfFinancialPositionIFRSTextBlock'),
    lambda ds,w,p,rows:rows['ShareCapitalIFRS'].values.pop(p.key),
])
def test_html_capital_reconstruction_rejects_unproved_issuer_period_scope_unit_or_physical_source(alter):
    ds,w,period,rows=_ajinomoto_html_capital_fixture();alter(ds,w,period,rows)
    assert FinancialRefs(w,ds).get('shareholders_equity',period)is None


def test_html_capital_explicit_unknown_other_component_does_not_become_zero():
    ds,w,period,rows=_ajinomoto_html_capital_fixture()
    fact=rows['OtherComponentsOfEquityIFRS'].values[period.key];fact.value=None;fact.nil=True
    w.book['BS-le']['B7']=None;w.values['BS-le','B7']=None
    assert FinancialRefs(w,ds).get('shareholders_equity',period)is None
    ds,w,period,rows=_ajinomoto_html_capital_fixture()
    # Including NCI in an owner-equity frame cannot replace the source-proved
    # four-component decomposition, even though it has a genuine HTML origin.
    w.layout_metadata['BS-le']['nodes'][0]['children'].append(9)
    assert FinancialRefs(w,ds).get('shareholders_equity',period)is None
