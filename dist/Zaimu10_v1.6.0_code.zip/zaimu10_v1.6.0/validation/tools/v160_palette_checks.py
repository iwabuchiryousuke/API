"""Independent DCF-to-financial-label palette footprint checks.

Checks only column A. It neither changes products nor imports their color
selection code, and does not infer account identity from Japanese captions.
"""
from __future__ import annotations

import json
import re

_FINANCIAL = {'PL', 'BS-a', 'BS-le', 'CF'}
_DCF_ROWS = {'effective_tax_rate': 13, 'noncash': 15, 'trade_receivables': 17,
             'inventory': 19, 'trade_payables': 21, 'capex': 25}
_STANDARD = re.compile(r'^\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp)/[^/]+/(?:jppfs|jpigp)_cor\}(.+)$')
_LOCALS = {
    'trade_receivables': {'NotesAndAccountsReceivableTrade', 'TradeReceivablesCAIFRS',
                          'TradeReceivablesIFRS', 'NotesReceivableTrade', 'AccountsReceivableTrade'},
    'inventory': {'Inventories', 'InventoriesIFRS', 'InventoriesCAIFRS', 'TotalInventories',
                  'MerchandiseAndFinishedGoods', 'WorkInProcess', 'RawMaterialsAndSupplies',
                  'Merchandise', 'FinishedGoods', 'RawMaterials', 'Supplies'},
    'trade_payables': {'NotesAndAccountsPayableTrade', 'TradePayablesCLIFRS',
                       'TradePayablesIFRS', 'NotesPayableTrade', 'AccountsPayableTrade'},
}
_GROUPS = {'trade_receivables': {'trade_receivables'},
           'inventory': {'inventory_goods', 'inventory_materials'}}


def _color(value):
    if value is None:
        return None
    return value.type, value.index, value.tint


def _fill(value):
    return value.patternType, _color(value.fgColor), _color(value.bgColor)


def _style(cell):
    return _fill(cell.fill), _color(cell.font.color)


def _row(address):
    match = re.fullmatch(r'\$?[A-Z]+\$?([1-9][0-9]*)', str(address))
    return int(match.group(1)) if match else None


def _groups(key):
    while key.startswith(('display:', 'net_asset:')):
        key = key.split(':', 1)[1]
    try:
        identity = json.loads(key)
    except (TypeError, ValueError):
        return set()
    return {token for token in identity if isinstance(token, str)} if isinstance(identity, list) else set()


def validate_palette(ds, metadata, formulas, check):
    """Require exact DCF colors on actual inputs; reject unrelated footprints.

    Proven numeric inputs are mandatory. Exact known account identities and CF
    roles additionally permit an already-colored counterpart whose annual data
    are all nil, without inventing a value or matching a label by similarity.
    """
    if 'DCF' not in formulas:
        check(False, 'palette_dcf_sheet_present')
        return
    dcf = formulas['DCF']
    desired = {metric: _style(dcf.cell(row, 1)) for metric, row in _DCF_ROWS.items()}
    active_fills = {_fill(dcf.cell(_DCF_ROWS[metric], 1).fill)
                    for metric in ['noncash', 'trade_receivables', 'inventory', 'trade_payables', 'capex']}
    mandatory = {}
    permitted = {}

    def allow(sheet, row, metric, required=False):
        if sheet not in _FINANCIAL or row is None or row <= 1:
            return False
        if sheet not in formulas.sheetnames:
            return False
        permitted.setdefault((sheet, row), set()).add(metric)
        if required:
            mandatory.setdefault((sheet, row), set()).add(metric)
        return True

    periods = metadata.get('supplemental', {}).get('DCF', {}).get('periods', {})
    for period, annual in periods.items():
        for metric in _DCF_ROWS:
            for item in annual.get(metric, {}).get('inputs', []):
                sheet, address = item.get('sheet'), item.get('address')
                row = _row(address)
                valid = allow(sheet, row, metric, required=True)
                check(valid, 'palette_dcf_input_visible_financial_address',
                      period=period, metric=metric, sheet=sheet, address=address)
    roles = metadata.get('layout', {}).get('CF', {}).get('roles', {})
    for metric, slots in [('noncash', [4, 5, 6]), ('capex', [44, 45, 46, 47, 50, 51])]:
        for slot in slots:
            row = roles.get(str(slot), roles.get(slot))
            if isinstance(row, int):
                allow('CF', row, metric)
    # Exact semantic identities may exist in a row while all annual values are
    # nil; permit those labels without requiring a DCF amount to be invented.
    addresses = metadata.get('source_addresses', {})
    for statement, sheet in [('BS_A', 'BS-a'), ('BS_LE', 'BS-le')]:
        for record in ds.get('rows', {}).get(statement, []):
            tokens = _groups(record.get('key', ''))
            for period, fact in record.get('values', {}).items():
                source = fact.get('source') or {}
                concept = source.get('semantic_concept') or source.get('concept', '')
                matched = _STANDARD.fullmatch(concept)
                local = matched.group(2) if matched else None
                mapping = addresses.get(record.get('key'), {}).get(period) or {}
                address = mapping.get('address')
                if mapping.get('sheet') != sheet or not address:
                    continue
                for metric, locals_ in _LOCALS.items():
                    correct_statement = statement == ('BS_LE' if metric == 'trade_payables' else 'BS_A')
                    grouped = bool(tokens & _GROUPS.get(metric, set()))
                    if correct_statement and (local in locals_ or grouped):
                        allow(sheet, _row(address), metric)
    for (sheet, row), metrics in sorted(mandatory.items()):
        cell = formulas[sheet].cell(row, 1)
        for metric in sorted(metrics):
            check(_style(cell) == desired[metric], 'palette_actual_input_label_matches_dcf',
                  sheet=sheet, address=cell.coordinate, label=cell.value, metric=metric,
                  expected=repr(desired[metric]), actual=repr(_style(cell)))
    for sheet in sorted(_FINANCIAL & set(formulas.sheetnames)):
        ws = formulas[sheet]
        for row in range(2, ws.max_row + 1):
            cell = ws.cell(row, 1)
            if cell.value is None or _fill(cell.fill) not in active_fills:
                continue
            metrics = permitted.get((sheet, row), set())
            check(bool(metrics), 'palette_no_unrelated_financial_label',
                  sheet=sheet, address=cell.coordinate, label=cell.value,
                  actual=repr(_style(cell)))
            if metrics:
                check(any(_style(cell) == desired[metric] for metric in metrics),
                      'palette_allowed_counterpart_has_correct_color',
                      sheet=sheet, address=cell.coordinate, label=cell.value,
                      metrics=sorted(metrics), expected=[repr(desired[metric]) for metric in sorted(metrics)],
                      actual=repr(_style(cell)))
    # The exporter's own coloring log is an assertion to inspect, not an
    # authority granting permission to paint an arbitrary financial row.
    for item in metadata.get('source_label_colors', []):
        sheet, row, source_row = item.get('sheet'), item.get('row'), item.get('dcf_row')
        metrics = permitted.get((sheet, row), set())
        check(any(_DCF_ROWS[metric] == source_row for metric in metrics),
              'palette_recorded_footprint_is_proven_counterpart',
              sheet=sheet, row=row, dcf_row=source_row)
