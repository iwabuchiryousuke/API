from datetime import date
from pathlib import Path
import io
import json
import zipfile

import pytest

from zaimu10.discovery import (
    DiscoveryError, _filings_from_rows, _parse_code_archive,
    _state_from_html, _request, discover_filings, normalize_code, resolve_company,
)


@pytest.mark.parametrize('raw,expected', [('６９４７','6947'), ('69470','6947'),
                                        (' 6947.T ', '6947'), ('285a.jp', '285A')])
def test_stock_codes(raw, expected):
    assert normalize_code(raw) == expected


@pytest.mark.parametrize('raw', ['../6947', '6947;rm', '0', '', 'ABCDEFGHI'])
def test_rejects_non_stock_codes(raw):
    with pytest.raises(ValueError):
        normalize_code(raw)


def _archive():
    text = 'ダウンロード実行日,2026年11月11日現在\r\nＥＤＩＮＥＴコード,提出者名,証券コード,連結の有無,決算日\r\nE01966,株式会社図研,69470,有,3月31日\r\nE99999,テスト,285A0,無,12月31日\r\n'
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w') as archive:
        archive.writestr('EdinetcodeDlInfo.csv', text.encode('cp932'))
    return output.getvalue()


def test_official_cp932_code_map_and_offline_resolve(tmp_path):
    archive_path = tmp_path/'discovery'/'Edinetcode.zip'
    archive_path.parent.mkdir()
    archive_path.write_bytes(_archive())
    assert len(_parse_code_archive(archive_path.read_bytes())) == 2
    company = resolve_company('6947', cache_dir=tmp_path, offline=True)
    assert company['edinet_code'] == 'E01966'
    assert company['company'] == '株式会社図研'
    assert company['consolidated'] is True
    assert resolve_company('285A', cache_dir=tmp_path, offline=True)['consolidated'] is False


def _row(doc='S100W07I', kind='12001', name='有価証券報告書－第49期(2024/04/01－2025/03/31)', edinet='E01966'):
    return {'SHORUI_KANRI_NO':doc, 'SYORUI_SB_CD_ID':kind, 'SHORUI_NAME':name,
            'EDINET_CD':edinet, 'TEISHUTSU_NICHIJI':'2025/06/20 14:09',
            'TEISYUTUSYA_NAME':'株式会社図研', 'STATUS':'31'}


def test_filter_annual_only_keep_amendments_avoid_other_companies():
    rows = [_row(), _row(), _row(doc='S100YAAA', kind='13001', name='訂正有価証券報告書－第49期(2024/04/01－2025/03/31)'),
            _row(doc='S100ZAAB', kind='16001', name='半期報告書－第50期(2025/04/01－2026/03/31)'),
            _row(doc='S100ZAAC', edinet='E00001')]
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    filings = _filings_from_rows(rows, company)
    assert len(filings) == 2
    assert {f.amended for f in filings} == {False, True}
    assert all(f.start == date(2024,4,1) and f.end == date(2025,3,31) for f in filings)


def test_invalid_period_fails_without_guessing():
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    with pytest.raises(DiscoveryError, match='対象期間'):
        _filings_from_rows([_row(name='有価証券報告書－第49期')],company)


def test_offline_discovery_never_needs_session_tokens(tmp_path):
    directory=tmp_path/'discovery';directory.mkdir()
    (directory/'Edinetcode.zip').write_bytes(_archive())
    (directory/'E01966.json').write_text(json.dumps({'schema':1,'edinet_code':'E01966','rows':[_row()], 'queried_at':'2026-11-11T00:00:00Z'}),encoding='utf-8')
    filings=discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)
    assert len(filings)==1
    assert filings[0].doc_id=='S100W07I'


def test_missing_offline_cache_is_explicit(tmp_path):
    with pytest.raises(DiscoveryError, match='オフライン'):
        discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)


def test_unexpected_search_response_not_parsed_as_empty_result():
    with pytest.raises(DiscoveryError, match='検索画面'):
        _state_from_html('<html>Service unavailable</html>')


def test_unavailable_and_unknown_statuses_not_selected():
    company={'code':'6947','company':'図研','edinet_code':'E01966'}
    withdrawn=_row();withdrawn['STATUS']='99'
    unavailable=_row(doc='S100YAAA');unavailable['BIKOU']='取り下げられた書類'
    assert not _filings_from_rows([withdrawn,unavailable],company,log=lambda _:None)


def test_swapped_offline_company_cache_is_rejected(tmp_path):
    directory=tmp_path/'discovery';directory.mkdir()
    (directory/'Edinetcode.zip').write_bytes(_archive())
    (directory/'E01966.json').write_text(json.dumps({'schema':1,'edinet_code':'E00001','rows':[_row()]}),encoding='utf-8')
    with pytest.raises(DiscoveryError,match='一致'):
        discover_filings('6947',cache_dir=tmp_path,offline=True,log=lambda _:None)


def test_long_server_retry_after_stops_without_early_retry(monkeypatch):
    from zaimu10 import edinet
    class Response:
        status_code=429
        headers={'Retry-After':'301'}
    class Session:
        calls=0
        def request(self,*args,**kwargs):
            self.calls+=1
            assert kwargs['allow_redirects'] is False
            return Response()
    session=Session()
    monkeypatch.setattr(edinet,'_pause',lambda *args:None)
    with pytest.raises(DiscoveryError,match='301秒'):
        _request(session,'GET','https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx')
    assert session.calls==1


def test_redirect_cannot_forward_form_tokens(monkeypatch):
    from zaimu10 import edinet
    class Response:
        status_code=302
        headers={'Location':'https://example.com'}
    class Session:
        def request(self,*args,**kwargs):
            assert kwargs['allow_redirects'] is False
            return Response()
    monkeypatch.setattr(edinet,'_pause',lambda *args:None)
    with pytest.raises(DiscoveryError,match='HTTP 302'):
        _request(Session(),'POST','https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx')
