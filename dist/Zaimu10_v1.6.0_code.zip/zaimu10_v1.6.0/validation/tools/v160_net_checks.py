"""Independent v1.6 net-only BS checks against original fact provenance.

No product calculation or classification function is imported. Callers supply
raw fact identities and the comparison/report helpers used by the main oracle.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
import json
import re

_FACTORS = {'yen': Decimal(1), 'thousand': Decimal(1000), 'million': Decimal(1000000)}
_CONTRA = ('AccumulatedDepreciationAndImpairmentLoss',
           'AccumulatedAmortizationAndImpairmentLoss', 'AccumulatedDepreciation',
           'AccumulatedImpairmentLoss', 'AccumulatedAmortization')
_STANDARD = re.compile(r'^\{(https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp)/[^/]+/(?:jppfs|jpigp)_cor)\}(.+)$')
_NITORI_ROU = re.compile(r'^\{https?://disclosure\.edinet-fsa\.go\.jp/jpcrp030000/asr/001/E03144-000/[^/]+/[^/]+/[^/]+\}(.+)$')
_NITORI_ROLES = {'RightOfUseAssetsPPE': 'gross', 'RightOfUseAssetsNetPPE': 'net',
                 'AccumulatedDepreclationRightOfUseAssets': 'AccumulatedDepreciation',
                 'AccumulatedDepreciationRightOfUseAssets': 'AccumulatedDepreciation'}


def _numeric(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        value = Decimal(str(value))
        return value if value.is_finite() else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def _class(source, *, nitori_rou=False):
    # This is a narrowly verified arithmetic relationship, not an assertion
    # that the extension QName and standard QName identify the same account.
    # Both genuine QName identities continue through the raw ledger checks.
    genuine = source.get('concept', '')
    issuer = _NITORI_ROU.fullmatch(genuine)
    standard = _STANDARD.fullmatch(genuine)
    if nitori_rou and '_E03144-000_' in source.get('filename', '') and not source.get('semantic_concept'):
        if issuer and issuer.group(1) in _NITORI_ROLES:
            return ('verified-arithmetic:E03144:ROU', 'E03144', 'RightOfUseAssets',
                    _NITORI_ROLES[issuer.group(1)])
        if standard and standard.group(2) == 'jppfs' and standard.group(3) == 'AccumulatedDepreciationRightOfUseAssets':
            return 'verified-arithmetic:E03144:ROU', 'E03144', 'RightOfUseAssets', 'AccumulatedDepreciation'
    matched = _STANDARD.fullmatch(source.get('semantic_concept') or source.get('concept', ''))
    if not matched:
        return None
    namespace, family, local = matched.groups()
    local = local.replace('AccumulatedDepreclation', 'AccumulatedDepreciation')
    kind = 'gross'
    for prefix in _CONTRA:
        if local.startswith(prefix):
            kind, local = prefix, local[len(prefix):]
            break
    if kind == 'gross' and 'Net' in local:
        kind, local = 'net', local.replace('Net', '')
    stem = re.sub(r'(?:PPE|IA)$', '', local)
    return namespace, family, stem, kind


def _key_scope(key):
    while key.startswith(('display:', 'net_asset:')):
        key = key.split(':', 1)[1]
    try:
        parts = json.loads(key)
    except (ValueError, TypeError):
        return None
    if not isinstance(parts, list) or len(parts) not in {8, 9} or parts[0] != 'BS_A':
        return None
    return json.dumps(parts[3], sort_keys=True, ensure_ascii=False), parts[4], parts[5], parts[-2]


def _rounding(cell):
    try:
        return Decimal(10) ** -int(cell['source']['decimals'])
    except (KeyError, ValueError, TypeError):
        return Decimal(0)


def validate_net_presentation(ds, metadata, formulas, cached, ledger, check,
                              counts, source_identity, source_leaves, equal):
    """Check each displayed net against independent original facts and scope."""
    sheet = 'BS-a'
    proofs = metadata.get('layout', {}).get(sheet, {}).get('net_asset_presentation', {}).get('periods', [])
    addresses = metadata.get('source_addresses', {})
    factor = _FACTORS.get(metadata.get('unit'))
    check(factor is not None, 'net_display_unit_known', unit=metadata.get('unit'))
    if factor is None:
        return
    period_keys = {p['start'] + '/' + p['end'] for p in ds.get('periods', [])}
    original_periods = {}
    for rows in list(ds.get('rows', {}).values()) + [ds.get('analysis_inputs', [])]:
        for row in rows:
            for period, cell in row.get('values', {}).items():
                for leaf in source_leaves(cell):
                    ident = source_identity(leaf.get('source', {}))
                    original_periods.setdefault((ident, str(leaf.get('value')), bool(leaf.get('nil'))), set()).add(period)
    entries = [item for item in metadata.get('cells', []) if item.get('sheet') == sheet]
    has_period_ledger = any(isinstance(key, tuple) and key and key[0] == 'period' for key in ledger)

    def fingerprint(cell):
        return (source_identity(cell.get('source', {})), str(cell.get('value')), bool(cell.get('nil')),
                cell.get('operation', ''), tuple(cell.get('component_keys', [])),
                tuple(fingerprint(child) for child in cell.get('components', [])))

    def original(cell, period, role):
        for leaf in source_leaves(cell):
            identity = source_identity(leaf.get('source', {}))
            value = (str(leaf.get('value')), bool(leaf.get('nil')))
            check(identity in ledger and value in ledger[identity], 'net_original_fact_provenance',
                  period=period, role=role, source=list(identity), value=value[0])
            period_identity = ('period', period, identity)
            if has_period_ledger:
                check(value in ledger.get(period_identity, set()), 'net_raw_fact_same_period',
                      period=period, role=role, source=list(identity), value=value[0])
            check(period in original_periods.get((identity, *value), set()), 'net_original_fact_period',
                  period=period, role=role, source=list(identity))

    seen = set()
    for proof in proofs:
        period, net_key = proof.get('period'), proof.get('net_key')
        context = {'period': period, 'net_key': net_key}
        check(period in period_keys and (period, net_key) not in seen, 'net_proof_unique_period', **context)
        seen.add((period, net_key))
        net = proof.get('net_cell') or {}
        net_source = net.get('source') or {}
        issuer_net = _NITORI_ROU.fullmatch(net_source.get('concept', ''))
        nitori_rou = (str(ds.get('code')) == '9843' and bool(proof.get('disclosed_net'))
                      and issuer_net is not None and issuer_net.group(1) == 'RightOfUseAssetsNetPPE'
                      and '_E03144-000_' in net_source.get('filename', '')
                      and not net_source.get('semantic_concept'))
        inputs = proof.get('original_inputs') or []
        selected = proof.get('selected_component_keys') or []
        by_key = {item.get('source_key'): item for item in inputs}
        check(bool(inputs) and len(inputs) == len(by_key), 'net_original_inputs_unique', **context)
        check(len(selected) >= 2 and len(selected) == len(set(selected)) and all(key in by_key for key in selected),
              'net_selected_components_unique', selected=selected, **context)
        if not inputs or not selected or not all(key in by_key for key in selected):
            continue
        target = addresses.get(net_key, {}).get(period)
        check(bool(target) and target.get('sheet') == sheet, 'net_visible_address_exists', **context)
        if not target or target.get('sheet') != sheet:
            continue
        address = target['address']
        display_cell = formulas[sheet][address]
        value = cached[sheet][address].value
        check(display_cell.data_type != 'f', 'net_visible_is_disclosed_or_derived_literal', address=address, **context)
        check('純額' not in str(formulas[sheet].cell(display_cell.row, 1).value),
              'net_display_label_without_suffix', address=address, **context)
        check(bool(proof.get('nil_preserved')) == (bool(net.get('nil')) or net.get('value') is None),
              'net_nil_flag_preserved', **context)
        scope = None
        standards = []
        for key, item in by_key.items():
            cell = item.get('original_cell') or {}
            original(cell, period, item.get('source_role'))
            source = cell.get('source') or {}
            cls = _class(source, nitori_rou=nitori_rou)
            key_scope = _key_scope(key)
            section = cell.get('source_section')
            check(cls is not None and cls[-1] == item.get('source_role'), 'net_standard_asset_role',
                  source_key=key, role=item.get('source_role'), **context)
            check(key_scope is not None and section is not None and
                  any('有形固定資産' in part or '無形固定資産' in part or '無形資産' in part for part in section),
                  'net_explicit_asset_scope', source_key=key, **context)
            if cls:
                standards.append(cls)
            current_scope = (source.get('doc_id'), source.get('filename'), source.get('context_id'),
                             source.get('unit'), source.get('basis'), tuple(section or []), key_scope,
                             cls[:3] if cls else None)
            check(scope is None or current_scope == scope, 'net_components_same_original_scope', source_key=key, **context)
            scope = current_scope if scope is None else scope
            check(item.get('period') == period and item.get('net_key') == net_key and
                  fingerprint(item.get('display_cell') or {}) == fingerprint(net),
                  'net_alias_proof_matches_target', source_key=key, **context)
            alias = addresses.get(key, {}).get(period) or {}
            check(alias.get('net_display') is True and alias.get('sheet') == sheet and alias.get('address') == address and
                  alias.get('net_source_role') == item.get('source_role') and
                  str(alias.get('original_value_jpy')) == str(cell.get('value')) and
                  str(alias.get('display_value_jpy')) == str(net.get('value')) and
                  fingerprint(alias.get('original_cell') or {}) == fingerprint(cell),
                  'net_source_address_alias_proof', source_key=key, address=address, **context)
            ident = source_identity(source)
            duplicates = [entry['address'] for entry in entries
                          if entry.get('period') == period and entry.get('address') != address
                          and entry.get('source') and source_identity(entry['source'].get('source', {})) == ident]
            check(not duplicates, 'net_gross_contra_not_separately_emitted', source_key=key, duplicates=duplicates, **context)
        selected_cells = [by_key[key]['original_cell'] for key in selected]
        selected_roles = [by_key[key]['source_role'] for key in selected]
        combined = [role for role in selected_roles if 'AndImpairmentLoss' in role]
        check(selected_roles[0] == 'gross' and selected_roles.count('gross') == 1 and
              all(role in _CONTRA for role in selected_roles[1:]) and
              (not combined or len(selected_roles) == 2 and len(combined) == 1),
              'net_contra_members_selected_once', roles=selected_roles, **context)
        # Every gross/contra is retained in the audit, but a combined contra
        # excludes its redundant detailed contra components from arithmetic.
        all_roles = [item.get('source_role') for item in inputs]
        required = [key for key, item in by_key.items() if item.get('source_role') == 'gross']
        all_combined = [key for key, item in by_key.items() if 'AndImpairmentLoss' in item.get('source_role', '')]
        required += all_combined if all_combined else [key for key, item in by_key.items() if item.get('source_role') in _CONTRA]
        check(set(selected) == set(required) and len(all_combined) <= 1,
              'net_selected_components_exhaustive', selected=selected, required=required, **context)
        known = all(_numeric(cell.get('value')) is not None and not cell.get('nil') for cell in selected_cells)
        calculated = None
        if known:
            calculated = _numeric(selected_cells[0]['value']) - sum((abs(_numeric(cell['value'])) for cell in selected_cells[1:]), Decimal(0))
        net_value = _numeric(net.get('value'))
        net_source = net.get('source', {})
        net_scope = (net_source.get('doc_id'), net_source.get('filename'), net_source.get('context_id'),
                     net_source.get('unit'), net_source.get('basis'), tuple(net.get('source_section') or []),
                     _key_scope(net_key))
        check(scope is not None and net_scope == scope[:7] and net_source.get('unit') == 'JPY',
              'net_target_same_original_scope', **context)
        if proof.get('disclosed_net'):
            original(net, period, 'net')
            net_class = _class(net.get('source', {}), nitori_rou=nitori_rou)
            check(net_class is not None and net_class[-1] == 'net' and
                  (not standards or net_class[:3] == standards[0][:3]), 'net_disclosed_standard_identity', **context)
            if known and net_value is not None and not net.get('nil'):
                tolerance = max(Decimal(1), sum((_rounding(cell) for cell in [net] + selected_cells), Decimal(0)))
                check(abs(net_value - calculated) <= tolerance, 'net_disclosed_matches_original_components',
                      disclosed=str(net_value), calculated=str(calculated), tolerance=str(tolerance), **context)
        else:
            check(net.get('operation') == 'asset_net' and
                  net.get('source', {}).get('concept') == '{urn:zaimu10:calculation}NetAsset' and
                  not net.get('source', {}).get('semantic_concept'), 'net_derived_marked_calculation', **context)
            check(known and not net.get('nil') and net_value is not None and net_value == calculated,
                  'net_derived_original_arithmetic', calculated=str(calculated), actual=str(net_value), **context)
            check(net.get('component_keys') == selected and
                  [fingerprint(cell) for cell in net.get('components', [])] == [fingerprint(cell) for cell in selected_cells],
                  'net_derived_components_match_originals', **context)
        expected = net_value / factor if net_value is not None and not net.get('nil') else None
        check(equal(value, expected), 'net_literal_cache_matches_original_amount', address=address,
              actual=str(value), expected=str(expected), **context)
        counts['net_groups_independently_reviewed'] += 1
