"""Acquisition, conservative merging, audit trails, and export orchestration."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path
from copy import deepcopy
import json
import os
import re
import tempfile
import threading
from typing import Callable

from .models import Dataset, Filing, Period, Row, Cell, SHEETS

class AcquisitionError(RuntimeError):
    """No complete, verified result is available; never report success."""

@dataclass
class Options:
    code: str
    output_dir: Path
    cache_dir: Path = Path('.cache/zaimu10')
    years: int = 10
    basis: str = 'auto'
    unit: str = 'thousand'
    until: date | None = None
    offline: bool = False
    refresh: bool = False
    allow_partial: bool = False

@dataclass
class Result:
    dataset: Dataset
    workbook: Path
    audit: Path


def validate_code(code: str) -> str:
    # JPX's alphanumeric securities codes were introduced in 2024.
    import unicodedata
    code = unicodedata.normalize('NFKC', str(code)).strip().upper()
    if not re.fullmatch(r'[0-9][0-9A-Z]{3}', code):
        raise ValueError('銘柄コードは4桁の数字・英字で入力してください（例：6947、285A）。')
    return code


def check_cancel(cancel: threading.Event | None) -> None:
    if cancel is not None and cancel.is_set():
        raise InterruptedError('処理を中止しました。取得済みキャッシュは次回再利用できます。')


def merge_datasets(datasets: list[Dataset], periods: list[Period], *, code: str,
                   basis: str, period_bases: dict[str, str] | None = None,
                   period_standards: dict[str, str] | None = None) -> Dataset:
    """Latest filing first: later comparative restatements replace older facts.

    Missing items in a newer report do NOT overwrite a fact disclosed in its
    original year's report. Every resulting cell retains the selected filing.
    Identity is produced by the parser; labels never participate in matching.
    """
    if not datasets:
        raise AcquisitionError('結合できる財務諸表がありません。')
    wanted = {p.key for p in periods}
    result = Dataset(code, datasets[0].company, basis, sorted(periods),
                     fetched_at=datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds'))
    result.period_bases = period_bases or {p.key: basis for p in periods}
    result.period_standards = period_standards or {p.key: datasets[0].accounting_standard for p in periods}
    standards = set(result.period_standards.values())
    result.accounting_standard = next(iter(standards)) if len(standards) == 1 else 'mixed'
    for ds in datasets:
        if validate_code(ds.code) != validate_code(code):
            raise AcquisitionError('異なる企業のデータが混在するため出力を中止しました。')
        if ds.basis != basis and basis != 'mixed':
            raise AcquisitionError('連結と個別が混在するため出力を中止しました。')
        result.warnings.extend(ds.warnings)
        result.source_notes.extend(ds.source_notes)
        for statement in SHEETS:
            output = result.rows[statement]
            index = {r.key: r for r in output}
            previous: str | None = None
            for original in ds.rows[statement]:
                cells = {k: v for k, v in original.values.items() if k in wanted
                         and result.period_bases.get(k, ds.basis) == ds.basis
                         and result.period_standards.get(k, ds.accounting_standard) == ds.accounting_standard}
                # Don't keep an old heading unless its adjacent data is retained.
                if not cells and not original.is_heading:
                    continue
                if original.key in index:
                    target = index[original.key]
                    # A late amendment to an old year can supply newer numeric
                    # evidence without making its historical label the latest
                    # fiscal year's display name.
                    candidate_label_period = max(cells, default=original.label_period)
                    if cells and candidate_label_period > target.label_period:
                        target.label = original.label
                        target.label_period = candidate_label_period
                    for key, cell in cells.items():
                        if key not in target.values:
                            target.values[key] = deepcopy(cell)
                else:
                    target = deepcopy(original)
                    target.values = deepcopy(cells)
                    if cells:
                        target.label_period = max(cells)
                    if previous is None:
                        # A new old-only row belongs before the first known row.
                        next_key = next((r.key for r in ds.rows[statement]
                                         if r.key in index), None)
                        pos = next((i for i, r in enumerate(output)
                                    if r.key == next_key), len(output))
                    else:
                        pos = next((i+1 for i, r in enumerate(output)
                                    if r.key == previous), len(output))
                    output.insert(pos, target)
                    index[target.key] = target
                previous = original.key
    result.warnings = list(dict.fromkeys(result.warnings))
    result.source_notes = list(dict.fromkeys(result.source_notes))
    # Remove headings whose section has no data after it before the next heading.
    for statement in SHEETS:
        rows = result.rows[statement]
        kept: list[Row] = []
        for i, row in enumerate(rows):
            if row.is_heading:
                content = []
                for following in rows[i+1:]:
                    if following.is_heading and following.indent <= row.indent:
                        break
                    content.append(following)
                if not any(not r.is_heading and r.values for r in content):
                    continue
            kept.append(row)
        result.rows[statement] = kept
    return result


def _concept_local(cell: Cell) -> str:
    return cell.source.concept.rsplit('}', 1)[-1].rsplit(':', 1)[-1]


def _standard_concept(cell: Cell) -> bool:
    return bool(re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp)/\d{4}-\d{2}-\d{2}/\1_cor\}.+',cell.source.concept))


def _find_total(ds: Dataset, statement: str, period: Period, names: set[str]) -> Cell | None:
    candidates = [r.values[period.key] for r in ds.rows[statement]
                  if period.key in r.values and _concept_local(r.values[period.key]) in names
                  and _standard_concept(r.values[period.key])
                  and r.values[period.key].value is not None]
    vals = {c.value for c in candidates}
    return candidates[0] if candidates and len(vals) == 1 else None


def _rounding_tolerance(*cells: Cell) -> Decimal:
    tolerance = Decimal(0)
    for cell in cells:
        try:
            d = int(cell.source.decimals)
        except (ValueError, TypeError):
            continue
        tolerance += Decimal(10) ** -d
    return max(tolerance, Decimal(1))


def cash_flow_checks(dataset: Dataset, period: Period) -> list[dict]:
    """Check disclosed CF roll-forwards only when every component is explicit.

    Unknown bridge adjustments cause an unverified result rather than a guessed
    zero or a reconstructed total. Rounding precision comes from each fact.
    """
    rows = dataset.rows['CF']
    def locate(names: set[str], role: str | None = None):
        found = []
        for i, row in enumerate(rows):
            cell = row.values.get(period.key)
            if cell is None or cell.value is None or cell.source.unit != 'JPY' or not _standard_concept(cell):
                continue
            if _concept_local(cell) not in names:
                continue
            if role is not None:
                try:
                    if json.loads(row.key)[3] != role:
                        continue
                except (ValueError, IndexError, TypeError):
                    continue
            found.append((i, cell))
        return found[0] if len(found) == 1 else None
    operations = locate({'NetCashProvidedByUsedInOperatingActivities', 'NetCashProvidedByUsedInOperatingActivitiesIFRS'})
    investment = locate({'NetCashProvidedByUsedInInvestmentActivities', 'NetCashProvidedByUsedInInvestingActivitiesIFRS'})
    finance = locate({'NetCashProvidedByUsedInFinancingActivities', 'NetCashProvidedByUsedInFinancingActivitiesIFRS'})
    fx = locate({'EffectOfExchangeRateChangeOnCashAndCashEquivalents', 'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS'})
    increase = locate({'NetIncreaseDecreaseInCashAndCashEquivalents', 'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS'})
    beginning = locate({'CashAndCashEquivalents', 'CashAndCashEquivalentsIFRS'}, 'begin')
    ending = locate({'CashAndCashEquivalents', 'CashAndCashEquivalentsIFRS'}, 'end')
    def extra_between(first: int, last: int, allowed: set[int]) -> bool:
        if first > last:
            return True
        return any(i not in allowed and period.key in row.values
                   and row.values[period.key].value is not None
                   for i, row in enumerate(rows) if first <= i <= last)
    def check(name: str, found: list, difference: Decimal | None, safe: bool) -> dict:
        result = {'check': name, 'period': period.key, 'ok': None}
        if safe and all(found) and difference is not None:
            tolerance = _rounding_tolerance(*(item[1] for item in found))
            result.update(ok=abs(difference) <= tolerance, difference_jpy=str(difference),
                          rounding_tolerance_jpy=str(tolerance))
        else:
            result['reason'] = '明示された標準項目が不足、または追加調整項目があり、自動照合を省略。'
        return result
    flows = [operations, investment, finance, fx, increase]
    flows_safe = bool(all(flows))
    flows_diff = None
    if flows_safe:
        total_position = max(item[0] for item in flows[:3])
        flows_safe = not extra_between(total_position, increase[0], {item[0] for item in flows})
        flows_diff = sum((item[1].value for item in flows[:4]), Decimal(0)) - increase[1].value
    bridge = [beginning, increase, ending]
    bridge_safe = bool(all(bridge))
    bridge_diff = None
    if bridge_safe:
        bridge_safe = not extra_between(increase[0], ending[0], {item[0] for item in bridge})
        bridge_diff = ending[1].value - beginning[1].value - increase[1].value
    return [check('cash_flow_components', flows, flows_diff, flows_safe),
            check('cash_balance_rollforward', bridge, bridge_diff, bridge_safe)]


def verify_dataset(dataset: Dataset, requested_years: int) -> list[dict]:
    checks: list[dict] = []
    checks.append({'check': 'period_count', 'ok': len(dataset.periods) == requested_years,
                   'actual': len(dataset.periods), 'expected': requested_years})
    for period in dataset.periods:
        for statement in SHEETS:
            counts = sum(1 for r in dataset.rows[statement] if period.key in r.values
                         and r.values[period.key].value is not None)
            checks.append({'check': 'statement_coverage', 'period': period.key,
                           'statement': statement, 'ok': counts > 0, 'numeric_facts': counts})
        assets = _find_total(dataset, 'BS_A', period, {'Assets', 'TotalAssetsIFRS', 'AssetsIFRS'})
        le = _find_total(dataset, 'BS_LE', period,
                         {'LiabilitiesAndNetAssets', 'TotalLiabilitiesAndEquityIFRS', 'LiabilitiesAndEquityIFRS'})
        if assets is not None and le is not None:
            diff = assets.value - le.value
            tolerance = _rounding_tolerance(assets, le)
            checks.append({'check': 'balance_sheet_equation', 'period': period.key,
                           'ok': abs(diff) <= tolerance,
                           'difference_jpy': str(diff), 'rounding_tolerance_jpy': str(tolerance)})
        else:
            checks.append({'check': 'balance_sheet_equation', 'period': period.key,
                           'ok': None, 'reason': '照合可能な標準タクソノミの両側合計がありません。'})
        checks.extend(cash_flow_checks(dataset, period))
    ends = sorted(dataset.periods, key=lambda p: p.end)
    for before, after in zip(ends, ends[1:]):
        checks.append({'check': 'consecutive_periods', 'before': before.key,
                       'after': after.key, 'ok': after.start == before.end + timedelta(days=1)})
    dataset.checks = checks
    return checks


def _serialize(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime, Path)):
        return str(value)
    raise TypeError(type(value).__name__)


def _atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,
                                         suffix='.tmp',delete=False) as stream:
            tmp = Path(stream.name)
            json.dump(obj,stream,ensure_ascii=False,indent=2,default=_serialize)
            stream.write('\n')
        os.replace(tmp,path)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def save_audit(dataset: Dataset, path: Path, options: Options) -> None:
    _atomic_json(path, {'format_version': 1, 'application': 'Zaimu10',
        'options': asdict(options), 'dataset': asdict(dataset),
        'identity_policy': '既知の標準タクソノミは版の日付のみを除いた同一語彙・同一要素。企業拡張は完全な名前空間URIと要素名。文字列の類似や日本語名では統合しない。',
        'selection_policy': '新しい提出書類の開示値を優先し、比較情報にある遡及修正も採用。欠落項目は古い開示値を保持。各セルの出典を確認可能。'})


def run(options: Options, log: Callable[[str], None] = print,
        cancel: threading.Event | None = None) -> Result:
    from .discovery import discover_filings
    from .edinet import fetch_filing
    from .parser import parse_filing
    from .excel import export_workbook
    from .amendment import inspect_amendment

    options.code = validate_code(options.code)
    if not 1 <= options.years <= 10:
        raise ValueError('取得する期数は1～10で指定してください。')
    if options.basis not in {'auto', 'consolidated', 'standalone'}:
        raise ValueError('連結区分が不正です。')
    options.output_dir = Path(options.output_dir).expanduser().resolve()
    options.cache_dir = Path(options.cache_dir).expanduser().resolve()
    check_cancel(cancel)
    log(f'{options.code}：EDINET公式の提出書類を検索しています。')
    filings = discover_filings(options.code, cache_dir=options.cache_dir,
                               years=10, log=log, cancel=cancel, offline=options.offline)
    filings = [f for f in filings if f.end is not None and
               (options.until is None or f.end <= options.until)]
    if not filings:
        raise AcquisitionError('対象の有価証券報告書がありません。銘柄コード・対象期・公開期間を確認してください。')
    primary = [f for f in filings if not f.amended]
    current_periods = sorted({Period(f.start, f.end) for f in primary if f.start and f.end},reverse=True)
    selected = current_periods[:options.years]
    if not selected:
        raise AcquisitionError('対象の会計期間を特定できません。')
    wanted = {p.key for p in selected}
    # Restrict the source filings to the selected fiscal horizon. Comparatives
    # inside that horizon can provide restated values for the preceding period.
    min_end, max_end = min(p.end for p in selected), max(p.end for p in selected)
    selected_filings = [f for f in filings if f.end and min_end <= f.end <= max_end]
    selected_filings.sort(key=lambda f: (f.submitted, f.doc_id), reverse=True)
    datasets: list[Dataset] = []
    errors: list[str] = []
    amendment_decisions: list[dict] = []
    source_notes: list[str] = []
    resolved_basis = options.basis
    for i, filing in enumerate(selected_filings):
        check_cancel(cancel)
        log(f'[{i+1}/{len(selected_filings)}] {filing.end} {filing.doc_id}：原文を取得・解析しています。')
        try:
            pages = fetch_filing(filing.doc_id, cache_dir=options.cache_dir,
                                 log=log, cancel=cancel, offline=options.offline,
                                 refresh=options.refresh)
            if filing.amended:
                decision = inspect_amendment(pages)
                decision.update(check='amendment_scope', doc_id=filing.doc_id,
                                period=f'{filing.start}/{filing.end}', ok=None)
                amendment_decisions.append(decision)
                if decision['status'] in {'nonfinancial_only', 'unchanged_financial_values'}:
                    decision['ok'] = True
                    note = f"{filing.doc_id}（{filing.submitted}提出の訂正報告書）：{decision['reason']}"
                    source_notes.append(note)
                    log('訂正報告書の照合：' + note)
                    continue
            dataset = parse_filing(filing, pages, basis=options.basis)
            if filing.amended:
                decision.update(ok=True, handled='原文XBRLとして解析し、新しい提出書類の値を優先。')
            datasets.append(dataset)
        except InterruptedError:
            raise
        except Exception as exc:
            error = f'{filing.doc_id}（{filing.end}）: {exc}'
            log('取得・解析エラー：' + error)
            errors.append(error)
    check_cancel(cancel)
    if not datasets:
        raise AcquisitionError('財務諸表を取得できませんでした。\n'+'\n'.join(errors))
    # Auto selects each fiscal period's available primary statements. A company
    # beginning consolidation must not lose its earlier standalone statements.
    # Basis is explicit in column headers and part of each row's identity.
    period_bases: dict[str, str] = {}
    period_standards: dict[str, str] = {}
    for period in selected:
        supporting = [ds for ds in datasets if any(period.key in r.values
                      for records in ds.rows.values() for r in records)]
        complete_support = [ds for ds in supporting if all(any(period.key in r.values
                            and r.values[period.key].value is not None
                            for r in ds.rows[s] if not r.is_heading) for s in SHEETS)]
        if options.basis == 'auto':
            complete_support.sort(key=lambda ds: ds.basis != 'consolidated')
            supporting.sort(key=lambda ds: ds.basis != 'consolidated')
        if complete_support:
            period_bases[period.key] = complete_support[0].basis
            period_standards[period.key] = complete_support[0].accounting_standard
        elif supporting:
            period_bases[period.key] = supporting[0].basis
            period_standards[period.key] = supporting[0].accounting_standard
        else:
            period_bases[period.key] = options.basis if options.basis != 'auto' else datasets[0].basis
            period_standards[period.key] = datasets[0].accounting_standard
    distinct_bases = set(period_bases.values())
    resolved_basis = next(iter(distinct_bases)) if len(distinct_bases) == 1 else 'mixed'
    log('取得区分：' + {'consolidated': '連結', 'standalone': '個別', 'mixed': '年度ごとの連結・個別（Excelの列見出しに明記）'}[resolved_basis])
    merged = merge_datasets(datasets, selected, code=options.code, basis=resolved_basis,
                            period_bases=period_bases, period_standards=period_standards)
    merged.source_notes.extend(source_notes)
    merged.warnings.extend(errors)
    if len(selected) != options.years:
        merged.warnings.append(f'要求{options.years}期に対し取得対象は{len(selected)}期です。上場・設立・公開期間を確認してください。')
    checks = verify_dataset(merged, options.years)
    checks.extend(amendment_decisions)
    failures = [c for c in checks if c['ok'] is False]
    for failure in failures:
        kind = failure['check']
        if kind == 'statement_coverage':
            message = f"{failure['period']}：{SHEETS[failure['statement']]}の数値がありません。"
        elif kind == 'balance_sheet_equation':
            message = f"{failure['period']}：BS左右合計が許容丸め差を超えて不一致（差額{failure['difference_jpy']}円）。"
        elif kind == 'consecutive_periods':
            message = f"会計期間が連続していません：{failure['before']} → {failure['after']}。"
        elif kind in {'cash_flow_components', 'cash_balance_rollforward'}:
            message = f"{failure['period']}：キャッシュフローの増減照合が許容丸め差を超えて不一致（{failure['check']}、差額{failure['difference_jpy']}円）。"
        else:
            message = f"要求{failure.get('expected')}期に対し対象は{failure.get('actual')}期です。"
        if message not in merged.warnings:
            merged.warnings.append(message)
    # A parser warning indicates possible omission or ambiguous facts, so require
    # explicit partial-output option rather than calling this a complete export.
    incomplete = bool(failures or errors or merged.warnings)
    safe_company = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', merged.company).strip(' .')[:70] or options.code
    period_span = f'{min(p.end for p in selected):%Y%m}-{max(p.end for p in selected):%Y%m}'
    basename = f'{options.code}_{safe_company}_{period_span}' + ('_要確認' if incomplete else '')
    options.output_dir.mkdir(parents=True,exist_ok=True)
    # Users may edit the exported workbook by hand. A repeated download must
    # preserve that work, and keep its original matching audit alongside it.
    original_basename = basename
    counter = 2
    while any((options.output_dir / (basename + suffix)).exists() for suffix in ('.xlsx', '.audit.json')):
        basename = f'{original_basename}_{counter}'
        counter += 1
    audit = options.output_dir / (basename + '.audit.json')
    save_audit(merged, audit, options)
    if incomplete and not options.allow_partial:
        raise AcquisitionError('完全な結果として出力できない項目があります。Excel出力を停止し、監査結果を保存しました。\n'
                               f'{audit}\n'+'\n'.join(merged.warnings[:8])+
                               ('\n検証NG: '+str(failures[:3]) if failures else '')+
                               '\n内容を確認して部分出力を明示的に許可すると、要確認と表示したExcelを作成できます。')
    check_cancel(cancel)
    workbook = options.output_dir / (basename + '.xlsx')
    export_workbook(merged,workbook,unit=options.unit)
    log(f'完了：{len(selected)}期・4シート。Excel：{workbook.name}')
    return Result(merged,workbook,audit)
