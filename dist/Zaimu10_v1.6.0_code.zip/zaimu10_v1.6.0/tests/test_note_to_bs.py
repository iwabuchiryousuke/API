"""Real filing and hostile controls for moving debt notes into the BS."""
from copy import deepcopy
from decimal import Decimal
import gzip
import json
from pathlib import Path

from zaimu10.excel import _bs_source_plans, _present
from zaimu10.excel import export_workbook
from openpyxl import load_workbook
from zaimu10.models import Filing
from zaimu10.note_to_bs import project_debt_notes
from zaimu10.parser import parse_filing
from zaimu10.debt_notes import extract_debt_notes
from zaimu10.presentation import annotate_filing, prepare_dataset


def zuken():
    pages=json.load(gzip.open(Path(__file__).parent/'fixtures'/'zuken_2025_ixbrl.json.gz','rt',encoding='utf8'))
    ds=annotate_filing(parse_filing(Filing('S100W07I',code='6947',submitted='2025-06-20'),pages))
    ds.analysis_inputs=extract_debt_notes(pages,ds)
    return prepare_dataset(ds)


def run_projection(ds):
    rows=[r for r in ds.rows['BS_LE'] if not r.is_heading and _present(r)]
    plans,coverage=_bs_source_plans(rows,ds.periods)
    return project_debt_notes(ds,rows,plans,coverage)


def local(row):
    return next(iter(row.values.values())).source.account_concept.rsplit('}',1)[-1]


def test_actual_lease_current_and_noncurrent_are_not_both_moved_to_current():
    ds=zuken();before=deepcopy(ds)
    out=run_projection(ds)
    assert ds==before
    assert not out.memoranda
    assert len(out.adjustments)==4
    current=next(r for r in out.rows if ':current_lease:' in r.key)
    noncurrent=next(r for r in out.rows if ':noncurrent_lease:' in r.key)
    for period in sorted(ds.periods):
        expected=(Decimal(38185000),Decimal(60313000)) if period.end.year==2024 else (Decimal(56239000),Decimal(59539000))
        assert (current.values[period.key].value,noncurrent.values[period.key].value)==expected
        for row,scope in [(current,'CurrentLiabilities'),(noncurrent,'NoncurrentLiabilities')]:
            parent=next(i for i,r in enumerate(out.rows) if local(r)==scope)
            assert out.rows.index(row) in out.plans[period.key][parent]
        for adjustment in [a for a in out.adjustments if a['period']==period.key]:
            assert Decimal(adjustment['original_value_jpy'])==Decimal(adjustment['residual_value_jpy'])+sum(map(Decimal,adjustment['note_values_jpy']))


def test_borrowing_amount_below_other_does_not_prove_wrong_document_containment():
    ds=zuken()
    for row in ds.analysis_inputs:
        if ':current_lease:' in row.key:
            for cell in row.values.values():cell.source.doc_id='S100DIFFERENT'
    out=run_projection(ds)
    assert len(out.memoranda)==1
    assert ':current_lease:' in out.memoranda[0].key
    assert all(':current_lease:' not in key for a in out.adjustments for key in a['note_keys'])
    for memo in out.memoranda:
        assert '再加算しません' in next(iter(memo.values.values())).note


def test_no_negative_other_residual_even_when_primary_totals_reconcile():
    ds=zuken()
    for period in ds.periods:
        host=next(r for r in ds.rows['BS_LE'] if r.values and local(r)=='OtherCL')
        reduction=host.values[period.key].value-Decimal(1)
        host.values[period.key].value=Decimal(1)
        for row in ds.rows['BS_LE']:
            if row.values and local(row) in {'CurrentLiabilities','Liabilities','LiabilitiesAndNetAssets'}:
                row.values[period.key].value-=reduction
    out=run_projection(ds)
    assert any(':current_lease:' in row.key for row in out.memoranda)
    assert all(Decimal(a['residual_value_jpy'])>=0 for a in out.adjustments)
    unchanged=next(r for r in out.rows if r.values and local(r)=='OtherCL')
    assert all(c.value==1 for c in unchanged.values.values())


def test_nonreconciling_primary_decomposition_does_not_allocate_to_other():
    ds=zuken()
    for row in ds.rows['BS_LE']:
        if row.values and local(row)=='CurrentLiabilities':
            for cell in row.values.values():cell.value+=Decimal(1000000000)
    out=run_projection(ds)
    assert any(':current_lease:' in row.key for row in out.memoranda)
    assert all(':current_lease:' not in key for a in out.adjustments for key in a['note_keys'])


def test_zero_only_note_categories_are_not_visible_fake_debt_lines():
    out=run_projection(zuken())
    assert out.omitted_zero
    assert not any(':bonds:' in row.key for row in out.rows+out.memoranda)
    assert all('bonds' in key or 'borrowings' in key for key in out.omitted_zero)


def test_unclassified_payable_prevents_false_unique_other_inference():
    ds=zuken()
    # A payable caption of unknown composition is another possible container.
    # The same amounts and perfectly reconciling subtotal cannot identify it.
    for row in ds.rows['BS_LE']:
        if row.values and local(row)=='AccountsPayableTrade':
            for cell in row.values.values():
                cell.source.concept=cell.source.concept.replace('AccountsPayableTrade','AccountsPayableOther')
    out=run_projection(ds)
    assert any(':current_lease:' in row.key for row in out.memoranda)
    assert all(':current_lease:' not in key for a in out.adjustments for key in a['note_keys'])


def test_actual_dawn_explicit_zero_survives_omission_of_zero_only_upper_rows(tmp_path):
    folder=Path(__file__).parent/'fixtures'
    pages=json.load(gzip.open(folder/'dawn_2026_ixbrl.json.gz','rt',encoding='utf8'))
    notes=json.load(gzip.open(folder/'dawn_2026_debt_notes.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100YXLE',code='2303',edinet_code='E05289'),pages)
    ds.analysis_inputs=extract_debt_notes(notes,ds)
    latest=max(ds.periods);path=export_workbook(ds,tmp_path/'dawn-zero.xlsx','thousand')
    wb=load_workbook(path);cache=load_workbook(path,data_only=True)
    layout=ds.export_metadata['layout']['BS-le']
    debt=next(row for row in layout['analysis_rows'] if row['metric']=='interest_bearing_debt')
    col=sorted(ds.periods).index(latest)+2
    assert cache['BS-le'].cell(debt['row'],col).value==0
    assert wb['BS-le'].cell(debt['row'],col).data_type=='n'
    assert debt['periods'][latest.key]['mode']=='proven_zero'
    assert layout['debt_presentation']['omitted_zero_notes']
    assert not any('計算補助' in str(r[0].value) for r in wb['BS-le'])
    assert not any(n['row_key'].startswith('presentation:debt') for n in layout['nodes'])
    wb.close();cache.close()
