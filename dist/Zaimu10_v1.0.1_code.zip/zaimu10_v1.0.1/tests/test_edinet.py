from __future__ import annotations

import hashlib
import json
import threading
from pathlib import Path

import pytest

from zaimu10 import edinet


def test_cache_roundtrip_preserves_original_xml_and_hashes(tmp_path):
    pages = [('0000000_header.htm', '<html xmlns:ix="urn:x">日本語</html>'),
             ('statements.htm', '<ix:nonFraction name="jppfs_cor:Assets">123</ix:nonFraction>')]
    directory = tmp_path / 'filings' / 'S100W07I'
    edinet._cache_write(directory, 'S100W07I', pages)
    assert edinet.fetch_filing('S100W07I', cache_dir=tmp_path, offline=True, log=lambda _: None) == pages
    manifest = json.loads((directory / 'manifest.json').read_text())
    assert manifest['files'][1]['sha256'] == hashlib.sha256(pages[1][1].encode()).hexdigest()
    assert 'GX_AJAX' not in json.dumps(manifest)


def test_cache_tampering_is_rejected_offline(tmp_path):
    directory = tmp_path / 'filings' / 'S100W07I'
    edinet._cache_write(directory, 'S100W07I', [('a.htm', '<html>123</html>')])
    manifest = json.loads((directory / 'manifest.json').read_text())
    (directory / manifest['files'][0]['path']).write_text('<html>999</html>')
    with pytest.raises(edinet.FetchError, match='キャッシュ'):
        edinet.fetch_filing('S100W07I', cache_dir=tmp_path, offline=True, log=lambda _: None)


def test_cache_cannot_escape_directory(tmp_path):
    directory = tmp_path / 'filings' / 'S100W07I'
    edinet._cache_write(directory, 'S100W07I', [('a.htm', '<html>123</html>')])
    manifest = json.loads((directory / 'manifest.json').read_text())
    manifest['files'][0]['path'] = '../../secret.txt'
    (directory / 'manifest.json').write_text(json.dumps(manifest))
    assert edinet._cache_read(directory, 'S100W07I') is None


def test_cancellation_before_network(tmp_path):
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(edinet.CancelledError):
        edinet.fetch_filing('S100W07I', cache_dir=tmp_path, cancel=cancel)


@pytest.mark.parametrize('doc_id', ['../bad', 'S100W07I?other', '6947', 's100w07i'])
def test_invalid_document_id(tmp_path, doc_id):
    with pytest.raises(edinet.FetchError, match='形式'):
        edinet.fetch_filing(doc_id, cache_dir=tmp_path, offline=True)


def test_statement_targets_deduplicate_same_chapter_and_exclude_narrative():
    links = [('0102010.htm#A', '事業の状況'), ('0105010.htm#BS', '連結貸借対照表'),
             ('0105010.htm#PL', '連結損益計算書'), ('0105010.htm#CF', '連結キャッシュ・フロー計算書'),
             ('0105020.htm#BS', '貸借対照表')]
    assert edinet._financial_targets(links) == ['0105010.htm#BS', '0105020.htm#BS']


def test_toc_rejects_remote_or_parent_path_targets():
    toc = '''<a href="javascript:linkclicknew('https://other.example/a.htm')">損益計算書</a>
    <a href="javascript:linkclicknew('../secret.htm')">貸借対照表</a>
    <a href="javascript:linkclicknew('0105010.htm#A')">連結貸借対照表</a>'''
    assert edinet._toc_links(toc) == [('0105010.htm#A', '連結貸借対照表')]


def test_retry_after_and_success(monkeypatch):
    monkeypatch.setattr(edinet, '_MIN_INTERVAL', 0)
    delays = []
    monkeypatch.setattr(edinet, '_pause', lambda seconds, cancel: delays.append(seconds))
    class Response:
        def __init__(self, status, headers=None):
            self.status_code = status
            self.headers = headers or {}
    class Session:
        def __init__(self): self.responses = iter([Response(429, {'Retry-After': '5'}), Response(200)])
        def request(self, *args, **kwargs): return next(self.responses)
    result = edinet._request(Session(), 'GET', edinet.VIEWER, log=lambda _: None, cancel=None)
    assert result.status_code == 200
    assert 5 in delays


def test_retry_limit_reports_status(monkeypatch):
    monkeypatch.setattr(edinet, '_MIN_INTERVAL', 0)
    monkeypatch.setattr(edinet, '_pause', lambda *_: None)
    class Session:
        calls = 0
        def request(self, *args, **kwargs):
            self.calls += 1
            return type('Response', (), {'status_code': 503, 'headers': {}})()
    session = Session()
    with pytest.raises(edinet.FetchError, match='503'):
        edinet._request(session, 'GET', edinet.VIEWER, log=lambda _: None, cancel=None)
    assert session.calls == 3


def test_official_host_only():
    with pytest.raises(edinet.FetchError, match='ホスト'):
        edinet._request(None, 'GET', 'https://example.net/', log=lambda _: None, cancel=None)


def test_failed_refresh_keeps_previous_complete_cache(tmp_path, monkeypatch):
    directory = tmp_path / 'filings' / 'S100W07I'
    old = [('cover.htm', '<html>old header</html>'), ('statements.htm', '<html>old values</html>')]
    new = [('cover.htm', '<html>new header</html>'), ('statements.htm', '<html>new values</html>')]
    edinet._cache_write(directory, 'S100W07I', old)
    write = edinet._atomic_write
    def fail_manifest(path, raw):
        if path.name == 'manifest.json':
            raise OSError('disk full')
        return write(path, raw)
    monkeypatch.setattr(edinet, '_atomic_write', fail_manifest)
    with pytest.raises(OSError, match='disk full'):
        edinet._cache_write(directory, 'S100W07I', new)
    assert edinet._cache_read(directory, 'S100W07I') == old
