"""Native desktop UI. Network work never runs on the Tk event loop."""
from __future__ import annotations

from datetime import date
from pathlib import Path
import os
import queue
import subprocess
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

from . import __version__
from .discovery import discover_filings, search_companies, display_company_name
from .registry import CompanyRegistry, RegistryError
from .service import Options, Result, run, validate_code

APP_DIR = Path(__file__).resolve().parent.parent
UNIT_OPTIONS = {'自動（取得元の表示単位）': 'auto', '千円': 'thousand', '百万円': 'million', '円': 'yen'}
BASIS_OPTIONS = {'自動（連結を優先）': 'auto', '連結': 'consolidated', '個別': 'standalone'}


def initial_window_size(screen_width: int, screen_height: int) -> tuple[int, int]:
    """Fit ordinary laptop screens while retaining a resizable working area."""
    return max(640, min(screen_width-80, 1040)), max(480, min(screen_height-100, 820))


def calendar_values(record: dict) -> tuple[str, ...]:
    """Display observed fiscal dates; no scheduled announcement is inferred."""
    submitted = str(record.get('latest_submitted') or '')
    return (str(record.get('code') or ''),
            str(record.get('display_name') or display_company_name(record.get('company') or '')),
            str(record.get('fiscal_year_end') or '未取得'),
            str(record.get('latest_period_end') or '未取得'),
            submitted.replace('T', ' ')[:16] if submitted else '未取得',
            str(record.get('announcement_date') or '未確認'))


class App:
    def __init__(self, root: tk.Tk, initial_code: str = '6947', *,
                 data_dir: Path | None = None, cache_dir: Path | None = None):
        self.root = root
        self.root.title(f'Zaimu10 v{__version__} — 財務諸表を10期まとめてExcelへ')
        width, height = initial_window_size(root.winfo_screenwidth(), root.winfo_screenheight())
        self.root.geometry(f'{width}x{height}')
        self.root.minsize(min(860, width), min(620, height))
        self.root.configure(bg='#f5f7fa')
        self.cache_dir = Path(cache_dir) if cache_dir is not None else APP_DIR/'.cache'/'zaimu10'
        self.registry = CompanyRegistry((Path(data_dir) if data_dir is not None else APP_DIR/'data')/'companies.json')
        self.busy = False
        self.closing = False
        self.task_kind = ''
        self.worker: threading.Thread | None = None
        self.cancel_event = threading.Event()
        self.events: queue.Queue = queue.Queue()
        self.result: Result | None = None
        self.selected_company: dict | None = None
        self.search_results: dict[str, dict] = {}
        self.registered: dict[str, dict] = {}
        self.pending_search_action = 'show'
        self.loading_company = False
        self.code = tk.StringVar(value=initial_code)
        self.years = tk.IntVar(value=10)
        self.basis = tk.StringVar(value=next(iter(BASIS_OPTIONS)))
        self.unit = tk.StringVar(value=next(iter(UNIT_OPTIONS)))
        self.output = tk.StringVar(value=str(APP_DIR/'results'))
        self.until = tk.StringVar()
        self.partial = tk.BooleanVar(value=False)
        self.offline = tk.BooleanVar(value=False)
        self.show_advanced = tk.BooleanVar(value=False)
        self.selected_text = tk.StringVar(value='銘柄コード、または会社名を入力してください。')
        self.registry_text = tk.StringVar(value='登録した企業の実際の決算期末・提出日を表示します。')
        self.status = tk.StringVar(value='会社を検索するか、銘柄コードを入力して「Excelを作成」を押してください。')
        self._styles()
        self._build()
        self.code.trace_add('write', self._query_changed)
        self._refresh_registry()
        self.root.protocol('WM_DELETE_WINDOW', self._close)
        self.root.after(150, self._poll)

    def _styles(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=('Yu Gothic UI', 10), background='#f5f7fa', foreground='#203047')
        style.configure('TFrame', background='#f5f7fa')
        style.configure('Card.TFrame', background='#ffffff')
        style.configure('Card.TLabel', background='#ffffff')
        style.configure('Title.TLabel', font=('Yu Gothic UI', 21, 'bold'), foreground='#172c48')
        style.configure('Sub.TLabel', foreground='#526276', font=('Yu Gothic UI', 9))
        style.configure('TButton', padding=(12, 7), font=('Yu Gothic UI', 10))
        style.configure('Primary.TButton', background='#174a7b', foreground='white', font=('Yu Gothic UI', 10, 'bold'))
        style.map('Primary.TButton', background=[('active', '#246296'), ('disabled', '#b4c2d0')])
        style.configure('TEntry', padding=5)
        style.configure('TCombobox', padding=5)
        style.configure('TLabelframe', padding=10, background='white')
        style.configure('TLabelframe.Label', background='#f5f7fa', font=('Yu Gothic UI', 10, 'bold'))
        style.configure('TCheckbutton', background='white')
        style.configure('Treeview', background='white', fieldbackground='white', rowheight=27, font=('Yu Gothic UI', 9))
        style.configure('Treeview.Heading', font=('Yu Gothic UI', 9, 'bold'))
        style.configure('TNotebook.Tab', padding=(14, 7))

    @staticmethod
    def _tree(parent, columns, headings, widths, height):
        frame = ttk.Frame(parent)
        tree = ttk.Treeview(frame, columns=columns, show='headings', selectmode='browse', height=height)
        for key, label, width in zip(columns, headings, widths):
            tree.heading(key, text=label)
            tree.column(key, width=width, minwidth=65, stretch=key == 'company')
        scroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.grid(row=0, column=0, sticky='nsew')
        scroll.grid(row=0, column=1, sticky='ns')
        horizontal = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(xscrollcommand=horizontal.set)
        horizontal.grid(row=1, column=0, sticky='ew')
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return frame, tree

    def _build(self):
        main = ttk.Frame(self.root, padding=(22, 16))
        main.pack(fill='both', expand=True)
        ttk.Label(main, text='財務諸表を、10期まとめて。', style='Title.TLabel').pack(anchor='w')
        ttk.Label(main, text='会社名でも検索。損益・資産・負債純資産・キャッシュフローの4シートを作成します。', style='Sub.TLabel').pack(anchor='w', pady=(3, 10))
        # Reserve the footer before the flexible notebook so progress/status
        # remain visible even on a 1366x768 laptop with advanced options open.
        footer = ttk.Frame(main)
        footer.pack(side='bottom', fill='x', pady=(8, 0))
        self.progress = ttk.Progressbar(footer, mode='indeterminate')
        self.progress.pack(fill='x')
        ttk.Label(footer, textvariable=self.status, style='Sub.TLabel', wraplength=950).pack(anchor='w', pady=(5, 0))
        self.notebook = ttk.Notebook(main)
        self.notebook.pack(fill='both', expand=True)
        self.create_tab = ttk.Frame(self.notebook, padding=(12, 10))
        self.registry_tab = ttk.Frame(self.notebook, padding=(12, 12))
        self.notebook.add(self.create_tab, text='Excelを作成')
        self.notebook.add(self.registry_tab, text='登録企業・決算カレンダー')
        self._build_create_tab()
        self._build_registry_tab()
        self.root.bind('<Control-Return>', lambda _: self._start() if not self.busy else None)
        self.code_entry.focus_set()

    def _build_create_tab(self):
        main = self.create_tab
        main.columnconfigure(0, weight=1)
        main.rowconfigure(4, weight=1, minsize=70)
        card = ttk.Frame(main, style='Card.TFrame', padding=12)
        card.grid(row=0, column=0, sticky='ew')
        card.columnconfigure(1, weight=1)
        ttk.Label(card, text='コード・会社名', style='Card.TLabel').grid(row=0, column=0, sticky='w', padx=(0, 10))
        self.code_entry = ttk.Entry(card, textvariable=self.code, font=('Yu Gothic UI', 12))
        self.code_entry.grid(row=0, column=1, sticky='ew')
        self.code_entry.bind('<Return>', lambda _: self._search())
        self.search_button = ttk.Button(card, text='検索', command=self._search)
        self.search_button.grid(row=0, column=2, padx=8)
        self.register_button = ttk.Button(card, text='企業を登録', command=self._register_company)
        self.register_button.grid(row=0, column=3)
        ttk.Label(card, textvariable=self.selected_text, style='Card.TLabel', wraplength=840).grid(row=1, column=0, columnspan=4, sticky='w', pady=(7, 8))
        # Ambiguous matches use their own selection window. A results table
        # embedded above the options would hide logs on small laptop screens.
        self.search_dialog = tk.Toplevel(self.root)
        self.search_dialog.withdraw()
        self.search_dialog.title('検索結果から企業を選択')
        self.search_dialog.transient(self.root)
        self.search_dialog.minsize(620, 300)
        self.search_dialog.geometry(f'{min(900,self.root.winfo_screenwidth()-100)}x{min(470,self.root.winfo_screenheight()-130)}')
        self.search_dialog.protocol('WM_DELETE_WINDOW', self._dismiss_search)
        self.search_dialog.bind('<Escape>', lambda _: self._dismiss_search())
        dialog_main = ttk.Frame(self.search_dialog, padding=16)
        dialog_main.pack(fill='both', expand=True)
        self.search_caption = tk.StringVar(value='対象の企業を選んでください。')
        ttk.Label(dialog_main, textvariable=self.search_caption, wraplength=820).pack(anchor='w', pady=(0, 10))
        self.search_frame, self.search_tree = self._tree(dialog_main,
            ('code', 'company', 'fiscal'), ('銘柄コード', '会社名', '決算日（届出情報）'),
            (95, 480, 180), 10)
        self.search_frame.pack(fill='both', expand=True)
        self.search_tree.bind('<Double-1>', lambda _: self._use_search_result())
        self.search_tree.bind('<Return>', lambda _: self._use_search_result())
        dialog_actions = ttk.Frame(dialog_main)
        dialog_actions.pack(fill='x', pady=(12, 0))
        self.use_search_button = ttk.Button(dialog_actions, text='選択した企業を入力', command=self._use_search_result, style='Primary.TButton')
        self.use_search_button.pack(side='left')
        ttk.Button(dialog_actions, text='閉じる', command=self._dismiss_search).pack(side='right')

        opts = ttk.Frame(main, style='Card.TFrame', padding=10)
        opts.grid(row=1, column=0, sticky='ew', pady=(8, 0))
        opts.columnconfigure(1, weight=1)
        opts.columnconfigure(5, weight=1)
        ttk.Label(opts, text='対象', style='Card.TLabel').grid(row=0, column=0, sticky='w', padx=(0, 8))
        self.basis_box = ttk.Combobox(opts, textvariable=self.basis, values=list(BASIS_OPTIONS), state='readonly', width=21)
        self.basis_box.grid(row=0, column=1, sticky='ew')
        ttk.Label(opts, text='期数', style='Card.TLabel').grid(row=0, column=2, sticky='w', padx=(12, 6))
        self.years_box = ttk.Combobox(opts, textvariable=self.years, values=list(range(1, 11)), width=4, state='readonly')
        self.years_box.grid(row=0, column=3, sticky='w')
        ttk.Label(opts, text='表示単位', style='Card.TLabel').grid(row=0, column=4, sticky='w', padx=(12, 7))
        self.unit_box = ttk.Combobox(opts, textvariable=self.unit, values=list(UNIT_OPTIONS), state='readonly', width=25)
        self.unit_box.grid(row=0, column=5, columnspan=2, sticky='ew')
        ttk.Label(opts, text='出力先', style='Card.TLabel').grid(row=1, column=0, sticky='w', pady=(8, 0))
        self.output_entry = ttk.Entry(opts, textvariable=self.output)
        self.output_entry.grid(row=1, column=1, columnspan=5, sticky='ew', pady=(8, 0))
        self.folder_button = ttk.Button(opts, text='選択…', command=self._choose_folder)
        self.folder_button.grid(row=1, column=6, padx=(8, 0), pady=(8, 0))
        self.advanced_check = ttk.Checkbutton(opts, text='詳細設定', variable=self.show_advanced, command=self._toggle_advanced)
        self.advanced_check.grid(row=2, column=0, columnspan=2, sticky='w', pady=(7, 0))
        ttk.Label(opts, text='自動単位は、取得した決算書の表示に合わせます。', style='Card.TLabel').grid(row=2, column=2, columnspan=5, sticky='e', pady=(7, 0))
        self.advanced_frame = ttk.Frame(opts, style='Card.TFrame')
        self.advanced_frame.grid(row=3, column=0, columnspan=7, sticky='ew', pady=(7, 0))
        ttk.Label(self.advanced_frame, text='最終決算日', style='Card.TLabel').grid(row=0, column=0, sticky='w')
        self.until_entry = ttk.Entry(self.advanced_frame, textvariable=self.until, width=17)
        self.until_entry.grid(row=0, column=1, sticky='w', padx=(8, 10))
        ttk.Label(self.advanced_frame, text='空欄＝最新 ／ 例：2025-03-31', style='Card.TLabel').grid(row=0, column=2, sticky='w')
        self.offline_check = ttk.Checkbutton(self.advanced_frame, text='取得済みデータのみ使用（オフライン）', variable=self.offline)
        self.offline_check.grid(row=1, column=0, columnspan=2, sticky='w', pady=(5, 0))
        self.partial_check = ttk.Checkbutton(self.advanced_frame, text='不足・警告があっても「要確認」で出力', variable=self.partial)
        self.partial_check.grid(row=1, column=2, sticky='w', padx=(12, 0), pady=(5, 0))
        self.advanced_frame.grid_remove()

        actions = ttk.Frame(main)
        actions.grid(row=2, column=0, sticky='ew', pady=(10, 7))
        self.start_button = ttk.Button(actions, text='Excelを作成', style='Primary.TButton', command=self._start)
        self.start_button.pack(side='left')
        self.cancel_button = ttk.Button(actions, text='中止', command=self._cancel, state='disabled')
        self.cancel_button.pack(side='left', padx=8)
        self.open_button = ttk.Button(actions, text='Excelを開く', command=self._open_file, state='disabled')
        self.open_button.pack(side='right')
        self.open_folder_button = ttk.Button(actions, text='出力先を開く', command=self._open_folder)
        self.open_folder_button.pack(side='right', padx=8)
        ttk.Label(main, text='公表値・原項目名を使用。欠落は空白、同一性を確認できない科目は別行に残します。', style='Sub.TLabel').grid(row=3, column=0, sticky='w', pady=(0, 5))
        self.logs = ScrolledText(main, height=4, wrap='word', font=('Yu Gothic UI', 9), bg='white', fg='#28384d', relief='flat', padx=10, pady=7, state='disabled')
        self.logs.grid(row=4, column=0, sticky='nsew')
        self.inputs = [self.code_entry, self.search_button, self.register_button, self.use_search_button,
                       self.years_box, self.basis_box, self.unit_box, self.output_entry,
                       self.folder_button, self.until_entry, self.offline_check, self.partial_check, self.advanced_check]

    def _build_registry_tab(self):
        main = self.registry_tab
        main.columnconfigure(0, weight=1)
        main.rowconfigure(2, weight=1)
        ttk.Label(main, text='登録企業の決算カレンダー', font=('Yu Gothic UI', 15, 'bold')).grid(row=0, column=0, sticky='w')
        ttk.Label(main, text='実際の最新決算期末が新しい順です。決算発表日は確認できた情報だけを表示します。', style='Sub.TLabel', wraplength=900).grid(row=1, column=0, sticky='w', pady=(5, 12))
        frame, self.registry_tree = self._tree(main,
            ('code', 'company', 'fiscal', 'period', 'submitted', 'announcement'),
            ('コード', '会社名', '届出決算日', '最新決算期末 ▼', '原本提出日時', '決算発表日'),
            (75, 235, 95, 130, 150, 110), 10)
        frame.grid(row=2, column=0, sticky='nsew')
        self.registry_tree.bind('<Double-1>', lambda _: self._use_registered())
        self.registry_tree.bind('<Return>', lambda _: self._use_registered())
        actions = ttk.Frame(main)
        actions.grid(row=3, column=0, sticky='ew', pady=(10, 8))
        self.use_registered_button = ttk.Button(actions, text='選択した企業を入力', command=self._use_registered)
        self.use_registered_button.pack(side='left')
        self.calendar_button = ttk.Button(actions, text='選択企業の提出情報を更新', command=self._update_calendar)
        self.calendar_button.pack(side='left', padx=8)
        self.calendar_cancel_button = ttk.Button(actions, text='中止', command=self._cancel, state='disabled')
        self.calendar_cancel_button.pack(side='left')
        self.remove_registered_button = ttk.Button(actions, text='登録を解除', command=self._remove_registered)
        self.remove_registered_button.pack(side='right')
        ttk.Label(main, textvariable=self.registry_text, style='Sub.TLabel', wraplength=900).grid(row=4, column=0, sticky='w', pady=(4, 0))
        ttk.Label(main, text='「届出決算日」はEDINETの月日情報です。最新の決算期末・提出日時は取得結果から更新します。\n未取得の企業は下段に表示し、未確認の決算発表日を推測で埋めません。登録はこのアプリ内に保存します。', style='Sub.TLabel', wraplength=900).grid(row=5, column=0, sticky='w', pady=(10, 0))
        self.inputs.extend([self.use_registered_button, self.calendar_button, self.remove_registered_button])

    def _toggle_advanced(self):
        if self.show_advanced.get():
            self.advanced_frame.grid()
        else:
            self.advanced_frame.grid_remove()

    def _show_search_results(self, count: int):
        if count > 1:
            self.search_caption.set(f'「{self.code.get()}」に一致する企業は{count}件です。対象企業を選んで入力してください。')
            self.search_dialog.deiconify()
            self.search_dialog.lift()
            self.search_dialog.grab_set()
        else:
            if self.search_dialog.grab_current() is self.search_dialog:
                self.search_dialog.grab_release()
            self.search_dialog.withdraw()

    def _dismiss_search(self):
        self.pending_search_action = 'show'
        self._show_search_results(0)
        self.status.set('企業選択を閉じました。検索語を変えて再検索できます。')

    def _query_changed(self, *_):
        if not self.loading_company:
            self.selected_company = None
            self.pending_search_action = 'show'
            self._show_search_results(0)
            self.search_tree.delete(*self.search_tree.get_children())
            self.search_results = {}
            self.selected_text.set('会社名の検索結果が複数ある場合は、対象企業を選んで入力してください。')

    def _set_company(self, company: dict):
        self.loading_company = True
        try:
            self.code.set(company['code'])
        finally:
            self.loading_company = False
        self.selected_company = dict(company)
        self.selected_text.set(f"{company['code']}　{company.get('display_name') or display_company_name(company.get('company',''))}　／　届出決算日：{company.get('fiscal_year_end') or '未取得'}")

    def _choose_folder(self):
        path = filedialog.askdirectory(title='Excelの出力先を選択', initialdir=self.output.get() if Path(self.output.get()).is_dir() else str(APP_DIR))
        if path:
            self.output.set(path)

    def _append(self, text: str):
        self.logs.configure(state='normal')
        self.logs.insert('end', text+'\n')
        self.logs.see('end')
        self.logs.configure(state='disabled')

    def _set_busy(self, busy: bool, task_kind: str = ''):
        self.busy = busy
        self.task_kind = task_kind if busy else ''
        for widget in self.inputs:
            widget.configure(state='disabled' if busy else ('readonly' if isinstance(widget, ttk.Combobox) else 'normal'))
        self.start_button.configure(state='disabled' if busy else 'normal')
        self.cancel_button.configure(state='normal' if busy else 'disabled')
        self.calendar_cancel_button.configure(state='normal' if busy else 'disabled')
        if busy:
            self.open_button.configure(state='disabled')
            self.progress.start(12)
        else:
            self.progress.stop()
            self.open_button.configure(state='normal' if self.result else 'disabled')

    def _worker(self, task_kind: str, call, done_kind: str):
        self.cancel_event.clear()
        self._set_busy(True, task_kind)
        def work():
            try:
                value = call()
                self.events.put((done_kind, value))
            except InterruptedError as exc:
                self.events.put(('cancelled', str(exc)))
            except Exception as exc:
                self.events.put(('error', str(exc)))
                self.events.put(('trace', traceback.format_exc()))
        self.worker = threading.Thread(target=work, name='zaimu10-'+task_kind, daemon=True)
        self.worker.start()

    def _search(self, purpose: str = 'show'):
        if self.busy or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showinfo('企業の検索', '銘柄コード、または会社名を入力してください。', parent=self.root)
            return
        self.pending_search_action = purpose
        offline = self.offline.get()
        self.status.set(f'「{query}」に一致する企業を検索しています。')
        self._worker('search', lambda: (search_companies(query, cache_dir=self.cache_dir,
            offline=offline, cancel=self.cancel_event, log=lambda text: self.events.put(('log', text))), purpose), 'search_done')

    def _search_done(self, results: list[dict], purpose: str):
        self._set_busy(False)
        self.search_tree.delete(*self.search_tree.get_children())
        self.search_results = {}
        for i, company in enumerate(results):
            item = str(i)
            self.search_results[item] = dict(company)
            self.search_tree.insert('', 'end', iid=item, values=(company['code'], company.get('display_name') or display_company_name(company.get('company','')), company.get('fiscal_year_end') or '未取得'))
        self.pending_search_action = purpose
        self._show_search_results(len(results))
        if not results:
            self.selected_company = None
            self.selected_text.set('一致する企業がありません。会社名の一部、または4文字の銘柄コードで再検索してください。')
            self.status.set('企業が見つかりませんでした。')
        elif len(results) == 1:
            self.search_tree.selection_set('0')
            self._set_company(results[0])
            self.status.set(f"{results[0]['code']} の企業情報を入力しました。")
            self._complete_search_action(purpose)
        else:
            self.selected_company = None
            self.selected_text.set(f'{len(results)}件見つかりました。検索結果をダブルクリックするか「選択した企業を入力」を押してください。')
            self.status.set('同じ名前を含む企業が複数あります。対象企業を選んでください。')
            self.search_tree.focus_set()

    def _complete_search_action(self, purpose):
        self.pending_search_action = 'show'
        if purpose == 'register':
            self._register_company()
        elif purpose == 'start':
            self._start()

    def _use_search_result(self):
        if self.busy or self.closing:
            return
        selected = self.search_tree.selection()
        if not selected:
            self.status.set('検索結果から企業を選択してください。')
            return
        company = self.search_results[selected[0]]
        purpose = self.pending_search_action
        self._set_company(company)
        self._show_search_results(0)
        self.status.set(f"{company['code']} の企業情報を入力しました。")
        self._complete_search_action(purpose)

    def _register_company(self):
        if self.busy or self.closing:
            return
        if self.selected_company is None:
            self._search('register')
            return
        try:
            company = self.registry.register(self.selected_company)
            self._refresh_registry()
            self.status.set(f"{company['code']} {display_company_name(company.get('company',''))} を登録しました。")
            self.registry_text.set('登録しました。「選択企業の提出情報を更新」またはExcel取得後に、最新の決算期末を表示します。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録できませんでした', str(exc), parent=self.root)

    def _refresh_registry(self):
        try:
            records = self.registry.calendar_rows()
        except (RegistryError, OSError, ValueError) as exc:
            self.registry_text.set(f'登録情報を読み込めませんでした：{exc}')
            self._append(f'登録情報：{exc}')
            return
        selected = self.registry_tree.selection()
        self.registry_tree.delete(*self.registry_tree.get_children())
        self.registered = {record['code']: record for record in records}
        for record in records:
            self.registry_tree.insert('', 'end', iid=record['code'], values=calendar_values(record))
        if selected and selected[0] in self.registered:
            self.registry_tree.selection_set(selected[0])
        elif records:
            self.registry_tree.selection_set(records[0]['code'])
        self.registry_text.set(f'登録企業：{len(records)}社。最新決算期末の新しい順（未取得は下段）。')

    def _use_registered(self):
        if self.busy or self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('登録企業から対象を選択してください。')
            return
        self._set_company(self.registered[selected[0]])
        self.notebook.select(self.create_tab)
        self.status.set('登録企業を入力しました。「Excelを作成」で取得できます。')
        self.code_entry.focus_set()

    def _remove_registered(self):
        if self.busy or self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('解除する登録企業を選択してください。')
            return
        code = selected[0]
        try:
            self.registry.remove(code)
            self._refresh_registry()
            self.status.set(f'{code} の登録を解除しました。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録を解除できませんでした', str(exc), parent=self.root)

    def _update_calendar(self):
        if self.busy or self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('提出情報を更新する登録企業を選択してください。')
            return
        code = selected[0]
        offline = self.offline.get()
        self.status.set(f'{code} の有価証券報告書の提出情報を確認しています。')
        def work():
            filings = discover_filings(code, cache_dir=self.cache_dir, years=10,
                offline=offline, cancel=self.cancel_event, log=lambda text: self.events.put(('log', text)))
            if self.cancel_event.is_set():
                raise InterruptedError('提出情報の更新を中止しました。')
            self.registry.update_filings(code, filings)
            return code
        self._worker('calendar', work, 'calendar_done')

    def _make_options(self, code: str) -> Options:
        until = date.fromisoformat(self.until.get().strip()) if self.until.get().strip() else None
        years = int(self.years.get())
        if not 1 <= years <= 10:
            raise ValueError('取得期数は1～10を指定してください。')
        if not self.output.get().strip():
            raise ValueError('出力先を指定してください。')
        return Options(code=code, output_dir=Path(self.output.get()), cache_dir=self.cache_dir,
            years=years, basis=BASIS_OPTIONS[self.basis.get()], unit=UNIT_OPTIONS[self.unit.get()],
            until=until, offline=self.offline.get(), allow_partial=self.partial.get())

    def _start(self):
        if self.busy or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showerror('入力を確認してください', '会社名、または銘柄コードを入力してください。', parent=self.root)
            return
        try:
            opts = self._make_options(query)
        except (ValueError, KeyError, tk.TclError) as exc:
            messagebox.showerror('入力を確認してください', str(exc), parent=self.root)
            return
        try:
            opts.code = validate_code(query)
        except ValueError:
            self._search('start')
            return
        code = opts.code
        self.result = None
        self.logs.configure(state='normal')
        self.logs.delete('1.0', 'end')
        self.logs.configure(state='disabled')
        self.status.set(f'{code} の財務諸表を取得しています。初回は数分かかる場合があります。')
        self._worker('acquisition', lambda: run(opts, log=lambda text: self.events.put(('log', text)), cancel=self.cancel_event), 'done')

    def _handle_event(self, kind, value):
        if kind == 'log':
            self._append(value)
            self.status.set(value)
        elif kind == 'search_done':
            if self.cancel_event.is_set() or self.closing:
                # A response can finish just before the user clicks stop. Do
                # not turn that queued search response into a new acquisition.
                self.pending_search_action = 'show'
                self._set_busy(False)
                self.status.set('企業の検索を中止しました。')
            else:
                results, purpose = value
                self._search_done(results, purpose)
        elif kind == 'calendar_done':
            self._set_busy(False)
            self._refresh_registry()
            self.status.set(f'{value} の最新決算期末・原本提出日時を更新しました。')
        elif kind == 'done':
            self.result = value
            self._set_busy(False)
            tag = '要確認の出力' if value.dataset.warnings else '作成完了'
            self.status.set(f'{tag}：{value.workbook.name}')
            self._append(f'Excel：{value.workbook}\n監査記録：{value.audit}')
            try:
                record = self.registry.update_result(value.dataset)
                if record is not None:
                    self._refresh_registry()
            except (RegistryError, OSError, ValueError) as exc:
                self._append(f'Excelは作成済みです。登録情報の更新に失敗しました：{exc}')
        elif kind == 'error':
            self._set_busy(False)
            self.status.set('処理を完了できませんでした。Excel作成タブの詳細を確認してください。')
            self._append(value)
        elif kind == 'cancelled':
            self._set_busy(False)
            self.status.set(value)
            self._append(value)
        # Technical tracebacks stay out of the ordinary UI; CLI --debug retains
        # the backend diagnostics for investigating source changes.

    def _poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                self._handle_event(kind, value)
        except queue.Empty:
            pass
        if self.closing and (self.worker is None or not self.worker.is_alive()):
            self.root.destroy()
            return
        self.root.after(150, self._poll)

    def _cancel(self):
        self.cancel_event.set()
        self.status.set('中止しています。実行中の通信が終了するまでお待ちください。')
        self.cancel_button.configure(state='disabled')
        self.calendar_cancel_button.configure(state='disabled')

    def _close(self):
        if self.busy or self.closing:
            self.closing = True
            self._cancel()
        else:
            self.root.destroy()

    def _open_path(self, path: Path):
        try:
            if sys.platform == 'win32':
                os.startfile(str(path))
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', str(path)])
            else:
                subprocess.Popen(['xdg-open', str(path)])
        except OSError as exc:
            messagebox.showerror('開けませんでした', str(exc), parent=self.root)

    def _open_file(self):
        if self.result:
            self._open_path(self.result.workbook)

    def _open_folder(self):
        path = Path(self.output.get()).expanduser()
        if path.is_dir():
            self._open_path(path)
        else:
            messagebox.showinfo('出力先', 'Excelの作成後にフォルダーを開けます。', parent=self.root)


def launch(initial_code: str = '6947'):
    root = tk.Tk()
    App(root, initial_code)
    root.mainloop()
