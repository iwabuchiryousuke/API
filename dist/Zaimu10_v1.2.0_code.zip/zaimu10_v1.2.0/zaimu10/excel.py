"""Template-faithful, auditable financial statements with editable formulas.

Only the supplied financial template's styles are shipped. Its numeric values,
old formulas and analysis worksheets are stripped from the packaged asset.
"""
from __future__ import annotations

from copy import copy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
from importlib.resources import files
import json
from math import ceil
from pathlib import Path
import re
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties

from .models import Cell, Dataset, Period, Row, SHEETS

SHEET_NAMES = ('PL', 'BS-A', 'BS-L,E', 'CF')
INTEGER_FORMAT = '#,##0_);[Red](#,##0)'
NUMBER_FORMAT = '#,##0.###_);[Red](#,##0.###)'
RATIO_FORMAT = '0.00%;[Red]\\-0.00%'
TEMPLATE_PATH = files('zaimu10').joinpath('assets').joinpath('financial_template.xlsx')
PL_ROWS = {2: 'revenue', 4: 'cost_of_sales', 5: 'gross_profit', 8: 'sga',
           9: 'operating_profit', 12: 'nonoperating_income', 13: 'nonoperating_expense',
           14: 'ordinary_profit', 15: 'extraordinary_income', 16: 'extraordinary_expense',
           17: 'profit_before_tax', 18: 'income_taxes', 19: 'net_profit'}
PL_LABELS = {2:'売上高',3:'(増加率）',4:'売上原価',5:'Ⅰ 売上総利益',6:'(粗利率）',
             7:'(増加率）',8:'販売費及び一般管理費計',9:'Ⅱ 営業利益',10:'（営業利益率）',
             11:'(増加率）',12:'営業外収益',13:'営業外費用',14:'Ⅲ 経常利益',15:'特別利益',
             16:'特別損失',17:'Ⅳ 税金等調整前当期純利益',18:'法人税等合計',19:'Ⅴ 当期純利益',
             20:'(増加率）',22:'実効税率'}
CF_GROUPS = {'operating_adjustments': 22, 'operating_working': 33, 'operating_payments': 40,
             'investing': 54, 'financing': 64, 'cash_bridge': 68}
TOTAL_LOCALS = {
    'CurrentAssets','NoncurrentAssets','Assets','PropertyPlantAndEquipment','IntangibleAssets',
    'InvestmentsAndOtherAssets','CurrentLiabilities','NoncurrentLiabilities','Liabilities',
    'CapitalSurplus','RetainedEarnings','OtherRetainedEarnings',
    'ShareholdersEquity','ValuationAndTranslationAdjustments','NetAssets','LiabilitiesAndNetAssets',
    'CurrentAssetsIFRS','NonCurrentAssetsIFRS','NoncurrentAssetsIFRS','AssetsIFRS','TotalAssetsIFRS',
    'PropertyPlantAndEquipmentIFRS','IntangibleAssetsIFRS','NonCurrentLiabilitiesIFRS',
    'NoncurrentLiabilitiesIFRS','CurrentLiabilitiesIFRS','LiabilitiesIFRS','EquityIFRS',
    'TotalEquityIFRS','LiabilitiesAndEquityIFRS','TotalLiabilitiesAndEquityIFRS',
    'EquityAttributableToOwnersOfParentIFRS',
    'TotalCurrentLiabilitiesIFRS','NonCurrentLabilitiesIFRS',
}


def era_date(value: date) -> str:
    if value >= date(2019, 5, 1):
        era = f'R{value.year - 2018}'
    elif value >= date(1989, 1, 8):
        era = f'H{value.year - 1988}'
    else:
        era = f'S{value.year - 1925}'
    return f'{era}-{value.year}\n{value.month}/{value.day}'


def _text(cell, value):
    cell.value = str(value)
    cell.data_type = 's'


def _local(row: Row, period: Period | None = None) -> str:
    facts = ([row.values[period.key]] if period is not None and period.key in row.values
             else row.values.values())
    for fact in facts:
        name = fact.source.concept
        if name:
            return name.rsplit('}', 1)[-1].rsplit(':', 1)[-1]
    return ''


def _fact(row: Row, period: Period) -> Cell | None:
    fact = row.values.get(period.key)
    return fact if fact is not None and fact.value is not None and not fact.nil else None


def _present(row: Row) -> bool:
    return row.is_heading or any(c.value is not None and not c.nil for c in row.values.values())


def _money(value, factor):
    value = Decimal(str(value)) / factor
    if not value.is_finite():
        raise ValueError('財務数値に非有限値があります。')
    return int(value) if value == value.to_integral_value() else float(value)


def _tolerance(cells) -> Decimal:
    result = Decimal(0)
    for fact in cells:
        if fact is None:
            continue
        try:
            result += Decimal(10) ** -int(fact.source.decimals)
        except (ValueError, TypeError):
            pass
    return max(result, Decimal(1))


def _source_dict(fact: Cell | None):
    return asdict(fact) if fact is not None else None


def _leaf_cells(fact: Cell) -> list[Cell]:
    components = getattr(fact, 'components', [])
    return [leaf for component in components for leaf in _leaf_cells(component)] if components else [fact]


def _unique_cells(cells):
    selected={}
    for cell in cells:
        source=cell.source
        key=(source.doc_id,source.filename,source.context_id,source.concept,source.unit,
             str(cell.value),cell.nil)
        selected.setdefault(key,cell)
    return list(selected.values())


def _comment(fact: Cell | None, row: Row | None, period: Period, dataset: Dataset,
             extra: str = '') -> Comment:
    if fact is None:
        text = extra
    else:
        s = fact.source
        text = '\n'.join([
            f'原項目名: {s.original_label}', f'項目識別子: {row.key if row else ""}',
            f'XBRL QName: {s.concept}', f'値（原単位・換算前）: {fact.value}',
            f'書類ID: {s.doc_id}', f'提出日: {s.submitted}', f'出典URL: {s.url}',
            f'ファイル名: {s.filename}', f'contextRef: {s.context_id}', f'原単位: {s.unit}',
            f'原表記: {s.raw_value}', f'scale: {s.scale}', f'decimals: {s.decimals}',
            f'nil: {fact.nil}', f'連結区分: {s.basis}', f'注記: {fact.note}',
            f'原文区分: {" > ".join(fact.source_section) if getattr(fact,"source_section",None) is not None else ""}',
            f'原文順序: {getattr(fact,"source_order",None)}',
        ])
        components = getattr(fact, 'components', [])
        if components:
            text += '\n統合元:\n' + '\n'.join(
                f'{c.source.original_label}: {c.value} [{c.source.doc_id}] {c.source.concept}'
                for c in components)
        if extra:
            text += '\n' + extra
    text += f'\n対象期間: {period.key}\n会計基準: {dataset.period_standards.get(period.key, dataset.accounting_standard)}'
    comment = Comment(text, 'Zaimu10')
    comment.width = 580
    comment.height = 400
    return comment


class Writer:
    def __init__(self, dataset: Dataset, unit: str):
        self.dataset = dataset
        self.periods = sorted(dataset.periods, key=lambda p: (p.end, p.start))
        factors = {'yen': (Decimal(1), '円'), 'thousand': (Decimal(1000), '千円'),
                   'million': (Decimal(1000000), '百万円')}
        if unit not in factors:
            raise ValueError('表示単位はyen / thousand / million / autoから指定してください。')
        self.factor, self.unit_label = factors[unit]
        self.unit = unit
        with TEMPLATE_PATH.open('rb') as stream:
            self.template = load_workbook(stream)
        with TEMPLATE_PATH.open('rb') as stream:
            self.book = load_workbook(stream)
        self.book['BS-L&E'].title = 'BS-L,E'
        self.values: dict[tuple[str, str], Decimal | str | None] = {}
        self.cached: dict[tuple[str, str], Decimal | str | None] = {}
        self.sources: dict[tuple[str, str], Cell] = {}
        self.precision: dict[tuple[str, str], list[Cell]] = {}
        self.cells: list[dict] = []
        self.checks: list[dict] = []
        self.helper_next = {}
        self.helpers = []
        self.layout_metadata = {}
        self.source_addresses = {}
        self.bs_metrics = {}
        self.main_ends = {}
        self.book.calculation = CalcProperties(calcId=191029, fullCalcOnLoad=True, forceFullCalc=True)
        latest = max(self.periods, key=lambda p: p.end)
        company = dataset.company.replace('株式会社', '').replace('　', ' ').strip()
        self.book.properties.title = f'{dataset.code} {company} {latest.end:%Y-%m-%d}'
        self.book.properties.creator = 'Zaimu10'
        self.book.properties.description = '財務原文と計算根拠はセルのメモおよび同名の監査JSONを参照。'
        for ws in self.book:
            for row in ws:
                for cell in row:
                    cell.value = None
                    cell.comment = None
                    cell.hyperlink = None

    def style(self, sheet, target_row, source_row):
        source_name = 'BS-L&E' if sheet == 'BS-L,E' else sheet
        src = self.template[source_name]
        ws = self.book[sheet]
        for column in range(1, len(self.periods) + 2):
            original = src.cell(source_row, min(column, 15))
            ws.cell(target_row, column)._style = copy(original._style)
            if target_row>1 and column>1:
                self.fit_number(ws.cell(target_row,column))
        ws.row_dimensions[target_row].height = src.row_dimensions[source_row].height
        ws.row_dimensions[target_row].hidden = False

    @staticmethod
    def fit_number(cell):
        # Keep source column widths and alignment while fitting large signed
        # amounts, including future entries in an originally blank year.
        alignment=copy(cell.alignment)
        alignment.wrap_text=False;alignment.shrink_to_fit=True
        cell.alignment=alignment

    def total_style(self, sheet, row_number, *, grand=False):
        """A semantic subtotal has a visible rule above and below the range."""
        for column in range(1,len(self.periods)+2):
            cell=self.book[sheet].cell(row_number,column)
            border=copy(cell.border)
            border.top=Side(style='thin',color='FF000000')
            border.bottom=Side(style='medium' if grand else 'thin',color='FF000000')
            cell.border=border

    def fit_label(self, sheet, row_number):
        cell=self.book[sheet].cell(row_number,1)
        font=copy(cell.font);font.sz=min(font.sz or 9,8);cell.font=font
        alignment=copy(cell.alignment)
        alignment.wrap_text=False;alignment.shrink_to_fit=True
        cell.alignment=alignment
        self.book[sheet].row_dimensions[row_number].height=12

    def headers(self, sheet):
        ws = self.book[sheet]
        self.style(sheet, 1, 1)
        titles = {'PL': '損益計算書', 'BS-A': '貸借対照表',
                  'BS-L,E': '貸借対照表', 'CF': 'キャッシュフロー計算書'}
        latest = max(self.periods, key=lambda period: period.end)
        latest_basis = self.dataset.period_bases.get(latest.key, self.dataset.basis)
        prefix = '個別' if latest_basis == 'standalone' else '連結' if latest_basis == 'consolidated' else '年度別'
        _text(ws['A1'], f'{prefix}{titles[sheet]}\n単位:{self.unit_label}')
        basis_names = {'consolidated': '連結', 'standalone': '個別'}
        standards = {'J-GAAP': '日本基準', 'IFRS': 'IFRS', 'US-GAAP': '米国基準'}
        notes = [f'銘柄: {self.dataset.code} {self.dataset.company}',
                 f'取得日時: {self.dataset.fetched_at}', f'取得元: {self.dataset.source_mode}']
        notes += ['取得注記: ' + text for text in self.dataset.source_notes]
        notes += ['要確認: ' + text for text in self.dataset.warnings]
        ws['A1'].comment = Comment('\n'.join(notes), 'Zaimu10')
        for column, period in enumerate(self.periods, 2):
            cell = ws.cell(1, column)
            label = era_date(period.end)
            if self.dataset.basis == 'mixed':
                label += '\n' + basis_names.get(self.dataset.period_bases.get(period.key), '不明')
            if self.dataset.accounting_standard == 'mixed':
                label += '\n' + standards.get(self.dataset.period_standards.get(period.key), '不明')
            _text(cell, label)
            cell.comment = Comment(
                f'会計期間: {period.key}\n日数: {period.days}\n'
                f'連結区分: {basis_names.get(self.dataset.period_bases.get(period.key, self.dataset.basis), "不明")}\n'
                f'会計基準: {standards.get(self.dataset.period_standards.get(period.key, self.dataset.accounting_standard), self.dataset.accounting_standard)}', 'Zaimu10')
        if self.dataset.basis == 'mixed' or self.dataset.accounting_standard == 'mixed':
            ws.row_dimensions[1].height = 50 if self.dataset.basis == 'mixed' and self.dataset.accounting_standard == 'mixed' else 38

    def record(self, sheet, row_number, record: Row, *, style_row=None, label=None):
        if style_row is not None:
            self.style(sheet, row_number, style_row)
        ws = self.book[sheet]
        _text(ws.cell(row_number, 1), record.label if label is None else label)
        ws.cell(row_number, 1).comment = Comment(
            f'項目識別子: {record.key}\n区分: {" > ".join(record.section)}', 'Zaimu10')
        for column, period in enumerate(self.periods, 2):
            fact = record.values.get(period.key)
            if fact is not None:
                self.source(sheet, row_number, column, record, fact, period)
        if sheet in {'BS-A','BS-L,E','CF'} and record.key not in {
                'template:CF:'+str(n) for n in [22,26,33,40,54,64,66,68]} and any(
                len(getattr(fact,'components',[]))>=2 and fact.operation in {'sum','net','difference'}
                for fact in record.values.values()):
            self.composite(sheet,row_number,record)

    def composite(self,sheet,target,row):
        """Original component sums use a stable, audited hidden range too."""
        keys=[];parts={};reported={}
        for period in self.periods:
            fact=row.values.get(period.key);parts[period.key]={}
            reported[period.key]=fact.value/self.factor if fact and fact.value is not None and not fact.nil else None
            if not fact or fact.operation not in {'sum','net','difference'}:continue
            for index,component in enumerate(fact.components):
                key=fact.component_keys[index] if index<len(fact.component_keys) else component.source.concept
                sign=-1 if fact.operation=='difference' and index else 1
                signature=(key,sign)
                if signature not in keys:keys.append(signature)
                parts[period.key][signature]=component
        if not keys:return
        start=self.helper_next.get(sheet,1000)
        for key,sign in keys:
            sources={period.key:parts[period.key].get((key,sign)) for period in self.periods}
            values={period.key:(sources[period.key].value/self.factor*sign
                                if sources[period.key] and sources[period.key].value is not None else None)
                    for period in self.periods}
            self.helper(sheet,'原文統合項目の内訳: '+row.label+' / '+key,values,sources=sources)
            self.helpers[-1]['coefficient']=sign
        end=self.helper_next[sheet]-1
        report=self.helper(sheet,'内訳がない年度の公表値: '+row.label,reported,sources=row.values)
        for column,period in enumerate(self.periods,2):
            letter=get_column_letter(column)
            expr=f'=IF(COUNT({letter}{start}:{letter}{end}),SUM({letter}{start}:{letter}{end}),IF(ISNUMBER({letter}{report}),{letter}{report},""))'
            fact=row.values.get(period.key)
            expected=reported[period.key]
            if parts[period.key]:
                known=[(component,sign) for (key,sign),component in parts[period.key].items() if component.value is not None]
                expected=sum((component.value*sign for component,sign in known),Decimal(0))/self.factor
            self.formula(sheet,target,column,expr,expected*self.factor if expected is not None else None,
                         row=row,source=fact,note='統合元の原文数値を連続した非表示行へ保存。式の範囲は全年度で同一です。')
        self.layout_metadata.setdefault(sheet,{}).setdefault('component_sum_rows',[]).append({
            'row':target,'helper_range':[start,end],'reported_helper_row':report})

    def source(self, sheet, row_number, column, row, fact, period):
        ws = self.book[sheet]
        cell = ws.cell(row_number, column)
        if fact.value is not None and not fact.nil:
            factor = self.factor if fact.source.unit == 'JPY' else Decimal(1)
            cell.value = _money(fact.value, factor)
            self.values[(sheet, cell.coordinate)] = Decimal(str(fact.value)) / factor
        else:
            cell.value = None
            self.values[(sheet, cell.coordinate)] = None
        cell.comment = _comment(fact, row, period, self.dataset)
        self.sources[(sheet, cell.coordinate)] = fact
        self.precision[(sheet, cell.coordinate)] = _leaf_cells(fact)
        self.cells.append({'sheet': sheet, 'address': cell.coordinate, 'row_key': row.key,
                           'period': period.key, 'formula': None,
                           'value': str(fact.value) if fact.value is not None else None,
                           'display_value': str(self.values[(sheet, cell.coordinate)]) if self.values[(sheet, cell.coordinate)] is not None else None,
                           'source': _source_dict(fact), 'unit': self.unit})
        components = getattr(fact, 'components', [])
        operation = getattr(fact, 'operation', '')
        if len(components) >= 2 and operation in {'sum', 'net', 'difference'} and all(
                component.value is not None and not component.nil for component in components):
            factor = self.factor if fact.source.unit == 'JPY' else Decimal(1)
            literals = [str(component.value / factor) for component in components]
            if operation in {'sum', 'net'}:
                expression = '=SUM(' + ','.join(literals) + ')'
                calculated = sum((component.value for component in components), Decimal(0))
            else:
                expression = '=' + literals[0] + ''.join('-(' + value + ')' for value in literals[1:])
                calculated = components[0].value - sum((component.value for component in components[1:]), Decimal(0))
            # Composite rules can carry mixed +/- signs (e.g. ordinary profit).
            # A literal equation is emitted only when the declared operation
            # actually reproduces the projection's computed value.
            if calculated == fact.value:
                self.formula(sheet, row_number, column, expression, calculated,
                             row=row, source=fact, note='同一意味の開示構成項目を原単位から換算して計算。',
                             monetary=fact.source.unit == 'JPY')

    def formula(self, sheet, row_number, column, expression, expected, *, row=None,
                source=None, note='', monetary=True):
        ws = self.book[sheet]
        cell = ws.cell(row_number, column)
        cell.value = expression
        value = expected / self.factor if monetary and isinstance(expected, Decimal) else expected
        self.values[(sheet, cell.coordinate)] = value
        self.cached[(sheet, cell.coordinate)] = value
        if source is not None:
            self.sources[(sheet, cell.coordinate)] = source
            self.precision.setdefault((sheet, cell.coordinate), _leaf_cells(source))
        period = self.periods[column - 2]
        cell.comment = _comment(source, row, period, self.dataset,
                                f'Excel計算式: {expression}\n計算値（原単位・換算前）: {expected}\n' + note)
        self.cells = [item for item in self.cells if not (item['sheet'] == sheet and item['address'] == cell.coordinate)]
        self.cells.append({'sheet': sheet, 'address': cell.coordinate,
                           'row_key': row.key if row else 'calculation', 'period': period.key,
                           'formula': expression, 'expected': str(expected) if expected is not None else None,
                           'display_value': str(value) if value is not None else None,
                           'disclosed_value': str(source.value) if source and source.value is not None else None,
                           'source': _source_dict(source), 'unit': self.unit if monetary else 'ratio_or_text'})

    def check_total(self, sheet, row_number, period, disclosed, children, calculated, formula):
        if disclosed is None or disclosed.value is None:
            return
        tolerance = _tolerance([disclosed] + children)
        difference = calculated - disclosed.value
        ok = abs(difference) <= tolerance
        check = {'check': 'presentation_total', 'sheet': sheet, 'row': row_number,
                 'period': period.key, 'ok': ok, 'disclosed_jpy': str(disclosed.value),
                 'calculated_jpy': str(calculated), 'difference_jpy': str(difference),
                 'rounding_tolerance_jpy': str(tolerance), 'formula': formula}
        self.checks.append(check)
        if not ok:
            message = f'{period.label} {sheet} {self.book[sheet].cell(row_number,1).value}：計算合計と開示合計が丸め許容差を超えています（差額{difference}円）。'
            if message not in self.dataset.warnings:
                self.dataset.warnings.append(message)

    def aggregate(self, sheet, row_number, columns, *, signs=None, disclosed_row=None,
                  min_children=2, name='', adjustments=None, fallback_ifrs=False,
                  require_proven_sum=False):
        signs = signs or [1] * len(columns)
        for column, period in enumerate(self.periods, 2):
            present = [(r, sign, self.values.get((sheet, f'{get_column_letter(column)}{r}')))
                       for r, sign in zip(columns, signs)]
            present = [(r, sign, value) for r, sign, value in present if isinstance(value, Decimal)]
            if len(present) < min_children:
                continue
            letter = get_column_letter(column)
            refs = [f'{letter}{r}' for r, sign, value in present]
            if all(sign == 1 for r, sign, value in present):
                expression = '=SUM(' + ','.join(refs) + ')'
            else:
                expression = '=' + ''.join(('+' if sign > 0 and i else '-' if sign < 0 else '') + ref
                                          for i, ((r, sign, value), ref) in enumerate(zip(present, refs)))
            calculated = sum((value * self.factor * sign for r, sign, value in present), Decimal(0))
            source = _fact(disclosed_row, period) if disclosed_row is not None else None
            children = [self.sources[(sheet, f'{letter}{r}')] for r, sign, value in present
                        if (sheet, f'{letter}{r}') in self.sources]
            precision = [leaf for r,sign,value in present
                         for leaf in self.precision.get((sheet, f'{letter}{r}'), [])]
            additional = (adjustments or {}).get(period.key, [])
            for component, sign in additional:
                expression += ('+' if sign > 0 else '-') + '(' + str(component.value / self.factor) + ')'
                calculated += component.value * sign
                children.append(component)
                precision.extend(_leaf_cells(component))
            standard = self.dataset.period_standards.get(period.key, self.dataset.accounting_standard)
            if fallback_ifrs and standard == 'IFRS' and source is not None and abs(
                    calculated - source.value) > _tolerance([source] + children):
                reason = 'この会計基準では売上総利益－販管費と営業利益が一致せず、明示項目だけで差額を説明できないため開示利益を使用。差額を推測で補いません。'
                self.checks.append({'check':'presentation_formula_not_applicable','sheet':sheet,
                                    'row':row_number,'period':period.key,'ok':None,'reason':reason,
                                    'disclosed_jpy':str(source.value),'candidate_jpy':str(calculated)})
                self.book[sheet].cell(row_number,column).comment = _comment(source,disclosed_row,period,self.dataset,reason)
                continue
            if require_proven_sum and source is not None and abs(calculated-source.value) > _tolerance([source] + precision):
                reason='既知のCF区分と換算差額だけでは現金増減額と一致しないため、追加調整を推測せず開示増減額を使用。'
                self.checks.append({'check':'presentation_formula_not_applicable','sheet':sheet,
                                    'row':row_number,'period':period.key,'ok':None,'reason':reason,
                                    'disclosed_jpy':str(source.value),'candidate_jpy':str(calculated)})
                self.book[sheet].cell(row_number,column).comment=_comment(source,disclosed_row,period,self.dataset,reason)
                continue
            self.formula(sheet, row_number, column, expression, calculated,
                         row=disclosed_row, source=source, note=name + (
                             '\n追加の開示営業損益:\n' + '\n'.join(
                                 f'{"+" if sign>0 else "-"} {component.source.original_label}: {component.value} [{component.source.doc_id}] {component.source.concept}'
                                 for component,sign in additional) if additional else ''))
            if additional:
                self.cells[-1]['adjustments'] = [{'sign':sign,'cell':_source_dict(component)}
                                                for component,sign in additional]
            self.precision[(sheet, f'{letter}{row_number}')] = precision
            self.check_total(sheet, row_number, period, source, precision or children, calculated, expression)

    def ratio(self, sheet, target, numerator, denominator, *, growth=False, conditional=False):
        for column, period in enumerate(self.periods, 2):
            if growth and column == 2:
                continue
            letter = get_column_letter(column)
            nref = f'{letter}{numerator}'
            dref = f'{get_column_letter(column - 1)}{denominator}' if growth else f'{letter}{denominator}'
            nvalue = self.values.get((sheet, nref)); dvalue = self.values.get((sheet, dref))
            condition = f'AND(COUNT({nref},{dref})=2,{nref}>0,{dref}<0)' if conditional else f'COUNT({nref},{dref})=2'
            operator = f'{nref}/(-{dref})' if conditional else f'{nref}/{dref}' + ('-1' if growth else '')
            expression = f'=IFERROR(IF({condition},{operator},""),"")'
            expected = None
            if isinstance(nvalue, Decimal) and isinstance(dvalue, Decimal) and dvalue:
                if not conditional or nvalue > 0 and dvalue < 0:
                    expected = nvalue / (-dvalue if conditional else dvalue) - (1 if growth else 0)
            self.book[sheet].cell(target, column).number_format = (
                self.template['CF'].cell(73, column).number_format
                if conditional and sheet == 'CF' else RATIO_FORMAT)
            self.formula(sheet, target, column, expression, expected, monetary=False)

    def helper(self,sheet,purpose,values,*,sources=None):
        """Preserve published data outside the visible/printed statement."""
        number=self.helper_next.get(sheet,1000)
        self.helper_next[sheet]=number+1
        ws=self.book[sheet];ws.row_dimensions[number].hidden=True
        _text(ws.cell(number,1),purpose)
        metadata={'sheet':sheet,'row':number,'purpose':purpose,'hidden':True,'values':{}}
        for column,period in enumerate(self.periods,2):
            value=values.get(period.key)
            ws.cell(number,column).value=_money(value,Decimal(1)) if value is not None else None
            ws.cell(number,column).number_format=NUMBER_FORMAT
            self.fit_number(ws.cell(number,column))
            metadata['values'][period.key]={'display_value':str(value) if value is not None else None,
                                           'source':_source_dict((sources or {}).get(period.key))}
        self.helpers.append(metadata)
        return number

    def uniform_sum(self,sheet,target,begin,end,*,row=None,nested=None,proof=None,
                    nil_preserved=True,note=''):
        """One contiguous range and the same structural formula in every year.

        Nested source subtotals replace their detail once. Published-only years
        fall back to their original disclosure, and newly filled input cells
        immediately activate the same range formula.
        """
        nested=nested or []
        self.total_style(sheet,target)
        ws=self.book[sheet]
        def total(a,b,column):
            return sum((self.values.get((sheet,f'{get_column_letter(column)}{r}'))
                        for r in range(a,b+1)
                        if isinstance(self.values.get((sheet,f'{get_column_letter(column)}{r}')),Decimal)),Decimal(0))
        def numeric(a,b,column):
            return any(isinstance(self.values.get((sheet,f'{get_column_letter(column)}{r}')),Decimal)
                       for r in range(a,b+1))
        def correction(spec,column):
            subtotal,a,b,children=spec;letter=get_column_letter(column)
            if subtotal is None:
                return f'SUM({letter}{a}:{letter}{b})',total(a,b,column)
            lower=[correction(child,column) for child in children]
            alternative='+'.join(item[0] for item in lower) or '0'
            expression=f'IF(ISNUMBER({letter}{subtotal}),SUM({letter}{a}:{letter}{b}),{alternative})'
            value=(total(a,b,column) if isinstance(self.values.get((sheet,f'{letter}{subtotal}')),Decimal)
                   else sum((item[1] for item in lower),Decimal(0)))
            return expression,value
        reported={};facts={};computed={};exceptions={};precisions={};exception_reasons={}
        for column,period in enumerate(self.periods,2):
            fact=row.values.get(period.key) if row else None
            facts[period.key]=fact
            reported[period.key]=(fact.value/self.factor if fact is not None and fact.value is not None and not fact.nil else None)
            corr=[correction(spec,column) for spec in nested]
            value=total(begin,end,column)-sum((item[1] for item in corr),Decimal(0))
            precision=_unique_cells([leaf for r in range(begin,end+1)
                       for leaf in self.precision.get((sheet,f'{get_column_letter(column)}{r}'),[])]
                                   )
            precisions[period.key]=precision
            available=numeric(begin,end,column)
            exceptional=bool(nil_preserved and fact is not None and fact.nil and available)
            exception_reason='公表値が明示的nilのため初期値を空白に保持。' if exceptional else ''
            if proof and period.key in proof and available:
                evidence=proof[period.key]
                expected_proof=evidence.get('expected') if isinstance(evidence,dict) else evidence
                if isinstance(evidence,dict) and evidence.get('force_fallback'):
                    exceptional=True;exception_reason=evidence['reason']
                if expected_proof is not None and abs(value*self.factor-expected_proof)>_tolerance(([fact] if fact else [])+precision):
                    if isinstance(evidence,dict) and evidence.get('complete') and not evidence.get('alternative'):
                        message=f'{period.label} {sheet} {ws.cell(target,1).value}：共通表示範囲が原文の完全な内訳関係と一致しません。'
                        self.checks.append({'check':'presentation_layout','sheet':sheet,'row':target,'period':period.key,
                                            'ok':False,'source_components_jpy':str(expected_proof),
                                            'union_calculated_jpy':str(value*self.factor),'reason':message})
                        if message not in self.dataset.warnings:self.dataset.warnings.append(message)
                    else:
                        exceptional=True
                        exception_reason=evidence.get('reason','原文で選択的な内訳が明示されるため公表値を保持。') if isinstance(evidence,dict) else '当該年度の内訳関係を一意に確認できません。'
            elif fact is not None and fact.value is not None and available:
                exceptional=True
                exception_reason='当該年度の原表にはこの表示合計の内訳が示されていないため公表値を保持。'
            exceptions[period.key]=exceptional
            exception_reasons[period.key]=exception_reason
            computed[period.key]=value if available and not exceptional else reported[period.key]
        report_row=self.helper(sheet,f'公表合計の保存: {ws.cell(target,1).value}',reported,sources=facts)
        eligibility=None;snapshot=None
        if any(exceptions.values()):
            eligibility=self.helper(sheet,f'元の内訳から計算できるか: {ws.cell(target,1).value}',
                                    {key:Decimal(0 if flag else 1) for key,flag in exceptions.items()})
            snapshot=self.helper_next.get(sheet,1000)
            for r in range(begin,end+1):
                self.helper(sheet,f'手修正検知用の元値: {sheet}!{r}',
                            {period.key:self.values.get((sheet,f'{get_column_letter(column)}{r}'))
                             for column,period in enumerate(self.periods,2)})
        for column,period in enumerate(self.periods,2):
            letter=get_column_letter(column);rng=f'{letter}{begin}:{letter}{end}'
            corr=[correction(spec,column)[0] for spec in nested]
            calculation=f'SUM({rng})'+('-('+ '+'.join(corr)+')' if corr else '')
            fallback=f'IF(ISNUMBER({letter}{report_row}),{letter}{report_row},"")'
            expression=f'IF(COUNT({rng}),{calculation},{fallback})'
            if eligibility is not None:
                old=f'{letter}{snapshot}:{letter}{snapshot+end-begin}'
                changed=f'OR(COUNT({rng})<>COUNT({old}),SUMPRODUCT(IFERROR(ABS({rng}-{old}),0))>0.000000001)'
                expression=f'IF(OR({letter}{eligibility}=1,{changed}),{expression},{fallback})'
            fact=facts[period.key];expected=computed[period.key]
            extra='全年度で同じ連続範囲を集計。空白の明細へ数値を入力した場合も再集計します。公表合計の保存行は非表示・印刷範囲外です。'
            if exceptions[period.key]:
                extra+=' '+exception_reasons[period.key]+' 明細を手修正すると範囲の再計算を有効にします。'
                self.checks.append({'check':'presentation_formula_not_applicable','sheet':sheet,'row':target,
                                    'period':period.key,'ok':None,'reason':extra})
            self.formula(sheet,target,column,'='+expression,
                         expected*self.factor if expected is not None else None,
                         row=row,source=fact,note=note+'\n'+extra)
            self.precision[(sheet,f'{letter}{target}')]=precisions[period.key] or (_leaf_cells(fact) if fact else [])
            if not exceptions[period.key] and expected is not None:
                self.check_total(sheet,target,period,fact,precisions[period.key],expected*self.factor,'='+expression)
        self.layout_metadata.setdefault(sheet,{}).setdefault('sum_rows',[]).append({
            'row':target,'range':[begin,end],'reported_helper_row':report_row,
            'eligibility_helper_row':eligibility,'exception_periods':[key for key,flag in exceptions.items() if flag],
            'modes':{period.key:('proof_fallback' if exceptions[period.key] else
                     'calculated' if numeric(begin,end,column) else
                     'reported_only' if reported[period.key] is not None else 'empty')
                     for column,period in enumerate(self.periods,2)},
            'reasons':{key:reason for key,reason in exception_reasons.items() if reason}})

    def finish_sheet(self, sheet, end_row):
        ws = self.book[sheet]
        last_column = len(self.periods) + 1
        # Delete unused template cells without shifting hidden helper addresses
        # or the identical formulas that reference those addresses.
        for r,c in list(ws._cells):
            if (r>end_row and r<1000) or c>last_column:del ws._cells[(r,c)]
        for r in list(ws.row_dimensions):
            if end_row<r<1000:del ws.row_dimensions[r]
        for key in list(ws.column_dimensions):
            if ws.column_dimensions[key].min and ws.column_dimensions[key].min > last_column:
                del ws.column_dimensions[key]
        ws.print_area = f'A1:{get_column_letter(last_column)}{end_row}'
        self.main_ends[sheet]=end_row


def _pl(writer: Writer, dataset: Dataset):
    from .presentation import pl_metrics
    metrics = pl_metrics(dataset)
    rows = {}
    for number, name in PL_ROWS.items():
        rows[number] = metrics.get('metric:' + name) or metrics.get(name) or Row('metric:' + name, PL_LABELS[number], 'PL')
    writer.headers('PL')
    for row_number, label in PL_LABELS.items():
        writer.style('PL', row_number, row_number)
        _text(writer.book['PL'].cell(row_number, 1), label)
        if row_number in rows:
            writer.record('PL', row_number, rows[row_number], label=label)
    operating_adjustments = {}
    allowed = {'OtherIncomeIFRS':1,'OtherOperatingIncomeIFRS':1,
               'OtherExpensesIFRS':-1,'OtherOperatingExpensesIFRS':-1,
               'ShareOfProfitLossOfInvestmentsAccountedForUsingEquityMethodIFRS':1}
    for period in writer.periods:
        selected = {}
        for row in dataset.rows['PL']:
            fact = _fact(row,period)
            if fact is None or fact.source.unit != 'JPY':
                continue
            match = re.fullmatch(r'\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpigp/\d{4}-\d{2}-\d{2}/jpigp_cor\}(.+)',fact.source.concept)
            if match and match.group(1) in allowed:
                name = match.group(1)
                old = selected.get(name)
                if old is None or (fact.source.submitted,fact.source.doc_id) > (old.source.submitted,old.source.doc_id):
                    selected[name] = fact
        operating_adjustments[period.key] = [(fact,allowed[name]) for name,fact in selected.items()]
    calculations = [(5,[2,4],[1,-1]),(9,[5,8],[1,-1]),
                    (14,[9,12,13],[1,1,-1]),(17,[14,15,16],[1,1,-1]),(19,[17,18],[1,-1])]
    for target, operands, signs in calculations:
        writer.aggregate('PL', target, operands, signs=signs, disclosed_row=rows[target],
                         min_children=2, name='固定PLの対応する開示項目による計算。',
                         adjustments=operating_adjustments if target==9 else None,
                         fallback_ifrs=target==9)
    for target, source in [(3,2),(7,5),(11,9),(20,19)]:
        writer.ratio('PL', target, source, source, growth=True)
    writer.ratio('PL',6,5,2); writer.ratio('PL',10,9,2); writer.ratio('PL',22,18,17)
    writer.finish_sheet('PL',22)


def _bs_style(row: Row, statement: str, template):
    sheet = template['BS-A' if statement == 'BS_A' else 'BS-L&E']
    label = row.label
    aliases = {'受取手形及び売掛金':'売掛金及び受取手形','流動資産合計':'流動資産計',
               '有形固定資産合計':'有形固定資産計','無形固定資産合計':'無形固定資産計',
               '投資その他の資産合計':'投資その他の資産計','流動負債合計':'Ⅰ 流動負債計',
               '固定負債合計':'Ⅱ 固定負債計','株主資本合計':'Ⅰ 株主資本計',
               'その他の包括利益累計額合計':'Ⅱ その他の包括利益累計額計'}
    target = aliases.get(label,label)
    for cells in sheet:
        if cells[0].value == target:
            return cells[0].row
    if row.is_heading:
        return 2 if statement == 'BS_A' else 25
    if _local(row) in TOTAL_LOCALS or label.endswith(('合計','計')):
        return 15 if statement == 'BS_A' else 15
    return 3 if statement == 'BS_A' else 4


def _bs_source_plans(records, periods):
    """Recover original per-year direct components before changing display order."""
    def is_total(row,period=None):
        return _local(row,period) in TOTAL_LOCALS or row.label.endswith(('合計','計'))

    def source_section(index,period):
        fact=_fact(records[index],period)
        section=getattr(fact,'source_section',None) if fact else None
        return tuple(section) if section is not None else tuple(records[index].section)

    def source_order(index,period):
        fact=_fact(records[index],period)
        order=getattr(fact,'source_order',None) if fact else None
        return order if order is not None else index

    def same_profile(left,right,period):
        a,b=_fact(records[left],period),_fact(records[right],period)
        return bool(a and b and a.source.basis==b.source.basis and a.source.unit==b.source.unit)

    def net_parts(index, period, *, include_breakdown=False):
        row = records[index]; local = _local(row,period)
        if 'Net' not in local:
            return []
        def asset_stem(name):
            # Known asset-class suffixes differ between gross/net/contra
            # vocabulary names (RightOfUseAssetsPPE versus depreciation
            # RightOfUseAssets). This establishes component relationships,
            # never a fuzzy match of Japanese labels or monetary amounts.
            name = name.replace('AccumulatedDepreclation','AccumulatedDepreciation')
            for prefix in ('AccumulatedDepreciationAndImpairmentLoss',
                           'AccumulatedAmortizationAndImpairmentLoss',
                           'AccumulatedDepreciation','AccumulatedImpairmentLoss',
                           'AccumulatedAmortization'):
                if name.startswith(prefix):
                    name = name[len(prefix):]
                    break
            name = name.replace('Net','')
            return re.sub(r'(?:PPE|IA)$','',name)
        def contra_kind(name):
            name = name.replace('AccumulatedDepreclation','AccumulatedDepreciation')
            return next((prefix for prefix in
                         ('AccumulatedDepreciationAndImpairmentLoss',
                          'AccumulatedAmortizationAndImpairmentLoss',
                          'AccumulatedDepreciation','AccumulatedImpairmentLoss',
                          'AccumulatedAmortization') if name.startswith(prefix)), '')
        stem = asset_stem(local)
        # Merged multi-year display order can place a newer standard-taxonomy
        # contra after an older extension's net row. Membership comes from the
        # exact asset class and section, not from that cross-year row order.
        available = [(i,r) for i,r in enumerate(records) if i != index and _fact(r,period)
                     and source_section(i,period) == source_section(index,period)
                     and same_profile(i,index,period)]
        gross = next(((i,r) for i,r in reversed(available)
                      if not contra_kind(_local(r,period)) and 'Net' not in _local(r,period)
                      and asset_stem(_local(r,period)) == stem), None)
        if gross is None:
            return []
        contra = [(i,r) for i,r in available
                  if contra_kind(_local(r,period)) and asset_stem(_local(r,period)) == stem]
        if not contra:
            return []
        if include_breakdown:
            return [gross[0]] + [i for i,r in contra]
        # A combined accumulated balance is an alternative to its separate
        # depreciation/impairment breakdown, not an additional deduction.
        combined = [(i,r) for i,r in contra if 'AndImpairmentLoss' in contra_kind(_local(r,period))]
        if combined:
            contra = [combined[-1]]
        return [gross[0]] + [i for i,r in contra]

    def children(index,period):
        row=records[index];prefix=source_section(index,period);local=_local(row,period)
        earlier=[i for i,r in enumerate(records) if i!=index and not r.is_heading
                 and _fact(r,period) and same_profile(i,index,period)
                 and source_order(i,period)<source_order(index,period)]
        owned_sections={'CapitalSurplus':('資本剰余金',),'RetainedEarnings':('利益剰余金',),
                        'OtherRetainedEarnings':('その他利益剰余金',),
                        'PropertyPlantAndEquipment':('有形固定資産',),'PropertyPlantAndEquipmentIFRS':('有形固定資産',),
                        'IntangibleAssets':('無形固定資産','無形資産'),'IntangibleAssetsIFRS':('無形資産','無形固定資産'),
                        'InvestmentsAndOtherAssets':('投資その他の資産',)}
        if local in owned_sections:
            names=owned_sections[local]
            normalized=[re.sub(r'\s+','',part) for part in prefix]
            existing=next((i for i,part in enumerate(normalized) if part in names),None)
            if existing is not None:prefix=prefix[:existing+1]
            else:
                child_names=[source_section(i,period)[len(prefix)] for i in earlier
                             if source_section(i,period)[:len(prefix)]==prefix
                             and len(source_section(i,period))>len(prefix)
                             and source_section(i,period)[len(prefix)] in names]
                prefix=prefix+((child_names[0] if child_names else names[0]),)
        # IFRS tables sometimes present section headings at the same indent as
        # their numeric rows. Explicit taxonomy subtotals are safer boundaries
        # than inferring that all preceding liabilities belong to non-current.
        dependencies = {
            'LiabilitiesAndNetAssets': [{'Liabilities'},{'NetAssets'}],
            'LiabilitiesAndEquityIFRS': [{'LiabilitiesIFRS'},{'EquityIFRS','TotalEquityIFRS'}],
            'TotalLiabilitiesAndEquityIFRS': [{'LiabilitiesIFRS'},{'EquityIFRS','TotalEquityIFRS'}],
            'Liabilities': [{'CurrentLiabilities'},{'NoncurrentLiabilities'}],
            'LiabilitiesIFRS': [{'CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS'},
                                {'NonCurrentLiabilitiesIFRS','NoncurrentLiabilitiesIFRS','NonCurrentLabilitiesIFRS'}],
            'Assets': [{'CurrentAssets'},{'NoncurrentAssets'}],
            'AssetsIFRS': [{'CurrentAssetsIFRS'}, {'NonCurrentAssetsIFRS','NoncurrentAssetsIFRS'}],
            'TotalAssetsIFRS': [{'CurrentAssetsIFRS'}, {'NonCurrentAssetsIFRS','NoncurrentAssetsIFRS'}],
            'EquityIFRS': [{'EquityAttributableToOwnersOfParentIFRS'},{'NonControllingInterestsIFRS'}],
            'TotalEquityIFRS': [{'EquityAttributableToOwnersOfParentIFRS'},{'NonControllingInterestsIFRS'}],
        }
        if local in dependencies:
            selected=[]
            for names in dependencies[local]:
                matches=[i for i in earlier if _local(records[i],period) in names]
                if matches:selected.append(max(matches,key=lambda i:source_order(i,period)))
            if selected:
                return selected
        if local in {'NonCurrentLiabilitiesIFRS','NoncurrentLiabilitiesIFRS','NonCurrentLabilitiesIFRS'}:
            boundaries=[i for i in earlier if _local(records[i],period) in {'CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS'}]
            if boundaries:
                boundary=max(source_order(i,period) for i in boundaries)
                return [i for i in earlier if source_order(i,period)>boundary
                        and source_section(i,period)[:len(prefix)]==prefix]
        candidates=[i for i in earlier if source_section(i,period)[:len(prefix)]==prefix]
        exact=[i for i in candidates if source_section(i,period)==prefix]
        groups={source_section(i,period)[:len(prefix)+1] for i in candidates
                if len(source_section(i,period))>len(prefix)}
        selected=list(exact)
        for group in groups:
            totals=[i for i in candidates if is_total(records[i],period) and (
                source_section(i,period)==group or
                source_section(i,period)==prefix and re.sub(r'\s+','',group[-1]) in owned_sections.get(_local(records[i],period),()))]
            if totals:
                selected.append(max(totals,key=lambda i:source_order(i,period)))
            else:
                selected.extend(i for i in candidates if source_section(i,period)[:len(group)]==group)
        selected=sorted(set(selected))
        suppressed=set()
        for i in selected:
            parts=net_parts(i,period,include_breakdown=True)
            if parts and all(part in selected for part in parts):
                suppressed.update(parts)
        selected=[i for i in selected if i not in suppressed]
        # A prior aggregate at the exact same section is a component only for
        # outer groups, not a second copy of the section's underlying leaves.
        same_totals=[i for i in selected if source_section(i,period)==prefix and is_total(records[i],period)]
        if same_totals and len(prefix)==0:
            selected=[i for i in selected if i in same_totals or source_section(i,period)]
        return selected

    plans={};coverage={}
    for period in periods:
        plans[period.key]={};coverage[period.key]={}
        for index,row in enumerate(records):
            if row.is_heading or _fact(row,period) is None:continue
            parts=net_parts(index,period)
            if parts:
                coverage[period.key][index]=net_parts(index,period,include_breakdown=True)
            elif is_total(row,period):
                parts=children(index,period)
            if parts:plans[period.key][index]=parts
    return plans,coverage


def _bs(writer: Writer, dataset: Dataset, statement: str):
    from .layout import build_balance_layout,role
    sheet='BS-A' if statement=='BS_A' else 'BS-L,E'
    writer.headers(sheet)
    source=[row for row in dataset.rows[statement] if not row.is_heading and _present(row)]
    plans,coverage=_bs_source_plans(source,writer.periods)
    layout=build_balance_layout(source,writer.periods,plans,coverage)
    positions={};line=2
    writer.style(sheet,line,2)
    _text(writer.book[sheet].cell(line,1),'資産の部' if statement=='BS_A' else '負債の部')
    line+=1;equity_started=False
    def equity(row):
        return role(row) in {'net_assets'} or any(
            '純資産' in '>'.join(cell.source_section if cell.source_section is not None else row.section)
            or '資本' in '>'.join(cell.source_section if cell.source_section is not None else row.section)
            for cell in row.values.values())
    for node in layout.order:
        row=layout.rows[node]
        if statement=='BS_LE' and not equity_started and equity(row):
            writer.style(sheet,line,25);_text(writer.book[sheet].cell(line,1),'純資産の部')
            line+=1;equity_started=True
        positions[node]=line
        aliases={'流動資産合計':'流動資産計','有形固定資産合計':'有形固定資産計',
                 '無形固定資産合計':'無形固定資産計','投資その他の資産合計':'投資その他の資産計',
                 '流動負債合計':'Ⅰ 流動負債計','固定負債合計':'Ⅱ 固定負債計',
                 '株主資本合計':'Ⅰ 株主資本計','その他の包括利益累計額合計':'Ⅱ その他の包括利益累計額計'}
        label=aliases.get(row.label,row.label)
        if _local(row) in {'NonControllingInterests','MinorityInterests','NonControllingInterestsIFRS'}:
            label='Ⅲ 非支配株主持分'
        elif _local(row)=='SubscriptionRightsToShares':label='Ⅳ 新株予約権'
        writer.record(sheet,line,row,style_row=_bs_style(row,statement,writer.template),label=label)
        if role(row) or _local(row) in TOTAL_LOCALS:
            writer.total_style(sheet,line,grand=role(row) in {'assets','net_assets','liabilities_equity'})
        line+=1
    def nested(node):
        result=[]
        for child in layout.graph[node]:
            if child in layout.spans:
                a,b=layout.spans[child]
                result.append((positions[child],positions[layout.order[a]],positions[layout.order[b]],nested(child)))
        return result
    for node in layout.order:
        if node not in layout.spans:continue
        a,b=layout.spans[node];proof={}
        for column,period in enumerate(writer.periods,2):
            parts=layout.plans.get(period.key,{}).get(node)
            if not parts:continue
            values=[writer.values.get((sheet,f'{get_column_letter(column)}{positions[child]}')) for child in parts]
            if any(not isinstance(value,Decimal) for value in values):continue
            expected=sum(values,Decimal(0))*writer.factor
            fact=layout.rows[node].values.get(period.key)
            precision=[leaf for child in parts for leaf in writer.precision.get(
                (sheet,f'{get_column_letter(column)}{positions[child]}'),[])]
            complete=bool(fact is not None and fact.value is not None and
                          abs(expected-fact.value)<=_tolerance([fact]+precision))
            alternate=False
            for original in layout.originals[node]:
                normal=plans.get(period.key,{}).get(original,[])
                all_parts=coverage.get(period.key,{}).get(original,normal)
                if set(all_parts)!=set(normal):alternate=True
            proof[period.key]={'expected':expected,'complete':complete,'alternative':alternate,
                               'reason':'原表に合算された償却・減損累計とその内訳が併記されるため、重複を避け公表純額を保持。' if alternate else '当該年度の原文内訳が表示上の共通区分とは異なるため公表値を保持。'}
            if len(parts)>=2 and fact is not None and fact.value is not None:
                writer.check_total(sheet,positions[node],period,fact,precision,expected,'原文の直接構成項目（表示範囲の検証前）')
        writer.uniform_sum(sheet,positions[node],positions[layout.order[a]],positions[layout.order[b]],
                           row=layout.rows[node],nested=nested(node),proof=proof,
                           note='原文で確認した親子関係を全年共通の順序へ配置。子の公表小計とその内訳は一度だけ集計。')
    for original,by_period in layout.origins.items():
        for period_key,node in by_period.items():
            writer.source_addresses.setdefault(original,{})[period_key]={
                'sheet':sheet,'address':f'{get_column_letter(next(i for i,p in enumerate(writer.periods,2) if p.key==period_key))}{positions[node]}',
                'row_key':layout.rows[node].key}
    writer.layout_metadata.setdefault(sheet,{})['nodes']=[{
        'row':positions[node],'row_key':layout.rows[node].key,'role':role(layout.rows[node]),
        'label':writer.book[sheet].cell(positions[node],1).value,
        'children':[positions[i] for i in layout.graph[node]],
        'original_keys':[source[i].key for i in layout.originals[node]],
    } for node in layout.order]
    writer.layout_metadata[sheet]['main_end_row']=line-1
    writer.finish_sheet(sheet,line-1)


def _cf(writer: Writer, dataset: Dataset):
    from .presentation import template_rows
    writer.headers('CF')
    projected=template_rows(dataset,'CF')
    slots={int(row.key.rsplit(':',1)[-1]):row for row in projected if row.key.startswith('template:CF:')}
    extras=[row for row in projected if not row.key.startswith('template:CF:') and not row.is_heading and _present(row)]
    source=writer.template['CF']
    # The three working-capital inputs remain consecutive, including absent
    # categories: a blank can be filled by the user without changing any SUM.
    used={slot for slot,row in slots.items() if _present(row)}|{2,22,23,24,25,26,33,40,41,42,54,55,64,68}
    positions={};layout=[]
    for slot in range(2,69):
        for extra in extras:
            if CF_GROUPS.get(getattr(extra,'display_group','operating_adjustments'))==slot:
                layout.append((None,extra))
        if slot in used:layout.append((slot,slots.get(slot)))
    for number,(slot,row) in enumerate(layout,2):
        if slot is not None:positions[slot]=number
        style_slot=slot or (21 if getattr(row,'display_group','')=='operating_adjustments' else
                           31 if getattr(row,'display_group','')=='operating_working' else
                           39 if getattr(row,'display_group','')=='operating_payments' else
                           53 if getattr(row,'display_group','')=='investing' else
                           63 if getattr(row,'display_group','')=='financing' else 66)
        writer.style('CF',number,style_slot)
        label=(source.cell(slot,1).value if slot else row.label) or (row.label if row else '')
        if slot==47:label='無形固定資産の売却'
        if row is not None:writer.record('CF',number,row,label=label)
        else:_text(writer.book['CF'].cell(number,1),label)
        if slot is None:
            # Original extras retain a readable font. A long wrapped label
            # receives enough height instead of colliding with the next row.
            cell=writer.book['CF'].cell(number,1)
            if cell.alignment.wrap_text:
                width=sum(1 if unicodedata.east_asian_width(c) in {'W','F'} else 0.5 for c in str(label))
                lines=ceil(width/max(writer.book['CF'].column_dimensions['A'].width,1))
                if lines>1:
                    writer.book['CF'].row_dimensions[number].height=max(
                        writer.book['CF'].row_dimensions[number].height or 12,lines*((cell.font.sz or 8)+4))
        if slot in {22,26,33,40,54,64,66,68}:
            writer.total_style('CF',number,grand=slot==68)
        if slot in {40,54,64,66,68}:writer.fit_label('CF',number)
    extras_positions={row.key:number for number,(slot,row) in enumerate(layout,2) if slot is None}
    def selected(components,groups=()):
        return [positions[c] for c in components if c in positions]+[extras_positions[r.key] for r in extras if getattr(r,'display_group','') in groups]
    def summed(target,rows,*,nested=None,net=False):
        if target not in positions or not rows:return
        proof={}
        for column,period in enumerate(writer.periods,2):
            letter=get_column_letter(column)
            values=[writer.values.get(('CF',f'{letter}{r}')) for r in rows]
            available=[value for value in values if isinstance(value,Decimal)]
            if not available:continue
            expected=sum(available,Decimal(0))*writer.factor
            fact=slots.get(target).values.get(period.key) if slots.get(target) else None
            info={'expected':expected,'complete':True}
            if net and fact is not None and fact.value is not None:
                precision=_unique_cells([leaf for r in rows for leaf in writer.precision.get(('CF',f'{letter}{r}'),[])])
                if abs(expected-fact.value)>_tolerance([fact]+precision):
                    info.update(force_fallback=True,complete=False,
                        reason='営業・投資・財務CFと換算差額だけでは公表現金増減額を説明できないため、未識別の追加調整を推測せず公表値を保存。')
            proof[period.key]=info
        writer.uniform_sum('CF',positions[target],min(rows),positions[target]-1,
                           row=slots.get(target),nested=nested,proof=proof,
                           note='同じCF区分の符号付き開示値を全年同一の連続範囲で集計。ラベルの(+)(-)で再反転しません。')
    summed(22,selected(range(3,22),('operating_adjustments',)))
    summed(26,selected([23,24,25]))
    wc=(positions[26],positions[23],positions[25],[])
    summed(33,selected([22,26,27,28,29,30,31,32],('operating_working',)),nested=[wc])
    summed(40,selected([33,34,35,36,37,38,39],('operating_payments',)))
    writer.ratio('CF',positions[41],positions[40],positions[40],growth=True)
    investing=selected(range(43,54),('investing',))
    financing=selected(range(56,64),('financing',))
    summed(54,investing);summed(64,financing)
    if 66 in positions:
        corrections=[(None,positions[41],positions[41],[])]
        if investing:corrections.append((positions[54],min(investing),positions[54]-1,[]))
        if financing:corrections.append((positions[64],min(financing),positions[64]-1,[]))
        summed(66,selected([40,54,64,65]),nested=corrections,net=True)
    summed(68,selected([66,67],('cash_bridge',)))
    last=1+len(layout);summary=last+2
    writer.style('CF',last+1,69)
    for offset,template_row,flow in [(0,70,40),(1,71,54),(2,72,64)]:
        writer.style('CF',summary+offset,template_row)
        _text(writer.book['CF'].cell(summary+offset,1),source.cell(template_row,1).value)
        for column,period in enumerate(writer.periods,2):
            letter=get_column_letter(column);ref=f'{letter}{positions[flow]}'
            previous=f'{get_column_letter(column-1)}{positions[flow]}'
            sign=f'IF({ref}>0,"+",IF({ref}<0,"－","0"))'
            arrow=(f'IF(ISNUMBER({previous}),IF({ref}>{previous},"↗",IF({ref}<{previous},"↘","→")),"")' if column>2 else '""')
            expression=f'=IF(ISNUMBER({ref}),{sign}&{arrow},"")'
            value=writer.values.get(('CF',ref));before=writer.values.get(('CF',previous)) if column>2 else None
            expected=None
            if isinstance(value,Decimal):
                expected='+' if value>0 else '－' if value<0 else '0'
                if isinstance(before,Decimal):expected+='↗' if value>before else '↘' if value<before else '→'
            writer.formula('CF',summary+offset,column,expression,expected,monetary=False,
                           note='符号は当年値、矢印は前年との実数比較。同額→、ゼロ0。')
    writer.style('CF',summary+3,73)
    _text(writer.book['CF'].cell(summary+3,1),source.cell(73,1).value)
    writer.fit_label('CF',summary+3)
    writer.ratio('CF',summary+3,positions[40],positions[54],conditional=True)
    writer.layout_metadata.setdefault('CF',{}).update({
        'roles':{str(slot):number for slot,number in positions.items()},
        'working_capital_rows':[positions[n] for n in [23,24,25]],
        'main_end_row':last,'summary_start_row':summary,'summary_end_row':summary+3})
    writer.finish_sheet('CF',summary+3)


def _analysis(writer: Writer, dataset: Dataset):
    """Reference-workbook measures linked to the editable visible balances."""
    from .analysis import analyze_dataset,metric_terms
    analysis=analyze_dataset(dataset)
    specifications={
        'net_noncurrent_assets':('BS-A',3,53),
        'net_current_assets':('BS-A',4,54),
        'net_working_capital':('BS-A',5,55),
        'invested_capital':('BS-A',7,57),
        'net_current_liabilities':('BS-L,E',2,40),
        'interest_bearing_debt':('BS-L,E',4,42)}
    positions={name:(sheet,writer.main_ends[sheet]+offset) for name,(sheet,offset,_) in specifications.items()}
    def address(key,period):
        if key.startswith('analysis:'):
            return positions.get(key.split(':',1)[1])
        mappings=writer.source_addresses.get(key,{})
        item=mappings.get(period.key) or next(iter(mappings.values()),None)
        if item:return item['sheet'],int(re.search(r'\d+$',item['address']).group())
        return None
    # Dependencies are evaluated before their consumers despite their visual
    # positions on separate sheets.
    order=['net_noncurrent_assets','net_current_assets','net_current_liabilities',
           'net_working_capital','invested_capital','interest_bearing_debt']
    for name in order:
        sheet,target=positions[name];row=analysis.metrics[name]
        writer.style(sheet,target,specifications[name][2])
        _text(writer.book[sheet].cell(target,1),row.label)
        writer.total_style(sheet,target,grand=name=='invested_capital')
        selected={};signatures=[];unresolved={}
        for period in writer.periods:
            selected[period.key]=set();unresolved[period.key]=[]
            for sign,key,fact in metric_terms(row.values[period.key]):
                ref=address(key,period)
                if ref is None:unresolved[period.key].append(key);continue
                signature=(*ref,sign)
                selected[period.key].add(signature)
                if signature not in signatures:signatures.append(signature)
        if not signatures:
            # There is no proven input, including no evidence for a zero debt.
            signatures=[(sheet,target,0)]
        start=writer.helper_next.get(sheet,1000)
        for ref_sheet,ref_row,sign in signatures:
            masks={};values={}
            for column,period in enumerate(writer.periods,2):
                visible=writer.values.get((ref_sheet,f'{get_column_letter(column)}{ref_row}'))
                masks[period.key]=Decimal(1 if (ref_sheet,ref_row,sign) in selected[period.key] or visible is None else 0)
                values[period.key]=visible*sign if masks[period.key] and isinstance(visible,Decimal) else Decimal(0)
            mask=writer.helper(sheet,'分析の対象区分: '+name,masks)
            number=writer.helper(sheet,'分析入力（表示BSへの参照）: '+name,values)
            for column,period in enumerate(writer.periods,2):
                letter=get_column_letter(column);ref=f"'{ref_sheet}'!{letter}{ref_row}"
                expression=(f'=IF(AND({letter}{mask}=1,ISNUMBER({ref})),{ref}*({sign}),0)' if sign else '=0')
                writer.book[sheet].cell(number,column).value=expression
                writer.cached[(sheet,f'{letter}{number}')]=values[period.key]
                writer.helpers[-1]['values'][period.key].update(formula=expression,reference=ref,coefficient=sign)
        end=writer.helper_next[sheet]-1
        # Interleaved selector rows must not enter the monetary SUM. Move the
        # linked values into one consecutive block, retaining simple SUM.
        term_start=writer.helper_next[sheet]
        linked_rows=list(range(start+1,end+1,2))
        for linked in linked_rows:
            number=writer.helper(sheet,'分析の連続集計入力: '+name,{p.key:Decimal(0) for p in writer.periods})
            for column,period in enumerate(writer.periods,2):
                letter=get_column_letter(column);expression=f'={letter}{linked}'
                value=writer.cached.get((sheet,f'{letter}{linked}'),Decimal(0))
                writer.book[sheet].cell(number,column).value=expression
                writer.cached[(sheet,f'{letter}{number}')]=value
                writer.helpers[-1]['values'][period.key].update(display_value=str(value),formula=expression)
        term_end=writer.helper_next[sheet]-1
        permitted={};needed={};valid={}
        for column,period in enumerate(writer.periods,2):
            meta=analysis.metadata[name][period.key]
            permitted[period.key]=Decimal(1 if meta['complete'] and selected[period.key] and not unresolved[period.key] else 0)
            needed[period.key]=Decimal(len(selected[period.key]))
            valid[period.key]=sum((Decimal(1) for ref_sheet,ref_row,sign in selected[period.key]
                if isinstance(writer.values.get((ref_sheet,f'{get_column_letter(column)}{ref_row}')),Decimal)),Decimal(0))
        allowed=writer.helper(sheet,'分析の算出可否（未識別区分を除外）: '+name,permitted)
        required=writer.helper(sheet,'分析の必須開示入力数: '+name,needed)
        numeric=writer.helper(sheet,'分析の数値入力数: '+name,valid)
        # Completeness comes from the structured source analysis. A missing
        # required balance or explicit nil stays unknown; absent optional
        # rows in a complete disclosure are editable inputs, not source zeros.
        for column,period in enumerate(writer.periods,2):
            letter=get_column_letter(column)
            refs=[f"ISNUMBER('{ref_sheet}'!{letter}{ref_row})*1" for ref_sheet,ref_row,sign in selected[period.key]]
            # Stable per-term required flags provide an identical helper
            # formula as well as an identical visible analysis formula.
            count_expr='='+('+'.join(refs) if refs else '0')
            writer.book[sheet].cell(numeric,column).value=count_expr
            writer.cached[(sheet,f'{letter}{numeric}')]=valid[period.key]
            writer.helpers[-1]['values'][period.key].update(formula=count_expr)
            expression=f'=IF(AND({letter}{allowed}=1,{letter}{numeric}={letter}{required}),SUM({letter}{term_start}:{letter}{term_end}),"")'
            expected=None
            if permitted[period.key] and valid[period.key]==needed[period.key]:
                expected=sum((writer.cached.get((sheet,f'{letter}{r}'),Decimal(0)) for r in range(term_start,term_end+1)),Decimal(0))*writer.factor
            fact=row.values[period.key]
            writer.formula(sheet,target,column,expression,expected,row=row,source=fact,
                note=meta['definition']+'\n参照: '+meta['reference']+'\n表示BSの編集に連動する参照式。非表示行は原文の証拠と計算入力を保存。'+('\n未算出理由: '+meta['reason'] if meta['reason'] else ''))
            writer.bs_metrics.setdefault(name,{})[period.key]={'sheet':sheet,'address':f'{letter}{target}','row_key':row.key,
                'display_value':str(expected/writer.factor) if expected is not None else None}
        writer.layout_metadata.setdefault(sheet,{}).setdefault('analysis_rows',[]).append({
            'metric':name,'row':target,'helper_range':[term_start,term_end],
            'eligibility_helper_row':allowed,'required_helper_row':required,'numeric_helper_row':numeric,
            'inputs':[{'sheet':sh,'row':r,'sign':sign} for sh,r,sign in signatures]})
    for sheet in ['BS-A','BS-L,E']:
        writer.finish_sheet(sheet,max(number for sh,number in positions.values() if sh==sheet))
    return analysis.metadata


def _write_cached(path: Path, values):
    namespace='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    ET.register_namespace('',namespace)
    with zipfile.ZipFile(path) as archive:
        entries={info.filename:(info,archive.read(info.filename)) for info in archive.infolist()}
    for index,sheet in enumerate(SHEET_NAMES,1):
        name=f'xl/worksheets/sheet{index}.xml'
        info,raw=entries[name]
        root=ET.fromstring(raw)
        for cell in root.findall(f'.//{{{namespace}}}c'):
            key=(sheet,cell.get('r'))
            if key not in values:
                continue
            value=values[key]
            node=cell.find(f'{{{namespace}}}v')
            if node is None:node=ET.SubElement(cell,f'{{{namespace}}}v')
            if isinstance(value,str):
                cell.set('t','str');node.text=value
            elif value is None:
                cell.set('t','str');node.text=None
            else:
                cell.attrib.pop('t',None)
                node.text=str(value)
        entries[name]=(info,ET.tostring(root,encoding='utf-8',xml_declaration=True))
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for info,raw in entries.values():archive.writestr(info,raw)


def export_workbook(dataset: Dataset, output_path: Path, unit: str = 'auto') -> Path:
    from .presentation import prepare_dataset, detect_display_unit
    if not dataset.periods:
        raise ValueError('出力する年度がありません。')
    if len({p.key for p in dataset.periods})!=len(dataset.periods):
        raise ValueError('年度キーが重複しています。')
    prepared=prepare_dataset(dataset)
    if unit=='auto':unit=detect_display_unit(prepared)
    path=Path(output_path)
    if path.suffix.lower()!='.xlsx':raise ValueError('出力ファイルの拡張子は.xlsxにしてください。')
    writer=Writer(prepared,unit)
    _pl(writer,prepared)
    _bs(writer,prepared,'BS_A');_bs(writer,prepared,'BS_LE');_cf(writer,prepared)
    analysis_metadata=_analysis(writer,prepared)
    # Keep source metadata and emitted addresses reproducible in the matching
    # audit JSON. The service saves the audit again after this export.
    metadata={'format_version':3,'unit':unit,'cells':writer.cells,
              'template':'financial_template.xlsx','sheets':list(SHEET_NAMES),
              'helpers':writer.helpers,'layout':writer.layout_metadata,
              'source_addresses':writer.source_addresses,'bs_metrics':writer.bs_metrics,
              'analysis':analysis_metadata}
    prepared.export_metadata=metadata
    prepared.checks.extend(writer.checks)
    dataset.export_metadata=metadata
    dataset.checks.extend(writer.checks)
    for warning in prepared.warnings:
        if warning not in dataset.warnings:dataset.warnings.append(warning)
    for ws in writer.book:
        existing=ws['A1'].comment.text if ws['A1'].comment else ''
        extra=['要確認: '+warning for warning in dataset.warnings if '要確認: '+warning not in existing]
        if extra:
            ws['A1'].comment=Comment(existing+'\n'+'\n'.join(extra),'Zaimu10')
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='.zaimu10-',suffix='.xlsx',dir=path.parent,delete=False) as stream:
        temporary=Path(stream.name)
    try:
        writer.book.save(temporary)
        _write_cached(temporary,writer.cached)
        temporary.replace(path)
    finally:
        writer.book.close();writer.template.close();temporary.unlink(missing_ok=True)
    return path
