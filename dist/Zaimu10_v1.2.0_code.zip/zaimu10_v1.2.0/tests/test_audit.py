from dataclasses import asdict
from datetime import date
from decimal import Decimal
import json

import pytest

from zaimu10.audit import AuditError, load_result
from zaimu10.models import Cell, Dataset, Period, Row, Source


def saved(tmp_path):
    p = Period(date(2025,4,1), date(2026,3,31))
    d = Dataset('6947','図研','consolidated',[p])
    s = Source('S100TEST','original.xhtml','https://example.test/source',concept='{test}NetSales')
    c = Cell(Decimal('1234000'),s,components=[Cell(Decimal('1000'),s)],source_section=('売上',))
    d.rows['PL'] = [Row('sales','売上高','PL',values={p.key:c})]
    d.export_metadata = {'unit':'thousand','cells':[{'formula':'=SUM(B1:B2)'}]}
    raw = {'application':'Zaimu10','format_version':2,'dataset':asdict(d)}
    path = tmp_path/'6947_図研_2026-03-31.audit.json'
    path.write_text(json.dumps(raw,default=str),encoding='utf-8')
    return path,raw


def test_reopen_preserves_precise_values_sources_components_and_formula_as_text(tmp_path):
    path,_ = saved(tmp_path)
    result = load_result(path)
    row, = result.dataset.rows['PL']
    c = next(iter(row.values.values()))
    assert c.value == Decimal('1234000')
    assert c.components[0].value == Decimal('1000')
    assert c.source_section == ('売上',)
    assert c.source.url == 'https://example.test/source'
    assert result.dataset.export_metadata['cells'][0]['formula'] == '=SUM(B1:B2)'
    assert result.workbook.name == '6947_図研_2026-03-31.xlsx'
    assert not result.workbook.exists()  # Charts do not require Excel to remain alongside it.


@pytest.mark.parametrize('change', ['version','period','statement','nonfinite','outside'])
def test_invalid_saved_data_is_rejected_without_modifying_file(tmp_path,change):
    path,raw=saved(tmp_path)
    d=raw['dataset'];r=d['rows']['PL'][0];key=next(iter(r['values']))
    if change=='version':raw['format_version']=999
    if change=='period':d['periods'][0]['end']='2020-03-31'
    if change=='statement':r['statement']='CF'
    if change=='nonfinite':r['values'][key]['value']='NaN'
    if change=='outside':r['values']['1900-01-01/1900-12-31']=r['values'].pop(key)
    path.write_text(json.dumps(raw,default=str),encoding='utf-8');before=path.read_bytes()
    with pytest.raises(AuditError):load_result(path)
    assert path.read_bytes()==before
