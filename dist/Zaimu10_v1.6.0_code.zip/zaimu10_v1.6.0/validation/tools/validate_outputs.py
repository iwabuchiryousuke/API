#!/usr/bin/env python3
"""Independent exported-file checks; never execute workbook formulas.

Usage: python work/validate_v160_outputs.py [directory] [--report path]
The small Excel expression interpreter below reads cached operands. It shares
no calculation code with the exporter and rejects unsupported expressions.
"""
from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import re
import sys

from openpyxl import load_workbook
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.formula.translate import Translator
from openpyxl.utils.cell import range_boundaries

APP = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(APP))

FACTORS = {'yen': Decimal(1), 'thousand': Decimal(1000), 'million': Decimal(1000000)}
ANALYSIS_LABELS = {'正味固定資産', '正味流動資産', '正味(流動資産-流動負債)', '投下資本', '正味流動負債', '有利子負債'}
METRIC_SHEETS = {'正味固定資産':'BS-a','正味流動資産':'BS-a',
                 '正味(流動資産-流動負債)':'BS-a','投下資本':'BS-a',
                 '正味流動負債':'BS-le','有利子負債':'BS-le'}


def number(value):
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def side_style(border, name):
    return getattr(getattr(border, name, None), 'style', None)


def decimal(value):
    return Decimal(str(value))


def equal(a, b):
    if a in {None, ''} and b in {None, ''}:
        return True
    if number(a) and number(b):
        left, right = decimal(a), decimal(b)
        return abs(left - right) <= max(Decimal('1e-9'), abs(right) * Decimal('2e-14'))
    return a == b


def flatten(values):
    for value in values:
        if isinstance(value, list):
            yield from flatten(value)
        else:
            yield value


class Expression:
    """Parse Excel's expression subset into an AST, then evaluate lazily."""
    precedence = {'=':1, '<>':1, '<':1, '>':1, '<=':1, '>=':1, '&':2,
                  '+':3, '-':3, '*':4, '/':4, '^':5}

    def __init__(self, formula):
        self.tokens = [t for t in Tokenizer(formula).items if t.type != 'WHITE-SPACE']
        self.position = 0
        self.tree = self.expression()
        if self.position != len(self.tokens):
            raise ValueError('unparsed formula suffix')

    def peek(self):
        return self.tokens[self.position] if self.position < len(self.tokens) else None

    def take(self):
        token = self.peek()
        if token is None:
            raise ValueError('unexpected end')
        self.position += 1
        return token

    def expression(self, minimum=0):
        token = self.take()
        if token.type == 'OPERATOR-PREFIX':
            left = ('prefix', token.value, self.expression(6))
        elif token.type == 'FUNC' and token.subtype == 'OPEN':
            name, args = token.value[:-1].upper(), []
            if not (self.peek().type == 'FUNC' and self.peek().subtype == 'CLOSE'):
                while True:
                    args.append(self.expression())
                    if self.peek() and self.peek().type == 'SEP':
                        self.take()
                    else:
                        break
            close = self.take()
            if close.type != 'FUNC' or close.subtype != 'CLOSE':
                raise ValueError('function close expected')
            left = ('function', name, args)
        elif token.type == 'PAREN' and token.subtype == 'OPEN':
            left = self.expression()
            close = self.take()
            if close.type != 'PAREN' or close.subtype != 'CLOSE':
                raise ValueError('parenthesis close expected')
        elif token.type == 'OPERAND':
            left = ('operand', token.subtype, token.value)
        else:
            raise ValueError(f'unsupported token {token.type}/{token.subtype}:{token.value}')
        while self.peek() and self.peek().type == 'OPERATOR-INFIX':
            operator = self.peek().value
            rank = self.precedence.get(operator)
            if rank is None:
                raise ValueError(f'unsupported operator {operator}')
            if rank < minimum:
                break
            self.take()
            right = self.expression(rank + (0 if operator == '^' else 1))
            left = ('binary', operator, left, right)
        if self.peek() and self.peek().type == 'OPERATOR-POSTFIX':
            if self.take().value != '%':
                raise ValueError('unsupported postfix')
            left = ('percent', left)
        return left

    def evaluate(self, workbook, current_sheet):
        def reference(text):
            if '!' in text:
                sheet, coordinates = text.rsplit('!', 1)
                sheet = sheet.strip("'").replace("''", "'")
            else:
                sheet, coordinates = current_sheet, text
            if '[' in coordinates or '[' in sheet:
                raise ValueError('external workbook reference')
            c1, r1, c2, r2 = range_boundaries(coordinates.replace('$', ''))
            if None in {c1, r1, c2, r2} or (c2-c1+1)*(r2-r1+1) > 20000:
                raise ValueError('unbounded or oversized range')
            values = [workbook[sheet].cell(r, c).value
                      for r in range(r1, r2+1) for c in range(c1, c2+1)]
            values = [decimal(v) if number(v) else v for v in values]
            return values if ':' in coordinates else values[0]

        def numeric(value):
            if value is None or value == '':
                return Decimal(0)  # Excel arithmetic treats a referenced blank as 0.
            if number(value) or isinstance(value, bool):
                return Decimal(int(value)) if isinstance(value, bool) else decimal(value)
            raise ValueError('text used as arithmetic operand')

        def evaluate(node):
            kind = node[0]
            if kind == 'operand':
                subtype, text = node[1:]
                if subtype == 'NUMBER': return Decimal(text)
                if subtype == 'TEXT': return text[1:-1].replace('""', '"')
                if subtype == 'LOGICAL': return text.upper() == 'TRUE'
                if subtype == 'RANGE': return reference(text)
                raise ValueError(f'unsupported operand {subtype}:{text}')
            if kind == 'prefix':
                value = numeric(evaluate(node[2]))
                return value if node[1] == '+' else -value
            if kind == 'percent': return numeric(evaluate(node[1])) / 100
            if kind == 'binary':
                op, lnode, rnode = node[1:]
                left, right = evaluate(lnode), evaluate(rnode)
                if op == '&':
                    return str(left or '') + str(right or '')
                if op in {'=', '<>', '<', '>', '<=', '>='}:
                    if number(left) or number(right) or left in {None, ''} or right in {None, ''}:
                        left, right = numeric(left), numeric(right)
                    return {'=': lambda: left == right, '<>': lambda: left != right,
                            '<': lambda: left < right, '>': lambda: left > right,
                            '<=': lambda: left <= right, '>=': lambda: left >= right}[op]()
                left, right = numeric(left), numeric(right)
                return {'+': lambda:left+right, '-':lambda:left-right,
                        '*':lambda:left*right, '/':lambda:left/right,
                        '^':lambda:left**right}[op]()
            if kind == 'function':
                name, nodes = node[1:]
                if name == 'IF': return evaluate(nodes[1] if evaluate(nodes[0]) else nodes[2])
                if name == 'IFERROR':
                    try: return evaluate(nodes[0])
                    except (ArithmeticError, ValueError, TypeError): return evaluate(nodes[1])
                values = list(flatten([evaluate(n) for n in nodes]))
                if name == 'SUM': return sum((numeric(v) for v in values if number(v)), Decimal(0))
                if name == 'AVERAGE':
                    selected=[numeric(v)for v in values if number(v)]
                    if not selected:raise ValueError('AVERAGE has no numeric observations')
                    return sum(selected,Decimal(0))/len(selected)
                if name == 'MEDIAN':
                    selected=sorted(numeric(v)for v in values if number(v)); size=len(selected)
                    return selected[size//2] if size%2 else (selected[size//2-1]+selected[size//2])/2
                if name == 'COUNT': return Decimal(sum(number(v) for v in values))
                if name == 'COUNTA': return Decimal(sum(v not in {None, ''} for v in values))
                if name == 'ISNUMBER': return number(values[0])
                if name == 'AND': return all(values)
                if name == 'OR': return any(values)
                if name == 'NOT': return not values[0]
                if name == 'ABS': return abs(numeric(values[0]))
                if name == 'MAX': return max(numeric(v) for v in values)
                if name == 'MIN': return min(numeric(v) for v in values)
                if name == 'ROUND': return numeric(values[0]).quantize(Decimal(10) ** -int(values[1]))
                raise ValueError(f'unsupported function {name}')
            raise ValueError(f'unknown AST {kind}')
        return evaluate(self.tree)


def source_identity(source):
    return tuple(str(source.get(k, '')) for k in
                 ('doc_id','filename','context_id','concept','unit','basis','semantic_concept','table_path','original_label','raw_value'))


def source_leaves(cell):
    children = cell.get('components', [])
    if children:
        for child in children:
            yield from source_leaves(child)
    else:
        yield cell


def source_amount(cell, ledger):
    """Recompute declared source combinations independently of export caches."""
    children=cell.get('components',[])
    operation=cell.get('operation','')
    value=None if cell.get('nil')or cell.get('value')is None else decimal(cell['value'])
    if not children:
        identity=source_identity(cell['source'])
        expected=(str(cell.get('value')),bool(cell.get('nil')))
        if identity not in ledger or expected not in ledger[identity]:
            if value is None and cell['source'].get('concept','').startswith('analysis:'):
                return None
            raise ValueError('literal source identity/value is absent from the original ledger')
        return value
    values=[source_amount(child,ledger)for child in children]
    if not operation:
        identity=source_identity(cell['source'])
        if (str(cell.get('value')),bool(cell.get('nil')))not in ledger.get(identity,set()):
            raise ValueError('undesignated source combination is not a disclosed original total')
        return value
    if any(v is None for v in values):
        return None
    if operation in {'sum','net','asset_net'}:return sum(values,Decimal(0))
    if operation=='difference':
        keys=cell.get('component_keys',[])
        if keys in [
            ['metric:operating_profit','metric:nonoperating_income','metric:nonoperating_expense'],
            ['metric:ordinary_profit','metric:extraordinary_income','metric:extraordinary_expense']]:
            return values[0]+values[1]-values[2]
        if len(values)==2:return values[0]-values[1]
        raise ValueError('unproved difference operand semantics')
    if operation=='subtract':return values[0]-sum(values[1:],Decimal(0))
    if operation=='negate':
        if len(values)!=1:raise ValueError('negation has multiple operands')
        return -values[0]
    if operation.startswith('analysis_linear:'):
        signs=[int(x)for x in operation.split(':',1)[1].split(',')if x]
        if len(signs)!=len(values)or any(x not in {-1,1}for x in signs):
            raise ValueError('invalid source linear combination')
        return sum((sign*value for sign,value in zip(signs,values)),Decimal(0))
    raise ValueError('unsupported source operation: '+operation)


def validate_one(path):
    from zaimu10.audit import load_result
    from zaimu10.analysis import chart_data
    payload = json.loads(path.read_text(encoding='utf-8'))
    ds = payload['dataset']
    metadata = ds.get('export_metadata', {})
    book_path = path.with_name(path.name.removesuffix('.audit.json') + '.xlsx')
    formulas, cached = load_workbook(book_path, data_only=False), load_workbook(book_path, data_only=True)
    failures, counts, observations = [], Counter(), []
    def check(ok, category, **details):
        counts[category] += 1
        if not ok:
            failures.append({'check':category, **details})
    periods = sorted(ds['periods'], key=lambda p:(p['end'],p['start']))
    periodkeys = [p['start'] + '/' + p['end'] for p in periods]
    width = len(periods)
    check(formulas.sheetnames == ['PL', 'BS-a', 'BS-le', 'CF', 'FR', 'DCF', 'CAPM', 'CAGR'], 'eight_sheet_names', actual=formulas.sheetnames)
    check(width == 10, 'ten_annual_periods', actual=width)
    ledger = {}
    raw_dataset=payload.get('raw_dataset',ds)
    source_groups=list(raw_dataset['rows'].values())+[raw_dataset.get('analysis_inputs',[])]
    for rows in source_groups:
        for row in rows:
            for source_period,cell in row.get('values', {}).items():
                for leaf in source_leaves(cell):
                    identity = source_identity(leaf['source'])
                    original_value=(str(leaf.get('value')),bool(leaf.get('nil')))
                    ledger.setdefault(identity,set()).add(original_value)
                    ledger.setdefault(('period',source_period,identity),set()).add(original_value)
    entries, keyed = {}, {}
    for item in metadata.get('cells', []):
        sheet, address, period = item['sheet'], item['address'], item['period']
        entries[sheet, address] = item
        keyed[sheet, item.get('row_key'), period] = address
        actual = cached[sheet][address].value
        expected = item.get('display_value')
        if isinstance(expected, str):
            try: expected = Decimal(expected)
            except InvalidOperation: pass
        if hasattr(actual,'isoformat'): actual=actual.isoformat()[:10]
        check(equal(actual, expected), 'audit_cache_match', sheet=sheet, address=address,
              actual=str(actual), expected=str(expected))
        if hasattr(actual,'isoformat'):
            actual=actual.isoformat()[:10]
        expression = item.get('formula')
        if expression:
            check(getattr(formulas[sheet][address].value,'text',formulas[sheet][address].value) == expression, 'audit_formula_match', sheet=sheet, address=address)
        source = item.get('source')
        if source:
            for leaf in source_leaves(source):
                identity = source_identity(leaf['source'])
                if leaf['source'].get('concept', '').startswith('analysis:'):
                    continue
                expected_leaf = (str(leaf.get('value')), bool(leaf.get('nil')))
                check(identity in ledger and expected_leaf in ledger[identity], 'original_fact_provenance',
                      sheet=sheet, address=address, source=list(identity), value=expected_leaf[0])
                if period in periodkeys:
                    check(expected_leaf in ledger.get(('period',period,identity),set()),'original_fact_period_provenance',
                          sheet=sheet,address=address,period=period,source=list(identity),value=expected_leaf[0])
            try:
                independent_source=source_amount(source,ledger)
                declared_source=None if source.get('nil')or source.get('value')is None else decimal(source['value'])
                check(equal(independent_source,declared_source),'source_combination_amount',
                      sheet=sheet,address=address,operation=source.get('operation',''),
                      original_amount=str(independent_source),declared_amount=str(declared_source))
                if not expression:
                    factor=FACTORS[metadata['unit']]if source['source'].get('unit')=='JPY'else Decimal(1)
                    expected_original=independent_source/factor if independent_source is not None else None
                    check(equal(actual,expected_original),'source_literal_value',sheet=sheet,address=address,
                          actual=str(actual),expected_original=str(expected_original))
            except Exception as exc:
                check(False,'source_combination_supported',sheet=sheet,address=address,
                      operation=source.get('operation',''),reason=str(exc))
    # The fixture driver may attach export metadata to its raw merge. Resolve
    # that older key shape by exact original XBRL fact identity, never by label,
    # amount similarity, or assumed display order. Composite rows can represent
    # several original identities; each is still tied to one visible address.
    primary_addresses, leaf_addresses = {}, {}
    for (sheet,address), item in entries.items():
        if formulas[sheet][address].row >= 1000 or not item.get('source'):
            continue
        source = item['source']
        identity = source_identity(source['source'])
        primary_addresses.setdefault((sheet,item['period'],identity),set()).add(address)
        for leaf in source_leaves(source):
            leaf_addresses.setdefault((sheet,item['period'],source_identity(leaf['source'])),set()).add(address)
    source_addresses = metadata.get('source_addresses', {})
    from v160_net_checks import validate_net_presentation
    validate_net_presentation(ds,metadata,formulas,cached,ledger,check,counts,source_identity,source_leaves,equal)
    from v160_palette_checks import validate_palette
    validate_palette(ds,metadata,formulas,check)
    # Borders follow actual displayed structure. A taxonomy is_total hint
    # alone cannot turn an ordinary account into a visual subtotal.
    section_roles={'current_assets','ppe','intangibles','investments','noncurrent_assets','assets',
                   'current_liabilities','noncurrent_liabilities','liabilities','net_assets','liabilities_equity'}
    for sheet in ('BS-a','BS-le'):
        for node in metadata.get('layout',{}).get(sheet,{}).get('nodes',[]):
            row=node['row'];label=str(formulas[sheet].cell(row,1).value or '')
            if node.get('role')in section_roles or node.get('children')or label.endswith(('合計','計'))or re.match(r'^[ⅠⅡⅢⅣⅤⅥ]',label):continue
            for column in range(1,width+2):
                cell=formulas[sheet].cell(row,column)
                check(not side_style(cell.border,'top')and not side_style(cell.border,'bottom'),
                      'bs_ordinary_rows_no_horizontal_lines',sheet=sheet,address=cell.coordinate,
                      label=label,role=node.get('role'),top=side_style(cell.border,'top'),bottom=side_style(cell.border,'bottom'))
    # Coverage starts from original main-PL facts, including facts omitted by
    # a faulty presentation alias. An audit saying "unavailable" is not proof
    # of unavailability when a unique known original main-statement fact exists.
    primary_names={
        2:{'NetSales','NetSalesIFRS','RevenueIFRS','Revenue','OperatingRevenue','OperatingRevenue1','OperatingRevenue2','OperatingRevenue3','OperatingRevenueSEC'},
        4:{'CostOfSales','CostOfSalesIFRS'},
        8:{'SellingGeneralAndAdministrativeExpenses','SellingGeneralAndAdministrativeExpensesIFRS'},
        9:{'OperatingIncome','OperatingProfitLossIFRS','OperatingIncomeLoss'},
        17:{'IncomeBeforeIncomeTaxes','ProfitLossBeforeTaxIFRS','IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest'},
        18:{'IncomeTaxes','IncomeTaxExpenseIFRS','IncomeTaxesExpenseIFRS','IncomeTaxExpenseBenefit'},
        19:{'ProfitLoss','ProfitLossIFRS','NetIncomeLoss'},
        22:{'ProfitLossAttributableToOwnersOfParent','ProfitLossAttributableToOwnersOfParentIFRS','NetIncomeLossAttributableToParent'},
    }
    for column,period in enumerate(periodkeys,2):
        expected_basis=ds.get('period_bases',{}).get(period,ds.get('basis'))
        for row_number,names in primary_names.items():
            candidates={}
            for row in raw_dataset['rows']['PL']:
                cell=row.get('values',{}).get(period)
                if not cell or cell.get('nil')or cell.get('value')is None:continue
                source=cell.get('source',{})
                if source.get('unit')!='JPY' or source.get('basis')!=expected_basis:continue
                account=source.get('semantic_concept')or source.get('concept','')
                if not re.match(r'^\{https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(?:jppfs|jpigp)/',account)and not account.startswith('{urn:zaimu10:html-table:'):continue
                if account.rsplit('}',1)[-1]not in names:continue
                try:
                    parts=json.loads(row['key'].removeprefix('display:'))
                    dimensions,role=(parts[3],parts[4])if len(parts)in {8,9}else(parts[2],parts[3])
                except (ValueError,TypeError,IndexError):continue
                if dimensions or role!='duration':continue
                candidates[source_identity(source)]=cell
            if len(candidates)==1:
                actual=cached['PL'].cell(row_number,column).value
                check(number(actual),'known_standard_primary_input_displayed',period=period,
                      address=cached['PL'].cell(row_number,column).coordinate,source_local=(next(iter(candidates.values()))['source'].get('semantic_concept')or next(iter(candidates.values()))['source'].get('concept','')).rsplit('}',1)[-1])
                if row_number==2:
                    original=next(iter(candidates.values()))
                    expected=decimal(original['value'])/FACTORS[metadata['unit']]
                    check(equal(actual,expected),'known_standard_revenue_displayed',period=period,
                          address=cached['PL'].cell(row_number,column).coordinate,actual=str(actual),expected=str(expected))
        pretax,tax=cached['PL'].cell(17,column).value,cached['PL'].cell(18,column).value
        expected=decimal(tax)/decimal(pretax)if number(tax)and number(pretax)and pretax!=0 else None
        check(equal(cached['PL'].cell(24,column).value,expected),'effective_tax_visible_input_arithmetic',
              period=period,actual=str(cached['PL'].cell(24,column).value),expected=str(expected))
    def resolved_address(sheet,row,period):
        mapping = source_addresses.get(row['key'], {}).get(period)
        direct = mapping.get('address') if mapping else keyed.get((sheet,row['key'],period))
        if direct:
            return direct
        cell = row.get('values',{}).get(period)
        if cell is None:
            return None
        identity = source_identity(cell['source'])
        candidates = primary_addresses.get((sheet,period,identity),set())
        if len(candidates) == 1:
            counts['original_identity_address_resolution'] += 1
            return next(iter(candidates))
        candidates = leaf_addresses.get((sheet,period,identity),set())
        if len(candidates) == 1:
            counts['original_identity_address_resolution'] += 1
            return next(iter(candidates))
        return None
    for ws in formulas:
        visible_last = max((r for r in range(1, ws.max_row+1)
                            if not ws.row_dimensions[r].hidden and any(ws.cell(r,c).value is not None for c in range(1,ws.max_column+1))), default=1)
        print_ranges = re.findall(r'\$?[A-Z]+\$?(\d+):\$?[A-Z]+\$?(\d+)', str(ws.print_area))
        print_last = max((int(end) for _,end in print_ranges), default=0)
        check(print_last >= visible_last and print_last < 1000, 'visible_print_area', sheet=ws.title,
              last_visible=visible_last, print_last=print_last)
        for row in ws:
            for cell in row:
                check(cell.comment is None,'workbook_comments_removed',sheet=ws.title,address=cell.coordinate)
                if cell.value is not None:
                    check(not ws.row_dimensions[cell.row].hidden and cell.row < 1000,
                          'no_hidden_helper_values',sheet=ws.title,address=cell.coordinate)
                if cell.data_type != 'f':
                    continue
                formula=getattr(cell.value,'text',cell.value)
                if 'LINEST(' in formula.upper():
                    counts['linest_formulas_for_market_oracle']+=1
                    continue
                functions=[t.value[:-1].upper() for t in Tokenizer(formula).items if t.type=='FUNC' and t.subtype=='OPEN']
                check(all(f in ({'SUM','AVERAGE'} if ws.title=='CAPM' else {'MEDIAN'} if ws.title=='CAGR' else {'SUM','AVERAGE'} if ws.title=='DCF' else {'SUM'}) for f in functions),'approved_reference_functions_only',sheet=ws.title,address=cell.coordinate,formula=cell.value,functions=functions)
                try:
                    independent = Expression(formula).evaluate(cached, ws.title)
                    check(equal(independent, cached[ws.title][cell.coordinate].value), 'independent_formula_cache',
                          sheet=ws.title, address=cell.coordinate, expression=cell.value,
                          expected=str(independent), actual=str(cached[ws.title][cell.coordinate].value))
                except Exception as exc:
                    check(False, 'independent_formula_supported', sheet=ws.title, address=cell.coordinate,
                          expression=cell.value, reason=f'{type(exc).__name__}: {exc}')
        if ws.title not in {'BS-a', 'BS-le', 'CF'}:
            continue
        for row in range(2, min(visible_last, 999)+1):
            expressions = [ws.cell(row,c).value for c in range(2,width+2)]
            selected = any(isinstance(f,str) and re.search(r'\bSUM\(',f,re.I) for f in expressions)
            selected |= ws.cell(row,1).value in ANALYSIS_LABELS
            if not selected:
                continue
            normalized = []
            for column,expression in enumerate(expressions,2):
                if not isinstance(expression,str) or not expression.startswith('='):
                    normalized.append(None)
                else:
                    normalized.append(Translator(expression, origin=ws.cell(row,column).coordinate).translate_formula(f'B{row}'))
            # A genuine source-only year can remain a disclosed literal, and
            # an unavailable analytical year stays blank. Across calculated
            # years the visible source membership should remain consistent.
            calculated = [f for f in normalized if f is not None]
            counts['annual_sum_formula_rows_reviewed'] += 1
            if len(set(calculated)) > 1:
                observations.append({'check':'annual_formula_variation','sheet':ws.title,
                                     'row':row,'label':ws.cell(row,1).value,'normalized':normalized})
            for expression in [e for e in expressions if isinstance(e,str) and e.startswith('=')]:
                for arg in [part for group in re.findall(r'\bSUM\(([^()]*)\)',expression,re.I) for part in group.split(',')]:
                    # A single referenced cell is a contiguous one-cell range.
                    check(bool(re.fullmatch(r"(?:'[^']+'!|[A-Za-z_][\w]*!)?\$?[A-Z]+\$?\d+(?::\$?[A-Z]+\$?\d+)?",arg)),
                          'contiguous_sum_range', sheet=ws.title, row=row, expression=expression, argument=arg)
    # New reference: all six labelled analytical rows remain present, even
    # when source uncertainty correctly leaves an individual year's cell blank.
    for label,sheet in METRIC_SHEETS.items():
        positions=[r for r in range(1,min(formulas[sheet].max_row,999)+1)
                   if formulas[sheet].cell(r,1).value==label]
        check(len(positions)==1,'analysis_metric_row_exists',sheet=sheet,label=label,rows=positions)
        if positions:
            row=positions[0]
            check(not formulas[sheet].row_dimensions[row].hidden,'analysis_row_visible',sheet=sheet,row=row)
            for col in range(1,width+2):
                border=formulas[sheet].cell(row,col).border
                check(not side_style(border,'top') and not side_style(border,'bottom'),'analysis_reference_borderless',
                      sheet=sheet,address=formulas[sheet].cell(row,col).coordinate,
                      top=side_style(border,'top'),bottom=side_style(border,'bottom'))
            for col,period in enumerate(periodkeys,2):
                cell=formulas[sheet].cell(row,col)
                entry=entries.get((sheet,cell.coordinate),{})
                if cached[sheet][cell.coordinate].value is None:
                    name=entry.get('row_key','').removeprefix('analysis:')
                    explanation=metadata.get('analysis',{}).get(name,{}).get(period,{})
                    note=(cell.comment.text if cell.comment else '')
                    check(bool(explanation.get('reason') or 'nil' in note or '未算出' in note),
                          'analysis_blank_has_reason',sheet=sheet,address=cell.coordinate,label=label)
    # Rebuild the six exact reference definitions from their signed original
    # source identities and actual visible table operands. This uses neither
    # analysis.py's amounts nor the exporter's cached expected-value field.
    for name, annual in metadata.get('analysis',{}).items():
        for period, definition in annual.items():
            target=metadata.get('bs_metrics',{}).get(name,{}).get(period)
            expected=None;reason=''
            if target is None:
                check(False,'analysis_semantic_operands',metric=name,period=period,reason='missing analytical display address')
                continue
            actual=cached[target['sheet']][target['address']].value
            if definition.get('complete'):
                expected=Decimal(0)
                for term in definition.get('terms',[]):
                    key=term['key']
                    operand=(metadata.get('bs_metrics',{}).get(key.removeprefix('analysis:'),{}).get(period)
                             if key.startswith('analysis:') else source_addresses.get(key,{}).get(period))
                    omitted=metadata.get('layout',{}).get('BS-le',{}).get('debt_presentation',{}).get('omitted_zero_notes',{})
                    if operand is None and period in omitted.get(key,[]): continue
                    if operand is None:
                        reason='missing original source address: '+key
                        break
                    amount=cached[operand['sheet']][operand['address']].value
                    if not number(amount):
                        reason='known semantic operand has no numeric display value: '+key
                        break
                    expected+=Decimal(term['sign'])*decimal(amount)
            check(not reason and equal(actual,expected),'analysis_semantic_operands',metric=name,period=period,
                  address=target['address'],actual=str(actual),expected=str(expected),reason=reason)
    # Ordinary BS/CF arithmetic must be directly editable visible formulas.
    # Growth ratios and the explicit sign/arrow summary retain their own IFs.
    summary_rows={r for r in range(1,min(formulas['CF'].max_row,999)+1)
                  if formulas['CF'].cell(r,1).value in {'営業CF','投資CF','財務CF','営業CF対投資CF比率'}}
    for sheet in ['BS-a','BS-le','CF']:
        for row in formulas[sheet]:
            label=formulas[sheet].cell(row[0].row,1).value
            growth=sheet=='CF' and isinstance(label,str) and ('増加率' in label or '増減率' in label)
            for cell in row[1:width+1]:
                if cell.data_type!='f' or (sheet=='CF' and (cell.row in summary_rows or growth)):
                    continue
                check(not re.search(r'\b(?:IF|IFERROR|ISNUMBER|COUNT|COUNTA|AND|OR)\(',cell.value,re.I),
                      'ordinary_formula_simple',sheet=sheet,address=cell.coordinate,formula=cell.value)
                refs=[t.value for t in Tokenizer(cell.value).items if t.type=='OPERAND' and t.subtype=='RANGE']
                for ref in refs:
                    coordinates=ref.rsplit('!',1)[-1]
                    for rn in re.findall(r'\$?[A-Z]+\$?(\d+)',coordinates):
                        check(int(rn)<1000,'ordinary_formula_visible_references',sheet=sheet,address=cell.coordinate,reference=ref)
    for row in [2,4,5,8,9,12,13,14,15,16,17,18,19,22,24]:
        for column in range(2,width+2):
            cell=formulas['PL'].cell(row,column)
            if cell.data_type=='f':
                check(not re.search(r'\b(?:IF|IFERROR|ISNUMBER|COUNT|COUNTA|AND|OR)\(',cell.value,re.I),
                      'ordinary_pl_formula_simple',address=cell.coordinate,formula=cell.value)
    # Source-to-display addresses independently expose any group member put
    # below its grand total by cross-year row insertion.
    for statement, sheet, totals in [('BS_A','BS-a',{'Assets','AssetsIFRS','TotalAssetsIFRS'}),
                                    ('BS_LE','BS-le',{'LiabilitiesAndNetAssets','LiabilitiesAndEquityIFRS','TotalLiabilitiesAndEquityIFRS'})]:
        for period in periodkeys:
            total_rows = []
            mapped_rows = []
            for row in ds['rows'][statement]:
                cell = row.get('values', {}).get(period)
                if not cell or cell.get('value') is None:
                    continue
                address = resolved_address(sheet,row,period)
                if not address:
                    continue
                rn = formulas[sheet][address].row
                if rn >= 1000:
                    continue
                mapped_rows.append((rn,row['label']))
                local = (cell['source'].get('semantic_concept') or cell['source'].get('concept','')).rsplit('}',1)[-1]
                if local in totals:
                    total_rows.append(rn)
            check(bool(total_rows), 'grand_total_present', sheet=sheet, period=period)
            if total_rows:
                grand = max(total_rows)
                for rn,label in mapped_rows:
                    check(rn <= grand, 'members_before_grand_total', sheet=sheet, period=period,
                          member_row=rn, member=label, total_row=grand)
            source_items = []
            for row in ds['rows'][statement]:
                cell = row.get('values', {}).get(period)
                address = resolved_address(sheet,row,period)
                if cell and cell.get('value') is not None and address:
                    source_items.append((row,cell,formulas[sheet][address].row))
            group_totals = {'CurrentAssets','CurrentAssetsIFRS','TotalCurrentAssetsIFRS',
                            'NoncurrentAssets','NonCurrentAssetsIFRS','NoncurrentAssetsIFRS',
                            'PropertyPlantAndEquipment','PropertyPlantAndEquipmentIFRS',
                            'IntangibleAssets','IntangibleAssetsIFRS','InvestmentsAndOtherAssets',
                            'CurrentLiabilities','CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS',
                            'NoncurrentLiabilities','NonCurrentLiabilitiesIFRS','NoncurrentLiabilitiesIFRS',
                            'NonCurrentLabilitiesIFRS','ShareholdersEquity','ValuationAndTranslationAdjustments'}
            for total, fact, display_total in source_items:
                local = (fact['source'].get('semantic_concept') or fact['source'].get('concept','')).rsplit('}',1)[-1]
                section = fact.get('source_section')
                order = fact.get('source_order')
                if local not in group_totals or section is None or order is None or display_total >= 1000:
                    continue
                for member, mfact, display_member in source_items:
                    msection, morder = mfact.get('source_section'), mfact.get('source_order')
                    if msection is None or morder is None or morder >= order or display_member >= 1000:
                        continue
                    if list(msection[:len(section)]) == list(section):
                        check(display_member <= display_total, 'source_group_members_before_total',
                              sheet=sheet,period=period,member=member['label'],member_row=display_member,
                              total=total['label'],total_row=display_total)
    # CF summary is directly below the closing balance and uses actual signed
    # amounts for both signs and direction, including negative-year changes.
    cf = formulas['CF']; cf_cache = cached['CF']
    cf_roles={}
    for (sheet,address),item in entries.items():
        if sheet=='CF' and str(item.get('row_key','')).startswith('template:CF:'):
            cf_roles.setdefault(cf[address].row,set()).add(item['row_key'])
    subtotal_roles={f'template:CF:{n}' for n in [22,26,33,40,54,64,66,68]}
    for row,roles in cf_roles.items():
        if roles & subtotal_roles:
            styles=[(side_style(cf.cell(row,column).border,'top'),side_style(cf.cell(row,column).border,'bottom'))
                    for column in range(1,width+2)]
            if roles & {'template:CF:22','template:CF:26'}:
                check(all(top and bottom for top,bottom in styles),'cf_subtotal_both_horizontal_rules',row=row,roles=sorted(roles),styles=styles)
            check(len(set(styles))==1,'cf_total_border_consistency',row=row,roles=sorted(roles),styles=styles)
        else:
            for column in range(1,width+2):
                border=cf.cell(row,column).border
                check(not side_style(border,'top') and not side_style(border,'bottom'),'cf_ordinary_rows_no_horizontal_lines',
                      address=cf.cell(row,column).coordinate,roles=sorted(roles),
                      top=side_style(border,'top'),bottom=side_style(border,'bottom'))
    summary = next((r for r in range(1,min(cf.max_row,999)+1) if cf.cell(r,1).value == '営業CF'),None)
    closing = None
    flow_addresses = {}
    for flow,slot in [('operating',40),('investing',54),('financing',64),('cash',68)]:
        flow_addresses[flow] = [keyed.get(('CF',f'template:CF:{slot}',p)) for p in periodkeys]
        if flow == 'cash':
            closing = next((cf[a].row for a in flow_addresses[flow] if a),None)
    check(summary is not None and closing is not None and 1 <= summary-closing <= 2,
          'cf_summary_near_closing', summary=summary, closing=closing)
    if summary:
        for offset,flow in enumerate(['operating','investing','financing']):
            previous = None
            for column,address in enumerate(flow_addresses[flow],2):
                amount = cf_cache[address].value if address else None
                expected = None
                if number(amount):
                    expected = '+' if amount > 0 else '－' if amount < 0 else '0'
                    if number(previous): expected += '↗' if amount > previous else '↘' if amount < previous else '→'
                actual = cf_cache.cell(summary+offset,column).value
                check(equal(actual,expected), 'cf_sign_and_arrow', flow=flow, column=column,
                      amount=amount, previous=previous, actual=actual, expected=expected)
                previous = amount
        for column,(op,inv) in enumerate(zip(flow_addresses['operating'],flow_addresses['investing']),2):
            operating = cf_cache[op].value if op else None
            investing = cf_cache[inv].value if inv else None
            expected = decimal(operating) / -decimal(investing) if number(operating) and number(investing) and operating > 0 and investing < 0 else None
            check(equal(cf_cache.cell(summary+3,column).value,expected),'cf_operating_investing_ratio',
                  column=column, actual=str(cf_cache.cell(summary+3,column).value), expected=str(expected))
    # Graph model against the actual cached table, rather than audit expected
    # fields. All main PL, BS and CF series use final displayed amounts.
    loaded = load_result(path).dataset
    chart = chart_data(loaded, metadata.get('unit','auto'))
    pl_rows = {'revenue':2,'gross_profit':5,'operating_profit':9,'net_profit':19}
    for name,rownum in pl_rows.items():
        for column,actual in enumerate(chart['PL'][name]['values'],2):
            check(equal(actual,cached['PL'].cell(rownum,column).value), 'chart_pl_cache', series=name,column=column)
    for name,numerator,table_row in [('gross_margin',5,6),('operating_margin',9,10),('net_margin',19,None)]:
        for column,actual in enumerate(chart['PL'][name]['values'],2):
            n,d = cached['PL'].cell(numerator,column).value, cached['PL'].cell(2,column).value
            expected = decimal(n)/decimal(d) if number(n) and number(d) and d != 0 else None
            check(equal(actual,expected), 'chart_margin_cache',series=name,column=column,
                  actual=str(actual),expected=str(expected))
            if table_row:
                check(equal(actual,cached['PL'].cell(table_row,column).value), 'chart_margin_table_cache',
                      series=name,column=column)
    bs_names = {'assets':{'Assets','AssetsIFRS','TotalAssetsIFRS'},
                'current_assets':{'CurrentAssets','CurrentAssetsIFRS','TotalCurrentAssetsIFRS'},
                'noncurrent_assets':{'NoncurrentAssets','NonCurrentAssetsIFRS','NoncurrentAssetsIFRS'},
                'liabilities':{'Liabilities','LiabilitiesIFRS'},
                'current_liabilities':{'CurrentLiabilities','CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS'},
                'noncurrent_liabilities':{'NoncurrentLiabilities','NonCurrentLiabilitiesIFRS','NoncurrentLiabilitiesIFRS','NonCurrentLabilitiesIFRS'},
                'equity':{'NetAssets','EquityIFRS','TotalEquityIFRS'}}
    for name,names in bs_names.items():
        statement, sheet = ('BS_A','BS-a') if name in {'assets','current_assets','noncurrent_assets'} else ('BS_LE','BS-le')
        for index,period in enumerate(periodkeys):
            matches=[]
            for row in ds['rows'][statement]:
                cell=row.get('values',{}).get(period)
                if cell and (cell['source'].get('semantic_concept') or cell['source'].get('concept','')).rsplit('}',1)[-1] in names:
                    address=resolved_address(sheet,row,period)
                    if address:matches.append(address)
            if matches:
                check(equal(chart['BS'][name]['values'][index],cached[sheet][matches[-1]].value),
                      'chart_bs_cache',series=name,period=period,address=matches[-1])
    for name,addresses_ in flow_addresses.items():
        for index,address in enumerate(addresses_):
            if address:
                check(equal(chart['CF'][name]['values'][index],cf_cache[address].value),
                      'chart_cf_cache',series=name,period=periodkeys[index],address=address)
    unique_inputs={key:values for key,values in ledger.items()if not(key and key[0]=='period')}
    formulas.close();cached.close()
    return {'code':ds['code'],'company':ds['company'],'workbook':str(book_path),
            'unique_original_source_input_identities':len(unique_inputs),
            'unique_original_source_identity_value_pairs':sum(len(values)for values in unique_inputs.values()),
            'checks':dict(counts),'failure_count':len(failures),'failures':failures,'observations':observations}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',nargs='?',default=str(APP/'results'))
    parser.add_argument('--report',default='validation_output.json')
    parser.add_argument('--expected-companies',type=int,default=None)
    args=parser.parse_args()
    if args.expected_companies is None:args.expected_companies=len(list(Path(args.directory).glob('*.audit.json')))
    files=sorted(Path(args.directory).glob('*.audit.json'))
    records=[]
    for path in files:
        try: records.append(validate_one(path))
        except Exception as exc:
            records.append({'path':str(path),'failure_count':1,'failures':[{'check':'file_validation',
                            'reason':f'{type(exc).__name__}: {exc}'}]})
    unique_companies=len({record.get('code')for record in records if record.get('code')})
    report={'directory':str(Path(args.directory)),'companies':len(records),'unique_companies':unique_companies,
            'failure_count':sum(r['failure_count']for r in records),
            'expected_companies':args.expected_companies,'expected_company_count':len(records)==args.expected_companies and unique_companies==args.expected_companies,'results':records}
    Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(json.dumps({'report':args.report,'companies':len(records),'failure_count':report['failure_count']},ensure_ascii=False))
    return 0 if records and len(records)==args.expected_companies and unique_companies==args.expected_companies and report['failure_count']==0 else 1


if __name__=='__main__':
    raise SystemExit(main())
