"""Auditable reference-workbook analysis and chart data.

Amounts stay in unscaled JPY until the chart boundary.  These are the precise
definitions in the supplied Zuken workbook, not universal accounting ratios.
In particular its current-asset formula subtracts the signed current allowance
for doubtful accounts.  The different, manually edited Furuya formulas are not
silently substituted.  No undisclosed borrowing balance is inferred as zero.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal
import json
import re
import unicodedata

from .models import Cell, Dataset, Period, Row, Source
from .presentation import _concept, _key_parts, cf_metrics, detect_display_unit, pl_metrics


@dataclass
class Analysis:
    metrics: dict[str, Row] = field(default_factory=dict)
    metadata: dict[str, dict[str, dict]] = field(default_factory=dict)


DEFINITIONS = {
    'net_noncurrent_assets': ('BS_A', '正味固定資産',
        '固定資産合計－非流動の繰延税金資産', '図研 BS-A!B34 = B30-B26'),
    'net_current_assets': ('BS_A', '正味流動資産',
        '流動資産合計－流動の繰延税金資産－流動の貸倒引当金（原文の負数をそのまま控除）',
        '図研 BS-A!B35 = B13-B10-B12'),
    'net_current_liabilities': ('BS_LE', '正味流動負債',
        '流動負債合計－流動の引当金（賞与・役員賞与・その他の引当金）',
        '図研 BS-L,E!B39 = B14-SUM(B9:B11)'),
    'net_working_capital': ('BS_A', '正味(流動資産-流動負債)',
        '正味流動資産－正味流動負債', "図研 BS-A!B36 = B35-'BS-L,E'!B39"),
    'invested_capital': ('BS_A', '投下資本',
        '正味固定資産＋正味(流動資産-流動負債)', '図研 BS-A!B38 = B34+B36'),
    'interest_bearing_debt': ('BS_LE', '有利子負債',
        '短期借入金・１年内返済予定長期借入金・社債・長期借入金・流動及び非流動リース債務の開示残高合計。'
        'その他の金融負債に未判別の有利子項目が含まれ得る場合は算出しない。',
        '図研 BS-L,E!B41 = SUM(B4:B6)+SUM(B15:B17)。'
        'フルヤ金属の長期未払金を含む参照範囲は一般化しない。'),
}

BS_CONCEPTS = {
    'assets': {'Assets', 'AssetsIFRS', 'TotalAssetsIFRS'},
    'current_assets': {'CurrentAssets', 'CurrentAssetsIFRS', 'TotalCurrentAssetsIFRS'},
    'noncurrent_assets': {'NoncurrentAssets', 'NonCurrentAssetsIFRS', 'NoncurrentAssetsIFRS', 'TotalNonCurrentAssetsIFRS'},
    'liabilities': {'Liabilities', 'LiabilitiesIFRS', 'TotalLiabilitiesIFRS'},
    'current_liabilities': {'CurrentLiabilities', 'CurrentLiabilitiesIFRS', 'TotalCurrentLiabilitiesIFRS'},
    'noncurrent_liabilities': {'NoncurrentLiabilities', 'NonCurrentLiabilitiesIFRS', 'NoncurrentLiabilitiesIFRS', 'NonCurrentLabilitiesIFRS'},
    'equity': {'NetAssets', 'EquityIFRS', 'TotalEquityIFRS'},
}
BS_LABELS = {'assets':'資産合計', 'current_assets':'流動資産', 'noncurrent_assets':'固定・非流動資産',
             'liabilities':'負債合計', 'current_liabilities':'流動負債',
             'noncurrent_liabilities':'固定・非流動負債', 'equity':'純資産・資本合計'}

_CURRENT_ASSET = {'流動資産'}
_NONCURRENT_ASSET = {'固定資産', '非流動資産', '投資その他の資産'}
_CURRENT_LIABILITY = {'流動負債'}
_NONCURRENT_LIABILITY = {'固定負債', '非流動負債'}
_DEBT_CONCEPTS = {
    'ShortTermLoansPayable', 'ShortTermBorrowings', 'ShortTermBorrowingsIFRS',
    'ShortTermLoansPayableIFRS', 'BorrowingsCLIFRS',
    'CurrentPortionOfLongTermLoansPayable', 'CurrentPortionOfLongTermBorrowings',
    'CurrentPortionOfLongTermBorrowingsIFRS', 'CurrentPortionOfBonds',
    'CurrentPortionOfBondsPayable', 'CurrentPortionOfBondsWithSubscriptionRightsToShares',
    'CurrentPortionOfConvertibleBondTypeBondsWithSubscriptionRightsToShares',
    'LeaseObligationsCL', 'LeaseLiabilitiesCLIFRS', 'LeaseLiabilitiesCurrentIFRS',
    'CurrentLeaseLiabilitiesIFRS', 'LongTermLoansPayable', 'LongTermBorrowings',
    'LongTermBorrowingsIFRS', 'BorrowingsNCLIFRS', 'BondsPayable',
    'BondsWithSubscriptionRightsToShares', 'ConvertibleBondTypeBondsWithSubscriptionRightsToShares',
    'BondsPayableNCLIFRS', 'BondsNCLIFRS', 'LeaseObligationsNCL',
    'LeaseLiabilitiesNCLIFRS', 'NonCurrentLeaseLiabilitiesIFRS',
    'CommercialPapers', 'CommercialPaper',
}
_OPAQUE_FINANCIAL = {'OtherFinancialLiabilitiesCLIFRS', 'OtherFinancialLiabilitiesNCLIFRS',
                     'OtherFinancialLiabilitiesCurrentIFRS', 'OtherFinancialLiabilitiesNonCurrentIFRS'}


def _compact(value: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or ''))


def _local(cell: Cell) -> str:
    return _concept(cell.source.concept)[1]


def _scope(row: Row, cell: Cell) -> set[str]:
    return {_compact(s).removesuffix('合計') for s in
            (cell.source_section if cell.source_section is not None else row.section)}


def _eligible(dataset: Dataset, row: Row, period: Period) -> Cell | None:
    cell = row.values.get(period.key)
    if row.is_heading or cell is None:
        return None
    dimensions, role, unit, _ = _key_parts(row)
    expected = dataset.period_bases.get(period.key, dataset.basis)
    if dimensions or role != 'end' or unit != 'JPY' or cell.source.unit != 'JPY':
        return None
    if expected in {'consolidated', 'standalone'} and cell.source.basis != expected:
        return None
    # Prepared row keys retain the original accounting framework even when
    # display-only stitching spans different annual consolidation profiles.
    try:
        parts = json.loads(row.key.removeprefix('display:'))
        standard = (parts[6] if row.key.startswith('display:') and len(parts) == 8
                    else parts[7] if len(parts) == 9 else '')
    except (ValueError, TypeError, IndexError):
        standard = ''
    expected_standard = dataset.period_standards.get(period.key, dataset.accounting_standard)
    if standard and expected_standard in {'J-GAAP', 'IFRS', 'US-GAAP'} and standard != expected_standard:
        return None
    family = _concept(cell.source.concept)[0]
    if family not in {'jppfs_cor', 'jpigp_cor'} and not family.startswith('issuer:'):
        return None
    return cell


def _select(dataset: Dataset, statement: str, period: Period, predicate):
    return [(row, cell) for row in dataset.rows.get(statement, [])
            if (cell := _eligible(dataset, row, period)) is not None and predicate(row, cell)]


def _unique(matches):
    """Choose a single disclosed balance, refusing conflicting/unknown copies."""
    if not matches:
        return None, '該当する開示残高がありません。'
    signatures = {(cell.value, cell.nil) for _, cell in matches}
    if len(signatures) > 1:
        return None, '同年度の候補残高が一致せず、一意に識別できません。'
    row, cell = max(matches, key=lambda rc: (rc[1].source.submitted, rc[1].source.doc_id))
    return (row, cell), ''


def _total(dataset: Dataset, name: str, period: Period):
    statement = 'BS_A' if name in {'assets', 'current_assets', 'noncurrent_assets'} else 'BS_LE'
    return _unique(_select(dataset, statement, period,
                           lambda r, c: _local(c) in BS_CONCEPTS[name] and
                           _concept(c.source.concept)[0] in {'jppfs_cor', 'jpigp_cor'}))


def bs_metrics(dataset: Dataset) -> dict[str, Row]:
    """Original disclosed BS totals; no replacement by parent equity or sums."""
    result = {}
    for name in BS_CONCEPTS:
        statement = 'BS_A' if name in {'assets', 'current_assets', 'noncurrent_assets'} else 'BS_LE'
        row = Row('bs_metric:' + name, BS_LABELS[name], statement, is_total=True)
        for period in sorted(dataset.periods):
            chosen, reason = _total(dataset, name, period)
            if chosen:
                row.values[period.key] = deepcopy(chosen[1])
        result[name] = row
    return result


def _tax_kind(row: Row, cell: Cell):
    name = _local(cell)
    if name == 'DeferredTaxAssetsCA':
        return 'current'
    if name == 'DeferredTaxAssetsIOA':
        return 'noncurrent'
    if name not in {'DeferredTaxAssets', 'DeferredTaxAssetsIFRS'} and _compact(
            cell.source.original_label or row.label) != '繰延税金資産':
        return None
    scope = _scope(row, cell)
    if scope & _CURRENT_ASSET and not scope & _NONCURRENT_ASSET:
        return 'current'
    if scope & _NONCURRENT_ASSET and not scope & _CURRENT_ASSET:
        return 'noncurrent'
    return 'unknown'


def _current_allowance(row: Row, cell: Cell):
    name = _local(cell)
    if name in {'AllowanceForDoubtfulAccountsCA', 'AllowanceForDoubtfulAccountsCurrentIFRS'}:
        return True
    return (name in {'AllowanceForDoubtfulAccounts', 'AllowanceForDoubtfulAccountsIFRS'} or
            _compact(cell.source.original_label or row.label) == '貸倒引当金') and bool(
        _scope(row, cell) & _CURRENT_ASSET) and not bool(_scope(row, cell) & _NONCURRENT_ASSET)


def _current_provision(row: Row, cell: Cell):
    name = _local(cell)
    if name in {'ProvisionsCLIFRS', 'ProvisionsCL', 'OtherProvisionCL', 'OtherProvisionsCL'}:
        return True
    return (name.startswith('ProvisionFor') or _compact(cell.source.original_label or row.label).endswith('引当金')) and bool(_scope(row, cell) & _CURRENT_LIABILITY) and not bool(
        _scope(row, cell) & _NONCURRENT_LIABILITY)


def _group_proven(row: Row, cell: Cell, kind: str):
    groups = {'current_assets': _CURRENT_ASSET, 'noncurrent_assets': _NONCURRENT_ASSET,
              'current_liabilities': _CURRENT_LIABILITY}
    # IFRS can flatten headings; exact standard-taxonomy total still proves the
    # reported group. Other arbitrary labels cannot establish completeness.
    return cell.value is not None and not cell.nil and (
        bool(_scope(row, cell) & groups[kind]) or _local(cell) in BS_CONCEPTS[kind])


def metric_terms(cell: Cell) -> list[tuple[int, str, Cell]]:
    """Signed formula inputs. Keys reference source rows or analysis:<name>."""
    if not cell.operation.startswith('analysis_linear:'):
        return []
    try:
        signs = [int(s) for s in cell.operation.split(':', 1)[1].split(',') if s]
    except ValueError:
        return []
    if len(signs) != len(cell.components) or len(signs) != len(cell.component_keys):
        return []
    return list(zip(signs, cell.component_keys, cell.components))


def _make_cell(name, terms, reasons, omitted):
    definition = DEFINITIONS[name]
    incomplete = list(reasons)
    for _, key, cell in terms:
        if cell.value is None or cell.nil:
            incomplete.append(f'{cell.source.original_label or key}が明示的な空欄・nilです。')
    complete = bool(terms) and not incomplete
    value = sum((Decimal(sign) * cell.value for sign, _, cell in terms), Decimal(0)) if complete else None
    source = deepcopy(terms[0][2].source) if terms else Source('', '', '')
    source.concept = 'analysis:' + name
    source.original_label = definition[1]
    source.raw_value = ''
    note = definition[2] + '\n参照式: ' + definition[3]
    if omitted:
        note += '\n本表の該当区分に開示行がないため控除項目に含めない: ' + '、'.join(omitted)
    if incomplete:
        note += '\n未算出: ' + ' '.join(dict.fromkeys(incomplete))
    cell = Cell(value, source, note=note, components=deepcopy([c for _, _, c in terms]),
                operation='analysis_linear:' + ','.join(str(s) for s, _, _ in terms),
                component_keys=[key for _, key, _ in terms])
    metadata = {'complete': complete, 'reason': ' '.join(dict.fromkeys(incomplete)),
                'definition': definition[2], 'reference': definition[3],
                'omitted_absent_inputs': list(omitted),
                'terms': [{'sign': sign, 'key': key, 'doc_id': c.source.doc_id,
                           'concept': c.source.concept, 'nil': c.nil,
                           'value': str(c.value) if c.value is not None else None}
                          for sign, key, c in terms]}
    return cell, metadata


def analyze_dataset(dataset: Dataset) -> Analysis:
    """Compute six explicitly defined BS measures, preserving every operand.

    An absent optional exclusion is omitted only alongside its disclosed
    authoritative subtotal. An explicit nil always makes the result unknown.
    Borrowings are not estimated from an opaque financial-liability balance.
    """
    result = Analysis()
    for name, (statement, label, _, _) in DEFINITIONS.items():
        result.metrics[name] = Row('analysis:' + name, label, statement, is_total=True)
        result.metadata[name] = {}
    for period in sorted(dataset.periods):
        for name, group, exclusions in [
                ('net_noncurrent_assets', 'noncurrent_assets', ('tax_noncurrent',)),
                ('net_current_assets', 'current_assets', ('tax_current', 'allowance_current')),
                ('net_current_liabilities', 'current_liabilities', ('provisions_current',))]:
            terms, reasons, omitted = [], [], []
            total, reason = _total(dataset, group, period)
            if total is None:
                reasons.append(BS_LABELS[group] + ': ' + reason)
            else:
                terms.append((1, total[0].key, total[1]))
                if not _group_proven(*total, group):
                    reasons.append('基礎となる区分合計が未開示・nilです。')
            for exclusion in exclusions:
                if exclusion.startswith('tax_'):
                    kind = exclusion.removeprefix('tax_')
                    matches = _select(dataset, 'BS_A', period, lambda r, c: _tax_kind(r, c) == kind)
                    unknown = _select(dataset, 'BS_A', period, lambda r, c: _tax_kind(r, c) == 'unknown')
                    if unknown:
                        reasons.append('繰延税金資産の流動・非流動区分を一意に識別できません。')
                elif exclusion == 'allowance_current':
                    matches = _select(dataset, 'BS_A', period, _current_allowance)
                else:
                    matches = _select(dataset, 'BS_LE', period, _current_provision)
                    aggregates = [rc for rc in matches if _local(rc[1]) in {'ProvisionsCLIFRS', 'ProvisionsCL'}]
                    if aggregates:
                        # Broad standard-taxonomy provision balances replace
                        # their individually disclosed breakdown, never add it.
                        picked, ambiguity = _unique(aggregates)
                        matches = [picked] if picked else []
                        if ambiguity:
                            reasons.append(ambiguity)
                if not matches:
                    if total and _group_proven(*total, group):
                        omitted.append({'tax_noncurrent':'非流動の繰延税金資産', 'tax_current':'流動の繰延税金資産',
                                        'allowance_current':'流動の貸倒引当金', 'provisions_current':'流動の引当金'}[exclusion])
                    else:
                        reasons.append('控除項目の有無を確認できません: ' + exclusion)
                else:
                    # Tax/allowance categories are each a single balance;
                    # provision categories may have independent components.
                    if exclusion != 'provisions_current':
                        picked, ambiguity = _unique(matches)
                        matches = [picked] if picked else []
                        if ambiguity:
                            reasons.append(ambiguity)
                    terms.extend((-1, row.key, cell) for row, cell in matches)
            cell, meta = _make_cell(name, terms, reasons, omitted)
            result.metrics[name].values[period.key] = cell
            result.metadata[name][period.key] = meta
        for name, inputs in [('net_working_capital', [('net_current_assets', 1), ('net_current_liabilities', -1)]),
                             ('invested_capital', [('net_noncurrent_assets', 1), ('net_working_capital', 1)])]:
            terms = [(sign, 'analysis:' + dep, result.metrics[dep].values[period.key]) for dep, sign in inputs]
            cell, meta = _make_cell(name, terms, [], [])
            result.metrics[name].values[period.key] = cell
            result.metadata[name][period.key] = meta
        matches = _select(dataset, 'BS_LE', period, lambda r, c: _local(c) in _DEBT_CONCEPTS)
        reasons = []
        opaque = _select(dataset, 'BS_LE', period, lambda r, c: _local(c) in _OPAQUE_FINANCIAL)
        if any(c.nil or c.value is None or c.value != 0 for _, c in opaque):
            reasons.append('その他の金融負債に有利子項目が含まれる可能性があり、本表だけでは総額を確定できません。')
        for aggregate, contained in [('BorrowingsCLIFRS', {'ShortTermBorrowingsIFRS', 'CurrentPortionOfLongTermBorrowingsIFRS'}),
                                     ('BorrowingsNCLIFRS', {'LongTermBorrowingsIFRS'})]:
            if any(_local(c) == aggregate for _, c in matches):
                matches = [(r, c) for r, c in matches if _local(c) not in contained]
        # Repeated identical concepts must not be counted twice, even if an
        # otherwise malformed dataset presents them under two source keys.
        unique = {}
        for row, cell in matches:
            name = _local(cell)
            if name in unique and (unique[name][1].value, unique[name][1].nil) != (cell.value, cell.nil):
                reasons.append('同一の有利子負債項目に一致しない複数残高があります: ' + name)
            elif name not in unique:
                unique[name] = (row, cell)
        if not unique:
            reasons.append('有利子負債の金額項目が本表に開示されていないため、0とは推定しません。')
        terms = [(1, r.key, c) for r, c in unique.values()]
        cell, meta = _make_cell('interest_bearing_debt', terms, reasons, [])
        result.metrics['interest_bearing_debt'].values[period.key] = cell
        result.metadata['interest_bearing_debt'][period.key] = meta
    return result


def analysis_metrics(dataset: Dataset) -> dict[str, Row]:
    return analyze_dataset(dataset).metrics


def chart_data(dataset: Dataset, unit: str = 'auto') -> dict:
    """UI-independent, chronological Decimal series with explicit gaps.

    Money is converted to the selected display unit. Ratio values are fractions
    (0.25 means 25%). Aligned cells retain the original public source evidence.
    """
    if unit == 'auto':
        unit = detect_display_unit(dataset)
    factors = {'yen': Decimal(1), 'thousand': Decimal(1000), 'million': Decimal(1000000)}
    if unit not in factors:
        raise ValueError('表示単位は auto / yen / thousand / million を指定してください。')
    factor = factors[unit]
    periods = sorted(dataset.periods)
    output = {'code': dataset.code, 'company': dataset.company, 'unit': unit,
              'unit_label': {'yen':'円', 'thousand':'千円', 'million':'百万円'}[unit], 'factor': factor,
              'periods': [{'key': p.key, 'label': p.label, 'start': p.start.isoformat(), 'end': p.end.isoformat(),
                           'basis': dataset.period_bases.get(p.key, dataset.basis),
                           'accounting_standard': dataset.period_standards.get(p.key, dataset.accounting_standard)}
                          for p in periods], 'PL': {}, 'BS': {}, 'CF': {}}
    exported, addresses = {}, {}
    for item in dataset.export_metadata.get('cells', []):
        key = item.get('sheet'), item.get('row_key'), item.get('period')
        if key[1] and not str(key[1]).startswith('helper:'):
            exported[key] = item
            addresses[item.get('sheet'), item.get('address'), item.get('period')] = item
    exported_unit = dataset.export_metadata.get('unit')
    def final_value(sheet, key, period, original):
        entry = exported.get((sheet, key, period.key))
        if sheet in {'BS-A', 'BS-L,E'}:
            mapped = dataset.export_metadata.get('source_addresses', {}).get(key, {}).get(period.key)
            if mapped:
                entry = addresses.get((mapped.get('sheet', sheet), mapped.get('address'), period.key), entry)
                if entry is None:
                    entry = exported.get((mapped.get('sheet', sheet), mapped.get('row_key'), period.key))
        if entry is None:
            return original
        raw = entry.get('display_value')
        if raw is None or raw == '':
            return None
        try:
            value = Decimal(str(raw))
        except Exception:
            return None
        if not value.is_finite():
            return None
        source_factor = factors.get(entry.get('unit'), factors.get(exported_unit))
        return value * source_factor if source_factor else original
    def series(label, row, *, sheet, keys=None, kind='money'):
        cells = [row.values.get(p.key) if row else None for p in periods]
        # Explicit branch ordering is important: nil values are not arithmetic
        # operands and cannot be converted into an apparent zero in the graph.
        original = [None if c is None or c.nil or c.value is None else c.value for c in cells]
        values = [final_value(sheet, keys.get(p.key) if keys else row.key if row else '', p, value)
                  for p, value in zip(periods, original)]
        values = [None if value is None else value / factor if kind == 'money' else value for value in values]
        return {'label': label, 'kind': kind, 'values': values, 'cells': cells}
    pl = pl_metrics(dataset)
    for name, label in [('revenue','売上高'), ('gross_profit','売上総利益'),
                        ('operating_profit','営業利益'), ('net_profit','当期純利益')]:
        output['PL'][name] = series(label, pl.get(name), sheet='PL')
    for name, numerator, label in [('gross_margin','gross_profit','売上総利益率'),
                                   ('operating_margin','operating_profit','営業利益率'),
                                   ('net_margin','net_profit','当期純利益率')]:
        values, cells = [], []
        for p in periods:
            n = pl.get(numerator).values.get(p.key) if pl.get(numerator) else None
            d = pl.get('revenue').values.get(p.key) if pl.get('revenue') else None
            nvalue = final_value('PL', 'metric:' + numerator, p,
                                 n.value if n and not n.nil else None)
            dvalue = final_value('PL', 'metric:revenue', p,
                                 d.value if d and not d.nil else None)
            valid = nvalue is not None and dvalue not in {None, Decimal(0)}
            values.append(nvalue / dvalue if valid else None)
            cells.append(n if valid else None)
        output['PL'][name] = {'label':label, 'kind':'ratio', 'values':values, 'cells':cells}
    for name, row in bs_metrics(dataset).items():
        keys = {}
        for p in periods:
            selected, _ = _total(dataset, name, p)
            if selected:
                keys[p.key] = selected[0].key
        output['BS'][name] = series(BS_LABELS[name], row, sheet='BS-A' if row.statement == 'BS_A' else 'BS-L,E', keys=keys)
    cf = cf_metrics(dataset)
    for name, slot, label in [('operating',40,'営業CF'), ('investing',54,'投資CF'),
                              ('financing',64,'財務CF'), ('cash',68,'現金及び現金同等物')]:
        output['CF'][name] = series(label, cf.get(f'template:CF:{slot}'), sheet='CF')
    return output
