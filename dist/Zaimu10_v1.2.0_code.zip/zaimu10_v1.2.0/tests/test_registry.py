from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from decimal import Decimal
import json

import pytest

from zaimu10.models import Dataset, Period, Row, Cell, Source, Filing
from zaimu10.registry import CompanyRegistry, RegistryError


def company(code='6947', name='株式会社図研', edinet='E01966', fiscal='3月31日'):
    return dict(code=code, company=name, edinet_code=edinet,
                fiscal_year_end=fiscal, consolidated=True)


def filing(code='6947', doc='S100YD7O', start=date(2025,4,1), end=date(2026,3,31),
           submitted='2026-06-19 11:04', amended=False, edinet='E01966'):
    return Filing(doc_id=doc, company='株式会社図研', code=code, edinet_code=edinet,
                  start=start, end=end, submitted=submitted, amended=amended)


def dataset(end=date(2026,3,31), submitted='2026-06-19 11:04'):
    period = Period(date(end.year-1,4,1), end)
    ds = Dataset('6947', '株式会社図研', 'consolidated', [period])
    source = Source('S100YD7O', 'financial.htm', 'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100YD7O', submitted=submitted)
    row = Row('Assets', '資産合計', 'BS_A', values={period.key:Cell(Decimal(100),source)})
    ds.rows['BS_A'].append(row)
    return ds


def test_registration_persists_official_name_and_separate_display_name(tmp_path):
    path=tmp_path/'app'/'data'/'companies.json'
    registry=CompanyRegistry(path)
    assert registry.list_companies()==[]
    assert not path.exists()
    added=registry.register(company())
    assert added['company']=='株式会社図研' and added['display_name']=='図研'
    assert added['latest_period_end'] is None
    assert added['announcement_date'] is None
    assert CompanyRegistry(path).list_companies()[0]['edinet_code']=='E01966'


def test_actual_annual_calendar_sorted_latest_first_no_forecasts(tmp_path):
    registry=CompanyRegistry(tmp_path/'companies.json')
    registry.register(company())
    registry.register(company('2303','株式会社ドーン','E05289','5月31日'))
    registry.register(company('285A','テスト株式会社','E99999','12月31日'))
    registry.update_filings('6947',[filing(),filing(doc='S100W07I',start=date(2024,4,1),end=date(2025,3,31),submitted='2025-06-20 14:09')])
    registry.update_filings('2303',[filing(code='2303',doc='S100YXLE',edinet='E05289',start=date(2025,6,1),end=date(2026,5,31),submitted='2026-08-28 10:00')])
    rows=registry.calendar_rows()
    assert [r['code'] for r in rows]==['2303','6947','285A']
    assert rows[0]['latest_period_end']=='2026-05-31'
    assert rows[0]['latest_fiscal_year']==2026
    assert rows[0]['fiscal_year_end']=='5月31日'
    assert all(r['announcement_date'] is None for r in rows)
    assert all('決算期末と決算発表日は別' in r['calendar_note'] for r in rows)


def test_correction_date_is_not_mislabeled_as_original_annual_submission(tmp_path):
    registry=CompanyRegistry(tmp_path/'companies.json'); registry.register(company())
    record=registry.update_filings('6947',[filing(),filing(doc='S100YAAA',submitted='2026-09-01 10:00',amended=True)])
    assert record['latest_submitted']=='2026-06-19 11:04'
    assert record['latest_doc_id']=='S100YD7O'
    assert record['latest_submitted_kind']=='annual_report'


def test_historical_export_and_missing_dates_do_not_erase_latest_actuals(tmp_path):
    registry=CompanyRegistry(tmp_path/'companies.json'); registry.register(company())
    registry.update_result(dataset())
    record=registry.update_result(dataset(end=date(2025,3,31),submitted='2025-06-20 14:09'))
    assert record['latest_period_end']=='2026-03-31'
    record=registry.update_result(dataset(submitted=''))
    assert record['latest_submitted']=='2026-06-19 11:04'
    assert record['latest_doc_id']=='S100YD7O'


def test_export_updates_only_explicitly_registered_companies(tmp_path):
    registry=CompanyRegistry(tmp_path/'companies.json')
    assert registry.update_result(dataset()) is None
    assert registry.list_companies()==[]


def test_reregister_preserves_actual_history_and_unknown_user_fields(tmp_path):
    path=tmp_path/'companies.json'; registry=CompanyRegistry(path)
    registry.register(company()); registry.update_result(dataset())
    payload=json.loads(path.read_text());payload['custom_root']={'keep':True}
    payload['companies'][0]['custom_note']='my note'
    path.write_text(json.dumps(payload))
    registry.register(company(name='株式会社　図研'))
    preserved=json.loads(path.read_text())
    assert preserved['custom_root']=={'keep':True}
    assert preserved['companies'][0]['custom_note']=='my note'
    assert preserved['companies'][0]['latest_period_end']=='2026-03-31'
    assert registry.register({'code':'6947','company':'株式会社図研','edinet_code':'E01966'})['fiscal_year_end']=='3月31日'


def test_remove_only_selected_company_and_foreign_identity_rejected(tmp_path):
    path=tmp_path/'companies.json';registry=CompanyRegistry(path)
    registry.register(company());registry.register(company('285A','テスト','E99999'))
    with pytest.raises(RegistryError,match='異なるEDINET'):
        registry.register(company(edinet='E00001'))
    with pytest.raises(RegistryError,match='異なる企業'):
        registry.update_filings('6947',[filing(edinet='E00001')])
    assert registry.remove('285A') is True
    assert [r['code'] for r in registry.list_companies()]==['6947']
    assert registry.remove('285A') is False


@pytest.mark.parametrize('content', ['{broken', '{"schema_version":99,"companies":[]}',
                                     '{"schema_version":1,"companies":[{}]}'])
def test_corrupt_or_newer_registry_never_reset_or_overwritten(tmp_path,content):
    path=tmp_path/'companies.json';path.write_text(content)
    registry=CompanyRegistry(path)
    with pytest.raises(RegistryError):
        registry.register(company())
    assert path.read_text()==content
    with pytest.raises(RegistryError):
        registry.remove('6947')
    assert path.read_text()==content


def test_concurrent_registry_objects_preserve_each_registration(tmp_path):
    path=tmp_path/'companies.json'
    entries=[company(str(1000+i),f'株式会社テスト{i}',f'E{i:05d}') for i in range(12)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        list(pool.map(lambda c:CompanyRegistry(path).register(c),entries))
    assert len(CompanyRegistry(path).list_companies())==12
    assert {r['code'] for r in CompanyRegistry(path).list_companies()}=={c['code'] for c in entries}


def test_atomic_replace_failure_keeps_previous_registry(tmp_path,monkeypatch):
    from pathlib import Path
    path=tmp_path/'companies.json';registry=CompanyRegistry(path);registry.register(company())
    original=path.read_bytes()
    def fail(*args,**kwargs): raise OSError('disk write failed')
    monkeypatch.setattr(Path,'replace',fail)
    with pytest.raises(RegistryError,match='保存できません'):
        registry.register(company('285A','テスト','E99999'))
    assert path.read_bytes()==original
    assert not list(tmp_path.glob('*.tmp'))


def test_future_dates_cannot_become_actual_calendar_entries(tmp_path):
    registry=CompanyRegistry(tmp_path/'companies.json');registry.register(company())
    future=date.today()+timedelta(days=365)
    with pytest.raises(RegistryError,match='将来の決算期末'):
        registry.update_filings('6947',[filing(end=future)])
    with pytest.raises(RegistryError,match='将来の提出日時'):
        registry.update_filings('6947',[filing(submitted=future.isoformat()+' 09:00')])
    assert registry.calendar_rows()[0]['latest_period_end'] is None
