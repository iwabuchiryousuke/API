"""Auditable reference-workbook analysis and chart data.

Amounts stay in unscaled JPY until the chart boundary.  These are the precise
definitions in the supplied Zuken workbook, not universal accounting ratios.
In particular its current-asset formula subtracts the signed current allowance
for doubtful accounts.  The different, manually edited Furuya formulas are not
silently substituted. Borrowing/lease note details supplement the primary BS;
zero requires an explicit no-balance disclosure or a fully verified clean BS.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal
import json
import re
import unicodedata

from .models import Cell, Dataset, Period, Row, Source
from .presentation import _concept, _key_parts, cf_metrics, detect_display_unit, pl_metrics


@dataclass
class Analysis:
    metrics: dict[str, Row] = field(default_factory=dict)
    metadata: dict[str, dict[str, dict]] = field(default_factory=dict)


DEFINITIONS = {
    'net_noncurrent_assets': ('BS_A', '正味固定資産',
        '固定資産合計－非流動の繰延税金資産', '図研 BS-A!B34 = B30-B26'),
    'net_current_assets': ('BS_A', '正味流動資産',
        '流動資産合計－流動の繰延税金資産－流動の貸倒引当金（原文の負数をそのまま控除）',
        '図研 BS-A!B35 = B13-B10-B12'),
    'net_current_liabilities': ('BS_LE', '正味流動負債',
        '流動負債合計－流動の引当金（賞与・役員賞与・その他の引当金）',
        '図研 BS-L,E!B39 = B14-SUM(B9:B11)'),
    'net_working_capital': ('BS_A', '正味(流動資産-流動負債)',
        '正味流動資産－正味流動負債', "図研 BS-A!B36 = B35-'BS-L,E'!B39"),
    'invested_capital': ('BS_A', '投下資本',
        '正味固定資産＋正味(流動資産-流動負債)', '図研 BS-A!B38 = B34+B36'),
    'interest_bearing_debt': ('BS_LE', '有利子負債',
        '短期借入金・１年内返済予定長期借入金・社債・長期借入金・流動及び非流動リース債務の開示残高合計。'
        'その他の金融負債に未判別の有利子項目が含まれ得る場合は算出しない。',
        '図研 BS-L,E!B41 = SUM(B4:B6)+SUM(B15:B17)。'
        'フルヤ金属の長期未払金を含む参照範囲は一般化しない。'),
}

BS_CONCEPTS = {
    'assets': {'Assets', 'AssetsIFRS', 'TotalAssetsIFRS'},
    'current_assets': {'CurrentAssets', 'CurrentAssetsIFRS', 'TotalCurrentAssetsIFRS'},
    'noncurrent_assets': {'NoncurrentAssets', 'NonCurrentAssetsIFRS', 'NoncurrentAssetsIFRS', 'TotalNonCurrentAssetsIFRS'},
    'liabilities': {'Liabilities', 'LiabilitiesIFRS', 'TotalLiabilitiesIFRS'},
    'current_liabilities': {'CurrentLiabilities', 'CurrentLiabilitiesIFRS', 'TotalCurrentLiabilitiesIFRS'},
    'noncurrent_liabilities': {'NoncurrentLiabilities', 'NonCurrentLiabilitiesIFRS', 'NoncurrentLiabilitiesIFRS', 'NonCurrentLabilitiesIFRS'},
    'equity': {'NetAssets', 'EquityIFRS', 'TotalEquityIFRS'},
}
BS_LABELS = {'assets':'資産合計', 'current_assets':'流動資産', 'noncurrent_assets':'固定・非流動資産',
             'liabilities':'負債合計', 'current_liabilities':'流動負債',
             'noncurrent_liabilities':'固定・非流動負債', 'equity':'純資産・資本合計'}

_CURRENT_ASSET = {'流動資産'}
_NONCURRENT_ASSET = {'固定資産', '非流動資産', '投資その他の資産'}
_CURRENT_LIABILITY = {'流動負債'}
_NONCURRENT_LIABILITY = {'固定負債', '非流動負債'}
_DEBT_CONCEPTS = {
    'ShortTermLoansPayable', 'ShortTermBorrowings', 'ShortTermBorrowingsIFRS',
    'ShortTermLoansPayableIFRS', 'BorrowingsCLIFRS',
    'CurrentPortionOfLongTermLoansPayable', 'CurrentPortionOfLongTermBorrowings',
    'CurrentPortionOfLongTermBorrowingsIFRS', 'CurrentPortionOfBonds',
    'CurrentPortionOfBondsPayable', 'CurrentPortionOfBondsWithSubscriptionRightsToShares',
    'CurrentPortionOfConvertibleBondTypeBondsWithSubscriptionRightsToShares',
    'LeaseObligationsCL', 'LeaseLiabilitiesCLIFRS', 'LeaseLiabilitiesCurrentIFRS',
    'CurrentLeaseLiabilitiesIFRS', 'LongTermLoansPayable', 'LongTermBorrowings',
    'LongTermBorrowingsIFRS', 'BorrowingsNCLIFRS', 'BondsPayable',
    'BondsWithSubscriptionRightsToShares', 'ConvertibleBondTypeBondsWithSubscriptionRightsToShares',
    'BondsPayableNCLIFRS', 'BondsNCLIFRS', 'LeaseObligationsNCL',
    'LeaseLiabilitiesNCLIFRS', 'NonCurrentLeaseLiabilitiesIFRS',
    'CommercialPapers', 'CommercialPaper',
}
_OPAQUE_FINANCIAL = {'OtherFinancialLiabilitiesCLIFRS', 'OtherFinancialLiabilitiesNCLIFRS',
                     'OtherFinancialLiabilitiesCurrentIFRS', 'OtherFinancialLiabilitiesNonCurrentIFRS'}
_DEBT_CATEGORY_CONCEPTS = {
    'current_interest_bearing_total': {'InterestBearingLiabilitiesCLIFRS'},
    'noncurrent_interest_bearing_total': {'InterestBearingLiabilitiesNCLIFRS'},
    'short_term_borrowings': {'ShortTermLoansPayable','ShortTermBorrowings','ShortTermBorrowingsIFRS','ShortTermLoansPayableIFRS'},
    'current_long_term_borrowings': {'CurrentPortionOfLongTermLoansPayable','CurrentPortionOfLongTermBorrowings','CurrentPortionOfLongTermBorrowingsIFRS'},
    'current_borrowings': {'BorrowingsCLIFRS'},
    'current_lease': {'LeaseObligationsCL','LeaseLiabilitiesCLIFRS','LeaseLiabilitiesCurrentIFRS','CurrentLeaseLiabilitiesIFRS'},
    'long_term_borrowings': {'LongTermLoansPayable','LongTermBorrowings','LongTermBorrowingsIFRS','BorrowingsNCLIFRS'},
    'noncurrent_lease': {'LeaseObligationsNCL','LeaseLiabilitiesNCLIFRS','NonCurrentLeaseLiabilitiesIFRS'},
    'bonds': {'BondsPayable','BondsWithSubscriptionRightsToShares','ConvertibleBondTypeBondsWithSubscriptionRightsToShares','BondsPayableNCLIFRS','BondsNCLIFRS'},
    'current_bonds': {'CurrentPortionOfBonds','CurrentPortionOfBondsPayable','CurrentPortionOfBondsWithSubscriptionRightsToShares','CurrentPortionOfConvertibleBondTypeBondsWithSubscriptionRightsToShares'},
    'commercial_paper': {'CommercialPapers','CommercialPaper'},
    'other_interest_bearing_debt': {'OtherInterestBearingDebt','OtherInterestBearingLiabilities'},
}
_INTEREST_TOTAL_CATEGORIES = {'current_interest_bearing_total','noncurrent_interest_bearing_total'}
_DEBT_NOTE_CATEGORIES = set(_DEBT_CATEGORY_CONCEPTS) - _INTEREST_TOTAL_CATEGORIES
_NOTE_STATUS_CATEGORIES = {'borrowings_coverage','borrowings_absent','bonds_coverage','bonds_absent',
                         'nonlease_debt_absent','current_lease_coverage','noncurrent_lease_coverage',
                         'ifrs_borrowings_coverage','financial_liabilities_coverage'}
_BENIGN_LIABILITY_PREFIXES = (
    'AccountsPayableTrade','NotesPayableTrade','NotesAndAccountsPayableTrade',
    'TradeAndOtherPayables','IncomeTaxesPayable','AccruedConsumptionTaxes',
    'ConsumptionTaxesPayable','DeferredTaxLiabilities','ProvisionFor','Provisions',
    'NetDefinedBenefitLiability','DefinedBenefitLiabilities','RetirementBenefitLiability',
    'AssetRetirementObligations','ContractLiabilities','AdvancesReceived',
    'LongTermAdvancesReceived','UnearnedRevenue','LongTermUnearnedRevenue',
    'DepositsReceived','GuaranteeDepositsReceived','AccruedExpenses',
)


def debt_category(row: Row, cell: Cell | None = None) -> str | None:
    """Exact debt category; note identities never masquerade as BS facts."""
    if row.key.startswith('notes:debt:'):
        category = row.key.split(':')[2]
        return category if category in _DEBT_NOTE_CATEGORIES | _NOTE_STATUS_CATEGORIES else None
    cell = cell or next(iter(row.values.values()), None)
    if cell is None:
        return None
    name = _local(cell)
    category = next((category for category, concepts in _DEBT_CATEGORY_CONCEPTS.items() if name in concepts), None)
    if category in _INTEREST_TOTAL_CATEGORIES and _concept(cell.source.account_concept)[0] != 'jpigp_cor':
        return None
    return category


def _compact(value: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or ''))


def _local(cell: Cell) -> str:
    return _concept(cell.source.account_concept)[1]


def _scope(row: Row, cell: Cell) -> set[str]:
    return {_compact(s).rstrip(':：').removesuffix('合計').rstrip(':：') for s in
            (cell.source_section if cell.source_section is not None else row.section)}


def _eligible(dataset: Dataset, row: Row, period: Period) -> Cell | None:
    cell = row.values.get(period.key)
    if row.is_heading or cell is None:
        return None
    dimensions, role, unit, _ = _key_parts(row)
    expected = dataset.period_bases.get(period.key, dataset.basis)
    if dimensions or role != 'end' or unit != 'JPY' or cell.source.unit != 'JPY':
        return None
    if expected in {'consolidated', 'standalone'} and cell.source.basis != expected:
        return None
    # Prepared row keys retain the original accounting framework even when
    # display-only stitching spans different annual consolidation profiles.
    try:
        parts = json.loads(row.key.removeprefix('display:'))
        standard = (parts[6] if row.key.startswith('display:') and len(parts) == 8
                    else parts[7] if len(parts) == 9 else '')
    except (ValueError, TypeError, IndexError):
        standard = ''
    expected_standard = dataset.period_standards.get(period.key, dataset.accounting_standard)
    if standard and expected_standard in {'J-GAAP', 'IFRS', 'US-GAAP'} and standard != expected_standard:
        return None
    family = _concept(cell.source.account_concept)[0]
    if family not in {'jppfs_cor', 'jpigp_cor'} and not family.startswith('issuer:'):
        return None
    return cell


def _select(dataset: Dataset, statement: str, period: Period, predicate):
    return [(row, cell) for row in dataset.rows.get(statement, [])
            if (cell := _eligible(dataset, row, period)) is not None and predicate(row, cell)]


def _unique(matches):
    """Choose a single disclosed balance, refusing conflicting/unknown copies."""
    if not matches:
        return None, '該当する開示残高がありません。'
    signatures = {(cell.value, cell.nil) for _, cell in matches}
    if len(signatures) > 1:
        return None, '同年度の候補残高が一致せず、一意に識別できません。'
    row, cell = max(matches, key=lambda rc: (rc[1].source.submitted, rc[1].source.doc_id))
    return (row, cell), ''


def _total(dataset: Dataset, name: str, period: Period):
    statement = 'BS_A' if name in {'assets', 'current_assets', 'noncurrent_assets'} else 'BS_LE'
    return _unique(_select(dataset, statement, period,
                           lambda r, c: _local(c) in BS_CONCEPTS[name] and
                           (_concept(c.source.account_concept)[0] in {'jppfs_cor', 'jpigp_cor'} or
                            _concept(c.source.account_concept)[0].startswith('issuer:html:'))))


def bs_metrics(dataset: Dataset) -> dict[str, Row]:
    """Original disclosed BS totals; no replacement by parent equity or sums."""
    result = {}
    for name in BS_CONCEPTS:
        statement = 'BS_A' if name in {'assets', 'current_assets', 'noncurrent_assets'} else 'BS_LE'
        row = Row('bs_metric:' + name, BS_LABELS[name], statement, is_total=True)
        for period in sorted(dataset.periods):
            chosen, reason = _total(dataset, name, period)
            if chosen:
                row.values[period.key] = deepcopy(chosen[1])
        result[name] = row
    return result


def _tax_kind(row: Row, cell: Cell):
    name = _local(cell)
    if name == 'DeferredTaxAssetsCA':
        return 'current'
    if name == 'DeferredTaxAssetsIOA':
        return 'noncurrent'
    if name not in {'DeferredTaxAssets', 'DeferredTaxAssetsIFRS'} and _compact(
            cell.source.original_label or row.label) != '繰延税金資産':
        return None
    scope = _scope(row, cell)
    if scope & _CURRENT_ASSET and not scope & _NONCURRENT_ASSET:
        return 'current'
    if scope & _NONCURRENT_ASSET and not scope & _CURRENT_ASSET:
        return 'noncurrent'
    return 'unknown'


def _current_allowance(row: Row, cell: Cell):
    name = _local(cell)
    if name in {'AllowanceForDoubtfulAccountsCA', 'AllowanceForDoubtfulAccountsCurrentIFRS'}:
        return True
    return (name in {'AllowanceForDoubtfulAccounts', 'AllowanceForDoubtfulAccountsIFRS'} or
            _compact(cell.source.original_label or row.label) == '貸倒引当金') and bool(
        _scope(row, cell) & _CURRENT_ASSET) and not bool(_scope(row, cell) & _NONCURRENT_ASSET)


def _current_provision(row: Row, cell: Cell):
    name = _local(cell)
    if name in {'ProvisionsCLIFRS', 'ProvisionsCL', 'OtherProvisionCL', 'OtherProvisionsCL'}:
        return True
    return (name.startswith('ProvisionFor') or _compact(cell.source.original_label or row.label).endswith('引当金')) and bool(_scope(row, cell) & _CURRENT_LIABILITY) and not bool(
        _scope(row, cell) & _NONCURRENT_LIABILITY)


def _group_proven(row: Row, cell: Cell, kind: str):
    groups = {'current_assets': _CURRENT_ASSET, 'noncurrent_assets': _NONCURRENT_ASSET,
              'current_liabilities': _CURRENT_LIABILITY}
    # IFRS can flatten headings; exact standard-taxonomy total still proves the
    # reported group. Other arbitrary labels cannot establish completeness.
    return cell.value is not None and not cell.nil and (
        bool(_scope(row, cell) & groups[kind]) or _local(cell) in BS_CONCEPTS[kind])


def metric_terms(cell: Cell) -> list[tuple[int, str, Cell]]:
    """Signed formula inputs. Keys reference source rows or analysis:<name>."""
    if not cell.operation.startswith('analysis_linear:'):
        return []
    try:
        signs = [int(s) for s in cell.operation.split(':', 1)[1].split(',') if s]
    except ValueError:
        return []
    if len(signs) != len(cell.components) or len(signs) != len(cell.component_keys):
        return []
    return list(zip(signs, cell.component_keys, cell.components))


def _make_cell(name, terms, reasons, omitted):
    definition = DEFINITIONS[name]
    incomplete = list(reasons)
    for _, key, cell in terms:
        if cell.value is None or cell.nil:
            incomplete.append(f'{cell.source.original_label or key}が明示的な空欄・nilです。')
    complete = bool(terms) and not incomplete
    value = sum((Decimal(sign) * cell.value for sign, _, cell in terms), Decimal(0)) if complete else None
    source = deepcopy(terms[0][2].source) if terms else Source('', '', '')
    source.concept = 'analysis:' + name
    source.semantic_concept = ''
    source.table_path = ''
    source.original_label = definition[1]
    source.raw_value = ''
    note = definition[2] + '\n参照式: ' + definition[3]
    if omitted:
        note += '\n本表の該当区分に開示行がないため控除項目に含めない: ' + '、'.join(omitted)
    if incomplete:
        note += '\n未算出: ' + ' '.join(dict.fromkeys(incomplete))
    cell = Cell(value, source, note=note, components=deepcopy([c for _, _, c in terms]),
                operation='analysis_linear:' + ','.join(str(s) for s, _, _ in terms),
                component_keys=[key for _, key, _ in terms])
    metadata = {'complete': complete, 'reason': ' '.join(dict.fromkeys(incomplete)),
                'definition': definition[2], 'reference': definition[3],
                'omitted_absent_inputs': list(omitted),
                'terms': [{'sign': sign, 'key': key, 'doc_id': c.source.doc_id,
                           'concept': c.source.concept, 'nil': c.nil,
                           'value': str(c.value) if c.value is not None else None}
                          for sign, key, c in terms]}
    return cell, metadata


def _debt_rounding(cells):
    result = Decimal(0)
    for cell in cells:
        for leaf in (cell.components or [cell]):
            try:
                result += Decimal(10) ** -int(leaf.source.decimals)
            except (ValueError, TypeError):
                pass
    return max(result, Decimal(1))


def _verified_clean_liabilities(dataset: Dataset, period: Period):
    """Prove zero only from a fully reconciled, unambiguously non-debt BS.

    Generic Other balances are intentionally not classified as non-debt: real
    Zuken lease obligations are buried in those balances. A subtotal alone is
    not a completeness proof. This narrow path is independent of note absence.
    """
    totals = {}
    for name in ['current_liabilities', 'noncurrent_liabilities', 'liabilities']:
        chosen, _ = _total(dataset, name, period)
        if chosen is None or chosen[1].value is None or chosen[1].nil:
            return False, [], '負債区分の合計を確認できません。'
        totals[name] = chosen
    primary = [c for _, c in totals.values()]
    if len({(c.source.doc_id, c.source.basis) for c in primary}) != 1:
        return False, [], '負債区分の原本・連結範囲が一致しません。'
    if abs(primary[0].value + primary[1].value - primary[2].value) > _debt_rounding(primary):
        return False, [], '負債区分合計の照合が一致しません。'
    all_totals = set().union(*BS_CONCEPTS.values())
    groups = {'current': [], 'noncurrent': []}
    for row, cell in _select(dataset, 'BS_LE', period, lambda r, c: _local(c) not in all_totals):
        scope = _scope(row, cell)
        if scope & _CURRENT_LIABILITY and not scope & _NONCURRENT_LIABILITY:
            group = 'current'
        elif scope & _NONCURRENT_LIABILITY and not scope & _CURRENT_LIABILITY:
            group = 'noncurrent'
        else:
            continue
        name = _local(cell)
        explicit_zero_debt = debt_category(row, cell) is not None and cell.value == 0 and not cell.nil
        if not explicit_zero_debt and (debt_category(row, cell) or not name.startswith(_BENIGN_LIABILITY_PREFIXES)):
            return False, [], '有利子項目又は性質が未確定の負債内訳があります。'
        # A nested aggregate and its breakdown cannot both prove a clean sum.
        if row.is_total:
            return False, [], '負債内訳に入れ子の合計があり、ゼロを単純照合できません。'
        groups[group].append(cell)
    for group, total_name in [('current', 'current_liabilities'), ('noncurrent', 'noncurrent_liabilities')]:
        cells = groups[group]
        total = totals[total_name][1]
        if not cells:
            if total.value != 0:
                return False, [], '負債合計に対応する全明細を確認できません。'
            continue
        numeric = [c for c in cells if c.value is not None and not c.nil]
        if abs(sum((c.value for c in numeric), Decimal(0)) - total.value) > _debt_rounding([total] + numeric):
            return False, [], '負債の全明細と合計が照合できません。'
    return True, primary, '流動・固定負債の全明細が既知の非有利子項目であり、各区分及び負債合計と原本精度内で一致。'


def _debt_analysis(dataset: Dataset, period: Period):
    reasons = list(getattr(dataset, 'analysis_input_errors', {}).get(period.key, []))
    main, notes, statuses, status_cells = {}, {}, set(), {}
    for row, cell in _select(dataset, 'BS_LE', period, lambda r, c: debt_category(r, c) is not None):
        main.setdefault(debt_category(row, cell), []).append((row, cell))
    expected_basis = dataset.period_bases.get(period.key, dataset.basis)
    for row in getattr(dataset, 'analysis_inputs', []):
        cell = row.values.get(period.key)
        category = debt_category(row, cell)
        if cell is None or category is None or cell.source.unit != 'JPY':
            continue
        if expected_basis in {'consolidated', 'standalone'} and cell.source.basis != expected_basis:
            continue
        if category in _NOTE_STATUS_CATEGORIES:
            statuses.add(category)
            status_cells.setdefault(category,[]).append(cell)
            continue
        notes.setdefault(category, []).append((row, cell))

    # Main aliases denote the same balance. Independent plain bonds and
    # warrant/convertible bonds are separate components of the bond category.
    for category, members in list(main.items()):
        by_name = {}
        for row, cell in members:
            name = _local(cell)
            if name in by_name and (by_name[name][1].value, by_name[name][1].nil) != (cell.value, cell.nil):
                reasons.append('同じ有利子負債項目に一致しない残高があります: ' + name)
            else:
                by_name[name] = (row, cell)
        members = list(by_name.values())
        if category not in {'bonds', 'current_bonds'} and len(members) > 1:
            picked, ambiguity = _unique(members)
            if ambiguity:
                reasons.append('同一範囲の借入金・リース残高を一意に識別できません: ' + category)
            members = [picked] if picked else members
        main[category] = members

    for category, members in list(notes.items()):
        picked, ambiguity = _unique(members)
        if ambiguity:
            reasons.append('注記内で同一範囲の金額が一致しません: ' + category)
        notes[category] = [picked] if picked else members

    # These two actual standard elements disclose WHOLE current/non-current
    # interest-bearing debt, not merely loans. Use the pair only when both
    # are numeric. Inactive nil elements must not shadow a later IFRS lease
    # breakdown or turn non-lease-zero evidence into a false total zero.
    reported_totals = {category:main.get(category,[]) for category in _INTEREST_TOTAL_CATEGORIES}
    known_totals = {category:members for category,members in reported_totals.items()
                    if members and all(c.value is not None and not c.nil for _,c in members)}
    if len(known_totals) == 2:
        terms=[(1,row.key,cell) for category in sorted(known_totals)
               for row,cell in known_totals[category]]
        total_cells=[cell for _,_,cell in terms]
        if len({(c.source.doc_id,c.source.basis)for c in total_cells})!=1:
            reasons.append('短期・長期有利子負債合計の原本又は連結区分が一致しません。')
        scopes={
            'current_interest_bearing_total':{'current_borrowings','short_term_borrowings','current_long_term_borrowings','current_lease','current_bonds','commercial_paper'},
            'noncurrent_interest_bearing_total':{'long_term_borrowings','noncurrent_lease','bonds'},
        }
        for category,covered in scopes.items():
            published=sum((c.value for _,c in known_totals[category]),Decimal(0))
            chosen={}
            for key in covered:
                primary=[c for _,c in main.get(key,[]) if c.value is not None and not c.nil]
                supplementary=[c for _,c in notes.get(key,[]) if c.value is not None and not c.nil]
                if primary and supplementary and abs(sum((c.value for c in primary),Decimal(0))-
                        sum((c.value for c in supplementary),Decimal(0)))>_debt_rounding(primary+supplementary):
                    reasons.append('本表と注記で同じ有利子構成額が一致しません: '+key)
                if primary or supplementary:chosen[key]=primary or supplementary
            if 'current_borrowings'in chosen:
                chosen.pop('short_term_borrowings',None);chosen.pop('current_long_term_borrowings',None)
            parts=[c for values in chosen.values()for c in values]
            subtotal=sum((c.value for c in parts),Decimal(0))
            if ((published==0 and any(c.value>0 for c in parts)) or
                    subtotal-published>_debt_rounding([c for _,c in known_totals[category]]+parts)):
                reasons.append('注記の有利子構成額が、同じ流動・非流動区分の原文有利子負債合計を上回っています。')
        cell,metadata=_make_cell('interest_bearing_debt',terms,reasons,[])
        metadata['coverage']={'note_status':sorted(statuses),
                              'explicit_standard_interest_totals':sorted(known_totals),
                              'whole_reported_interest_bearing_scope':True}
        if metadata['complete']and cell.value==0:
            metadata['zero_evidence']='本表の標準短期・長期有利子負債合計が、どちらも明示された数値ゼロ。'
        cell.note+='\n本表に明示された標準の短期・長期有利子負債合計を採用。この範囲に含まれる借入金・社債・リースの注記構成額は再加算しない。'
        return cell,metadata
    if known_totals:
        reasons.append('短期・長期有利子負債の全体残高の片方だけでは総額を確定できません。')
    for category in _INTEREST_TOTAL_CATEGORIES:
        main.pop(category,None)

    # Japanese BSs can report the whole current-loan bucket under the standard
    # ShortTermLoansPayable element. Establish this narrow relationship from
    # the same original schedule, never from arbitrary equal-valued accounts.
    current_loan_proof = None
    primary_short = main.get('short_term_borrowings', [])
    note_short = notes.get('short_term_borrowings', [])
    note_current = notes.get('current_long_term_borrowings', [])
    if (not main.get('current_borrowings') and not main.get('current_long_term_borrowings')
            and len(primary_short) == len(note_short) == len(note_current) == 1
            and 'borrowings_coverage' in statuses):
        source_row, source_cell = primary_short[0]
        short_row, short_cell = note_short[0]
        current_row, current_cell = note_current[0]
        cells = [source_cell, short_cell, current_cell]
        family, local, _ = _concept(source_cell.source.account_concept)
        same_source = (len({(c.source.doc_id, c.source.basis) for c in cells}) == 1
                       and any((p.source.doc_id, p.source.basis) ==
                               (source_cell.source.doc_id, source_cell.source.basis)
                               for p in status_cells.get('borrowings_coverage', [])))
        if (family == 'jppfs_cor' and local == 'ShortTermLoansPayable' and same_source
                and all(c.value is not None and not c.nil for c in cells)
                and current_cell.value > 0):
            combined = short_cell.value + current_cell.value
            tolerance = _debt_rounding(cells)
            # If both interpretations fit within reporting precision, retain
            # the conservative ambiguity rather than invent an inclusion.
            distinct = abs(source_cell.value-short_cell.value) > _debt_rounding([source_cell,short_cell])
            if distinct and abs(source_cell.value-combined) <= tolerance:
                main['current_borrowings'] = main.pop('short_term_borrowings')
                current_loan_proof = {
                    'kind':'same_original_standard_current_loan_bucket',
                    'period':period.key,'doc_id':source_cell.source.doc_id,'basis':source_cell.source.basis,
                    'main_key':source_row.key,'main_value_jpy':str(source_cell.value),
                    'note_short_term_key':short_row.key,'note_short_term_jpy':str(short_cell.value),
                    'note_current_long_term_key':current_row.key,'note_current_long_term_jpy':str(current_cell.value),
                    'note_sum_jpy':str(combined),'rounding_tolerance_jpy':str(tolerance),
                    'no_separate_main_current_long_term_balance':True,
                    'reason':'本表の標準短期借入金残高が、同じ原本の短期借入金と１年内返済予定長期借入金の合計に一致。報告精度内の本表合算額を採用し、注記構成額を再加算しない。',
                }

    # IFRS current borrowings already contain both short-term borrowing and
    # the current portion of long-term borrowing. Compare a complete note
    # breakdown, or reject an impossible partial amount, before suppressing it.
    suppressed_notes = set()
    broad_html = {}
    for category, members in main.items():
        if category not in {'current_borrowings', 'long_term_borrowings'}:
            continue
        if all(_concept(c.source.account_concept)[0].startswith('issuer:html:') and
               '有利子負債' in _compact(c.source.original_label) for _, c in members):
            covered = ({'short_term_borrowings','current_long_term_borrowings','current_lease','current_bonds','commercial_paper'}
                       if category == 'current_borrowings' else {'long_term_borrowings','noncurrent_lease','bonds'})
            broad_html[category] = covered
            parts = [rc for covered_category in covered for rc in notes.get(covered_category, [])]
            if parts and all(c.value is not None and not c.nil for _, c in members + parts):
                main_value = sum((c.value for _, c in members), Decimal(0))
                part_value = sum((c.value for _, c in parts), Decimal(0))
                if part_value - main_value > _debt_rounding([c for _, c in members + parts]):
                    reasons.append('注記の構成額が原文で明示された有利子負債合計を上回っています。')
            suppressed_notes.update(covered)
    if main.get('current_borrowings'):
        broad = main['current_borrowings']
        broad_cells = [c for _, c in broad]
        parts = [rc for category in ['short_term_borrowings', 'current_long_term_borrowings']
                 for rc in notes.get(category, [])]
        if 'current_borrowings' not in broad_html and all(c.value is not None and not c.nil for c in broad_cells) and parts and all(c.value is not None and not c.nil for _, c in parts):
            total = sum((c.value for c in broad_cells), Decimal(0))
            portion = sum((c.value for _, c in parts), Decimal(0))
            tolerance = _debt_rounding(broad_cells + [c for _, c in parts])
            if {'short_term_borrowings', 'current_long_term_borrowings'} <= set(notes):
                if abs(total - portion) > tolerance:
                    reasons.append('本表の流動借入金と注記の短期・１年内返済借入金が一致しません。')
            elif portion - total > tolerance:
                reasons.append('注記の借入内訳が本表の流動借入金を上回っています。')
        suppressed_notes.update({'short_term_borrowings', 'current_long_term_borrowings'})
        explicit_parts = [rc for category in ['short_term_borrowings', 'current_long_term_borrowings']
                          for rc in main.get(category, [])]
        if explicit_parts and all(c.value is not None and not c.nil for _, c in broad + explicit_parts):
            aggregate = sum((c.value for _, c in broad), Decimal(0))
            subtotal = sum((c.value for _, c in explicit_parts), Decimal(0))
            tolerance = _debt_rounding([c for _, c in broad + explicit_parts])
            if {'short_term_borrowings','current_long_term_borrowings'} <= set(main):
                if abs(aggregate-subtotal)>tolerance:
                    reasons.append('本表の流動借入金合計と同じ本表の構成残高が一致しません。')
            elif subtotal-aggregate>tolerance:
                reasons.append('本表の借入内訳が本表の流動借入金合計を上回っています。')
        for category in ['short_term_borrowings', 'current_long_term_borrowings']:
            if main.get(category):
                # These are an explicit breakdown of the broader IFRS line.
                main.pop(category)

    selected = {}
    for category in sorted(set(main) | set(notes)):
        primary = main.get(category, [])
        supplementary = [] if category in suppressed_notes else notes.get(category, [])
        primary_valid = primary and all(c.value is not None and not c.nil for _, c in primary)
        note_valid = supplementary and all(c.value is not None and not c.nil for _, c in supplementary)
        if primary_valid and note_valid:
            main_value = sum((c.value for _, c in primary), Decimal(0))
            note_value = sum((c.value for _, c in supplementary), Decimal(0))
            if abs(main_value - note_value) > _debt_rounding([c for _, c in primary + supplementary]):
                reasons.append('本表と注記で同一の有利子負債範囲が一致しません: ' + category)
        if primary_valid:
            selected[category] = primary
        elif note_valid:
            selected[category] = supplementary
        elif primary or supplementary:
            selected[category] = primary or supplementary

    opaque = _select(dataset, 'BS_LE', period, lambda r, c: _local(c) in _OPAQUE_FINANCIAL)
    note_coverage = bool(statuses & {'borrowings_coverage', 'borrowings_absent', 'nonlease_debt_absent'})
    bounded_ifrs_coverage = {'ifrs_borrowings_coverage','financial_liabilities_coverage'} <= statuses
    lease_coverage = ({'current_lease', 'noncurrent_lease'} <= set(selected) or
                      {'current_borrowings','long_term_borrowings'} <= set(broad_html))
    if any(c.nil or c.value is None or c.value != 0 for _, c in opaque) and not (
            (note_coverage or bounded_ifrs_coverage) and lease_coverage or
            {'current_borrowings','long_term_borrowings'} <= set(broad_html)):
        reasons.append('その他の金融負債に含まれる有利子項目を、借入金・リースの注記内訳まで確認できません。')
    # A complete BS with Generic Other can still conceal leases (Zuken is a
    # real counterexample). Do not produce zero or a loan-only partial total.
    generic_other = _select(dataset, 'BS_LE', period, lambda r, c: _local(c) in {
        'OtherCL', 'OtherNCL', 'OtherCurrentLiabilitiesCLIFRS', 'OtherNonCurrentLiabilitiesNCLIFRS'})
    if any(c.value not in {None, Decimal(0)} for _, c in generic_other) and not note_coverage and not lease_coverage:
        reasons.append('本表の「その他」にリース債務等が含まれる可能性があり、注記の確認が必要です。')
    terms = [(1, row.key, cell) for members in selected.values() for row, cell in members]
    zero_evidence = None
    if terms and all(cell.value == 0 and not cell.nil for _, _, cell in terms):
        core = {'short_term_borrowings','current_long_term_borrowings','current_lease',
                'bonds','long_term_borrowings','noncurrent_lease'}
        if core <= set(selected):
            zero_evidence = '見本の借入・社債・流動及び非流動リースの全構成範囲について、明示された残高ゼロ又は該当事項なしを確認。'
        elif {'current_borrowings','long_term_borrowings'} <= set(broad_html):
            zero_evidence = '原文の短期・長期有利子負債という明示された全体残高がともにゼロ。'
        else:
            verified, _, explanation = _verified_clean_liabilities(dataset, period)
            if verified:
                zero_evidence = explanation
            else:
                reasons.append('一部構成項目のゼロだけでは有利子負債全体のゼロを確定できません。' + explanation)
    if not terms:
        verified, proof, explanation = _verified_clean_liabilities(dataset, period)
        if verified and not reasons:
            cell, metadata = _make_cell('interest_bearing_debt', [], [], [])
            cell.value = Decimal(0)
            cell.operation = 'analysis_zero_proven'
            cell.components = deepcopy(proof)
            cell.source = deepcopy(proof[0].source)
            cell.source.concept = 'analysis:interest_bearing_debt'
            cell.source.semantic_concept = ''
            cell.source.table_path = ''
            cell.source.original_label = '有利子負債'
            cell.source.raw_value = ''
            cell.note += '\n算出0の根拠: ' + explanation
            metadata.update(complete=True, reason='', zero_evidence=explanation)
            metadata['coverage'] = {'note_status': sorted(statuses), 'clean_balance': True}
            return cell, metadata
        reasons.append('借入金・社債・リースの構成残高又は明示的な該当なしを確認できません。' + explanation)
    cell, metadata = _make_cell('interest_bearing_debt', terms, reasons, [])
    metadata['coverage'] = {'note_status': sorted(statuses), 'lease_categories': lease_coverage,
                            'adopted_categories': sorted(selected),
                            'explicit_html_aggregate_categories': sorted(broad_html),
                            'bounded_ifrs_core_scope': bounded_ifrs_coverage}
    if current_loan_proof:
        metadata['current_loan_aggregate_proof']=current_loan_proof
        cell.note+='\n流動借入金の合算範囲の根拠: '+current_loan_proof['reason']
    excluded=[]
    for proof in status_cells.get('financial_liabilities_coverage',[]):
        try:
            encoded=proof.note.split('debt_note_evidence:',1)[1].splitlines()[0]
            evidence=json.loads(encoded)
        except (IndexError,ValueError,TypeError):
            continue
        for item in evidence.get('excluded_rows',[]):
            excluded.append({**deepcopy(item),'doc_id':proof.source.doc_id,
                             'concept':proof.source.concept,
                             'scope_reason':'見本の借入金・社債・リース及び明示有利子項目に分類されていないため加算しない。有利子ではない・残高ゼロとは断定しない。'})
    if excluded:
        metadata['excluded_financial_components']=excluded
        cell.note+='\n計算定義の範囲外として加算しない金融負債注記項目（非有利子・ゼロとは断定しない）:\n'+'\n'.join(
            f"{item.get('label','項目')}: {item.get('value_jpy',item.get('value',''))}円"for item in excluded)
    if zero_evidence and metadata['complete']:
        metadata['zero_evidence'] = zero_evidence
        cell.note += '\n算出0の根拠: ' + zero_evidence
    if any(row.key.startswith('notes:debt:') for members in selected.values() for row, _ in members):
        cell.note += '\n本表の既知項目を優先し、同じ範囲の注記と照合。不足する借入・リース内訳だけ注記から補完し、二重加算しない。'
    return cell, metadata


def used_debt_note_rows(dataset: Dataset, analysis: Analysis | None = None) -> list[Row]:
    """Visible supporting inputs, restricted to exactly adopted annual cells."""
    analysis = analysis or analyze_dataset(dataset)
    adopted = {}
    for period in dataset.periods:
        cell = analysis.metrics['interest_bearing_debt'].values[period.key]
        for _, key, _ in metric_terms(cell):
            if key.startswith('notes:debt:'):
                adopted.setdefault(key, set()).add(period.key)
    result = []
    for row in getattr(dataset, 'analysis_inputs', []):
        if row.key not in adopted:
            continue
        copied = deepcopy(row)
        copied.values = {key: cell for key, cell in copied.values.items() if key in adopted[row.key]}
        if copied.values:
            result.append(copied)
    return result


def analyze_dataset(dataset: Dataset) -> Analysis:
    """Compute six explicitly defined BS measures, preserving every operand.

    An absent optional exclusion is omitted only alongside its disclosed
    authoritative subtotal. An explicit nil always makes the result unknown.
    Borrowings are not estimated from an opaque financial-liability balance.
    """
    result = Analysis()
    for name, (statement, label, _, _) in DEFINITIONS.items():
        result.metrics[name] = Row('analysis:' + name, label, statement, is_total=True)
        result.metadata[name] = {}
    for period in sorted(dataset.periods):
        for name, group, exclusions in [
                ('net_noncurrent_assets', 'noncurrent_assets', ('tax_noncurrent',)),
                ('net_current_assets', 'current_assets', ('tax_current', 'allowance_current')),
                ('net_current_liabilities', 'current_liabilities', ('provisions_current',))]:
            terms, reasons, omitted = [], [], []
            total, reason = _total(dataset, group, period)
            if total is None:
                reasons.append(BS_LABELS[group] + ': ' + reason)
            else:
                terms.append((1, total[0].key, total[1]))
                if not _group_proven(*total, group):
                    reasons.append('基礎となる区分合計が未開示・nilです。')
            for exclusion in exclusions:
                if exclusion.startswith('tax_'):
                    kind = exclusion.removeprefix('tax_')
                    matches = _select(dataset, 'BS_A', period, lambda r, c: _tax_kind(r, c) == kind)
                    unknown = _select(dataset, 'BS_A', period, lambda r, c: _tax_kind(r, c) == 'unknown')
                    if unknown:
                        reasons.append('繰延税金資産の流動・非流動区分を一意に識別できません。')
                elif exclusion == 'allowance_current':
                    matches = _select(dataset, 'BS_A', period, _current_allowance)
                else:
                    matches = _select(dataset, 'BS_LE', period, _current_provision)
                    aggregates = [rc for rc in matches if _local(rc[1]) in {'ProvisionsCLIFRS', 'ProvisionsCL'}]
                    if aggregates:
                        # Broad standard-taxonomy provision balances replace
                        # their individually disclosed breakdown, never add it.
                        picked, ambiguity = _unique(aggregates)
                        matches = [picked] if picked else []
                        if ambiguity:
                            reasons.append(ambiguity)
                if not matches:
                    if total and _group_proven(*total, group):
                        omitted.append({'tax_noncurrent':'非流動の繰延税金資産', 'tax_current':'流動の繰延税金資産',
                                        'allowance_current':'流動の貸倒引当金', 'provisions_current':'流動の引当金'}[exclusion])
                    else:
                        reasons.append('控除項目の有無を確認できません: ' + exclusion)
                else:
                    # Tax/allowance categories are each a single balance;
                    # provision categories may have independent components.
                    if exclusion != 'provisions_current':
                        picked, ambiguity = _unique(matches)
                        matches = [picked] if picked else []
                        if ambiguity:
                            reasons.append(ambiguity)
                    terms.extend((-1, row.key, cell) for row, cell in matches)
            cell, meta = _make_cell(name, terms, reasons, omitted)
            result.metrics[name].values[period.key] = cell
            result.metadata[name][period.key] = meta
        for name, inputs in [('net_working_capital', [('net_current_assets', 1), ('net_current_liabilities', -1)]),
                             ('invested_capital', [('net_noncurrent_assets', 1), ('net_working_capital', 1)])]:
            terms = [(sign, 'analysis:' + dep, result.metrics[dep].values[period.key]) for dep, sign in inputs]
            cell, meta = _make_cell(name, terms, [], [])
            result.metrics[name].values[period.key] = cell
            result.metadata[name][period.key] = meta
        cell, meta = _debt_analysis(dataset, period)
        result.metrics['interest_bearing_debt'].values[period.key] = cell
        result.metadata['interest_bearing_debt'][period.key] = meta
    return result


def analysis_metrics(dataset: Dataset) -> dict[str, Row]:
    return analyze_dataset(dataset).metrics


def chart_data(dataset: Dataset, unit: str = 'auto') -> dict:
    """UI-independent, chronological Decimal series with explicit gaps.

    Money is converted to the selected display unit. Ratio values are fractions
    (0.25 means 25%). Aligned cells retain the original public source evidence.
    """
    if unit == 'auto':
        unit = detect_display_unit(dataset)
    factors = {'yen': Decimal(1), 'thousand': Decimal(1000), 'million': Decimal(1000000)}
    if unit not in factors:
        raise ValueError('表示単位は auto / yen / thousand / million を指定してください。')
    factor = factors[unit]
    periods = sorted(dataset.periods)
    output = {'code': dataset.code, 'company': dataset.company, 'unit': unit,
              'unit_label': {'yen':'円', 'thousand':'千円', 'million':'百万円'}[unit], 'factor': factor,
              'periods': [{'key': p.key, 'label': p.label, 'start': p.start.isoformat(), 'end': p.end.isoformat(),
                           'basis': dataset.period_bases.get(p.key, dataset.basis),
                           'accounting_standard': dataset.period_standards.get(p.key, dataset.accounting_standard)}
                          for p in periods], 'PL': {}, 'BS': {}, 'CF': {}}
    exported, addresses = {}, {}
    for item in dataset.export_metadata.get('cells', []):
        key = item.get('sheet'), item.get('row_key'), item.get('period')
        if key[1] and not str(key[1]).startswith('helper:'):
            exported[key] = item
            addresses[item.get('sheet'), item.get('address'), item.get('period')] = item
    exported_unit = dataset.export_metadata.get('unit')
    def final_value(sheet, key, period, original):
        entry = exported.get((sheet, key, period.key))
        if sheet in {'BS-A', 'BS-L,E'}:
            mapped = dataset.export_metadata.get('source_addresses', {}).get(key, {}).get(period.key)
            if mapped:
                entry = addresses.get((mapped.get('sheet', sheet), mapped.get('address'), period.key), entry)
                if entry is None:
                    entry = exported.get((mapped.get('sheet', sheet), mapped.get('row_key'), period.key))
        if entry is None:
            return original
        raw = entry.get('display_value')
        if raw is None or raw == '':
            return None
        try:
            value = Decimal(str(raw))
        except Exception:
            return None
        if not value.is_finite():
            return None
        source_factor = factors.get(entry.get('unit'), factors.get(exported_unit))
        return value * source_factor if source_factor else original
    def series(label, row, *, sheet, keys=None, kind='money'):
        cells = [row.values.get(p.key) if row else None for p in periods]
        # Explicit branch ordering is important: nil values are not arithmetic
        # operands and cannot be converted into an apparent zero in the graph.
        original = [None if c is None or c.nil or c.value is None else c.value for c in cells]
        values = [final_value(sheet, keys.get(p.key) if keys else row.key if row else '', p, value)
                  for p, value in zip(periods, original)]
        values = [None if value is None else value / factor if kind == 'money' else value for value in values]
        return {'label': label, 'kind': kind, 'values': values, 'cells': cells}
    pl = pl_metrics(dataset)
    for name, label in [('revenue','売上高'), ('gross_profit','売上総利益'),
                        ('operating_profit','営業利益'), ('net_profit','当期純利益')]:
        output['PL'][name] = series(label, pl.get(name), sheet='PL')
    for name, numerator, label in [('gross_margin','gross_profit','売上総利益率'),
                                   ('operating_margin','operating_profit','営業利益率'),
                                   ('net_margin','net_profit','当期純利益率')]:
        values, cells = [], []
        for p in periods:
            n = pl.get(numerator).values.get(p.key) if pl.get(numerator) else None
            d = pl.get('revenue').values.get(p.key) if pl.get('revenue') else None
            nvalue = final_value('PL', 'metric:' + numerator, p,
                                 n.value if n and not n.nil else None)
            dvalue = final_value('PL', 'metric:revenue', p,
                                 d.value if d and not d.nil else None)
            valid = nvalue is not None and dvalue not in {None, Decimal(0)}
            values.append(nvalue / dvalue if valid else None)
            cells.append(n if valid else None)
        output['PL'][name] = {'label':label, 'kind':'ratio', 'values':values, 'cells':cells}
    for name, row in bs_metrics(dataset).items():
        keys = {}
        for p in periods:
            selected, _ = _total(dataset, name, p)
            if selected:
                keys[p.key] = selected[0].key
        output['BS'][name] = series(BS_LABELS[name], row, sheet='BS-A' if row.statement == 'BS_A' else 'BS-L,E', keys=keys)
    cf = cf_metrics(dataset)
    for name, slot, label in [('operating',40,'営業CF'), ('investing',54,'投資CF'),
                              ('financing',64,'財務CF'), ('cash',68,'現金及び現金同等物')]:
        output['CF'][name] = series(label, cf.get(f'template:CF:{slot}'), sheet='CF')
    return output
