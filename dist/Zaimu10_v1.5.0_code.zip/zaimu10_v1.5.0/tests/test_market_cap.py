from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest

from zaimu10.market_cap import (ShareCountError, assemble_market_caps,
                               extract_fiscal_shares, load_fiscal_share_counts,
                               _share_amendment_review)
from zaimu10.models import Filing, Period


END = date(2024, 3, 31)
PERIOD = Period(date(2023, 4, 1), END)
FILING = Filing('S100TEST', code='6947', end=END, submitted='2024-06-19')


def pages(*, shares='22249804', fiscal='2024-03-31', code='69470', extra='', dimension='',
          ordinary_axis='ClassesOfSharesAxis', numeric=True):
    numeric_facts = f'''<ix:nonFraction name="jpcrp_cor:NumberOfIssuedSharesAsOfFiscalYearEndIssuedSharesTotalNumberOfSharesEtc"
          contextRef="FilingDateInstant" unitRef="shares" scale="0">{shares}</ix:nonFraction>
      <ix:nonFraction name="jpcrp_cor:NumberOfIssuedSharesAsOfFiscalYearEndIssuedSharesTotalNumberOfSharesEtc"
          contextRef="FilingDateInstant_OrdinaryShareMember" unitRef="shares" scale="0">{shares}</ix:nonFraction>''' if numeric else ''
    return [('shares.xhtml', f'''<html
      xmlns:ix="http://www.xbrl.org/2013/inlineXBRL"
      xmlns:xbrli="http://www.xbrl.org/2003/instance"
      xmlns:xbrldi="http://xbrl.org/2006/xbrldi"
      xmlns:jpdei_cor="http://disclosure.edinet-fsa.go.jp/taxonomy/jpdei/2024-11-01/jpdei_cor"
      xmlns:jpcrp_cor="http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor">
      <xbrli:context id="FilingDateInstant"><xbrli:entity>{dimension}</xbrli:entity>
        <xbrli:period><xbrli:instant>2024-06-19</xbrli:instant></xbrli:period></xbrli:context>
      <xbrli:context id="FilingDateInstant_OrdinaryShareMember"><xbrli:entity><xbrldi:explicitMember
        dimension="jpcrp_cor:{ordinary_axis}">jpcrp_cor:OrdinaryShareMember</xbrldi:explicitMember></xbrli:entity>
        <xbrli:period><xbrli:instant>2024-06-19</xbrli:instant></xbrli:period></xbrli:context>
      <xbrli:unit id="shares"><xbrli:measure>xbrli:shares</xbrli:measure></xbrli:unit>
      <ix:nonNumeric name="jpdei_cor:CurrentFiscalYearEndDateDEI">{fiscal}</ix:nonNumeric>
      <ix:nonNumeric name="jpdei_cor:SecurityCodeDEI">{code}</ix:nonNumeric>
      {numeric_facts}{extra}</html>''')]


def test_fiscal_issued_shares_uses_exact_as_of_fiscal_year_end_fact():
    extra = '''<ix:nonFraction name="jpcrp_cor:NumberOfIssuedSharesAsOfFilingDateIssuedSharesTotalNumberOfSharesEtc"
       contextRef="FilingDateInstant" unitRef="shares">99999999</ix:nonFraction>'''
    item = extract_fiscal_shares(pages(extra=extra), FILING, END, '6947')
    assert Decimal(item['value_shares']) == Decimal(22249804)
    assert item['fiscal_end'] == '2024-03-31'
    assert len(item['sha256']) == 64


@pytest.mark.parametrize('changed', [dict(fiscal='2025-03-31'), dict(code='78260'),
    dict(shares='1.5'), dict(shares='0'),
    dict(extra='''<ix:nonFraction name="jpcrp_cor:NumberOfIssuedSharesAsOfFiscalYearEndIssuedSharesTotalNumberOfSharesEtc"
       contextRef="FilingDateInstant" unitRef="shares">999</ix:nonFraction>'''),
    dict(dimension='''<xbrldi:explicitMember dimension="jpcrp_cor:ClassOfSharesAxis">jpcrp_cor:PreferredShareMember</xbrldi:explicitMember>''')])
def test_wrong_year_code_value_or_share_dimension_is_not_used(changed):
    with pytest.raises(ShareCountError):
        extract_fiscal_shares(pages(**changed), FILING, END, '6947')


def test_market_cap_uses_dated_historical_price_with_historical_issued_shares():
    shares = extract_fiscal_shares(pages(), FILING, END, '6947')
    result = assemble_market_caps([PERIOD], {'shares': {PERIOD.key: shares}}, {'prices': {
        '2024-03-31': {'historical_close_jpy': '4505', 'trading_date': '2024-03-29',
                       'split_factor_after_fiscal_date': '1'}}})
    assert result[PERIOD.key]['value_jpy'] == '100235367020'
    assert result[PERIOD.key]['issued_shares']['value_shares'] == '22249804'


@pytest.mark.parametrize('trading_date,price', [('2024-04-01','4505'), ('2024-03-01','4505'),
                                               ('2024-03-29','NaN'), ('2024-03-29','0')])
def test_invalid_fiscal_price_is_rejected(trading_date, price):
    shares = extract_fiscal_shares(pages(), FILING, END, '6947')
    with pytest.raises(ShareCountError):
        assemble_market_caps([PERIOD], {'shares': {PERIOD.key: shares}}, {'prices': {
            END.isoformat(): {'historical_close_jpy': price, 'trading_date': trading_date}}})


def test_missing_share_or_price_stays_missing():
    assert assemble_market_caps([PERIOD], {'shares': {}}, {'prices': {}}) == {}


def legacy_pages(*, fiscal_header='事業年度末現在発行数（株）（令和６年３月31日）',
                 submission_header='提出日現在発行数（株）（2024年６月19日）',
                 fiscal_value='22,249,804', total_value=None, submission_value='99,999,999',
                 class_label='普通株式', extra_rows='', reversed_columns=False,
                 extra_table='', context='FilingDateInstant', duplicate=False):
    total_value = fiscal_value if total_value is None else total_value
    heads = [fiscal_header, submission_header]
    ordinary = [fiscal_value, submission_value]
    total = [total_value, submission_value]
    if reversed_columns:
        heads.reverse(); ordinary.reverse(); total.reverse()
    table = f'''<table><tr><th>種類</th><th>{heads[0]}</th><th>{heads[1]}</th><th>上場金融商品取引所名</th><th>内容</th></tr>
      <tr><td>{class_label}</td><td>{ordinary[0]}</td><td>{ordinary[1]}</td><td>東京証券取引所</td><td>単元株式数100株</td></tr>
      {extra_rows}<tr><td>計</td><td>{total[0]}</td><td>{total[1]}</td><td>－</td><td>－</td></tr></table>{extra_table}'''
    block = f'''<ix:nonNumeric name="jpcrp_cor:IssuedSharesTotalNumberOfSharesEtcTextBlock"
                 contextRef="{context}"><h5>②【発行済株式】</h5>{table}</ix:nonNumeric>'''
    return pages(numeric=False, extra=block * (2 if duplicate else 1))


@pytest.mark.parametrize('reversed_columns', [False, True])
def test_legacy_uses_the_dated_fiscal_column_even_when_submission_shares_differ(reversed_columns):
    item = extract_fiscal_shares(legacy_pages(reversed_columns=reversed_columns), FILING, END, '6947')
    assert item['value_shares'] == '22249804'
    assert item['extraction_method'] == 'issued_shares_textblock'
    evidence = item['source_evidence']
    assert evidence['fiscal_header_date'] == END.isoformat()
    assert evidence['fiscal_column'] == (3 if reversed_columns else 2)
    assert evidence['submission_ordinary_raw'] == '99,999,999'
    assert evidence['ordinary_physical_row'] == 2
    assert evidence['total_raw'] == '22,249,804'


@pytest.mark.parametrize('change', [
    {'fiscal_header': '事業年度末現在発行数（千株）（2024年３月31日）'},
    {'fiscal_header': '事業年度末現在発行数（株）（2023年３月31日）'},
    {'fiscal_header': '事業年度末現在発行数（株）（平成36年３月31日）'},
    {'fiscal_header': '事業年度末現在発行数（株）'},
    {'fiscal_header': '提出日現在発行数（株）（2024年３月31日）'},
    {'submission_header': '提出日現在発行数（株）（2024年６月20日）'},
    {'class_label': '優先株式'},
    {'total_value': '22,249,805'},
    {'fiscal_value': '0'}, {'fiscal_value': '1.5'},
    {'fiscal_value': '1,00'}, {'fiscal_value': '22249804株'},
    {'extra_rows': '<tr><td>優先株式</td><td>1</td><td>1</td><td>－</td><td>－</td></tr>'},
    {'extra_rows': '<tr><td>普通株式</td><td>22249804</td><td>22249804</td><td>－</td><td>－</td></tr>'},
    {'extra_table': '<table><tr><td>別表</td></tr></table>'},
    {'context': 'FilingDateInstant_OrdinaryShareMember'},
    {'duplicate': True},
])
def test_legacy_rejects_wrong_date_unit_class_ambiguous_or_noninteger_tables(change):
    with pytest.raises(ShareCountError):
        extract_fiscal_shares(legacy_pages(**change), FILING, END, '6947')


def test_ordinary_member_on_an_unrelated_axis_cannot_confirm_ordinary_share_count():
    with pytest.raises(ShareCountError, match='株式次元'):
        extract_fiscal_shares(pages(ordinary_axis='BusinessSegmentsAxis'), FILING, END, '6947')


def test_aggregate_without_any_ordinary_share_evidence_is_not_a_common_share_market_cap():
    raw = pages()[0][1]
    raw = raw.replace('contextRef="FilingDateInstant_OrdinaryShareMember"', 'contextRef="FilingDateInstant"')
    with pytest.raises(ShareCountError, match='普通株式'):
        extract_fiscal_shares([('shares.xhtml', raw)], FILING, END, '6947')


@pytest.mark.parametrize('change', ['continuation', 'future_context', 'missing_context'])
def test_numeric_share_facts_cannot_use_partial_text_or_unrelated_instant(change):
    raw = pages()[0][1]
    if change == 'continuation':
        raw = raw.replace('unitRef="shares" scale="0">22249804',
                          'unitRef="shares" scale="0" continuedAt="remainingDigits">22249804', 1)
    elif change == 'future_context':
        raw = raw.replace('<xbrli:instant>2024-06-19</xbrli:instant>',
                          '<xbrli:instant>2024-07-01</xbrli:instant>')
    else:
        raw = raw.replace('contextRef="FilingDateInstant"', 'contextRef="unknown"', 1)
    with pytest.raises(ShareCountError):
        extract_fiscal_shares([('shares.xhtml', raw)], FILING, END, '6947')


LEGACY_CASES = json.loads(gzip.decompress((Path(__file__).parent / 'fixtures' / 'shares_legacy_ixbrl.json.gz').read_bytes()))


@pytest.mark.parametrize('case', LEGACY_CASES, ids=lambda case: case['doc_id'])
def test_real_legacy_fiscal_share_tables(case):
    end = date.fromisoformat(case['fiscal_end'])
    filing = Filing(case['doc_id'], code=case['code'], end=end, submitted=case['submitted'])
    item = extract_fiscal_shares(case['pages'], filing, end, case['code'])
    assert item['value_shares'] == case['expected_shares']
    assert item['source_evidence']['fiscal_header_date'] == case['fiscal_end']
    assert item['source_evidence']['submission_header_date'] == case['submitted']
    assert item['source_evidence']['ordinary_raw'] == item['source_evidence']['total_raw']
    assert item['concept'].endswith('}IssuedSharesTotalNumberOfSharesEtcTextBlock')


def _amendment_fixture(doc):
    root = Path(__file__).parent / 'fixtures' / 'amendments'
    zipped = root / f'furuya_{doc}.json.gz'
    if zipped.exists():
        return json.loads(gzip.decompress(zipped.read_bytes()))
    return [('0000000_header.htm' if i == 0 else '0101000_body.htm', p.read_text())
            for i, p in enumerate(sorted((root / doc).glob('*.html')))]


@pytest.mark.parametrize('doc', ['S100COBD', 'S100C56P', 'S100EPJ6', 'S100JLQS', 'S100LFL0'])
def test_real_bounded_corrections_have_positive_share_scope_proof(doc):
    result = _share_amendment_review(_amendment_fixture(doc))
    assert result['status'] == 'shares_unaffected'
    assert result['scope_proof']['evidence']


def test_extra_issued_share_count_prose_in_an_otherwise_safe_correction_blocks_old_shares():
    source = _amendment_fixture('S100C56P')
    modified = [source[0], (source[1][0], source[1][1].replace('</body>',
        '<p>発行済株式総数は訂正後99,999株です。</p></body>'))]
    assert _share_amendment_review(modified)['status'] == 'unknown'


def _load_with_pages(monkeypatch, filings, documents):
    calls = []
    def fetch(doc_id, **kwargs):
        calls.append(doc_id)
        value = documents[doc_id]
        if isinstance(value, Exception):
            raise value
        return value
    monkeypatch.setattr('zaimu10.edinet.fetch_filing', fetch)
    result = load_fiscal_share_counts('6947', [PERIOD], filings,
                                     cache_dir=Path('/unused-cache'), log=lambda _: None)
    return result, calls


def test_malformed_latest_annual_never_falls_back_to_an_older_annual(monkeypatch):
    older = Filing('S100OLDER', code='6947', end=END, submitted='2024-06-18')
    result, calls = _load_with_pages(monkeypatch, [older, FILING],
                                   {FILING.doc_id: pages(shares='0'), older.doc_id: pages()})
    assert result['shares'] == {}
    assert PERIOD.key in result['missing']
    assert calls == [FILING.doc_id]


@pytest.mark.parametrize('amended_pages', [pages(shares='0'), pages(code='78260'),
    [('unknown.htm', '<html><body><p>発行済株式数を訂正する。</p></body></html>')],
    OSError('amendment unavailable')])
def test_share_bearing_malformed_or_unknown_newer_correction_blocks_the_period(monkeypatch, amended_pages):
    amendment = Filing('S100AMEND', code='6947', end=END,
                       submitted='2024-07-01', amended=True)
    result, calls = _load_with_pages(monkeypatch, [FILING, amendment],
        {FILING.doc_id: pages(), amendment.doc_id: amended_pages})
    assert result['shares'] == {}
    assert PERIOD.key in result['missing']
    assert calls == [FILING.doc_id, amendment.doc_id]


def test_complete_validated_newer_share_correction_replaces_the_annual_count(monkeypatch):
    amendment = Filing('S100AMEND', code='6947', end=END,
                       submitted='2024-07-01', amended=True)
    updated = [(name, raw.replace('2024-06-19', '2024-07-01')) for name, raw in pages(shares='33333333')]
    result, _ = _load_with_pages(monkeypatch, [FILING, amendment],
        {FILING.doc_id: pages(), amendment.doc_id: updated})
    item = result['shares'][PERIOD.key]
    assert item['doc_id'] == amendment.doc_id
    assert item['value_shares'] == '33333333'
    assert item['baseline_annual_doc_id'] == FILING.doc_id
    assert item['amendment_review'][0]['status'] == 'validated_updated_share_count'


def test_positive_absence_proof_preserves_annual_with_the_amendment_audit(monkeypatch):
    amendment = Filing('S100AMEND', code='6947', end=END,
                       submitted='2024-07-01', amended=True)
    result, _ = _load_with_pages(monkeypatch, [FILING, amendment],
        {FILING.doc_id: pages(), amendment.doc_id: _amendment_fixture('S100COBD')})
    item = result['shares'][PERIOD.key]
    assert item['doc_id'] == FILING.doc_id
    assert item['amendment_review'][0]['status'] == 'shares_unaffected'
    assert item['amendment_review'][0]['scope_proof']['evidence']


def test_amendment_without_a_normal_annual_is_unavailable(monkeypatch):
    amendment = Filing('S100AMEND', code='6947', end=END,
                       submitted='2024-07-01', amended=True)
    result, calls = _load_with_pages(monkeypatch, [amendment], {amendment.doc_id: pages()})
    assert result['shares'] == {}
    assert calls == []


def test_share_loader_propagates_cancellation(monkeypatch):
    with pytest.raises(InterruptedError):
        _load_with_pages(monkeypatch, [FILING], {FILING.doc_id: InterruptedError('cancel')})


@pytest.mark.parametrize('status', [None, '', 'unverified', 'failed'])
@pytest.mark.parametrize('provider', ['YahooJapan', 'Kabutan'])
def test_nominal_japan_quote_is_unavailable_until_legal_share_basis_is_proven(status, provider):
    period = Period(date(2023, 7, 1), date(2024, 6, 30))
    shares = {'shares': {period.key: {'value_shares': '8463212', 'fiscal_end': '2024-06-30'}}}
    price = {'historical_close_jpy': '4370', 'trading_date': '2024-06-28',
             'price_provider': provider, 'share_basis_state': 'nominal_quote_at_trading_date'}
    if status is not None:
        price['basis_alignment_status'] = status
    assert assemble_market_caps([period], shares, {'prices': {'2024-06-30': price}}) == {}
    aligned = dict(price, historical_close_jpy='13110', basis_alignment_status='aligned')
    result = assemble_market_caps([period], shares, {'prices': {'2024-06-30': aligned}})
    assert result[period.key]['value_jpy'] == '110952709320'


def test_japan_quote_without_a_split_requires_explicit_not_needed_alignment():
    shares = extract_fiscal_shares(pages(), FILING, END, '6947')
    result = assemble_market_caps([PERIOD], {'shares': {PERIOD.key: shares}}, {'prices': {
        '2024-03-31': {'historical_close_jpy': '4505', 'trading_date': '2024-03-29',
                       'price_provider': 'YahooJapan', 'basis_alignment_status': 'not_needed'}}})
    assert result[PERIOD.key]['value_jpy'] == '100235367020'
