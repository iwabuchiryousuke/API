"""Read explicitly dated IFRS main tables without account-level numeric tags.

The TextBlock QName is kept as the source. Caption roles below are separate
issuer-scoped HTML identities, never fabricated numeric XBRL QNames.
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal
import hashlib
import json
import re
import unicodedata

from .models import Cell, Row, Source

BS = {
    '有形固定資産':'PropertyPlantAndEquipmentIFRS', '無形資産':'IntangibleAssetsIFRS',
    '繰延税金資産':'DeferredTaxAssetsIFRS', '非流動資産合計':'NonCurrentAssetsIFRS',
    '棚卸資産':'InventoriesIFRS', '流動資産合計':'CurrentAssetsIFRS',
    '資産合計':'AssetsIFRS', '現金及び現金同等物':'CashAndCashEquivalentsIFRS',
    '非流動負債合計':'NonCurrentLabilitiesIFRS','流動負債合計':'CurrentLiabilitiesIFRS',
    '負債合計':'LiabilitiesIFRS','資本合計':'EquityIFRS',
    '純資産合計':'HtmlNetAssetsIFRS','当社の株主持分':'EquityAttributableToOwnersOfParentIFRS',
    '非支配持分':'NonControllingInterestsIFRS',
    '長期有利子負債':'BorrowingsNCLIFRS','短期有利子負債':'BorrowingsCLIFRS',
    '長期引当金':'ProvisionsNCLIFRS','短期引当金':'ProvisionsCLIFRS',
    '繰延税金負債':'DeferredTaxLiabilitiesIFRS',
    '負債及び資本合計':'LiabilitiesAndEquityIFRS',
    '親会社の所有者に帰属する持分':'EquityAttributableToOwnersOfParentIFRS',
    '売上債権及びその他の債権':'TradeAndOtherReceivablesCAIFRS',
    '仕入債務及びその他の債務':'TradeAndOtherPayablesCLIFRS',
    '短期借入金':'ShortTermBorrowingsIFRS',
    '1年内返済予定の長期借入金':'CurrentPortionOfLongTermBorrowingsIFRS',
    '1年内償還予定の社債':'CurrentPortionOfBonds',
    '長期借入金':'LongTermBorrowingsIFRS','社債':'BondsPayableNCLIFRS',
    '資本金':'ShareCapitalIFRS','資本剰余金':'CapitalSurplusIFRS',
    '自己株式':'TreasurySharesIFRS','利益剰余金':'RetainedEarningsIFRS',
    'その他の資本の構成要素':'OtherComponentsOfEquityIFRS',
    'その他の流動資産':'OtherCurrentAssetsIFRS',
    'その他の非流動資産':'OtherNonCurrentAssetsIFRS',
}
PL = {'売上収益':'RevenueIFRS','売上高':'RevenueIFRS','売上原価':'CostOfSalesIFRS',
      '売上総利益':'GrossProfitIFRS','営業利益':'OperatingProfitLossIFRS',
      '税引前当期利益':'ProfitLossBeforeTaxIFRS','法人所得税':'IncomeTaxExpenseIFRS',
      '当期利益':'ProfitLossIFRS','金融費用':'FinanceCostsIFRS',
      'その他の金融収入(支出)':'FinanceIncomeIFRS',
      '当社の株主持分':'ProfitLossAttributableToOwnersOfParentIFRS',
      '非支配持分':'ProfitLossAttributableToNonControllingInterestsIFRS',
      '販売費':'SellingExpensesIFRS','研究開発費':'ResearchAndDevelopmentExpensesIFRS',
      '一般管理費':'GeneralAndAdministrativeExpensesIFRS','一般管理費等':'GeneralAndAdministrativeExpensesIFRS',
      '持分法による損益':'ShareOfProfitLossOfInvestmentsAccountedForUsingEquityMethodIFRS',
      'その他の営業収益':'OtherIncomeIFRS','その他の営業費用':'OtherExpensesIFRS',
      '金融収益':'FinanceIncomeIFRS','税金費用':'IncomeTaxExpenseIFRS',
      '継続事業の当期利益':'ProfitLossFromContinuingOperationsIFRS',
      '非継続事業の当期利益':'ProfitLossFromDiscontinuedOperationsIFRS',
      '親会社の所有者に帰属する当期利益合計':'ProfitLossAttributableToOwnersOfParentIFRS'}
CF = {'営業活動によるキャッシュ・フロー':'NetCashProvidedByUsedInOperatingActivitiesIFRS',
      '投資活動によるキャッシュ・フロー':'NetCashProvidedByUsedInInvestingActivitiesIFRS',
      '財務活動によるキャッシュ・フロー':'NetCashProvidedByUsedInFinancingActivitiesIFRS',
      '現金及び現金同等物に係る換算差額':'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS',
      '現金及び現金同等物の増減額':'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS',
      '現金及び現金同等物の期首残高':'CashAndCashEquivalentsIFRS',
      '現金及び現金同等物の期末残高':'CashAndCashEquivalentsIFRS',
      '法人所得税の支払':'IncomeTaxesPaidOpeCFIFRS',
      '有形固定資産の取得':'PurchaseOfPropertyPlantAndEquipmentInvCFIFRS',
      '無形資産の取得':'PurchaseOfIntangibleAssetsInvCFIFRS',
      '税引前当期利益':'ProfitLossBeforeTaxIFRS',
      '減価償却費及び償却費':'DepreciationAndAmortizationOpeCFIFRS',
      '減損損失':'ImpairmentLossesReversalOfImpairmentLossesOpeCFIFRS',
      '受取利息':'InterestAndDividendIncomeOpeCFIFRS',
      '受取配当金':'InterestAndDividendsIncomeOpeCF',
      '支払利息':'InterestExpensesOpeCFIFRS',
      '持分法による損益':'ShareOfLossProfitOfInvestmentsAccountedForUsingEquityMethodOpeCFIFRS',
      '固定資産除却損':'LossOnRetirementOfNoncurrentAssetsOpeCF',
      '固定資産売却益':'LossGainOnSaleOfFixedAssetsOpeCFIFRS',
      '売上債権及びその他の債権の増減額':'DecreaseIncreaseInTradeAndOtherReceivablesOpeCFIFRS',
      '仕入債務及びその他の債務の増減額':'IncreaseDecreaseInTradeAndOtherPayablesOpeCFIFRS',
      '棚卸資産の増減額':'DecreaseIncreaseInInventoriesOpeCFIFRS',
      '未払消費税等の増減額':'IncreaseDecreaseInAccruedConsumptionTaxesOpeCF',
      '保険金の受取額':'ProceedsFromInsuranceIncomeOpeCF',
      '利息の受取額':'InterestReceivedOpeCFIFRS',
      '配当金の受取額':'DividendsReceivedOpeCFIFRS',
      '利息の支払額':'InterestPaidOpeCFIFRS',
      '法人所得税の支払額':'IncomeTaxesPaidOpeCFIFRS',
      '有形固定資産の取得による支出':'PurchaseOfPropertyPlantAndEquipmentInvCF',
      '有形固定資産の売却による収入':'ProceedsFromSalesOfPropertyPlantAndEquipmentInvCF',
      '無形資産の取得による支出':'PurchaseOfIntangibleAssetsInvCF',
      '連結の範囲の変更を伴う子会社株式の取得による支出':'PurchaseOfInvestmentsInSubsidiariesResultingInChangeInScopeOfConsolidationInvCF',
      '連結の範囲の変更を伴う子会社株式の売却による収入':'ProceedsFromSalesOfInvestmentsInSubsidiariesResultingInChangeInScopeOfConsolidationInvCF',
      '関係会社株式の取得による支出':'PurchaseOfStocksOfSubsidiariesAndAffiliatesInvCF',
      '関係会社株式の売却による収入':'ProceedsFromSalesOfStocksOfSubsidiariesAndAffiliatesInvCF',
      '短期借入金の増減額':'NetIncreaseDecreaseInShortTermBorrowingsFinCFIFRS',
      '長期借入れによる収入':'ProceedsFromLongTermLoansPayableFinCF',
      '長期借入金の返済による支出':'RepaymentsOfLongTermBorrowingsFinCFIFRS',
      '社債の償還による支出':'RedemptionOfBondsPayableFinCF',
      '配当金の支払額':'DividendsPaidFinCFIFRS',
      '自己株式の取得による支出':'PaymentsForPurchaseOfTreasurySharesFinCFIFRS',
      '現金及び現金同等物の換算差額':'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS'}


def compact(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or '')).rstrip('：:')


def read_html_block(filing, page, block, statement, dataset, contexts):
    from .parser import (_cells,_text,_grid,_table_rows,_expanded,_total,_indent,
                         ParseError)
    if 'IFRS' not in block.get('name',''):
        raise ParseError('タグのない本表は、明示されたIFRS本表以外では解釈しません。')
    block_context=contexts.get(block.get('contextref',''))
    if block_context is None or block_context.dimensions or block.get('continuedat'):
        raise ParseError('HTML本表のコンテキストまたは継続参照を確定できません。')
    units=set(re.findall(r'単位\s*[:：]\s*(百万円|千円|円)',_text(block)))
    if len(units)!=1:
        raise ParseError('HTML本表の単位を一意に確定できません。')
    scale={'円':0,'千円':3,'百万円':6}[units.pop()]
    source_qname=_expanded(block.get('name',''),page.namespaces)
    issuer=filing.edinet_code
    if not re.fullmatch(r'E\d{5}',issuer or ''):
        raise ParseError('HTML本表の提出者を確定できません。')
    namespace='urn:zaimu10:html-table:'+issuer+':'+block.get('name','').rsplit(':',1)[-1]
    side='BS_A';section=();count=0
    by_end={p.end:p for p in dataset.periods}
    for table_index,(table,rows) in enumerate(_table_rows(block)):
        grid=_grid(rows); columns={};opening_columns={}
        for tr in rows:
            for col,cell in grid[tr]:
                text=unicodedata.normalize('NFKC',_text(cell))
                dates=[date(int(y),int(m),int(d)) for y,m,d in
                       re.findall(r'(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日',text)]
                if not dates:continue
                end=dates[-1]
                if end not in by_end:
                    # First-time IFRS adoption can show an explicitly dated
                    # opening balance beside the annual comparative/current
                    # columns. It is not an extra annual result. Require the
                    # actual earliest duration start; never infer a year/date.
                    header_role=re.sub(r'\d{4}年\s*\d{1,2}月\s*\d{1,2}日','',text)
                    header_role=re.sub(r'[\s()（）:：]','',header_role)
                    if (statement=='BS'and len(dates)==1 and
                        header_role in {'移行日','期首','IFRS移行日'}and
                        end==min(p.start for p in dataset.periods)):
                        opening_columns[col]={'header':text,'date':end.isoformat()}
                        continue
                    raise ParseError('HTML本表に対象期間と対応しない日付列があります。')
                if end in by_end:
                    if len(dates)>1 and dates[0]!=by_end[end].start:
                        raise ParseError('HTML本表の開始日と年度が一致しません。')
                    if col in columns and columns[col]!=by_end[end]:
                        raise ParseError('HTML本表の年度列が重複しています。')
                    columns[col]=by_end[end]
        if set(columns)&set(opening_columns):
            raise ParseError('HTML本表の期首列と年度末列が重複しています。')
        if not columns:
            if any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',compact(_text(c)))
                   for tr in rows for c in _cells(tr)[1:]):
                raise ParseError('HTML本表の数値表に明示的な年度列がありません。')
            continue
        if len(set(columns.values()))!=len(columns):
            raise ParseError('HTML本表の同年度に複数の金額列があります。')
        for col,opening in opening_columns.items():
            reason='明示的なIFRS移行・期首BS列で、年度末ではなく原文の最古比較期間の開始日に一致するため年度末比較から除外。'
            dataset.checks.append({'check':'html_opening_bs_excluded','ok':True,
                'doc_id':filing.doc_id,'filename':page.filename,'table_index':table_index,
                'column':col,'date':opening['date'],'header':opening['header'],'reason':reason})
            dataset.source_notes.append(f"{filing.doc_id} {page.filename}: {opening['header']}（表{table_index+1}・展開列{col+1}）は年度末以外の明示的な期首・IFRS移行BS列のため除外。原文キャッシュに保存。")
        for row_index,tr in enumerate(rows):
            positions=grid[tr];lookup=dict(positions)
            label_cell=next((c for col,c in positions if col<min(columns) and _text(c)),None)
            if label_cell is None:continue
            label=_text(label_cell).strip();caption=compact(label)
            if re.search(r'単位|会計年度|事業年度|注記',caption) or re.search(r'\d{4}年',caption):continue
            raw_values={col:compact(_text(lookup[col])) if col in lookup else '' for col in columns}
            numeric=any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',v)
                        for v in raw_values.values() if v)
            if not numeric:
                if not any(raw_values.values()):
                    if statement=='BS':
                        if caption in {'資産','負債','資本','資本の帰属'}:
                            side='BS_A' if caption=='資産' else 'BS_LE';section=(label,)
                        elif caption in {'非流動資産','流動資産','非流動負債','流動負債'}:section=(label,)
                    elif statement=='CF' and '活動' in caption:section=(label,)
                    elif statement=='PL' and '帰属' in caption:section=(label,)
                continue
            target=side if statement=='BS' else statement
            mapping={'BS':BS,'PL':PL,'CF':CF}[statement]
            if statement=='CF'and mapping.get(caption)in {
                'EffectOfExchangeRateChangesOnCashAndCashEquivalentsIFRS',
                'NetIncreaseDecreaseInCashAndCashEquivalentsIFRS','CashAndCashEquivalentsIFRS'}:
                # A cash reconciliation can contain a held-for-sale cash
                # adjustment after financing. It belongs to the cash bridge,
                # despite the last section heading still saying financing.
                section=()
            local=mapping.get(caption,'HtmlRow_'+hashlib.sha256((caption+'|'+str(section)).encode()).hexdigest()[:18])
            if statement=='BS'and caption=='その他の金融負債':
                scopes={compact(s)for s in section}
                if '非流動負債'in scopes or'固定負債'in scopes:
                    local='OtherFinancialLiabilitiesNCLIFRS'
                elif '流動負債'in scopes:
                    local='OtherFinancialLiabilitiesCLIFRS'
                else:
                    raise ParseError('HTML本表のその他の金融負債の流動・非流動区分を原文で確定できません。')
            role='begin' if statement=='CF' and caption=='現金及び現金同等物の期首残高' else 'end' if statement=='BS' or (statement=='CF' and caption=='現金及び現金同等物の期末残高') else 'duration'
            unit='JPY/shares' if '1株当たり' in caption else 'JPY'
            key=json.dumps([target,namespace,local,[],role,unit,dataset.basis,dataset.accounting_standard,list(section)],ensure_ascii=False)
            row=Row(key,label,target,section,_indent(label_cell),_total(label,tr))
            for col,period in columns.items():
                raw=raw_values[col];nil=raw in {'','-','－','—','―','–','−','ー'}
                if nil:value=None
                else:
                    if not re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?',raw):
                        raise ParseError(f'HTML本表の数値を解釈できません: {label}: {raw}')
                    negative=raw.startswith(('△','▲','−','-','('))
                    value=Decimal(raw.lstrip('△▲−-+(').rstrip(')').replace(',',''))
                    if negative:value=-value
                    value*=Decimal(10)**(scale if unit=='JPY' else 0)
                path=json.dumps({'table':table_index,'row':row_index,'column':col},sort_keys=True)
                source=Source(filing.doc_id,page.filename,
                    f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}',
                    filing.submitted,block.get('contextref',''),source_qname,unit,
                    str(-scale if unit=='JPY' else -2),label,raw,scale if unit=='JPY' else 0,
                    dataset.basis,'{'+namespace+'}'+local,path)
                row.values[period.key]=Cell(value,source,nil,
                    note='勘定別数値タグのないIFRS本表。元TextBlock内の明示された年度列・科目名・単位から取得。HTML役割はXBRL QNameと区別。',
                    source_section=section,source_order=len(dataset.rows[target]))
            row.label_period=max(row.values)
            dataset.rows[target].append(row);count+=1
    if not count:
        raise ParseError('HTML本表の数値を取得できません。')
    dataset.source_notes.append(f'{filing.doc_id} {page.filename}: {statement}は勘定別数値タグのないIFRS本表。明示的な年度・単位と物理セル位置を検証して取得。合成した表示役割を実在の数値QNameとして扱いません。')
