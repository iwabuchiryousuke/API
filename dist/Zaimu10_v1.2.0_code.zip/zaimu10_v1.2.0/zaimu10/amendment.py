"""Conservative inspection of public annual-report corrections.

An untagged correction is never guessed into an XBRL account. Two narrowly
provable exceptions can leave original numeric facts usable: declared changes
outside the financial-statement chapter, or exactly invariant before/after
financial tables whose only difference is presentation order.
"""
from __future__ import annotations

from collections import Counter
from decimal import Decimal
import hashlib
import re
import unicodedata

from bs4 import BeautifulSoup, Comment, NavigableString, Tag

POLICY = 'strict-correction-scope-v2'
_BLOCK_TAGS = {'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'}
_OUTSIDE_CHAPTERS = {'企業の概況', '事業の状況', '設備の状況', '提出会社の状況',
                     '提出会社の参考情報', 'その他の参考情報'}
_FINANCIAL_HEADINGS = {'経理の状況', '連結財務諸表等', '財務諸表等', '連結財務諸表',
                       '財務諸表', '連結貸借対照表', '貸借対照表', '連結財政状態計算書',
                       '財政状態計算書', '連結損益計算書', '損益計算書',
                       '連結包括利益計算書', '包括利益計算書',
                       '連結キャッシュ・フロー計算書', 'キャッシュ・フロー計算書',
                       '連結キャッシュフロー計算書', 'キャッシュフロー計算書'}
_MAIN_BLOCKS = {'ConsolidatedBalanceSheetTextBlock', 'BalanceSheetTextBlock',
                'ConsolidatedStatementOfIncomeTextBlock', 'StatementOfIncomeTextBlock',
                'ConsolidatedStatementOfCashFlowsTextBlock', 'StatementOfCashFlowsTextBlock',
                'ConsolidatedStatementOfFinancialPositionIFRSTextBlock',
                'ConsolidatedStatementOfComprehensiveIncomeIFRSTextBlock',
                'ConsolidatedStatementOfCashFlowsIFRSTextBlock'}


def _text(node: Tag | str) -> str:
    value = node.get_text(' ', strip=True) if isinstance(node, Tag) else str(node)
    return re.sub(r'\s+', ' ', value).strip()


def _structural(text: str) -> str:
    # This normalization is used only for structural markers, never to compare
    # monetary values or establish account identity.
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text))


def _blocks(soup: BeautifulSoup) -> list[Tag]:
    return [n for n in soup.find_all(list(_BLOCK_TAGS))
            if n.find_parent(list(_BLOCK_TAGS)) is None and n.find_parent('table') is None]


def _chapter_title(text: str) -> str | None:
    value = unicodedata.normalize('NFKC', text).strip()
    match = re.fullmatch(r'第\d+\s*(?:【([^】]+)】|([^【】]+))', value)
    if match:
        return (match.group(1) or match.group(2)).strip()
    return None


def _direct_rows(table: Tag) -> list[list[str]]:
    return [[_structural(_text(c)) for c in row.find_all(['td', 'th'], recursive=False)]
            for row in table.find_all('tr') if row.find_parent('table') is table]


def _summary_invariant(before: Tag, after: Tag) -> dict:
    """Permit corrected derived ratios/caption typos, never changed amounts.

    Major-management-indicator tables are not the financial-statement body.
    Nevertheless, a correction of their monetary figures could conflict with
    the body. Only unchanged rows plus explicitly named derived ratios and one
    unambiguous caption typo can be classified as outside the exported values.
    """
    old = [r for r in _direct_rows(before) if any(r)]
    new = [r for r in _direct_rows(after) if any(r)]
    if len(old) != len(new):
        raise ValueError('経営指標の訂正前後で行数が異なります。')
    typo = {'親会社株式に帰属する当期純利益': '親会社株主に帰属する当期純利益'}
    allowed_ratios = {'自己資本利益率', '自己資本比率', '株価収益率'}
    changes = []
    for left, right in zip(old, new):
        if left == right:
            continue
        if len(left) != len(right) or not left or not right:
            raise ValueError('経営指標の訂正前後で年度列が異なります。')
        first = typo.get(left[0], left[0])
        second = typo.get(right[0], right[0])
        if first != second:
            raise ValueError('経営指標の科目変更の同一性を証明できません。')
        if left[1:] == right[1:] and first != left[0]:
            changes.append({'kind': 'caption_typo', 'before': left[0], 'after': right[0]})
            continue
        if (first in allowed_ratios and left[:2] == right[:2]
                and len(left) > 2 and left[1] in {'(%)', '(倍)'}
                and all(re.fullmatch(r'[△▲+\-−]?\d[\d,]*(?:\.\d+)?|[―－—-]', x)
                        for x in left[2:] + right[2:])):
            changes.append({'kind': 'derived_ratio', 'label': first,
                            'before': left[2:], 'after': right[2:]})
            continue
        raise ValueError('経営指標の金額・人数・株式数・単位・年度の変更を本表に照合する必要があります。')
    return {'summary_amounts_unchanged': True, 'rows_compared': len(old), 'changes': changes}


def _nonfinancial_table_evidence(soup: BeautifulSoup, declared_scope: str,
                                 pairs: list[tuple[Tag, Tag, Tag | None]] | None = None) -> list[dict]:
    """Positive header evidence for supported non-statement table schemas.

    An arbitrary table inside a non-accounting chapter is not automatically
    treated as harmless. Other schemas require explicit review.
    """
    evidence = []
    role_tables: set[int] = set()
    summary_tables: list[Tag] = []
    all_tables = soup.find_all('table')
    for index, table in enumerate(all_tables):
        parent = table.find_parent('table')
        rows = _direct_rows(table)
        nonempty = [r for r in rows if any(r)]
        headers = nonempty[:2]
        if parent is not None:
            # Nested career layouts are permitted only in the explicitly
            # identified 略歴 column of an approved officers table. A nested
            # financial table, or an unclassified extra table, is rejected.
            cell = table.find_parent(['td', 'th'])
            parent_row = cell.find_parent('tr') if cell else None
            cells = parent_row.find_all(['td', 'th'], recursive=False) if parent_row else []
            column = next((i for i, item in enumerate(cells) if item is cell), -1)
            if (id(parent) not in role_tables or column != 3 or table.find('table') is not None
                    or not nonempty or any(len(r) != 2 for r in nonempty)
                    or any(not re.fullmatch(r'(?:\d{4}年(?:\d{1,2}月)?|〃|同年\d{1,2}月)*', r[0])
                           for r in nonempty)
                    or not any(re.search(r'\d{4}年', r[0]) for r in nonempty)
                    or any(not r[1] or re.fullmatch(r'[△▲+\-−]?\d[\d,.]*(?:円|千円|百万円)?', r[1])
                           for r in nonempty)):
                raise ValueError('役員略歴の年月・経歴に限定できない入れ子表があります。')
            evidence.append({'table_index': index, 'table_schema': '役員略歴の年月・経歴',
                             'parent_column': '略歴', 'rows': len(nonempty)})
            continue
        if ('生産、受注及び販売の状況' in declared_scope and len(headers) == 2
                and len(headers[0]) == 2 and headers[0][0] == '品目'
                and re.fullmatch(r'当事業年度\(自\d{4}年\d+月\d+日至\d{4}年\d+月\d+日\)', headers[0][1])
                and headers[1] == ['金額(千円)', '前年同期比(%)']):
            evidence.append({'table_schema': '生産実績', 'original_headers': headers})
        elif ('事業等のリスク' in declared_scope and headers
              and headers[0] == ['許認可等の名称', '有効期限', '規制法令', '法令違反の要件及び主な許認可取消事由']):
            evidence.append({'table_schema': '許認可の状況', 'original_headers': headers[:1]})
        elif ('関係会社の状況' in declared_scope and headers and headers[0] ==
              ['名称', '住所', '資本金(百万円)', '主要な事業の内容',
               '議決権の所有割合又は被所有割合(%)', '関係内容'] and table.find('table') is None):
            evidence.append({'table_index': index, 'table_schema': '関係会社の状況',
                             'original_headers': headers[:1]})
        elif ('役員の状況' in declared_scope and headers and len(headers[0]) == 6
              and headers[0][:5] == ['役職名', '氏名', '生年月日', '略歴', '任期']
              and headers[0][5] in {'所有株式数(株)', '所有株式数(百株)', '所有株式数(千株)'}):
            role_tables.add(id(table))
            evidence.append({'table_index': index, 'table_schema': '役員一覧',
                             'original_headers': headers[:1]})
        elif ('大株主の状況' in declared_scope and any(r in [
                ['氏名又は名称', '住所', '所有株式数(株)', '発行済株式(自己株式を除く。)の総数に対する所有株式数の割合(%)'],
                ['氏名又は名称', '住所', '保有株件等の数(株)', '株券等保有割合(%)'],
                ['氏名又は名称', '住所', '保有株券等の数(株)', '株券等保有割合(%)'],
                ] for r in nonempty[:3]) and table.find('table') is None):
            evidence.append({'table_index': index, 'table_schema': '大株主・大量保有の株式数',
                             'original_headers': nonempty[:3]})
        elif ('主要な経営指標等の推移' in declared_scope and len(headers) == 2
              and len(headers[0]) >= 3 and headers[0][0] == '回次'
              and all(re.fullmatch(r'第\d+期', x) for x in headers[0][1:])
              and headers[1][0] == '決算年月' and table.find('table') is None):
            summary_tables.append(table)
            evidence.append({'table_index': index, 'table_schema': '主要な経営指標等の推移',
                             'original_headers': headers})
        elif ('ストックオプション制度の内容' in declared_scope and len(nonempty) >= 3
              and all(len(r) == 2 for r in nonempty)
              and [r[0] for r in nonempty[:3]] ==
                  ['決議年月日', '付与対象者の区分及び人数(名)', '新株予約権の数(個)※']
              and all(r[0] in {'決議年月日', '付与対象者の区分及び人数(名)', '新株予約権の数(個)※',
                              '新株予約権の目的となる株式の種類、内容及び数(株)※',
                              '新株予約権の行使時の払込金額(円)※', '新株予約権の行使期間※',
                              '新株予約権の行使により株式を発行する場合の株式の発行価格及び資本組入額(円)※',
                              '新株予約権の行使の条件※', '新株予約権の譲渡に関する事項※',
                              '組織再編成行為に伴う新株予約権の交付に関する事項※'} for r in nonempty)
              and table.find('table') is None):
            evidence.append({'table_index': index, 'table_schema': 'ストックオプション制度の内容',
                             'original_headers': [r[:1] for r in nonempty]})
        else:
            raise ValueError('本表以外であると確認できる対応済みの表見出しではありません。')
    if summary_tables:
        if not pairs:
            raise ValueError('経営指標の訂正前後の範囲がありません。')
        nodes = list(soup.descendants)
        position = {id(node): i for i, node in enumerate(nodes)}
        covered = set()
        for before, after, following in pairs:
            start, middle = position[id(before)], position[id(after)]
            end = position[id(following)] if following is not None else len(nodes)
            old = [t for t in summary_tables if start < position[id(t)] < middle]
            new = [t for t in summary_tables if middle < position[id(t)] < end]
            if len(old) != len(new):
                raise ValueError('経営指標の訂正前後の表数が異なります。')
            for first, second in zip(old, new):
                invariant = _summary_invariant(first, second)
                evidence.append({'table_schema': '経営指標の金額不変照合', 'invariant': invariant})
                covered.update((id(first), id(second)))
        if covered != {id(t) for t in summary_tables}:
            raise ValueError('訂正前後に属さない経営指標の表があります。')
    return evidence


def _indent(cell: Tag) -> Decimal:
    leaf = next((n for n in cell.descendants if isinstance(n, NavigableString) and str(n).strip()), None)
    path = [cell]
    if leaf is not None:
        parent = leaf.parent
        while parent is not None and parent is not cell:
            path.append(parent)
            parent = parent.parent
    total = Decimal(0)
    for node in path:
        for name in ('margin-left', 'padding-left', 'text-indent'):
            match = re.search(r'(?:^|;)\s*' + name + r'\s*:\s*([^;]+)', node.get('style', ''))
            if not match:
                continue
            value = re.fullmatch(r'([+-]?[\d.]+)\s*(pt|px|mm)?', match.group(1).strip())
            if value is None or (value.group(2) is None and Decimal(value.group(1)) != 0):
                raise ValueError('科目の字下げ指定を厳密に照合できません。')
            total += Decimal(value.group(1)) * {'pt': Decimal(1), 'px': Decimal(3)/4,
                     'mm': Decimal(72)/Decimal('25.4'), None: Decimal(1)}[value.group(2)]
    return total


def _table_signature(table: Tag) -> dict:
    if table.find('table') is not None:
        raise ValueError('入れ子の訂正表は自動照合しません。')
    rows = []
    numeric_labels = []
    sections: list[tuple[tuple[int, Decimal], str]] = []
    for tr in table.find_all('tr'):
        cells = tr.find_all(['td', 'th'], recursive=False)
        texts = [_text(c) for c in cells]
        if not any(texts):
            continue
        spans = []
        for cell in cells:
            try:
                rowspan = int(cell.get('rowspan', 1))
                colspan = int(cell.get('colspan', 1))
            except (ValueError, TypeError):
                raise ValueError('訂正表のセル結合を確認できません。') from None
            if rowspan != 1 or not 1 <= colspan <= 100:
                raise ValueError('縦結合または不明なセル結合の訂正表は自動照合しません。')
            spans.append((rowspan, colspan))
        nonempty = [(i, t) for i, t in enumerate(texts) if t]
        first_col, label = nonempty[0]
        # Blank leading grid columns encode hierarchy in many original tables.
        # Preserve both the physical column start and explicit CSS inset.
        indent = (sum(span[1] for span in spans[:first_col]), _indent(cells[first_col]))
        # Values are compared as original text including signs/note markers.
        # Dates ending 日 or ) do not pass this numeric-cell test.
        numeric = any(re.search(r'[△▲+\-−]?\d[\d,]*(?:\.\d+)?\s*$', t)
                      for _, t in nonempty[1:])
        if numeric:
            # A numeric row must not erase its preceding section heading just
            # because the source uses equal indentation. Crossing any explicit
            # heading boundary makes an untagged reorder unprovable.
            context = tuple(s for _, s in sections)
            numeric_labels.append(label)
        elif len(nonempty) == 1 and '単位' not in label:
            while sections and sections[-1][0] >= indent:
                sections.pop()
            context = tuple(s for _, s in sections)
            sections.append((indent, label))
        else:
            context = tuple(s for _, s in sections)
        # Preserve column positions, merging, indentation, and heading context.
        rows.append((tuple(texts), tuple(spans), str(indent), context))
    if not numeric_labels:
        raise ValueError('照合可能な数値行がありません。')
    if len(numeric_labels) != len(set(numeric_labels)):
        raise ValueError('同名の数値科目が複数あり、表の並び替えだけとは証明できません。')
    return {'rows': rows, 'counter': Counter(rows), 'numeric_labels': numeric_labels}


def _outside_text(nodes: list, start: int, end: int) -> str:
    pieces = []
    for node in nodes[start:end]:
        if isinstance(node, NavigableString) and node.find_parent('table') is None:
            if node.find_parent(['head', 'style', 'script']) is None:
                pieces.append(str(node))
    return re.sub(r'\s+', ' ', ' '.join(pieces)).strip()


def _unchanged_tables(soup: BeautifulSoup, before: Tag, after: Tag) -> dict:
    nodes = list(soup.descendants)
    positions = {id(node): i for i, node in enumerate(nodes)}
    def end_of(node: Tag) -> int:
        return max([positions[id(node)]] + [positions[id(child)] for child in node.descendants]) + 1
    b_start, a_start = positions[id(before)], positions[id(after)]
    b_end, a_end = end_of(before), end_of(after)
    tables = [t for t in soup.find_all('table') if t.find_parent('table') is None]
    old = [t for t in tables if b_end <= positions[id(t)] < a_start]
    new = [t for t in tables if positions[id(t)] >= a_end]
    if not old or len(old) != len(new) or len(tables) != len(old) + len(new):
        raise ValueError('訂正前後の全ての表を一対一で照合できません。')
    before_text = _outside_text(nodes, b_end, a_start)
    after_text = _outside_text(nodes, a_end, len(nodes))
    if before_text != after_text:
        raise ValueError('訂正前後で表外の文章・注記が異なります。')
    counts = []
    order_changed = False
    for first, second in zip(old, new):
        left, right = _table_signature(first), _table_signature(second)
        if left['counter'] != right['counter']:
            raise ValueError('訂正前後で科目・数値・単位・年度列・節・セル結合のいずれかが異なります。')
        counts.append(len(left['rows']))
        order_changed |= left['rows'] != right['rows']
    return {'paired_tables': len(old), 'rows_per_table': counts,
            'all_raw_cells_equal_as_multiset': True,
            'outside_table_text_equal': True,
            'column_spans_and_section_context_equal': True,
            'unique_numeric_row_labels': True, 'presentation_order_changed': order_changed}


def inspect_amendment(pages: list[tuple[str, str]]) -> dict:
    """Return a proof-bearing decision; unsupported structures remain unknown.

    Statuses: nonfinancial_only, unchanged_financial_values, financial, unknown.
    This function does not import values from untagged corrections. A financial
    or unknown correction must be parsed/handled strictly by the caller.
    """
    evidence = []
    result = {'status': 'unknown', 'policy': POLICY, 'reason': '', 'evidence': evidence}
    if not pages:
        result['reason'] = '訂正書類の原文がありません。'
        return result
    for filename, html in pages:
        evidence.append({'filename': filename, 'sha256': hashlib.sha256(html.encode('utf-8')).hexdigest()})
    cover = BeautifulSoup(pages[0][1], 'html.parser')
    if '有価証券報告書の訂正報告書' not in _structural(_text(cover)):
        result['reason'] = '有価証券報告書の訂正報告書と確認できません。'
        return result
    body_pages = [(f, h) for f, h in pages if not f.startswith('0000000_')]
    # A known, tagged financial statement should go through the normal parser.
    for filename, html in body_pages:
        soup = BeautifulSoup(html, 'html.parser')
        financial_blocks = [n.get('name', '') for n in soup.find_all()
                            if n.get('name', '').rsplit(':', 1)[-1] in _MAIN_BLOCKS]
        numeric_facts = [n for n in soup.find_all()
                         if n.name.lower().rsplit(':', 1)[-1] in {'nonfraction', 'fraction'}]
        if financial_blocks or numeric_facts:
            result.update(status='financial', reason='XBRL数値または財務諸表本表のタグがあり、通常の厳密な解析が必要です。',
                          tagged_financial_blocks=financial_blocks, numeric_xbrl_fact_count=len(numeric_facts))
            return result
    if len(body_pages) != 1:
        # Every separate body must provide its own complete, explicit scope
        # proof. A continuation without declarations remains unsupported rather
        # than borrowing a harmless scope from a different file.
        decisions = [inspect_amendment([pages[0], body]) for body in body_pages]
        if body_pages and all(d['status'] == 'nonfinancial_only' for d in decisions):
            result.update(status='nonfinancial_only', body_decisions=decisions,
                          reason='全ての本文で、それぞれ明示的な訂正範囲が財務諸表本表以外と照合できました。')
        else:
            result.update(body_decisions=decisions,
                          reason='複数本文の全てについて本表以外の訂正であると証明できません。')
        return result
    filename, html = body_pages[0]
    soup = BeautifulSoup(html, 'html.parser')
    for hidden in soup.find_all(['head', 'script', 'style']):
        hidden.decompose()
    # Do not select only familiar p/h nodes and silently ignore visible text in
    # a div, arbitrary span, or a future document format.
    for node in soup.find_all(string=True):
        if (not isinstance(node, Comment) and str(node).strip()
                and node.find_parent('body') is not None
                and node.find_parent(list(_BLOCK_TAGS) + ['td', 'th']) is None):
            result['reason'] = '対応する段落・見出し・表セル以外に未分類の本文があります。'
            return result
    blocks = _blocks(soup)
    scope_starts = [i for i, n in enumerate(blocks) if re.fullmatch(r'\d*【訂正事項】', _structural(_text(n)))]
    body_starts = [i for i, n in enumerate(blocks) if re.fullmatch(r'\d*【訂正箇所】', _structural(_text(n)))]
    if len(scope_starts) != 1 or len(body_starts) != 1 or scope_starts[0] >= body_starts[0]:
        result['reason'] = '明示された訂正事項・訂正箇所を一意に確認できません。'
        return result
    scope = [_text(n) for n in blocks[scope_starts[0]+1:body_starts[0]] if _text(n)]
    actual = blocks[body_starts[0]+1:]
    all_nodes = list(soup.descendants)
    marker_node = blocks[body_starts[0]]
    positions = {id(n): i for i, n in enumerate(all_nodes)}
    marker_end = max([positions[id(marker_node)]] + [positions[id(n)] for n in marker_node.descendants]) + 1
    # Exhaustive visible heading scan, including table cells and all DOM tags.
    actual_visible = ' '.join(str(n) for n in all_nodes[marker_end:]
                              if isinstance(n, NavigableString) and not isinstance(n, Comment))
    headings = re.findall(r'【([^】]+)】', actual_visible)
    result.update(declared_scope=scope, actual_headings=headings)
    # A second narrow proof is the issuer's exact declaration of two missing
    # shareholders-meeting notices being attached. This does not amend the
    # submitted financial-statement body and has no before/after numeric table.
    actual_lines = [_text(n) for n in actual if _text(n)]
    if len(scope) == 1 and len(actual_lines) == 1:
        declaration = _structural(scope[0])
        attachment = re.fullmatch(r'添付書類(?P<titles>「第(?P<term>\d+)期定時株主総会招集ご通知」及び「第(?P=term)期定時株主総会決議ご通知」)の未添付', declaration)
        reason_text = ''.join(_structural(_text(n)) for n in blocks[:scope_starts[0]])
        numeric_tags = [n for n in soup.find_all() if n.name.lower().rsplit(':', 1)[-1] in {'nonfraction', 'fraction'}]
        if (attachment and _structural(actual_lines[0]) == '添付書類' + attachment.group('titles') + 'の添付'
                and '書類の添付漏れ' in reason_text and not soup.find('table') and not numeric_tags):
            result.update(status='nonfinancial_only', attachment_only=True,
                          actual_scope=actual_lines,
                          reason='訂正事項・訂正箇所が同じ定時株主総会招集通知と決議通知の未添付→添付だけを明示しています。元の財務諸表本表のXBRL数値を維持します。')
            return result
    markers = [(n, _structural(_text(n))) for n in actual
               if _structural(_text(n)) in {'(訂正前)', '(訂正後)'}]
    if (not markers or len(markers) % 2 or
            any(value != ('(訂正前)' if i % 2 == 0 else '(訂正後)')
                for i, (_, value) in enumerate(markers))):
        result['reason'] = '明示された訂正前・訂正後の範囲を一意に確認できません。'
        return result
    pairs = [(markers[i][0], markers[i+1][0], markers[i+2][0] if i+2 < len(markers) else None)
             for i in range(0, len(markers), 2)]
    before, after = [pairs[0][0]], [pairs[0][1]]
    result['explicit_before_after_pairs'] = len(pairs)
    declared_compact = ''.join(_structural(s) for s in scope)
    declared_chapters = []
    for line in scope:
        title = _chapter_title(line)
        if title:
            declared_chapters.append(title)
    actual_chapters = []
    for n in actual:
        title = _chapter_title(_text(n))
        if title:
            actual_chapters.append(title)
    # Every bracketed actual outline name must also be in the declared scope.
    matching_outline = all(_structural(h) in declared_compact for h in headings)
    is_financial = any(h in _FINANCIAL_HEADINGS for h in headings) or any(
        _structural(h) in declared_compact for h in _FINANCIAL_HEADINGS)
    if is_financial:
        if len(pairs) != 1:
            result['reason'] = '複数の財務訂正範囲は数値不変として自動で対象外と判定しません。'
            return result
        preamble = actual[:actual.index(before[0])]
        for block in preamble:
            compact = _structural(_text(block))
            if not compact:
                continue
            is_outline = bool(re.fullmatch(r'(?:第[0-9一二三四五六七八九十]+部?|[0-9]+|\([0-9]+\))?【[^】]+】', compact))
            is_notice = compact.startswith('訂正箇所は') and compact.endswith('表示しております。') and not re.search(r'\d', compact)
            if not (is_outline or is_notice):
                result['reason'] = '訂正前後の対比外に、見出し・定型説明以外の文章があります。'
                return result
        if not matching_outline or not actual_chapters or set(actual_chapters) != set(declared_chapters):
            result['reason'] = '財務訂正の宣言範囲と実際の見出しが一致しません。'
            return result
        # Only an explicit, exhaustive paired-table invariant can establish
        # unchanged untagged monetary content; ordering alone does not match IDs.
        try:
            invariant = _unchanged_tables(soup, before[0], after[0])
        except ValueError as exc:
            result.update(status='financial', reason=str(exc))
            return result
        result.update(status='unchanged_financial_values', invariant=invariant,
                      reason='明示された訂正前後の全表について科目・元の数値文字列・単位・年度列・節・セル結合が一致し、表外の文章も同一です。元のXBRL数値を維持します。')
        return result
    numeric_tags = [n for n in soup.find_all() if n.name.lower().rsplit(':', 1)[-1] in {'nonfraction', 'fraction'}]
    try:
        table_evidence = _nonfinancial_table_evidence(soup, declared_compact, pairs)
    except ValueError as exc:
        result['reason'] = str(exc)
        return result
    if (declared_chapters and set(declared_chapters) <= _OUTSIDE_CHAPTERS
            and set(actual_chapters) == set(declared_chapters) and matching_outline and headings and not numeric_tags):
        result.update(status='nonfinancial_only',
                      business_table_evidence=table_evidence,
                      reason='訂正事項と実際の見出しの双方が財務諸表の章以外を明示しています。元の財務諸表本表のXBRL数値を維持します。')
    else:
        result['reason'] = '本表以外の訂正だけであると証明できる明示的な章・見出しの一致がありません。'
    return result
