"""Financial hierarchy boundaries and separately disclosed issuer views."""
from decimal import Decimal
from datetime import date

from openpyxl import load_workbook
import pytest

from zaimu10.excel import _bs_source_plans,export_workbook
from zaimu10.layout import build_balance_layout
from zaimu10.models import Cell,Dataset,Period,Row,Source

P=Period(date(2025,1,1),date(2025,12,31))
STANDARD='http://disclosure.edinet-fsa.go.jp/taxonomy/jpigp/2024-11-01/jpigp_cor'
ISSUER='http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E00932-000/2025-12-31/01/2026-03-25'


def fact_row(name,label,value,section,order,*,namespace=STANDARD):
    source=Source('S100XTBJ','main.xhtml','https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100XTBJ',
        concept='{'+namespace+'}'+name,context_id='CurrentYearInstant',unit='JPY',decimals='-3',
        original_label=label,basis='consolidated')
    fact=Cell(Decimal(value)*1000,source,source_section=tuple(section),source_order=order)
    return Row(name,label,'BS_LE',tuple(section),values={P.key:fact})


def separate_equity_view():
    noncurrent=('非流動負債：',);current=('流動負債：',);capital=('資本の帰属：',)
    return [
        fact_row('OtherNonCurrentLiabilitiesNCLIFRS','その他の非流動負債',10,noncurrent,1),
        fact_row('NonCurrentLabilitiesIFRS','非流動負債合計',10,noncurrent,2),
        fact_row('TradeAndOtherPayablesCLIFRS','営業債務及びその他の債務',60,current,3),
        fact_row('TotalCurrentLiabilitiesIFRS','流動負債合計',60,current,4),
        fact_row('LiabilitiesIFRS','負債合計',70,current,5),
        # As in Chugai's source, the heading has not changed at this row.
        # This is an issuer extension, not a standard-equity alias.
        fact_row('TotalNetAssetsIFRS','純資産合計',130,current,6,namespace=ISSUER),
        fact_row('EquityAttributableToOwnersOfParentIFRS','当社の株主持分',130,capital,8),
        fact_row('EquityIFRS','資本合計',130,capital,9),
        fact_row('LiabilitiesAndEquityIFRS','負債及び資本合計',200,capital,10),
    ]


def test_completed_liabilities_total_stops_stale_heading_from_claiming_next_issuer_total():
    rows=separate_equity_view();plans,coverage=_bs_source_plans(rows,[P])
    assert plans[P.key][4]==[3,1]
    assert 5 not in plans[P.key]
    assert plans[P.key][8]==[4,7]
    layout=build_balance_layout(rows,[P],plans,coverage)
    positions={rows[index].key:layout.order.index(layout.original_to_node[index][P.key]) for index in range(len(rows))}
    assert positions['LiabilitiesIFRS']<positions['TotalNetAssetsIFRS']<positions['EquityAttributableToOwnersOfParentIFRS']
    assert positions['EquityAttributableToOwnersOfParentIFRS']<positions['EquityIFRS']<positions['LiabilitiesAndEquityIFRS']
    extension=layout.original_to_node[5][P.key]
    assert not layout.graph[extension]
    assert not any(extension in children for children in layout.graph.values())
    assert len(layout.rows)==len(rows)  # no equality-based issuer alias merge


def test_separate_net_assets_disclosure_is_visible_literal_and_not_added_to_equity_twice(tmp_path):
    ds=Dataset('4519','中外製薬株式会社','consolidated',[P],accounting_standard='IFRS')
    ds.rows['BS_LE']=separate_equity_view()
    path=export_workbook(ds,tmp_path/'chugai-shape.xlsx','thousand')
    workbook=load_workbook(path);cached=load_workbook(path,data_only=True)
    ws=workbook['BS-L,E']
    extension=next(item for item in ds.export_metadata['cells'] if item['row_key'].endswith('TotalNetAssetsIFRS') or
                   (item.get('source') or {}).get('source',{}).get('concept','')=='{'+ISSUER+'}TotalNetAssetsIFRS')
    address=extension['address']
    assert ws[address].data_type=='n' and ws[address].value==130
    assert ISSUER in ws[address].comment.text
    grand=next(row[0].row for row in ws if row[0].value=='負債純資産合計')
    assert cached['BS-L,E'].cell(grand,2).value==200
    assert address not in ws.cell(grand,2).value
    assert not any(item.get('ok') is False for item in ds.checks)
    workbook.close();cached.close()


def test_genuinely_incompatible_parents_are_still_rejected():
    section=('資産の部','流動資産')
    rows=[fact_row('CustomLeaf','明細',10,section,1,namespace=ISSUER),
          fact_row('CustomTotalA','区分A合計',10,section,2,namespace=ISSUER),
          fact_row('CustomTotalB','区分B合計',10,section,3,namespace=ISSUER)]
    with pytest.raises(ValueError,match='異なる親区分'):
        build_balance_layout(rows,[P],{P.key:{1:[0],2:[0]}},{P.key:{}})


def test_html_table_semantic_account_classifies_without_relabeling_real_textblock_qname():
    from copy import deepcopy
    from zaimu10.excel import _local,_unique_cells,_comment
    from zaimu10.layout import role
    rows=separate_equity_view()
    real='{'+STANDARD+'}ConsolidatedStatementOfFinancialPositionIFRSTextBlock'
    for index,row in enumerate(rows):
        cell=row.values[P.key]
        original=cell.source.concept.rsplit('}',1)[-1]
        cell.source.concept=real
        cell.source.semantic_concept='{urn:zaimu10:html-table:E00932:IFRS:BS_LE}'+original
        cell.source.table_path=f'table[1]/tr[{index+1}]/td[2]'
    assert _local(rows[4],P)=='LiabilitiesIFRS' and role(rows[4])=='liabilities'
    plans,coverage=_bs_source_plans(rows,[P])
    assert plans[P.key][4]==[3,1] and 5 not in plans[P.key]
    build_balance_layout(rows,[P],plans,coverage)
    cells=[deepcopy(rows[0].values[P.key]),deepcopy(rows[1].values[P.key])]
    cells[1].value=cells[0].value
    assert len(_unique_cells(cells+[deepcopy(cells[0])]))==2
    ds=Dataset('4519','中外製薬','consolidated',[P],accounting_standard='IFRS')
    comment=_comment(rows[4].values[P.key],rows[4],P,ds).text
    assert f'XBRL QName: {real}' in comment
    assert 'HTML原表の明示項目分類（XBRL概念とは別）' in comment
    assert 'table[1]/tr[5]/td[2]' in comment
