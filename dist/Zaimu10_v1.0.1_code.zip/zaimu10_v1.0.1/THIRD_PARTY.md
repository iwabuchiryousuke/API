# データ・ライブラリの出典

## 財務データ

金融庁EDINETの公式公開情報を使用します。

- [EDINETトップページ](https://disclosure2.edinet-fsa.go.jp/)
- [公式の書類検索画面](https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx)
- [EDINETコードリスト](https://disclosure2dl.edinet-fsa.go.jp/searchdocument/codelist/Edinetcode.zip)
- 原文閲覧URL：`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?書類ID`

銘柄コードと提出者の対応には、公式EDINETコードリストのCSVを使用します。**財務数値はCSV変換データではなく、各有価証券報告書の原文inline XBRLから取得します。** 有料データ、バフェットコードAPI、EDINET APIキーは使用していません。

開示資料の作成者は各提出会社です。本プログラムが生成するExcel・監査JSONには元書類を追跡できる識別子とURLを記録します。財務資料やEDINETの画面素材に本プログラムのライセンスを適用するものではありません。

テストには、図研の有価証券報告書第49期（提出日2025年6月20日、書類ID **S100W07I**）の公開原文を使用しています。

- [図研 S100W07I の原文閲覧](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100W07I)
- 保存形式・照合対象値：[tests/fixtures/README.md](tests/fixtures/README.md)

同梱の画面・応答フィクスチャは取得処理の回帰検証用です。財務情報を加工して別会社の値としたものではありません。作成時にユーザーから提供されたExcelは書式の参考に使用し、その数式や手作業集計を財務データの取得元にはしていません。

## Pythonライブラリ

ライブラリ本体は初回セットアップで通常のPythonパッケージとしてインストールします。各ライブラリにはそれぞれのライセンスが適用されます。正確な版はインストールされた環境で`python -m pip freeze`により確認できます。

|ライブラリ|用途|公開元・ライセンス|
|---|---|---|
|requests|HTTPS通信|[プロジェクト](https://github.com/psf/requests)・Apache-2.0|
|lxml|HTML／XML／inline XBRLの解析|[プロジェクト](https://lxml.de/)・BSD系。詳細は配布物のLICENSESを参照|
|cryptography|公式閲覧画面の応答処理|[プロジェクト](https://cryptography.io/)・Apache-2.0／BSD-3-Clause|
|openpyxl|Excel生成|[プロジェクト](https://openpyxl.readthedocs.io/)・MIT|
|Beautiful Soup 4|公開検索結果のHTML解析|[プロジェクト](https://www.crummy.com/software/BeautifulSoup/)・MIT|
|pytest（テスト用）|回帰テスト|[プロジェクト](https://pytest.org/)・MIT|

Python標準ライブラリとTkinterも使用します。Python・Tcl/Tkのライセンスは、それぞれの公式配布物を参照してください。
