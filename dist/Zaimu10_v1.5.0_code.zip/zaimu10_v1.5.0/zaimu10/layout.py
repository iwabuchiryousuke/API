"""A union of proven source hierarchies, independent of any year's row order.

This module changes display order only. It never matches Japanese labels to
establish monetary account identity and never adds overlapping disclosures.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from collections import defaultdict
import re
from .models import Row, Period

ROLES = {
    'current_assets': {'CurrentAssets','CurrentAssetsIFRS'},
    'noncurrent_assets': {'NoncurrentAssets','NonCurrentAssetsIFRS','NoncurrentAssetsIFRS'},
    'assets': {'Assets','AssetsIFRS','TotalAssetsIFRS'},
    'ppe': {'PropertyPlantAndEquipment','PropertyPlantAndEquipmentIFRS'},
    'intangibles': {'IntangibleAssets','IntangibleAssetsIFRS'},
    'investments': {'InvestmentsAndOtherAssets'},
    'current_liabilities': {'CurrentLiabilities','CurrentLiabilitiesIFRS','TotalCurrentLiabilitiesIFRS'},
    'noncurrent_liabilities': {'NoncurrentLiabilities','NoncurrentLiabilitiesIFRS','NonCurrentLiabilitiesIFRS','NonCurrentLabilitiesIFRS'},
    'liabilities': {'Liabilities','LiabilitiesIFRS'},
    'net_assets': {'NetAssets','EquityIFRS','TotalEquityIFRS'},
    'liabilities_equity': {'LiabilitiesAndNetAssets','LiabilitiesAndEquityIFRS','TotalLiabilitiesAndEquityIFRS'},
}
ROLE_LABELS = {'current_assets':'流動資産計','noncurrent_assets':'固定資産合計','assets':'資産合計',
               'ppe':'有形固定資産計','intangibles':'無形固定資産計','investments':'投資その他の資産計',
               'current_liabilities':'Ⅰ 流動負債計','noncurrent_liabilities':'Ⅱ 固定負債計',
               'liabilities':'負債合計','net_assets':'純資産合計','liabilities_equity':'負債純資産合計'}
LOCAL_ROLE = {local:role for role,names in ROLES.items() for local in names}


def local(row):
    return next((c.source.account_concept.rsplit('}',1)[-1].rsplit(':',1)[-1]
                 for c in row.values.values() if c.source.account_concept),'')


def role(row):
    roles={LOCAL_ROLE.get(c.source.account_concept.rsplit('}',1)[-1].rsplit(':',1)[-1])
           for c in row.values.values() if c.source.account_concept}
    return next(iter(roles)) if len(roles)==1 and None not in roles else None


def rank(row,index=0):
    name=local(row);r=role(row)
    fixed={'current_assets':100,'ppe':200,'intangibles':300,'investments':400,
           'noncurrent_assets':700,'assets':900,'current_liabilities':100,
           'noncurrent_liabilities':200,'liabilities':300,'net_assets':800,
           'liabilities_equity':900}
    if r in fixed:return fixed[r],index
    if name in {'ShareholdersEquity','EquityAttributableToOwnersOfParentIFRS'}:return 200,index
    if name in {'ValuationAndTranslationAdjustments'}:return 300,index
    if name in {'NonControllingInterests','MinorityInterests','NonControllingInterestsIFRS'}:return 400,index
    if name=='SubscriptionRightsToShares':return 500,index
    if name in {'CapitalStock','ShareCapitalIFRS'}:return 10,index
    if name in {'CapitalSurplus','CapitalSurplusIFRS'}:return 20,index
    if name in {'RetainedEarnings','RetainedEarningsIFRS'}:return 30,index
    if name in {'TreasuryStock','TreasurySharesIFRS'}:return 40,index
    if name=='OtherComponentsOfEquityIFRS':return 50,index
    if name in {'CashAndDeposits','CashAndCashEquivalentsIFRS'}:return 1,index
    if 'trade_receivables' in row.key or name in {'NotesAndAccountsReceivableTrade','TradeAndOtherReceivablesCAIFRS'}:return 2,index
    if 'inventory_goods' in row.key or name in {'MerchandiseAndFinishedGoods','InventoriesCAIFRS'}:return 3,index
    if name=='WorkInProcess':return 4,index
    if 'inventory_materials' in row.key or name=='RawMaterialsAndSupplies':return 5,index
    if 'AllowanceForDoubtfulAccounts' in name:return 99,index
    # Within a net-value branch, retain gross -> signed contra -> net.
    if name.startswith(('AccumulatedDepreciation','AccumulatedDepreclation')):return 80,index
    if name.startswith('AccumulatedImpairmentLoss'):return 81,index
    for number,stem in enumerate(('Buildings','Structures','Machinery','Tools','Vehicles','Land','LeaseAssets','RightOfUseAssets','ConstructionInProgress','OtherPPE'),10):
        if name.startswith(stem):return number,index
    return 60,index


@dataclass
class BalanceLayout:
    rows:list[Row]
    originals:dict[int,list[int]]
    original_to_node:dict[int,dict[str,int]]
    plans:dict[str,dict[int,list[int]]]
    graph:dict[int,list[int]]
    order:list[int]
    spans:dict[int,tuple[int,int]]  # indices within order, children only
    origins:dict[str,dict[str,int]]


def classification(section):
    text='>'.join(section)
    if '流動資産' in text and '非流動資産' not in text:return 'assets/current'
    if '有形固定資産' in text:return 'assets/noncurrent/ppe'
    if '無形固定資産' in text or '無形資産' in text:return 'assets/noncurrent/intangibles'
    if '投資その他の資産' in text:return 'assets/noncurrent/investments'
    if '非流動資産' in text or '固定資産' in text:return 'assets/noncurrent'
    if '流動負債' in text and '非流動負債' not in text:return 'liabilities/current'
    if '非流動負債' in text or '固定負債' in text:return 'liabilities/noncurrent'
    if 'その他の包括利益' in text or '評価・換算差額' in text:return 'equity/oci'
    if '株主資本' in text:return 'equity/shareholder'
    if '純資産' in text or '資本' in text:return 'equity'
    return text


def build_balance_layout(source:list[Row],periods:list[Period],plans,coverage) -> BalanceLayout:
    rows=[];old_to_new=defaultdict(dict);originals=defaultdict(list);role_nodes=defaultdict(list)
    original_parents={parent for per in plans.values() for parent in per}
    for old,row in enumerate(source):
        r=role(row);buckets=defaultdict(dict)
        for key,cell in row.values.items():
            group=None if r or old in original_parents else classification(cell.source_section if cell.source_section is not None else row.section)
            buckets[group][key]=cell
        for group,values in buckets.items():
            found=None
            if r:
                for candidate in role_nodes[r]:
                    if not (set(rows[candidate].values)&set(values)):
                        found=candidate;break
            if found is None:
                found=len(rows);rows.append(deepcopy(row));rows[found].values=deepcopy(values)
                if len(buckets)>1:rows[found].key+=':classification:'+str(group)
                if r:
                    role_nodes[r].append(found)
                    rows[found].key='layout:aggregate:'+r+':'+str(len(role_nodes[r]))
                    rows[found].label=ROLE_LABELS[r]
            else:rows[found].values.update(deepcopy(values))
            for key in values:old_to_new[old][key]=found
            originals[found].append(old)
    mapped={};edges=defaultdict(set)
    for period in periods:
        mapped[period.key]={}
        for parent,parts in plans.get(period.key,{}).items():
            p=old_to_new[parent][period.key]
            children=list(dict.fromkeys(old_to_new[i][period.key] for i in parts if old_to_new[i][period.key]!=p))
            if children:mapped[period.key][p]=children;edges[p].update(children)
        for parent,parts in coverage.get(period.key,{}).items():
            p=old_to_new[parent][period.key]
            edges[p].update(old_to_new[i][period.key] for i in parts if old_to_new[i][period.key]!=p)
    def descendants(node,visiting=None):
        visiting=set() if visiting is None else visiting
        if node in visiting:raise ValueError('年度をまたぐBS階層に循環があります。原文を確認してください。')
        out=set()
        for child in edges[node]:
            out.add(child);out.update(descendants(child,visiting|{node}))
        return out
    # A gross/contra line may be a direct source component in one year and sit
    # beneath a published net subtotal in another. Keep one nested display block.
    for parent in list(edges):
        remove=set()
        for child in list(edges[parent]):
            remove.update(descendants(child)&edges[parent])
        edges[parent]-=remove
    parents=defaultdict(set)
    for parent,children in edges.items():
        for child in children:parents[child].add(parent)
    conflicts={i:p for i,p in parents.items() if len(p)>1}
    if conflicts:
        labels='、'.join(rows[i].label for i in conflicts)
        raise ValueError('同じBS項目に異なる親区分があり、自動配置できません: '+labels)
    roots=[i for i in range(len(rows)) if not parents[i]]
    order=[];spans={};graph={}
    def emit(node):
        start=len(order)
        children=sorted(edges[node],key=lambda i:rank(rows[i],i))
        graph[node]=children
        for child in children:emit(child)
        end=len(order)-1
        if children:spans[node]=(start,end)
        order.append(node)
    for root in sorted(roots,key=lambda i:rank(rows[i],i)):emit(root)
    # A separately disclosed issuer total can sit between two standard
    # presentation views without belonging to either arithmetic tree. Keep
    # its proven source position instead of inventing an alias or parent.
    # This changes display order only: graph and monetary plans stay intact.
    independent=[node for node in roots if not graph[node] and role(rows[node]) is None]
    for node in independent:
        for period in sorted(periods,key=lambda item:(item.end,item.start),reverse=True):
            original=[old for old in originals[node] if period.key in source[old].values]
            if not original:continue
            old=original[-1];cell=source[old].values[period.key]
            source_position=cell.source_order if cell.source_order is not None else old
            following=[]
            for other in range(len(rows)):
                if other==node or other in independent:continue
                for candidate in originals[other]:
                    fact=source[candidate].values.get(period.key)
                    if fact is None:continue
                    position=fact.source_order if fact.source_order is not None else candidate
                    if position>source_position:following.append((position,other))
            if following:
                anchor=min(following)[1]
                order.remove(node);order.insert(order.index(anchor),node)
            break
    # Legacy span metadata remains a cover of the descendants; arithmetic
    # uses the explicit direct-child graph, never the intervening extra row.
    offsets={node:index for index,node in enumerate(order)}
    spans={node:(min(offsets[child] for child in descendants(node)),
                 max(offsets[child] for child in descendants(node)))
           for node in graph if graph[node]}
    if len(order)!=len(rows) or len(set(order))!=len(rows):
        raise ValueError('BS表示階層で項目が重複しています。')
    origins={source[old].key:dict(new) for old,new in old_to_new.items()}
    return BalanceLayout(rows,dict(originals),dict(old_to_new),mapped,graph,order,spans,origins)
