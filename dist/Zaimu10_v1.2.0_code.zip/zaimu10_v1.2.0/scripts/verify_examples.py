"""Verify exported cells independently against raw official iXBRL and Excel.

No acquisition/parser implementation is imported. This checks every exported
fact's original QName/context/value against the hash-checked saved source, then
checks the numeric value written into its actual Excel cell.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from decimal import Decimal
import hashlib
import html as html_std
import json
from pathlib import Path
import re
import unicodedata

from lxml import html
from openpyxl import load_workbook

SHEETS = {'PL':'PL','BS_A':'BS-A','BS_LE':'BS-L,E','CF':'CF'}


def plain(node):
    return re.sub(r'\s+',' ',''.join(node.itertext()).replace('\xa0',' ')).strip()


def raw_facts(cache: Path, doc: str, filename: str):
    directory=cache/'filings'/doc
    manifest=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    matches=[f for f in manifest['files'] if f['filename']==filename]
    assert len(matches)==1,(doc,filename)
    raw=(directory/matches[0]['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==matches[0]['sha256'],doc
    text=raw.decode('utf-8')
    namespaces=defaultdict(set)
    for prefix,_,uri in re.findall(r'xmlns:([\w.-]+)\s*=\s*([\'"])(.*?)\2',text,re.S):
        namespaces[prefix.casefold()].add(html_std.unescape(uri))
    root=html.fromstring(text.lstrip('\ufeff').encode('utf-8'),parser=html.HTMLParser(encoding='utf-8',no_network=True))
    facts=defaultdict(list)
    for node in root.iter():
        if not isinstance(node.tag,str) or node.tag.rsplit(':',1)[-1].lower()!='nonfraction':continue
        prefix,local=node.get('name','').split(':',1)
        uris=namespaces[prefix.casefold()]
        assert len(uris)==1,(doc,prefix,uris)
        concept='{'+next(iter(uris))+'}'+local
        context=node.get('contextref','')
        nil=node.get('xsi:nil','').lower() in {'true','1'}
        original=plain(node)
        if nil:value=None
        else:
            fmt=node.get('format','').split(':')[-1].lower()
            value_text=unicodedata.normalize('NFKC',original).replace(',','')
            value_text=re.sub(r'\s+','',value_text)
            if fmt in {'numdash','zerodash','fixed-zero','fixedzero'}:value=Decimal(0)
            else:
                negative=value_text.startswith(('△','▲','−','-')) or value_text.startswith('(')
                value=Decimal(value_text.lstrip('△▲−-+').strip('()'))
                if negative:value=-value
            value*=Decimal(10)**int(node.get('scale','0'))
            if node.get('sign')=='-':value=-abs(value)
        facts[(concept,context)].append((value,nil,original))
    return facts


def verify(samples: Path, cache: Path):
    summaries=[];fact_cache={}
    for audit in sorted(samples.glob('*.audit.json')):
        payload=json.loads(audit.read_text(encoding='utf-8'));ds=payload['dataset']
        workbook=audit.with_name(audit.name.removesuffix('.audit.json')+'.xlsx')
        assert workbook.exists(),workbook
        wb=load_workbook(workbook,data_only=False);values=load_workbook(workbook,data_only=True)
        assert wb.sheetnames==list(SHEETS.values()) and not wb._external_links
        periods=sorted(ds['periods'],key=lambda p:(p['end'],p['start']))
        for sheet in wb:
            assert sheet['A1'].value and '単位' in sheet['A1'].value
            for j,period in enumerate(periods,2):
                assert period['end'][:4] in str(sheet.cell(1,j).value),(workbook,sheet.title,period)
            assert all('#REF!' not in str(c.value) for row in sheet for c in row)
            assert all(c.data_type!='e' for row in values[sheet.title] for c in row)
        assert wb['PL'].max_row==22 and wb['PL']['A2'].value=='売上高'
        raw=payload.get('raw_dataset') or ds;raw_count=0;nil_count=0
        for rows in raw['rows'].values():
            for row in rows:
                for fact in row['values'].values():
                    src=fact['source']
                    if not src['context_id']:
                        assert fact['value'] is None
                        continue
                    key=(src['doc_id'],src['filename'])
                    if key not in fact_cache:fact_cache[key]=raw_facts(cache,*key)
                    candidates=fact_cache[key][(src['concept'],src['context_id'])]
                    expected=(None if fact['value'] is None else Decimal(fact['value']),fact['nil'],src['raw_value'])
                    assert expected in candidates,(workbook,row['label'],expected,candidates)
                    raw_count+=1;nil_count+=int(fact['nil'])
        # Only the final emitted record for a cell is authoritative; an earlier
        # disclosed literal can subsequently be replaced by an audited formula.
        emitted={(c['sheet'],c['address']):c for c in ds['export_metadata']['cells']}
        count=0;formulas=0
        for (sheet,address),item in emitted.items():
            actual=values[sheet][address].value;expected=item.get('display_value')
            if expected is None or expected=='':
                assert actual in (None,''),(workbook,sheet,address,expected,actual)
            else:
                try:a,b=Decimal(str(expected)),Decimal(str(actual))
                except Exception:
                    assert str(actual)==str(expected),(workbook,sheet,address,expected,actual)
                else:
                    assert abs(a-b)<=max(Decimal('0.00000001'),abs(a)*Decimal('1e-12')),(workbook,sheet,address,expected,actual)
                    count+=1
            if item.get('formula'):
                assert wb[sheet][address].data_type=='f'
                assert wb[sheet][address].value==item['formula']
                formulas+=1
        assert not ds['warnings'],(workbook,ds['warnings'])
        assert all(c.get('ok') is not False for c in ds['checks'])
        summaries.append({'code':ds['code'],'company':ds['company'],'periods':len(periods),
                          'unit':ds['export_metadata']['unit'],'numeric_excel_cells':count,
                          'formula_cells':formulas,'raw_facts_verified':raw_count,'nil_cells':nil_count,
                          'checks_passed':sum(c.get('ok') is True for c in ds['checks']),
                          'checks_unverified':sum(c.get('ok') is None for c in ds['checks']),
                          'workbook':workbook.name})
        wb.close();values.close()
    assert summaries,'No sample audits found'
    return summaries


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=Path,default=Path('examples'))
    parser.add_argument('--cache',type=Path,default=Path('.cache/zaimu10'))
    parser.add_argument('--json',type=Path)
    args=parser.parse_args()
    results=verify(args.samples,args.cache)
    output=json.dumps(results,ensure_ascii=False,indent=2)
    print(output)
    if args.json:args.json.write_text(output+'\n',encoding='utf-8')
