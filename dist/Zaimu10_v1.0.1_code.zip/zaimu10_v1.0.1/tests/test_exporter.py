from datetime import date
from decimal import Decimal

from openpyxl import load_workbook
import pytest

from zaimu10.excel import export_workbook
from zaimu10.models import Cell, Dataset, Period, Row, SHEETS, Source


def source(label="売上高", concept="{https://example.jp/taxonomy/2025}Revenue"):
    return Source(doc_id="S100TEST", filename="statement.xbrl",
                  url="https://example.jp/filing/S100TEST", submitted="2025-06-20",
                  context_id="CurrentYearDuration", concept=concept,
                  original_label=label, raw_value="123456789", scale=0,
                  decimals="-3", basis="consolidated")


def fixture_dataset():
    old = Period(date(2023, 4, 1), date(2024, 3, 31))
    new = Period(date(2024, 4, 1), date(2025, 3, 31))
    ds = Dataset(code="6947", company="図研", basis="consolidated",
                 periods=[new, old], fetched_at="2025-06-21T09:00:00+09:00")
    for statement in SHEETS:
        ds.rows[statement] = [
            Row(key="section", label="区分", statement=statement, is_heading=True),
            Row(key="revenue", label="最新表示名", statement=statement,
                indent=1, section=("区分",), label_period=new.key,
                values={old.key: Cell(Decimal("123456789"), source("旧表示名")),
                        new.key: Cell(Decimal("0"), source("最新表示名"))}),
            Row(key="old-only", label="廃止項目", statement=statement,
                values={old.key: Cell(Decimal("-1234000"), source("廃止項目"))}),
            Row(key="nil-item", label="nil項目", statement=statement,
                values={new.key: Cell(None, source("nil項目"), nil=True)}),
            Row(key="same-label-different-concept", label="最新表示名",
                statement=statement, is_total=True,
                values={new.key: Cell(Decimal("1111000"), source())}),
        ]
    return ds, old, new


def test_four_sheets_chronological_facts_and_missing_values(tmp_path):
    ds, old, new = fixture_dataset()
    path = export_workbook(ds, tmp_path / "図研.xlsx")
    wb = load_workbook(path)
    assert wb.sheetnames == list(SHEETS.values())
    for ws in wb:
        assert "2024/03/31" in ws["B6"].value
        assert "2025/03/31" in ws["C6"].value
        assert ws["B8"].value == 123456.789
        assert ws["C8"].value == 0
        assert ws["B9"].value == -1234
        assert ws["C9"].value is None
        assert ws["C10"].value is None
        assert "nil: True" in ws["C10"].comment.text
        assert ws["A8"].value == ws["A11"].value
        assert ws["C11"].value == 1111
        assert not any(c.data_type == "f" for row in ws for c in row)
    wb.close()


def test_provenance_keeps_original_names_qname_and_unscaled_value(tmp_path):
    ds, old, new = fixture_dataset()
    wb = load_workbook(export_workbook(ds, tmp_path / "provenance.xlsx"))
    comment = wb.worksheets[0]["B8"].comment.text
    for expected in ["旧表示名", "S100TEST", "statement.xbrl",
                     "https://example.jp/filing/S100TEST",
                     "{https://example.jp/taxonomy/2025}Revenue",
                     "CurrentYearDuration", "123456789", "JPY", "-3"]:
        assert expected in comment
    assert new.key in wb.worksheets[0]["A8"].comment.text
    wb.close()


def test_template_style_and_readable_layout(tmp_path):
    ds, _, _ = fixture_dataset()
    ds.warnings = ["決算期変更により対象日数が異なります。"]
    wb = load_workbook(export_workbook(ds, tmp_path / "style.xlsx"))
    for ws in wb:
        assert ws.freeze_panes == "B7"
        assert ws["A8"].font.name == "ＭＳ Ｐゴシック"
        assert ws["B8"].font.name == "Times New Roman"
        assert "[Red](" in ws["B9"].number_format
        assert ws["B11"].border.top.style == "thin"
        assert ws["B11"].border.bottom.style == "thin"
        assert ws["B8"].fill.patternType is None
        assert ws.column_dimensions["A"].width >= 40
        assert "千円" in ws["A2"].value
        assert "2025-06-21" in ws["A4"].value
        assert ws["A13"].value.startswith("注記：")
    wb.close()


def test_untrusted_text_is_never_an_excel_formula(tmp_path):
    ds, _, _ = fixture_dataset()
    ds.company = "=HYPERLINK(\"https://example.jp\",\"x\")"
    ds.rows["PL"][1].label = "=1+1"
    wb = load_workbook(export_workbook(ds, tmp_path / "literal.xlsx"))
    assert wb.worksheets[0]["A1"].data_type == "s"
    assert wb.worksheets[0]["A8"].value == "=1+1"
    assert wb.worksheets[0]["A8"].data_type == "s"
    wb.close()


@pytest.mark.parametrize("unit,value", [("yen", 123456789),
                                      ("thousand", 123456.789),
                                      ("million", 123.456789)])
def test_unit_conversion_preserves_source_precision(tmp_path, unit, value):
    ds, _, _ = fixture_dataset()
    wb = load_workbook(export_workbook(ds, tmp_path / f"{unit}.xlsx", unit=unit))
    assert wb.worksheets[0]["B8"].value == value
    wb.close()


def test_invalid_export_does_not_replace_existing_file(tmp_path):
    ds, _, _ = fixture_dataset()
    path = tmp_path / "existing.xlsx"
    path.write_bytes(b"original")
    ds.rows["PL"][1].values[ds.periods[0].key].value = Decimal("NaN")
    with pytest.raises(ValueError, match="非有限値"):
        export_workbook(ds, path)
    assert path.read_bytes() == b"original"


def test_empty_periods_rejected(tmp_path):
    with pytest.raises(ValueError, match="年度"):
        export_workbook(Dataset("6947", "図研", "consolidated", []),
                        tmp_path / "empty.xlsx")


def test_non_monetary_values_keep_original_unit_and_exact_label(tmp_path):
    ds, old, new = fixture_dataset()
    eps_source = source("1株当たり利益")
    eps_source.unit = "JPY/shares"
    ds.rows["PL"].append(Row(key="EPS", label="1株当たり利益", statement="PL",
                             values={new.key: Cell(Decimal("123.45"), eps_source)}))
    wb = load_workbook(export_workbook(ds, tmp_path / "eps.xlsx"))
    ws = wb["損益計算書"]
    assert ws["A12"].value == "1株当たり利益"
    assert ws["C12"].value == 123.45
    assert ws["D6"].value == "表示単位"
    assert ws["D8"].value == "千円"
    assert ws["D12"].value == "円/株"
    assert wb["BS_資産"].max_column == 3
    assert "JPY/shares" in ws["C12"].comment.text
    assert "値（原単位・換算前）: 123.45" in ws["C12"].comment.text
    assert "値（円" not in ws["C12"].comment.text
    wb.close()


def test_yearly_basis_changes_are_visible_without_changing_original_labels(tmp_path):
    ds, old, new = fixture_dataset()
    ds.basis = "mixed"
    ds.period_bases = {old.key: "standalone", new.key: "consolidated"}
    for statement in SHEETS:
        old_source, new_source = source(), source()
        old_source.basis = "standalone"
        ds.rows[statement] = [
            Row("standalone:Revenue", "売上高", statement,
                values={old.key: Cell(Decimal("123000"), old_source)}),
            Row("consolidated:Revenue", "売上高", statement,
                values={new.key: Cell(Decimal("456000"), new_source)}),
        ]
    wb = load_workbook(export_workbook(ds, tmp_path / "yearly.xlsx"))
    for ws in wb:
        assert "対象：年度別" in ws["A2"].value
        assert "連結・個別は列見出しを参照" in ws["A2"].value
        assert ws["B6"].value.endswith("個別")
        assert ws["C6"].value.endswith("連結")
        assert ws.row_dimensions[6].height >= 45
        assert ws["A7"].value == ws["A8"].value == "売上高"
        assert ws["B7"].value == 123
        assert ws["C7"].value is None
        assert ws["B8"].value is None
        assert ws["C8"].value == 456
        assert "個別" in ws["A7"].comment.text
        assert "連結" in ws["A8"].comment.text
    wb.close()


def test_yearly_basis_change_requires_complete_column_basis_metadata(tmp_path):
    ds, _, _ = fixture_dataset()
    ds.basis = "mixed"
    ds.period_bases = {}
    with pytest.raises(ValueError, match="全年度"):
        export_workbook(ds, tmp_path / "ambiguous.xlsx")


@pytest.mark.parametrize("standard,label", [("J-GAAP", "日本基準"),
                                            ("IFRS", "IFRS"),
                                            ("US-GAAP", "米国基準")])
def test_single_accounting_standard_is_explicit_in_metadata(tmp_path, standard, label):
    ds, old, new = fixture_dataset()
    ds.accounting_standard = standard
    ds.period_standards = {old.key: standard, new.key: standard}
    wb = load_workbook(export_workbook(ds, tmp_path / f"standard-{standard}.xlsx"))
    for ws in wb:
        assert f"会計基準：{label}" in ws["A2"].value
        assert f"会計基準: {label}" in ws["B6"].comment.text
        assert f"会計基準: {label}" in ws["B8"].comment.text
    wb.close()


def test_yearly_accounting_standard_and_basis_changes_have_unambiguous_headers(tmp_path):
    ds, old, new = fixture_dataset()
    ds.basis = "mixed"
    ds.period_bases = {old.key: "standalone", new.key: "consolidated"}
    ds.accounting_standard = "mixed"
    ds.period_standards = {old.key: "J-GAAP", new.key: "IFRS"}
    wb = load_workbook(export_workbook(ds, tmp_path / "mixed-accounting.xlsx"))
    for ws in wb:
        assert "対象：年度別" in ws["A2"].value
        assert "会計基準：年度別" in ws["A2"].value
        assert "個別\n日本基準" in ws["B6"].value
        assert "連結\nIFRS" in ws["C6"].value
        assert ws.row_dimensions[6].height >= (45 if ws.title.startswith("BS") else 60)
        assert "会計基準: 日本基準" in ws["B8"].comment.text
        assert "会計基準: IFRS" in ws["C8"].comment.text
    wb.close()


def test_information_source_notes_are_distinct_from_warnings_and_keep_all_facts(tmp_path):
    ds, old, new = fixture_dataset()
    ds.source_notes = ["明示的なIFRS移行日の期首BS列は年度末比較から除外。" * 8,
                       "訂正報告書の本文で財務数値に変更がないことを照合済み。"]
    original_warnings = list(ds.warnings)
    wb = load_workbook(export_workbook(ds, tmp_path / "source-notes.xlsx"))
    assert ds.warnings == original_warnings == []
    for ws in wb:
        assert ws["B8"].value == 123456.789
        assert ws["C8"].value == 0
        assert ws["A13"].value.startswith("取得注記：")
        assert ws["A14"].value.startswith("取得注記：")
        assert ws.row_dimensions[13].height > 30
        assert "14" in str(ws.print_area)
        assert not any(c.value and isinstance(c.value, str) and c.value.startswith("注記：")
                       for row in ws for c in row)
    wb.close()


def test_source_notes_follow_actual_warnings_without_conflating_them(tmp_path):
    ds, _, _ = fixture_dataset()
    ds.warnings = ["未解析の項目があります。"]
    ds.source_notes = ["財務以外の訂正範囲を原文で確認しました。"]
    wb = load_workbook(export_workbook(ds, tmp_path / "both-notes.xlsx"))
    for ws in wb:
        assert ws["A13"].value == "注記：未解析の項目があります。"
        assert ws["A14"].value == "取得注記：財務以外の訂正範囲を原文で確認しました。"
    wb.close()


def test_mixed_accounting_requires_all_column_metadata(tmp_path):
    ds, _, _ = fixture_dataset()
    ds.accounting_standard = "mixed"
    ds.period_standards = {}
    with pytest.raises(ValueError, match="全年度の会計基準"):
        export_workbook(ds, tmp_path / "missing-standard.xlsx")
