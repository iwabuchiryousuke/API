"""Actual early IFRS filing plus hostile changes to its explicit table proof."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path
import pytest

from zaimu10.models import Filing
from zaimu10.parser import ParseError,parse_filing
from zaimu10.presentation import prepare_dataset,pl_metrics,local_name

FILING=Filing('S1009X6V',code='4519',edinet_code='E00932',company='中外製薬',
              start=date(2016,1,1),end=date(2016,12,31),submitted='2017-03-23')


def pages():
    with gzip.open(Path(__file__).parent/'fixtures/chugai_2016_html_main.json.gz','rt',encoding='utf-8') as f:
        return json.load(f)


def test_actual_untagged_ifrs_retains_real_textblock_and_physical_provenance():
    d=parse_filing(FILING,pages())
    assert d.complete and not d.warnings
    assert {k:len(v) for k,v in d.rows.items()}=={'PL':19,'BS_A':14,'BS_LE':17,'CF':28}
    key='2016-01-01/2016-12-31'
    revenue=pl_metrics(d)['revenue'].values[key]
    assert revenue.value==Decimal('491780000000')
    assert revenue.source.concept.endswith('}ConsolidatedStatementOfIncomeIFRSTextBlock')
    assert revenue.source.semantic_concept.startswith('{urn:zaimu10:html-table:E00932:')
    assert revenue.source.table_path and revenue.source.raw_value=='491,780'
    assert all(not c.source.concept.endswith('}RevenueIFRS')
               for row in d.rows['PL'] for c in row.values.values())


def test_signed_source_is_preserved_and_projection_reconciles_costs_and_liabilities():
    d=parse_filing(FILING,pages());key='2016-01-01/2016-12-31'
    original=deepcopy(d)
    x=prepare_dataset(d)
    raw=pl_metrics(d);projected=pl_metrics(x)
    assert raw['cost_of_sales'].values[key].value==Decimal('-247944000000')
    assert projected['cost_of_sales'].values[key].value==Decimal('247944000000')
    assert projected['income_taxes'].values[key].value==Decimal('20076000000')
    c=projected['cost_of_sales'].values[key]
    assert c.components[0].value==Decimal('-247944000000') and c.operation=='negate'
    liability=next(r for r in x.rows['BS_LE'] if local_name(r)=='LiabilitiesIFRS')
    assert liability.values[key].value==Decimal('159788000000')
    grand=next(r for r in x.rows['BS_LE'] if local_name(r)=='LiabilitiesAndEquityIFRS')
    assert grand.values[key].value==Decimal('806285000000')
    assert d==original


@pytest.mark.parametrize('change',['unit','date','issuer','number'])
def test_missing_or_conflicting_html_proof_is_rejected(change):
    data=pages();filing=deepcopy(FILING)
    if change=='issuer':filing.edinet_code=''
    else:
        changed=[]
        for name,text in data:
            if name.startswith('0105010'):
                if change=='unit':text=text.replace('百万円','通貨不明')
                if change=='date':text=text.replace('2016年12月31日','2020年12月31日')
                if change=='number':text=text.replace('491,780','491,7xx')
            changed.append((name,text))
        data=changed
    with pytest.raises((ParseError,ValueError)):
        parse_filing(filing,data)
