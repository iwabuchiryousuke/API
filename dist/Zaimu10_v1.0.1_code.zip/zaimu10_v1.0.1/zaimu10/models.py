"""Shared financial data model. Amounts are Decimal in unscaled JPY."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Literal

Statement = Literal['PL', 'BS_A', 'BS_LE', 'CF']
SHEETS: dict[str, str] = {'PL': '損益計算書', 'BS_A': 'BS_資産', 'BS_LE': 'BS_負債純資産', 'CF': 'キャッシュフロー'}

@dataclass(frozen=True, order=True)
class Period:
    start: date
    end: date
    @property
    def key(self) -> str:
        return f'{self.start.isoformat()}/{self.end.isoformat()}'
    @property
    def label(self) -> str:
        return f'{self.end.year}/{self.end.month:02d}'
    @property
    def days(self) -> int:
        return (self.end-self.start).days+1

@dataclass
class Source:
    doc_id: str
    filename: str
    url: str
    submitted: str = ''
    context_id: str = ''
    concept: str = ''  # Original expanded QName, including taxonomy version
    unit: str = 'JPY'
    decimals: str = ''
    original_label: str = ''
    raw_value: str = ''
    scale: int = 0
    basis: str = ''

@dataclass
class Cell:
    value: Decimal | None
    source: Source
    nil: bool = False
    note: str = ''

@dataclass
class Row:
    key: str  # Proven concept identity, dimensions, section and instant role
    label: str
    statement: Statement
    section: tuple[str, ...] = ()
    indent: int = 0
    is_total: bool = False
    is_heading: bool = False
    values: dict[str, Cell] = field(default_factory=dict)  # Period.key -> Cell
    label_period: str = ''

@dataclass
class Dataset:
    code: str
    company: str
    basis: str  # 'consolidated' or 'standalone'; never silently mix
    periods: list[Period]
    rows: dict[str, list[Row]] = field(default_factory=lambda: {s: [] for s in SHEETS})
    warnings: list[str] = field(default_factory=list)
    fetched_at: str = ''
    source_mode: str = 'EDINET公開閲覧'
    checks: list[dict] = field(default_factory=list)
    period_bases: dict[str, str] = field(default_factory=dict)
    accounting_standard: str = ''
    period_standards: dict[str, str] = field(default_factory=dict)
    source_notes: list[str] = field(default_factory=list)
    @property
    def complete(self) -> bool:
        return bool(self.periods) and all(any(p.key in r.values and r.values[p.key].value is not None for r in self.rows[s] if not r.is_heading) for p in self.periods for s in SHEETS)

@dataclass
class Filing:
    doc_id: str
    company: str = ''
    code: str = ''
    edinet_code: str = ''
    start: date | None = None
    end: date | None = None
    submitted: str = ''
    description: str = ''
    amended: bool = False
