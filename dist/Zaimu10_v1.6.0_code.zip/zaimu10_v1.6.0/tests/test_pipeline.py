"""Pipeline failure and selection tests, using deterministic disclosure sources.

Network discovery, retrieval and parsing are substituted, while the real merge,
validation, audit writer and Excel writer are exercised together.
"""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import json
import threading

from openpyxl import load_workbook
import pytest

from zaimu10.models import Cell, Dataset, Filing, Period, Row, SHEETS, Source
from zaimu10.service import AcquisitionError, Options, run

OLD = Period(date(2023, 4, 1), date(2024, 3, 31))
NEW = Period(date(2024, 4, 1), date(2025, 3, 31))
OLD_ID, NEW_ID, AMEND_ID = 'S100AAAA', 'S100BBBB', 'S100CCCC'


def filing(doc_id, period, *, submitted=None, amended=False):
    return Filing(doc_id, company='検証会社', code='6947', edinet_code='E01966',
                  start=period.start, end=period.end,
                  submitted=submitted or f'{period.end.year}-06-20 14:00',
                  description='訂正有価証券報告書' if amended else '有価証券報告書',
                  amended=amended)


def complete(doc_id, periods, *, basis='consolidated', standard='J-GAAP', amount=1000000000):
    ds = Dataset('6947', '検証会社', basis, list(periods), accounting_standard=standard)
    ds.period_bases = {p.key: basis for p in periods}
    ds.period_standards = {p.key: standard for p in periods}
    family = 'jpigp' if standard == 'IFRS' else 'jppfs'
    namespace = f'http://disclosure.edinet-fsa.go.jp/taxonomy/{family}/2024-11-01/{family}_cor'
    concepts = ({'PL':'RevenueIFRS','BS_A':'AssetsIFRS',
                 'BS_LE':'LiabilitiesAndEquityIFRS',
                 'CF':'NetCashProvidedByUsedInOperatingActivitiesIFRS'} if standard == 'IFRS'
                else {'PL':'NetSales','BS_A':'Assets','BS_LE':'LiabilitiesAndNetAssets',
                      'CF':'NetCashProvidedByUsedInOperatingActivities'})
    for statement in SHEETS:
        local = concepts[statement]
        row = Row(f'{statement}:{standard}:{basis}', local, statement)
        for period in periods:
            source = Source(doc_id, 'statements.xhtml',
                            f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{doc_id}',
                            concept=f'{{{namespace}}}{local}', unit='JPY',
                            decimals='-3', basis=basis, original_label=local)
            row.values[period.key] = Cell(Decimal(amount), source)
        ds.rows[statement] = [row]
    return ds


def sources(monkeypatch, filings, datasets, *, fetch_hook=None, decisions=None):
    # Market acquisition has its own source and orchestration tests. These
    # financial-selection fixtures must never contact public price endpoints.
    monkeypatch.setattr('zaimu10.service._prepare_capm_market', lambda *a, **k: {})
    import zaimu10.discovery as discovery
    import zaimu10.edinet as edinet
    import zaimu10.parser as parser
    import zaimu10.amendment as amendment
    calls = {'fetch': [], 'parse': [], 'inspect': []}
    monkeypatch.setattr(discovery, 'discover_filings', lambda *args, **kwargs: deepcopy(filings))
    def fetch(doc_id, **kwargs):
        calls['fetch'].append(doc_id)
        if fetch_hook:
            fetch_hook(doc_id, kwargs)
        return [('original.xhtml', doc_id)]
    def parse(f, pages, basis='auto'):
        calls['parse'].append((f.doc_id, basis))
        ds = datasets[(f.doc_id,basis)] if (f.doc_id,basis) in datasets else datasets[f.doc_id]
        if isinstance(ds, Exception):
            raise ds
        return deepcopy(ds)
    def inspect(pages):
        doc_id = pages[0][1]
        calls['inspect'].append(doc_id)
        return deepcopy((decisions or {})[doc_id])
    monkeypatch.setattr(edinet, 'fetch_filing', fetch)
    monkeypatch.setattr(parser, 'parse_filing', parse)
    monkeypatch.setattr(amendment, 'inspect_amendment', inspect)
    return calls


def options(tmp_path, **kwargs):
    return Options('6947', tmp_path/'results', cache_dir=tmp_path/'cache', years=2, **kwargs)


def test_success_writes_four_sheets_matching_audit_and_all_period_checks(monkeypatch, tmp_path):
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD])})
    result = run(options(tmp_path), log=lambda _: None)
    assert not result.dataset.warnings
    audit = json.loads(result.audit.read_text(encoding='utf-8'))
    assert len(audit['dataset']['periods']) == 2
    coverage = [c for c in audit['dataset']['checks'] if c['check']=='statement_coverage']
    assert len(coverage) == 8 and all(c['ok'] for c in coverage)
    assert all(c['ok'] is True for c in audit['dataset']['checks']
               if c['check'] not in {'cash_flow_components', 'cash_balance_rollforward'})
    cf_checks = [c for c in audit['dataset']['checks']
                 if c['check'] in {'cash_flow_components', 'cash_balance_rollforward'}]
    assert len(cf_checks)==4 and all(c['ok'] is None and c['reason'] for c in cf_checks)
    assert result.workbook.stem == result.audit.name.removesuffix('.audit.json')
    wb = load_workbook(result.workbook)
    assert wb.sheetnames == ['PL','BS-a','BS-le','CF','FR','DCF','CAPM','CAGR']
    assert all(any(item['sheet']==sheet.title and item.get('display_value')=='1000000'
                   for item in result.dataset.export_metadata['cells']) for sheet in [wb[name] for name in ['PL','BS-a','BS-le','CF']])
    wb.close()


def test_strict_missing_statement_stops_excel_and_keeps_honest_audit(monkeypatch, tmp_path):
    older = complete(OLD_ID, [OLD])
    older.rows['CF'] = []
    newer = complete(NEW_ID, [NEW])
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newer, OLD_ID: older})
    opts = options(tmp_path)
    with pytest.raises(AcquisitionError, match='完全な結果として出力できない'):
        run(opts, log=lambda _: None)
    assert not list(opts.output_dir.glob('*.xlsx'))
    [audit_path] = opts.output_dir.glob('*.audit.json')
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    failed = [c for c in audit['dataset']['checks'] if c['ok'] is False]
    assert any(c['statement']=='CF' and c['period']==OLD.key for c in failed)
    assert any('キャッシュフロー' in warning for warning in audit['dataset']['warnings'])


def test_verification_only_partial_failure_is_visible_in_ui_data_and_workbook(monkeypatch, tmp_path):
    ds = complete(NEW_ID, [OLD, NEW])
    ds.rows['BS_LE'][0].values[OLD.key].value += Decimal('1000000')
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: ds, OLD_ID: complete(OLD_ID, [OLD])})
    result = run(options(tmp_path, allow_partial=True), log=lambda _: None)
    assert '_要確認' in result.workbook.name
    assert any('BS左右合計' in warning for warning in result.dataset.warnings)
    assert any(c['check']=='balance_sheet_equation' and c['ok'] is False
               for c in result.dataset.checks)
    wb = load_workbook(result.workbook)
    assert all(cell.comment is None for sheet in wb for row in sheet for cell in row)
    assert any('BS左右合計'in text for text in result.dataset.warnings)
    wb.close()


def test_auto_keeps_one_complete_basis_and_standard_per_year(monkeypatch, tmp_path):
    newest = complete(NEW_ID, [NEW], standard='IFRS')
    # Opening/comparative BS alone must not replace an earlier complete solo set.
    for statement in ['BS_A', 'BS_LE']:
        newest.rows[statement][0].values[OLD.key] = deepcopy(newest.rows[statement][0].values[NEW.key])
        newest.rows[statement][0].values[OLD.key].value = Decimal('999000000000')
    older = complete(OLD_ID, [OLD], basis='standalone', amount=2000000000)
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newest, OLD_ID: older})
    result = run(options(tmp_path), log=lambda _: None)
    assert result.dataset.basis == 'mixed'
    assert result.dataset.period_bases == {OLD.key:'standalone', NEW.key:'consolidated'}
    assert result.dataset.period_standards == {OLD.key:'J-GAAP', NEW.key:'IFRS'}
    for rows in result.dataset.rows.values():
        for row in rows:
            for period_key, cell in row.values.items():
                assert cell.source.basis == result.dataset.period_bases[period_key]
                assert cell.value != Decimal('999000000000')
    assert result.dataset.complete
    assert not result.dataset.warnings


def test_restated_ifrs_comparative_excludes_old_jgaap_same_year(monkeypatch, tmp_path):
    newer = complete(NEW_ID, [OLD, NEW], standard='IFRS', amount=3000000000)
    older = complete(OLD_ID, [OLD], amount=1000000000)
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newer, OLD_ID: older})
    result = run(options(tmp_path), log=lambda _: None)
    assert result.dataset.period_standards == {OLD.key:'IFRS', NEW.key:'IFRS'}
    assert result.dataset.accounting_standard == 'IFRS'
    assert all(cell.source.doc_id==NEW_ID for rows in result.dataset.rows.values()
               for row in rows for cell in row.values.values())
    assert all(cell.value==Decimal('3000000000') for rows in result.dataset.rows.values()
               for row in rows for cell in row.values.values())


@pytest.mark.parametrize('safe_status', ['nonfinancial_only', 'unchanged_financial_values'])
def test_proven_irrelevant_amendment_is_logged_and_not_used_as_financial_fact(monkeypatch, tmp_path, safe_status):
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD])},
                    decisions={AMEND_ID: {'status':safe_status,'reason':'原文照合済み','evidence':['exact original scope']}})
    result = run(options(tmp_path), log=lambda _: None)
    assert calls['inspect'] == [AMEND_ID]
    assert all(doc_id!=AMEND_ID for doc_id, _ in calls['parse'])
    assert any(AMEND_ID in note for note in result.dataset.source_notes)
    [review] = [c for c in result.dataset.checks if c['check']=='amendment_scope']
    assert review['ok'] is True and review['status']==safe_status
    assert not result.dataset.warnings


def test_unknown_unparseable_amendment_never_becomes_a_complete_result(monkeypatch, tmp_path):
    from zaimu10.parser import ParseError
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD]),
                     AMEND_ID: ParseError('訂正前後の数値を確定できません。')},
                    decisions={AMEND_ID: {'status':'unknown','reason':'scope ambiguous','evidence':[]}})
    with pytest.raises(AcquisitionError, match='完全な結果として出力できない'):
        run(options(tmp_path), log=lambda _: None)
    assert AMEND_ID in calls['inspect']
    assert (AMEND_ID, 'auto') in calls['parse']
    assert not list((tmp_path/'results').glob('*.xlsx'))
    [audit_path] = (tmp_path/'results').glob('*.audit.json')
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    assert any(AMEND_ID in warning for warning in audit['dataset']['warnings'])


def test_tagged_financial_amendment_replaces_original_with_new_provenance(monkeypatch, tmp_path):
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [NEW]), OLD_ID: complete(OLD_ID, [OLD]),
                     AMEND_ID: complete(AMEND_ID, [OLD], amount=4000000000)},
                    decisions={AMEND_ID: {'status':'financial','reason':'full tagged corrected statements','evidence':[]}})
    result = run(options(tmp_path), log=lambda _: None)
    assert (AMEND_ID,'auto') in calls['parse']
    assert all(row.values[OLD.key].source.doc_id==AMEND_ID for rows in result.dataset.rows.values() for row in rows)
    assert all(row.values[OLD.key].value==Decimal('4000000000') for rows in result.dataset.rows.values() for row in rows)
    assert any(c['check']=='amendment_scope' and c['ok'] is True for c in result.dataset.checks)


def test_cancelled_before_start_never_calls_discovery_or_writes_output(monkeypatch, tmp_path):
    import zaimu10.discovery as discovery
    event=threading.Event();event.set()
    def unexpected(*args, **kwargs):raise AssertionError('discovery must not run after cancellation')
    monkeypatch.setattr(discovery,'discover_filings',unexpected)
    with pytest.raises(InterruptedError):run(options(tmp_path),log=lambda _:None,cancel=event)
    assert not (tmp_path/'results').exists()


def test_cancellation_during_fetch_propagates_without_partial_audit(monkeypatch, tmp_path):
    event=threading.Event()
    def interrupt(doc_id, kwargs):
        event.set()
        raise InterruptedError('user cancelled')
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
                  {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])},fetch_hook=interrupt)
    with pytest.raises(InterruptedError):run(options(tmp_path),log=lambda _:None,cancel=event)
    assert calls['parse']==[]
    assert not (tmp_path/'results').exists()


def test_repeated_run_preserves_edited_workbook_and_matching_original_audit(monkeypatch, tmp_path):
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
            {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])})
    first=run(options(tmp_path),log=lambda _:None)
    edited=first.workbook.read_bytes()+b'\nuser edits must remain\n'
    first.workbook.write_bytes(edited)
    original_audit=first.audit.read_bytes()
    second=run(options(tmp_path),log=lambda _:None)
    assert first.workbook.read_bytes()==edited
    assert first.audit.read_bytes()==original_audit
    assert second.workbook.stem==first.workbook.stem+'_2'
    assert second.audit.stem==first.workbook.stem+'_2.audit'
    assert second.workbook.is_file() and second.audit.is_file()


def solo_without_cf(doc_id,periods,*,amount=1000000000):
    ds=complete(doc_id,periods,basis='standalone',amount=amount)
    ds.rows['CF']=[]
    ds.warnings=[f'{doc_id}: standaloneのCF本表がありません。']
    return ds


def test_individual_cf_absence_switches_all_four_statements_and_records_requested_basis(monkeypatch,tmp_path):
    requested={NEW_ID:solo_without_cf(NEW_ID,[OLD,NEW]),OLD_ID:solo_without_cf(OLD_ID,[OLD])}
    requested[(NEW_ID,'consolidated')]=complete(NEW_ID,[OLD,NEW],amount=3000000000)
    requested[(OLD_ID,'consolidated')]=complete(OLD_ID,[OLD],amount=2000000000)
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],requested)
    messages=[];opts=options(tmp_path,basis='standalone')
    result=run(opts,log=messages.append)
    assert opts.basis=='standalone' and result.requested_basis=='standalone'
    assert result.resolved_basis==result.dataset.basis=='consolidated'
    assert result.basis_notice and any(result.basis_notice in message for message in messages)
    assert not result.dataset.warnings and result.dataset.complete
    assert set(calls['parse'])=={(NEW_ID,'standalone'),(NEW_ID,'consolidated'),
                                (OLD_ID,'standalone'),(OLD_ID,'consolidated')}
    for rows in result.dataset.rows.values():
        assert all(cell.source.basis=='consolidated' and cell.value==Decimal(3000000000)
                   for row in rows for cell in row.values.values())
    audit=json.loads(result.audit.read_text())
    assert audit['options']['basis']=='standalone'
    resolution=audit['basis_resolution']
    assert resolution['requested']=='standalone' and resolution['resolved']=='consolidated'
    assert resolution['fallback_used'] is True
    assert all(p['fallback'] and p['source_doc_id']==NEW_ID for p in resolution['periods'].values())
    assert result.basis_notice in audit['dataset']['source_notes']
    wb=load_workbook(result.workbook)
    assert all(wb[name]['A1'].value.startswith('連結') for name in ['PL','BS-a','BS-le','CF'])
    assert all(sheet['A1'].comment is None for sheet in wb)
    assert result.basis_notice in result.dataset.source_notes
    wb.close()


def test_complete_requested_individual_period_beats_newer_consolidated_fallback(monkeypatch,tmp_path):
    requested={NEW_ID:solo_without_cf(NEW_ID,[OLD,NEW]),
               OLD_ID:complete(OLD_ID,[OLD],basis='standalone',amount=2000000000),
               (NEW_ID,'consolidated'):complete(NEW_ID,[OLD,NEW],amount=3000000000)}
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],requested)
    result=run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert result.resolved_basis=='mixed'
    assert result.dataset.period_bases=={OLD.key:'standalone',NEW.key:'consolidated'}
    assert result.basis_resolution['periods'][OLD.key]['fallback'] is False
    assert result.basis_resolution['periods'][NEW.key]['fallback'] is True
    assert (OLD_ID,'consolidated') not in calls['parse']
    for rows in result.dataset.rows.values():
        for row in rows:
            for key,cell in row.values.items():
                assert cell.source.basis==result.dataset.period_bases[key]
                assert cell.value==Decimal(2000000000 if key==OLD.key else 3000000000)
    wb=load_workbook(result.workbook)
    for sheet in [wb[name] for name in ['PL','BS-a','BS-le','CF']]:
        headers=[sheet.cell(1,c).value for c in (2,3)]
        assert any('個別' in header for header in headers)
        assert any('連結' in header for header in headers)
    wb.close()


def test_complete_individual_set_keeps_requested_basis_without_fallback(monkeypatch,tmp_path):
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW],basis='standalone'),
         OLD_ID:complete(OLD_ID,[OLD],basis='standalone')})
    result=run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert result.resolved_basis=='standalone' and result.basis_notice==''
    assert not result.basis_resolution['fallback_used']
    assert calls['parse']==[(NEW_ID,'standalone'),(OLD_ID,'standalone')]


def test_individual_cf_unavailable_and_incomplete_consolidated_remains_explicit_failure(monkeypatch,tmp_path):
    conso=complete(NEW_ID,[OLD,NEW]);conso.rows['CF']=[]
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:solo_without_cf(NEW_ID,[OLD,NEW]),OLD_ID:solo_without_cf(OLD_ID,[OLD]),
         (NEW_ID,'consolidated'):conso,(OLD_ID,'consolidated'):conso})
    with pytest.raises(AcquisitionError,match='完全な結果として出力できない'):
        run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert not list((tmp_path/'results').glob('*.xlsx'))
    [path]=(tmp_path/'results').glob('*.audit.json')
    audit=json.loads(path.read_text())
    assert not audit['basis_resolution']['fallback_used']
    assert any('個別CFを取得できず' in warning for warning in audit['dataset']['warnings'])


def test_published_cf_with_missing_numeric_values_does_not_trigger_basis_fallback(monkeypatch,tmp_path):
    ds=complete(NEW_ID,[OLD,NEW],basis='standalone')
    for row in ds.rows['CF']:
        for cell in row.values.values():cell.value=None;cell.nil=True
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:ds,OLD_ID:ds})
    with pytest.raises(AcquisitionError):
        run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert all(basis=='standalone' for _,basis in calls['parse'])


def test_other_individual_parse_warning_cannot_be_hidden_by_consolidated_fallback(monkeypatch,tmp_path):
    ds=solo_without_cf(NEW_ID,[OLD,NEW]);ds.warnings.append('原本の数値を一意に確認できません。')
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],{NEW_ID:ds,OLD_ID:ds})
    with pytest.raises(AcquisitionError,match='原本の数値'):
        run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert all(basis=='standalone' for _,basis in calls['parse'])


def test_consolidated_fallback_parser_error_is_never_a_complete_success(monkeypatch,tmp_path):
    from zaimu10.parser import ParseError
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:solo_without_cf(NEW_ID,[OLD,NEW]),OLD_ID:solo_without_cf(OLD_ID,[OLD]),
         (NEW_ID,'consolidated'):ParseError('連結CFの未対応XBRLファクト'),
         (OLD_ID,'consolidated'):complete(OLD_ID,[OLD])})
    with pytest.raises(AcquisitionError,match='連結CFの未対応XBRLファクト'):
        run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert not list((tmp_path/'results').glob('*.xlsx'))


def test_explicit_consolidated_missing_cf_never_splices_individual_cf(monkeypatch,tmp_path):
    ds=complete(NEW_ID,[OLD,NEW]);ds.rows['CF']=[]
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],{NEW_ID:ds,OLD_ID:ds})
    with pytest.raises(AcquisitionError):
        run(options(tmp_path,basis='consolidated'),log=lambda _:None)
    assert all(basis=='consolidated' for _,basis in calls['parse'])


def test_debt_note_inputs_follow_exact_selected_authority_basis_and_standard():
    from zaimu10.service import merge_datasets
    newest=complete(NEW_ID,[OLD,NEW])
    older=complete(OLD_ID,[OLD])
    solo=complete(OLD_ID,[OLD],basis='standalone')
    for ds,amount in [(newest,300),(older,200),(solo,100)]:
        values={p.key:deepcopy(ds.rows['BS_LE'][0].values[p.key]) for p in ds.periods}
        for cell in values.values():cell.value=Decimal(amount)
        ds.analysis_inputs=[Row('notes:debt:leases:'+ds.basis,'リース債務','BS_LE',values=values)]
    newest.analysis_input_errors={OLD.key:['unused comparative note problem']}
    older.analysis_input_errors={OLD.key:['unused old report note problem']}
    solo.analysis_input_errors={OLD.key:['authoritative solo note ambiguity']}
    merged=merge_datasets([newest,older,solo],[OLD,NEW],code='6947',basis='mixed',
        period_bases={OLD.key:'standalone',NEW.key:'consolidated'},
        period_standards={OLD.key:'J-GAAP',NEW.key:'J-GAAP'},
        period_authorities={OLD.key:solo,NEW.key:newest})
    assert len(merged.analysis_inputs)==2
    notes={(key,cell.source.basis):(cell.value,cell.source.doc_id)
           for row in merged.analysis_inputs for key,cell in row.values.items()}
    assert notes=={(OLD.key,'standalone'):(Decimal(100),OLD_ID),
                   (NEW.key,'consolidated'):(Decimal(300),NEW_ID)}
    assert merged.analysis_input_errors=={OLD.key:['authoritative solo note ambiguity']}
    assert all(row.key.startswith('notes:') for row in merged.analysis_inputs)
    assert not any(row.key.startswith('notes:') for rows in merged.rows.values() for row in rows)
    merged.analysis_inputs[0].values[next(iter(merged.analysis_inputs[0].values))].value+=1
    assert newest.analysis_inputs[0].values[NEW.key].value==Decimal(300)


def test_proven_financial_notes_only_amendment_keeps_primary_statements_and_blocks_affected_metrics(monkeypatch,tmp_path):
    amended=filing(AMEND_ID,OLD,submitted='2025-07-01 09:00',amended=True)
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[NEW]),OLD_ID:complete(OLD_ID,[OLD])},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=True,
            reason='財務注記の訂正だけであることを宣言と本文で確認。',
            analysis_inputs_affected=True,affected_periods=[OLD.key],changed_rows=['原本差分'])})
    result=run(options(tmp_path),log=lambda _:None)
    assert not result.dataset.warnings and result.dataset.complete
    assert (AMEND_ID,'auto') not in calls['parse']
    assert set(result.dataset.analysis_input_errors)=={OLD.key}
    assert AMEND_ID in result.dataset.analysis_input_errors[OLD.key][0]
    [check]=[c for c in result.dataset.checks if c['check']=='amendment_scope']
    assert check['ok'] is True and check['analysis_blocked_periods']==[OLD.key]
    assert any('財務注記のみの訂正' in note for note in result.dataset.source_notes)
    audit=json.loads(result.audit.read_text())
    assert OLD.key in audit['raw_dataset']['analysis_input_errors']


def test_later_complete_comparative_authority_is_not_invalidated_by_older_note_correction(monkeypatch,tmp_path):
    amended=filing(AMEND_ID,OLD,submitted='2024-07-01 09:00',amended=True)
    sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=True,
            reason='原本の注記訂正',analysis_inputs_affected=True,affected_periods=None)})
    result=run(options(tmp_path),log=lambda _:None)
    assert result.dataset.analysis_input_errors=={}
    [check]=[c for c in result.dataset.checks if c['check']=='amendment_scope']
    assert check['analysis_blocked_periods']==[]


def test_proven_nondebt_financial_note_change_does_not_blank_debt_indicators(monkeypatch,tmp_path):
    amended=filing(AMEND_ID,OLD,submitted='2025-07-01 09:00',amended=True)
    sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[NEW]),OLD_ID:complete(OLD_ID,[OLD])},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=True,
            reason='資本注記のみの変更を明示的に確認。',analysis_inputs_affected=False)})
    result=run(options(tmp_path),log=lambda _:None)
    assert result.dataset.analysis_input_errors=={}
    assert not result.dataset.warnings


def test_financial_notes_only_without_complete_positive_proof_remains_strict(monkeypatch,tmp_path):
    from zaimu10.parser import ParseError
    amended=filing(AMEND_ID,OLD,submitted='2025-07-01 09:00',amended=True)
    sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[NEW]),OLD_ID:complete(OLD_ID,[OLD]),
         AMEND_ID:ParseError('訂正本表の範囲を確定できません。')},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=False,
            reason='注記のみとの十分な証拠がありません。',analysis_inputs_affected=True)})
    with pytest.raises(AcquisitionError,match='訂正本表の範囲'):
        run(options(tmp_path),log=lambda _:None)


def test_ambiguous_note_input_blanks_only_affected_analysis_and_keeps_valid_four_sheets(monkeypatch,tmp_path):
    import zaimu10.debt_notes as debt_notes
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])})
    def ambiguous(pages,ds):
        raise debt_notes.DebtNoteError('注記の期首・期末列が一意ではありません。',periods=[OLD.key])
    monkeypatch.setattr(debt_notes,'extract_debt_notes',ambiguous)
    messages=[];result=run(options(tmp_path),log=messages.append)
    assert result.workbook.exists() and result.dataset.complete
    assert result.dataset.warnings==[]
    assert result.dataset.analysis_input_errors=={OLD.key:['注記の期首・期末列が一意ではありません。']}
    assert any('負債関係指標を未算出' in message for message in messages)
    audit=json.loads(result.audit.read_text())
    assert audit['raw_dataset']['analysis_input_errors']==result.dataset.analysis_input_errors
    assert len(audit['dataset']['rows'])==4


def test_supplementary_notes_attached_to_fallback_from_same_selected_basis(monkeypatch,tmp_path):
    import zaimu10.debt_notes as debt_notes
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:solo_without_cf(NEW_ID,[OLD,NEW]),OLD_ID:solo_without_cf(OLD_ID,[OLD]),
         (NEW_ID,'consolidated'):complete(NEW_ID,[OLD,NEW]),
         (OLD_ID,'consolidated'):complete(OLD_ID,[OLD])})
    extracted=[]
    def notes(pages,ds):
        extracted.append((pages[0][1],ds.basis))
        values={period.key:deepcopy(ds.rows['BS_LE'][0].values[period.key]) for period in ds.periods}
        for cell in values.values():cell.value=Decimal(99 if ds.basis=='standalone' else 12)
        return [Row('notes:debt:leases:'+ds.basis,'リース債務','BS_LE',values=values)]
    monkeypatch.setattr(debt_notes,'extract_debt_notes',notes)
    result=run(options(tmp_path,basis='standalone'),log=lambda _:None)
    assert set(extracted)==set(calls['parse'])
    assert result.dataset.analysis_inputs
    assert all(cell.value==12 and cell.source.basis=='consolidated' and cell.source.doc_id==NEW_ID
               for row in result.dataset.analysis_inputs for cell in row.values.values())


def test_changed_specific_note_caption_overlapping_primary_row_stops_strict_output(monkeypatch,tmp_path):
    amended=filing(AMEND_ID,OLD,submitted='2025-07-01 09:00',amended=True)
    sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[NEW]),OLD_ID:complete(OLD_ID,[OLD])},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=True,
            reason='原本注記の実際の変更',analysis_inputs_affected=False,
            changed_row_labels=['Assets'],affected_periods=[OLD.key])})
    with pytest.raises(AcquisitionError,match='数値の整合を確定できません'):
        run(options(tmp_path),log=lambda _:None)
    assert not list((tmp_path/'results').glob('*.xlsx'))
    [path]=(tmp_path/'results').glob('*.audit.json')
    audit=json.loads(path.read_text())
    [check]=[c for c in audit['dataset']['checks'] if c['check']=='amendment_scope']
    assert check['ok'] is False and check['primary_label_conflicts']==['Assets']


def test_generic_note_total_caption_is_not_a_primary_identity_conflict(monkeypatch,tmp_path):
    amended=filing(AMEND_ID,OLD,submitted='2025-07-01 09:00',amended=True)
    older=complete(OLD_ID,[OLD]);older.rows['BS_A'][0].label='合計'
    sources(monkeypatch,[filing(NEW_ID,NEW),amended,filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[NEW]),OLD_ID:older},
        decisions={AMEND_ID:dict(status='financial_notes_only',proof_complete=True,
            reason='注記の内訳変更',analysis_inputs_affected=False,
            changed_row_labels=['合計'],affected_periods=[OLD.key])})
    result=run(options(tmp_path),log=lambda _:None)
    assert result.dataset.complete and not result.dataset.warnings


def test_cf_fallback_cannot_fill_an_unrelated_missing_individual_statement_in_another_period(monkeypatch,tmp_path):
    newest=solo_without_cf(NEW_ID,[OLD,NEW])
    newest.rows['PL'][0].values.pop(OLD.key)
    older=solo_without_cf(OLD_ID,[OLD]);older.rows['PL']=[]
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:newest,OLD_ID:older,
         (NEW_ID,'consolidated'):complete(NEW_ID,[OLD,NEW])})
    with pytest.raises(AcquisitionError,match='完全な結果として出力できない'):
        run(options(tmp_path,basis='standalone'),log=lambda _:None)
    [path]=(tmp_path/'results').glob('*.audit.json')
    audit=json.loads(path.read_text())
    assert audit['basis_resolution']['periods'][OLD.key]['fallback'] is False
    assert audit['basis_resolution']['periods'][NEW.key]['fallback'] is True
    assert audit['dataset']['period_bases']=={NEW.key:'consolidated',OLD.key:'standalone'}
    assert any(c.get('statement')=='PL' and c.get('period')==OLD.key and c['ok'] is False
               for c in audit['dataset']['checks'])
    assert not list((tmp_path/'results').glob('*.xlsx'))


@pytest.mark.parametrize('standard',['IFRS','J-GAAP'])
def test_optional_note_fetch_failure_keeps_verified_primary_sheets_and_blanks_debt(monkeypatch,tmp_path,standard):
    def fail_notes(doc_id,kwargs):
        if kwargs.get('include_notes'):
            raise OSError('補足注記サーバーへの接続失敗')
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW],standard=standard),
         OLD_ID:complete(OLD_ID,[OLD],standard=standard)},fetch_hook=fail_notes)
    messages=[];result=run(options(tmp_path),log=messages.append)
    assert result.dataset.complete and result.dataset.warnings==[]
    assert result.workbook.exists()
    assert set(result.dataset.analysis_input_errors)=={OLD.key,NEW.key}
    assert all('財務注記・借入明細の追加取得に失敗' in reason
               for reasons in result.dataset.analysis_input_errors.values() for reason in reasons)
    assert any('補足注記サーバー' in message for message in messages)


@pytest.mark.parametrize('standard',['IFRS','J-GAAP'])
def test_offline_does_not_attempt_optional_network_note_upgrade(monkeypatch,tmp_path,standard):
    fetches=[]
    def offline_only(doc_id,kwargs):
        fetches.append(kwargs)
        assert kwargs['offline'] is True and not kwargs.get('include_notes')
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW],standard=standard),
         OLD_ID:complete(OLD_ID,[OLD],standard=standard)},fetch_hook=offline_only)
    result=run(options(tmp_path,offline=True),log=lambda _:None)
    assert result.dataset.complete and len(fetches)==2
    assert result.dataset.analysis_input_errors=={}


def test_jgaap_online_acquires_borrowing_annex_outside_verified_primary_pages(monkeypatch,tmp_path):
    import zaimu10.edinet as edinet
    import zaimu10.debt_notes as debt_notes
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
        {NEW_ID:complete(NEW_ID,[OLD,NEW],standard='J-GAAP'),
         OLD_ID:complete(OLD_ID,[OLD],standard='J-GAAP')})
    acquired=[]
    def fetch(doc_id,**kwargs):
        acquired.append((doc_id,kwargs.get('include_notes',False)))
        pages=[('original.xhtml',doc_id)]
        if kwargs.get('include_notes'):
            pages.append(('borrowing-annex.xhtml','verified borrowing schedule'))
        return pages
    def notes(pages,ds):
        assert ('borrowing-annex.xhtml','verified borrowing schedule') in pages
        values={period.key:deepcopy(ds.rows['BS_LE'][0].values[period.key]) for period in ds.periods}
        for cell in values.values():
            cell.value=Decimal('456000');cell.source.filename='borrowing-annex.xhtml'
        return [Row('notes:debt:short_term_borrowings:consolidated','短期借入金','BS_LE',values=values)]
    monkeypatch.setattr(edinet,'fetch_filing',fetch)
    monkeypatch.setattr(debt_notes,'extract_debt_notes',notes)
    result=run(options(tmp_path),log=lambda _:None)
    assert set(acquired)=={(NEW_ID,False),(NEW_ID,True),(OLD_ID,False),(OLD_ID,True)}
    assert result.dataset.complete and result.dataset.warnings==[]
    assert result.dataset.analysis_input_errors=={}
    assert all(cell.value==456000 and cell.source.filename=='borrowing-annex.xhtml'
               for row in result.dataset.analysis_inputs for cell in row.values.values())
