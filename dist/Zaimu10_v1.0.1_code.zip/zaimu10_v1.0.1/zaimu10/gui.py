"""Native desktop UI: all network/parsing work runs off the Tk event loop."""
from __future__ import annotations
from datetime import date
from pathlib import Path
import os
import queue
import subprocess
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

from . import __version__
from .service import Options, Result, run, validate_code

APP_DIR = Path(__file__).resolve().parent.parent

class App:
    def __init__(self, root: tk.Tk, initial_code: str = '6947'):
        self.root = root
        self.root.title(f'Zaimu10 v{__version__} — 財務諸表を10期まとめてExcelへ')
        self.root.geometry('940x790')
        self.root.minsize(800,700)
        self.root.configure(bg='#f5f7fa')
        self.busy=False
        self.closing=False
        self.worker: threading.Thread | None = None
        self.cancel_event=threading.Event()
        self.events: queue.Queue=queue.Queue()
        self.result: Result | None=None
        self.code=tk.StringVar(value=initial_code)
        self.years=tk.IntVar(value=10)
        self.basis=tk.StringVar(value='自動（連結を優先）')
        self.unit=tk.StringVar(value='千円（見本と同じ）')
        self.output=tk.StringVar(value=str(APP_DIR/'results'))
        self.until=tk.StringVar()
        self.partial=tk.BooleanVar(value=False)
        self.offline=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='銘柄コードを入力して「Excelを作成」を押してください。')
        self._styles()
        self._build()
        self.root.protocol('WM_DELETE_WINDOW',self._close)
        self.root.after(150,self._poll)

    def _styles(self):
        style=ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.',font=('Yu Gothic UI',10),background='#f5f7fa',foreground='#203047')
        style.configure('TFrame',background='#f5f7fa')
        style.configure('Card.TFrame',background='#ffffff')
        style.configure('Card.TLabel',background='#ffffff')
        style.configure('Title.TLabel',font=('Yu Gothic UI',22,'bold'),foreground='#172c48')
        style.configure('Sub.TLabel',foreground='#526276',font=('Yu Gothic UI',10))
        style.configure('TButton',padding=(14,9),font=('Yu Gothic UI',10))
        style.configure('Primary.TButton',background='#174a7b',foreground='white',font=('Yu Gothic UI',11,'bold'))
        style.map('Primary.TButton',background=[('active','#246296'),('disabled','#b4c2d0')])
        style.configure('TEntry',padding=7)
        style.configure('TCombobox',padding=7)
        style.configure('TLabelframe',padding=15,background='white')
        style.configure('TLabelframe.Label',background='#f5f7fa',font=('Yu Gothic UI',10,'bold'))
        style.configure('TCheckbutton',background='white')

    def _build(self):
        main=ttk.Frame(self.root,padding=(30,24))
        main.pack(fill='both',expand=True)
        ttk.Label(main,text='財務諸表を、10期まとめて。',style='Title.TLabel').pack(anchor='w')
        ttk.Label(main,text='銘柄コードから、損益・資産・負債純資産・キャッシュフローの4シートを作成します。',style='Sub.TLabel').pack(anchor='w',pady=(5,18))
        card=ttk.Frame(main,style='Card.TFrame',padding=20)
        card.pack(fill='x')
        card.columnconfigure(1,weight=1)
        card.columnconfigure(3,weight=1)
        ttk.Label(card,text='銘柄コード',style='Card.TLabel').grid(row=0,column=0,sticky='w',padx=(0,10))
        self.code_entry=ttk.Entry(card,textvariable=self.code,width=12,font=('Consolas',17))
        self.code_entry.grid(row=0,column=1,sticky='w',pady=(0,14))
        ttk.Label(card,text='取得期数',style='Card.TLabel').grid(row=0,column=2,sticky='w',padx=(20,10))
        self.years_box=ttk.Combobox(card,textvariable=self.years,values=list(range(1,11)),width=6,state='readonly')
        self.years_box.grid(row=0,column=3,sticky='w',pady=(0,14))
        ttk.Label(card,text='対象',style='Card.TLabel').grid(row=1,column=0,sticky='w')
        self.basis_box=ttk.Combobox(card,textvariable=self.basis,values=['自動（連結を優先）','連結','個別'],width=23,state='readonly')
        self.basis_box.grid(row=1,column=1,sticky='ew',pady=(0,14))
        ttk.Label(card,text='表示単位',style='Card.TLabel').grid(row=1,column=2,sticky='w',padx=(20,10))
        self.unit_box=ttk.Combobox(card,textvariable=self.unit,values=['千円（見本と同じ）','百万円','円'],width=22,state='readonly')
        self.unit_box.grid(row=1,column=3,sticky='ew',pady=(0,14))
        ttk.Label(card,text='出力先',style='Card.TLabel').grid(row=2,column=0,sticky='w')
        self.output_entry=ttk.Entry(card,textvariable=self.output)
        self.output_entry.grid(row=2,column=1,columnspan=3,sticky='ew')
        self.folder_button=ttk.Button(card,text='選択…',command=self._choose_folder)
        self.folder_button.grid(row=2,column=4,padx=(8,0))
        ttk.Label(card,text='EDINETの公表値と原項目名を使用。欠落項目は空白、同一性を確認できない項目は別行に残します。',style='Card.TLabel',wraplength=790).grid(row=3,column=0,columnspan=5,sticky='w',pady=(14,0))
        advanced=ttk.Labelframe(main,text='詳細設定（通常は変更不要）')
        advanced.pack(fill='x',pady=(14,12))
        ttk.Label(advanced,text='最終決算日',style='Card.TLabel').grid(row=0,column=0,sticky='w')
        self.until_entry=ttk.Entry(advanced,textvariable=self.until,width=17)
        self.until_entry.grid(row=0,column=1,padx=10,sticky='w')
        ttk.Label(advanced,text='空欄＝最新　／　指定例：2025-03-31',style='Card.TLabel').grid(row=0,column=2,sticky='w')
        self.offline_check=ttk.Checkbutton(advanced,text='取得済みデータのみ使用（オフライン）',variable=self.offline)
        self.offline_check.grid(row=1,column=0,columnspan=3,sticky='w',pady=(10,0))
        self.partial_check=ttk.Checkbutton(advanced,text='不足・警告がある場合も「要確認」のExcelを出力する',variable=self.partial)
        self.partial_check.grid(row=2,column=0,columnspan=3,sticky='w',pady=(7,0))
        actions=ttk.Frame(main)
        actions.pack(fill='x',pady=(0,10))
        self.start_button=ttk.Button(actions,text='Excelを作成',style='Primary.TButton',command=self._start)
        self.start_button.pack(side='left')
        self.cancel_button=ttk.Button(actions,text='中止',command=self._cancel,state='disabled')
        self.cancel_button.pack(side='left',padx=8)
        self.open_button=ttk.Button(actions,text='Excelを開く',command=self._open_file,state='disabled')
        self.open_button.pack(side='right')
        self.open_folder_button=ttk.Button(actions,text='出力先を開く',command=self._open_folder)
        self.open_folder_button.pack(side='right',padx=8)
        self.progress=ttk.Progressbar(main,mode='indeterminate')
        self.progress.pack(fill='x')
        ttk.Label(main,textvariable=self.status,style='Sub.TLabel',wraplength=850).pack(anchor='w',pady=(8,6))
        self.logs=ScrolledText(main,height=8,wrap='word',font=('Yu Gothic UI',9),bg='white',fg='#28384d',relief='flat',padx=12,pady=10,state='disabled')
        self.logs.pack(fill='both',expand=True)
        ttk.Label(main,text='Excelは編集可能です。数値セルのメモに原項目名・出典、同名のaudit.jsonに全検証結果を記録します。',style='Sub.TLabel',wraplength=850).pack(anchor='w',pady=(9,0))
        self.code_entry.focus_set()
        self.root.bind('<Return>',lambda _: self._start() if not self.busy else None)
        self.inputs=[self.code_entry,self.years_box,self.basis_box,self.unit_box,self.output_entry,self.folder_button,self.until_entry,self.offline_check,self.partial_check]

    def _choose_folder(self):
        path=filedialog.askdirectory(title='Excelの出力先を選択',initialdir=self.output.get() if Path(self.output.get()).is_dir() else str(APP_DIR))
        if path:self.output.set(path)

    def _append(self,text:str):
        self.logs.configure(state='normal')
        self.logs.insert('end',text+'\n')
        self.logs.see('end')
        self.logs.configure(state='disabled')

    def _set_busy(self,busy:bool):
        self.busy=busy
        for widget in self.inputs:
            widget.configure(state='disabled' if busy else ('readonly' if isinstance(widget,ttk.Combobox) else 'normal'))
        self.start_button.configure(state='disabled' if busy else 'normal')
        self.cancel_button.configure(state='normal' if busy else 'disabled')
        if busy:
            self.open_button.configure(state='disabled')
            self.progress.start(12)
        else:
            self.progress.stop()
            self.open_button.configure(state='normal' if self.result else 'disabled')

    def _start(self):
        if self.busy:return
        try:
            code=validate_code(self.code.get())
            until=date.fromisoformat(self.until.get().strip()) if self.until.get().strip() else None
            years=int(self.years.get())
            if not 1<=years<=10:raise ValueError('取得期数は1～10を指定してください。')
            if not self.output.get().strip():raise ValueError('出力先を指定してください。')
            opts=Options(code=code,output_dir=Path(self.output.get()),cache_dir=APP_DIR/'.cache'/'zaimu10',years=years,
                         basis={'自動（連結を優先）':'auto','連結':'consolidated','個別':'standalone'}[self.basis.get()],
                         unit={'千円（見本と同じ）':'thousand','百万円':'million','円':'yen'}[self.unit.get()],
                         until=until,offline=self.offline.get(),allow_partial=self.partial.get())
        except (ValueError,KeyError) as exc:
            messagebox.showerror('入力を確認してください',str(exc),parent=self.root)
            return
        self.result=None
        self.cancel_event.clear()
        self.logs.configure(state='normal');self.logs.delete('1.0','end');self.logs.configure(state='disabled')
        self._set_busy(True)
        self.status.set(f'{code} の財務諸表を取得しています。初回は数分かかる場合があります。')
        def work():
            try:
                result=run(opts,log=lambda text:self.events.put(('log',text)),cancel=self.cancel_event)
                self.events.put(('done',result))
            except InterruptedError as exc:
                self.events.put(('cancelled',str(exc)))
            except Exception as exc:
                self.events.put(('error',str(exc)))
                self.events.put(('trace',traceback.format_exc()))
        self.worker=threading.Thread(target=work,name='zaimu10-acquisition',daemon=True)
        self.worker.start()

    def _poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='log':
                    self._append(value)
                    self.status.set(value)
                elif kind=='done':
                    self.result=value
                    self._set_busy(False)
                    tag='要確認の出力' if value.dataset.warnings else '作成完了'
                    self.status.set(f'{tag}：{value.workbook.name}')
                    self._append(f'Excel：{value.workbook}\n監査記録：{value.audit}')
                elif kind=='error':
                    self._set_busy(False)
                    self.status.set('出力を完了できませんでした。下の詳細を確認してください。')
                    self._append(value)
                elif kind=='cancelled':
                    self._set_busy(False)
                    self.status.set(value)
                    self._append(value)
                # Tracebacks are omitted from the end-user flow. CLI --debug
                # provides the technical details when diagnosing source changes.
        except queue.Empty:
            pass
        if self.closing and (self.worker is None or not self.worker.is_alive()):
            self.root.destroy();return
        self.root.after(150,self._poll)

    def _cancel(self):
        self.cancel_event.set()
        self.status.set('中止しています。実行中の通信が終了するまでお待ちください。')
        self.cancel_button.configure(state='disabled')

    def _close(self):
        if self.busy:
            self.closing=True
            self._cancel()
        else:self.root.destroy()

    def _open_path(self,path:Path):
        try:
            if sys.platform=='win32':os.startfile(str(path))
            elif sys.platform=='darwin':subprocess.Popen(['open',str(path)])
            else:subprocess.Popen(['xdg-open',str(path)])
        except OSError as exc:messagebox.showerror('開けませんでした',str(exc),parent=self.root)

    def _open_file(self):
        if self.result:self._open_path(self.result.workbook)

    def _open_folder(self):
        path=Path(self.output.get()).expanduser()
        if path.is_dir():self._open_path(path)
        else:messagebox.showinfo('出力先','Excelの作成後にフォルダーを開けます。',parent=self.root)


def launch(initial_code:str='6947'):
    root=tk.Tk()
    App(root,initial_code)
    root.mainloop()
