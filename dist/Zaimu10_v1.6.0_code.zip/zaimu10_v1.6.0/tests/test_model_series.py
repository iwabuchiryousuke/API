"""Chart model values keep their Excel units, missing inputs and true axes."""
from decimal import Decimal
from types import SimpleNamespace

import pytest

from zaimu10.charts import DEFAULT_KEYS, VIEW_KEYS, axis_label, format_value, series_for_view
from zaimu10.model_series import MODEL_VIEWS, append_model_series


def chart(unit='thousand', factor=Decimal(1000000)):
    annual = {
        'old': {'nopat': {'display_value': '2500.125'},
                'trade_receivables': {'display_value': '1000'}},
        'new': {'nopat': {'display_value': None, 'missing': ['法人税入力なし']},
                'trade_receivables': {'display_value': '0'}},
    }
    fr = {'old': {'roic': {'display_value': '0.125'},
                  'liquidity_months': {'display_value': '2.5'},
                  'receivables_days': {'display_value': '45.25'},
                  'ppe_turnover': {'display_value': '3.75'}}}
    ds = SimpleNamespace(export_metadata={'format_version': 6, 'unit': unit,
        'supplemental': {'DCF': {'periods': annual}, 'FR': {'periods': fr}}})
    output = {'periods': [{'key': 'old'}, {'key': 'new'}], 'unit_label': '百万円'}
    return append_model_series(ds, output, factor)


def test_model_money_scales_to_requested_unit_and_ratios_and_days_do_not():
    model = chart()
    assert model['FCF']['nopat']['values'] == [Decimal('2.500125'), None]
    assert model['FCF']['trade_receivables']['values'] == [Decimal(1), Decimal(0)]
    assert model['ROIC']['roic']['values'] == [Decimal('.125'), None]
    assert model['生産指標']['receivables_days']['values'][0] == Decimal('45.25')
    assert model['安全指標']['liquidity_months']['values'][0] == Decimal('2.5')
    assert model['FCF']['nopat']['reasons'][1] == ['法人税入力なし']
    assert chart(factor=Decimal(1))['FCF']['nopat']['values'][0] == Decimal('2500125')


def test_all_requested_groups_and_default_fcf_choices():
    model = chart()
    assert tuple(MODEL_VIEWS) == ('ROIC', 'バリュードライバー', '安全指標', '生産指標', 'FCF')
    assert [len(VIEW_KEYS[group]) for group in MODEL_VIEWS] == [4, 6, 3, 5, 8]
    assert set(DEFAULT_KEYS['FCF']) == {'nopat', 'noncash', 'working_capital_change', 'capex', 'fcf'}
    assert next(s for s in series_for_view(model, 'FCF') if s.key == 'fcf').style == 'bar'
    assert not {'inventory', 'trade_receivables', 'trade_payables'} & {s.key for s in series_for_view(model, 'FCF')}


def test_heterogeneous_model_axes_use_their_actual_units():
    model = chart()
    production = series_for_view(model, '生産指標')
    assert axis_label(production, 'left', '百万円') == '期間（日）'
    assert axis_label(production, 'right', '百万円') == '回転（倍）'
    safety = series_for_view(model, '安全指標')
    assert axis_label(safety, 'left', '百万円') == '比率（%）'
    assert axis_label(safety, 'right', '百万円') == '月数（か月）'
    assert format_value(Decimal('2.5'), kind='multiple') == '2.50 倍'
    assert format_value(Decimal('2.5'), kind='months') == '2.50 か月'
    assert format_value(Decimal('45.25'), kind='days') == '45.25 日'


@pytest.mark.parametrize('raw', ['NaN', 'Infinity', 'bad'])
def test_corrupt_saved_model_value_is_rejected_not_drawn(raw):
    ds = SimpleNamespace(export_metadata={'format_version': 6, 'unit': 'thousand', 'supplemental': {
        'DCF': {'periods': {'old': {'fcf': {'display_value': raw}}}}}})
    with pytest.raises(ValueError):
        append_model_series(ds, {'periods': [{'key': 'old'}]}, Decimal(1000))


def test_unknown_model_unit_is_rejected_for_money_instead_of_guessing():
    with pytest.raises(ValueError, match='単位'):
        chart(unit='unknown')


def test_formula_text_in_untrusted_saved_metadata_is_never_executed():
    ds = SimpleNamespace(export_metadata={'format_version': 6, 'unit': 'yen', 'supplemental': {
        'DCF': {'periods': {'old': {'fcf': {'display_value': None,
            'formula': '=EXECUTE("untrusted")', 'missing': ['入力なし']}}}}}})
    output = append_model_series(ds, {'periods': [{'key': 'old'}]}, Decimal(1))
    assert output['FCF']['fcf']['values'] == [None]
    assert output['FCF']['fcf']['reasons'] == [['入力なし']]


def test_previous_saved_noncash_definition_is_not_relabelled_as_current():
    ds = SimpleNamespace(export_metadata={'format_version': 5, 'unit': 'yen', 'supplemental': {
        'DCF': {'periods': {'old': {'noncash': {'display_value': '999'}}}}}})
    output = append_model_series(ds, {'periods': [{'key': 'old'}]}, Decimal(1))
    assert output['FCF']['noncash']['values'] == [None]
    assert '新版でExcelを再作成' in output['FCF']['noncash']['reasons'][0][0]
