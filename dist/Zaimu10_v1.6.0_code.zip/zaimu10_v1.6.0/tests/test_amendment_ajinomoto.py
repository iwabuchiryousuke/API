"""Real remuneration correction and strict counterexamples for unchanged metrics."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

from bs4 import BeautifulSoup
import pytest

from zaimu10.amendment import inspect_amendment

ROOT = Path(__file__).parent/'fixtures'/'ajinomoto_correction'
META = json.loads((ROOT/'manifest.json').read_text())
SAFE = {'nonfinancial_only', 'financial_notes_only', 'unchanged_financial_values'}


def pages():
    return [(f['filename'],(ROOT/f['file']).read_bytes().decode('utf-8'))for f in META['files']]


def edit(operation):
    original = pages(); name,markup = original[1]
    soup = BeautifulSoup(markup,'html.parser'); operation(soup)
    original[1] = name,str(soup)
    return original


def replace_cell(soup, before, after, *, final=True):
    cells=[c for c in soup.find_all(['td','th']) if c.get_text(' ',strip=True)==before]
    assert cells
    cell=cells[-1]if final else cells[0]
    cell.clear();cell.append(after)


def test_real_ajinomoto_role_and_personal_remuneration_is_proven_only_scope():
    result=inspect_amendment(pages())
    assert result['status']=='nonfinancial_only',result
    assert result['proof_complete']is True
    assert result['paired_table_counts']==[3]
    assert result['table_shapes_equal']is True
    assert len(result['changed_tables'])==2
    assert any(c['before']=='375'and c['after']=='389'for t in result['changed_tables']for c in t['changed_cells'])
    assert any(c['before']=='107'and c['after']=='121'for t in result['changed_tables']for c in t['changed_cells'])
    proof=result['invariant_remuneration_metric_tables']
    assert len(proof)==1 and proof[0]['all_cells_unchanged']is True
    assert proof[0]['rows'][1:]==[['1','売上高','11,493億円'],['2','事業利益','1,209億円'],['3','親会社の所有者に帰属する当期利益','757億円']]
    assert result['outside_table_prose_changes']
    assert result['analysis_inputs_affected']is False
    assert result['evidence']==[dict(filename=f['filename'],sha256=f['sha256'])for f in META['files']]


@pytest.mark.parametrize('label,value',[
    ('11,493億円','11,494億円'),('1,209億円','1,210億円'),('757億円','758億円'),
    ('売上高','売上収益'),('当期の実績','前期の実績'),
])
def test_financial_metric_changes_cannot_hide_in_compensation_scope(label,value):
    result=inspect_amendment(edit(lambda s:replace_cell(s,label,value)))
    assert result['status']not in SAFE,result


def test_new_schema_names_are_not_company_or_officer_specific():
    original=pages()
    original=[(name,markup.replace('グイネット','検証').replace('ボンパス','役員').replace('味の素','検証会社'))for name,markup in original]
    assert inspect_amendment(original)['status']=='nonfinancial_only'


def test_uncertified_officer_in_changed_benefit_prose_is_rejected():
    original=pages();name,markup=original[1]
    # Only the explanatory sentence is changed, not the certified named table.
    markup=markup.replace('グイネット ボンパス氏','無関係者氏')
    assert markup!=original[1][1]
    original[1]=name,markup
    assert inspect_amendment(original)['status']not in SAFE


@pytest.mark.parametrize('replacement',[
    '営業利益', '日本に在住中の家賃100万円', '借入金利息', '未分類の給付',
])
def test_changed_prose_cannot_add_financial_claims_amounts_or_unknown_benefits(replacement):
    original=pages();name,markup=original[1]
    assert '日本に在住中の家賃' in markup
    original[1]=name,markup.replace('日本に在住中の家賃',replacement)
    assert inspect_amendment(original)['status']not in SAFE


@pytest.mark.parametrize('fragment',[
    '<p>売上高を100から101に訂正します。</p>',
    '<table><tr><td>資産合計</td><td>100</td></tr></table>',
    '<p>【連結損益計算書】</p>',
    '<p><ix:nonFraction name="jppfs_cor:NetSales" contextRef="CurrentYearDuration">999</ix:nonFraction></p>',
])
def test_extra_financial_changes_do_not_borrow_supported_remuneration_scope(fragment):
    result=inspect_amendment(edit(lambda s:s.body.append(BeautifulSoup(fragment,'html.parser'))))
    assert result['status']not in SAFE,result


def test_unknown_officer_role_or_year_or_units_are_rejected():
    for old,new in [('執行役','売上高'),('百万円','千円'),('2021年','2020年')]:
        original=pages();name,markup=original[1]
        # Change only the last occurrence (after), retaining genuine old text.
        head,sep,tail=markup.rpartition(old)
        assert sep
        original[1]=name,head+new+tail
        assert inspect_amendment(original)['status']not in SAFE,(old,new)


def test_identically_broken_merged_headers_are_not_positive_compensation_schema():
    def change(soup):
        for table in [soup.find_all('table')[0],soup.find_all('table')[3]]:
            cell=table.find('tr').find_all(['td','th'],recursive=False)[2]
            assert cell.get('colspan')=='3';cell['colspan']='2'
    assert inspect_amendment(edit(change))['status']not in SAFE


def test_public_source_fixture_identity_and_hashes_are_retained():
    for f in META['files']:
        assert sha256((ROOT/f['file']).read_bytes()).hexdigest()==f['sha256']


def test_tsr_indicator_schema_does_not_allow_numeric_financial_performance_changes():
    root=Path(__file__).parent/'fixtures'/'chugai_corrections'
    meta=next(e for e in json.loads((root/'manifest.json').read_text())if e['doc_id']=='S100TB9F')
    original=[(f['filename'],(root/f['path']).read_bytes().decode('utf-8'))for f in meta['files']]
    name,markup=original[-1];soup=BeautifulSoup(markup,'html.parser')
    # Remove displayed units consistently, so both changed values are purely
    # numeric. A TSR-labelled table still cannot authorize the profit change.
    cells=[c for c in soup.find_all(['td','th'])if c.get_text(' ',strip=True)=='4,507億円']
    assert len(cells)==2
    cells[0].clear();cells[0].append('4507')
    cells[1].clear();cells[1].append('4508')
    original[-1]=name,str(soup)
    result=inspect_amendment(original)
    assert result['status']not in SAFE,result
