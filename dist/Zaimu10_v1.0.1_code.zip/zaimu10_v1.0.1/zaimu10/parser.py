"""Parse the *original* EDINET inline-XBRL statement tables.

This module deliberately does not perform fuzzy label matching. Standard EDINET
concepts retain their stable vocabulary/local name across taxonomy releases;
company extension concepts retain their complete namespace URI. Context members,
statement and beginning/end roles also form part of every monetary row identity.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
import html as html_std
import json
import re
import unicodedata

from lxml import etree, html

from .models import Cell, Dataset, Filing, Period, Row, Source


class ParseError(ValueError):
    """The filing cannot be interpreted without guessing financial facts."""


@dataclass(frozen=True)
class Context:
    id: str
    start: date | None
    end: date
    instant: bool
    dimensions: tuple[tuple[str, str], ...] = ()
    basis: str | None = None


@dataclass
class Page:
    filename: str
    root: etree._Element
    namespaces: dict[str, str]


def _local(tag: str) -> str:
    return tag.rsplit('}', 1)[-1].rsplit(':', 1)[-1].lower()


def _elements(element: etree._Element, name: str):
    return (e for e in element.iter() if isinstance(e.tag, str) and _local(e.tag) == name.lower())


def _text(element: etree._Element) -> str:
    # Joining without inserting spaces preserves Japanese labels split over spans.
    # Source formatting whitespace is collapsed only; words/punctuation remain.
    text = ''.join(element.itertext())
    return re.sub(r'\s+', ' ', text.replace('\xa0', ' ')).strip()


def _compact(element: etree._Element) -> str:
    return re.sub(r'\s+', '', _text(element))


def _namespaces(markup: str) -> dict[str, str]:
    return {m.group(1): html_std.unescape(m.group(3)) for m in re.finditer(r'xmlns:([\w.-]+)\s*=\s*([\'"])(.*?)\2', markup, re.S)}


def _expanded(qname: str, namespaces: dict[str, str]) -> str:
    if qname.startswith('{'):
        return qname
    if ':' not in qname:
        raise ParseError(f'名前空間のないXBRL識別子: {qname}')
    prefix, local = qname.split(':', 1)
    uri = namespaces.get(prefix)
    if uri is None:
        # EDINET's public HTML viewer lowercases xmlns attribute names while
        # retaining QName attribute values. Resolve that HTML case folding only
        # when it identifies one unambiguous URI; concept local names stay exact.
        choices = {value for key, value in namespaces.items() if key.casefold() == prefix.casefold()}
        if len(choices) != 1:
            raise ParseError(f'名前空間が見つかりません: {qname}')
        uri = choices.pop()
    return '{' + uri + '}' + local


def concept_identity(expanded_name: str) -> str:
    """Normalize only the release date of a known *standard* EDINET vocabulary.

    Extension namespaces, unfamiliar standard vocabularies and IFRS Foundation
    namespaces remain exact. The original QName always remains in Source.
    """
    if not expanded_name.startswith('{') or '}' not in expanded_name:
        return expanded_name
    uri, local = expanded_name[1:].split('}', 1)
    match = re.fullmatch(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/(jppfs|jpigp|jpcrp|jpdei)/(\d{4}-\d{2}-\d{2})/(jppfs_cor|jpigp_cor|jpcrp_cor|jpdei_cor)', uri)
    if match and match.group(3) == match.group(1) + '_cor':
        return match.group(3) + ':' + local
    return expanded_name


def _parse_date(text: str) -> date:
    try:
        return date.fromisoformat(text.strip()[:10])
    except (TypeError, ValueError) as exc:
        raise ParseError(f'不正なXBRL日付: {text}') from exc


def _contexts(pages: list[Page]) -> dict[str, Context]:
    out: dict[str, Context] = {}
    for page in pages:
        for node in _elements(page.root, 'context'):
            cid = node.get('id', '')
            by_name = {_local(e.tag): _text(e) for e in node.iter() if isinstance(e.tag, str) and _local(e.tag) in {'startdate', 'enddate', 'instant'}}
            if not cid or not by_name:
                continue
            dims: list[tuple[str, str]] = []
            basis = None
            for member in _elements(node, 'explicitmember'):
                axis = concept_identity(_expanded(member.get('dimension', ''), page.namespaces))
                value = concept_identity(_expanded(_text(member), page.namespaces))
                if value.endswith(':NonConsolidatedMember') or value.endswith('}NonConsolidatedMember'):
                    basis = 'standalone'
                elif value.endswith(':ConsolidatedMember') or value.endswith('}ConsolidatedMember'):
                    basis = 'consolidated'
                else:
                    dims.append((axis, value))
            for member in _elements(node, 'typedmember'):
                axis = concept_identity(_expanded(member.get('dimension', ''), page.namespaces))
                # Exact serialized typed member; no semantic/label normalization.
                value = ''.join(etree.tostring(c, encoding='unicode', with_tail=False) for c in member)
                dims.append((axis, value))
            instant = 'instant' in by_name
            ctx = Context(cid, None if instant else _parse_date(by_name['startdate']), _parse_date(by_name['instant'] if instant else by_name['enddate']), instant, tuple(sorted(dims)), basis)
            if cid in out and out[cid] != ctx:
                raise ParseError(f'同じコンテキストIDに異なる定義があります: {cid}')
            out[cid] = ctx
    return out


def _units(pages: list[Page]) -> dict[str, str]:
    out: dict[str, str] = {}
    for page in pages:
        for node in _elements(page.root, 'unit'):
            uid = node.get('id', '')
            measures = []
            for measure in _elements(node, 'measure'):
                qname = _text(measure)
                expanded = _expanded(qname, page.namespaces)
                uri, name = expanded[1:].split('}', 1)
                measures.append(name if uri in {'http://www.xbrl.org/2003/iso4217', 'http://www.xbrl.org/2003/instance'} else expanded)
            if uid and measures:
                divide = any(True for _ in _elements(node, 'divide'))
                out[uid] = '/'.join(measures) if divide else '*'.join(measures)
    return out


def _number(fact: etree._Element) -> tuple[Decimal | None, bool, str]:
    """Decode iXBRL numeric transformations, sign and decimal scale exactly."""
    nil = fact.get('xsi:nil', fact.get('{http://www.w3.org/2001/XMLSchema-instance}nil', '')).lower() in {'true', '1'}
    raw = _text(fact)
    if nil:
        return None, True, raw
    fmt = fact.get('format', '').rsplit(':', 1)[-1].lower()
    text = unicodedata.normalize('NFKC', raw)
    if fmt in {'numdash', 'zerodash', 'fixed-zero', 'fixedzero'}:
        value = Decimal(0)
    else:
        if fmt and fmt not in {'numdotdecimal', 'num-dot-decimal', 'numcommadot', 'numdotdecimalin', 'numcommadecimal', 'num-comma-decimal', 'numspacecomma', 'numspacedot'}:
            raise ParseError(f'未対応の数値変換形式: {fact.get("format")} ({raw})')
        text = re.sub(r'\s+', '', text)
        negative = text.startswith(('△', '▲', '−', '－', '-')) or (text.startswith('(') and text.endswith(')'))
        text = text.lstrip('△▲−－-+').strip('()')
        if fmt in {'numcommadecimal', 'num-comma-decimal', 'numspacecomma'}:
            text = text.replace('.', '').replace(',', '.')
        else:
            text = text.replace(',', '')
        if not re.fullmatch(r'\d+(?:\.\d+)?', text):
            raise ParseError(f'数値を確定できません: {raw!r}')
        try:
            value = Decimal(text)
        except InvalidOperation as exc:
            raise ParseError(f'不正な数値: {raw}') from exc
        if negative:
            value = -value
    try:
        scale = int(fact.get('scale', '0'))
    except ValueError as exc:
        raise ParseError(f'不正なscale: {fact.get("scale")}') from exc
    if abs(scale) > 18:
        raise ParseError(f'過大なscale: {scale}')
    value *= Decimal(10) ** scale
    if fact.get('sign') == '-':
        value = -abs(value)
    return value, False, raw


# Only exact main-statement TextBlocks. Notes and comprehensive income alone
# are intentionally excluded. IFRS combined income/comprehensive tables are PL.
_STATEMENT_NAMES = {
    'ConsolidatedBalanceSheetTextBlock': ('BS', 'consolidated'),
    'BalanceSheetTextBlock': ('BS', 'standalone'),
    'ConsolidatedStatementOfFinancialPositionIFRSTextBlock': ('BS', 'consolidated'),
    'StatementOfFinancialPositionIFRSTextBlock': ('BS', 'standalone'),
    'ConsolidatedStatementOfIncomeTextBlock': ('PL', 'consolidated'),
    'StatementOfIncomeTextBlock': ('PL', 'standalone'),
    'ConsolidatedStatementOfProfitOrLossIFRSTextBlock': ('PL', 'consolidated'),
    'ConsolidatedStatementOfProfitOrLossAndOtherComprehensiveIncomeIFRSTextBlock': ('PL', 'consolidated'),
    'StatementOfProfitOrLossIFRSTextBlock': ('PL', 'standalone'),
    'ConsolidatedStatementOfCashFlowsTextBlock': ('CF', 'consolidated'),
    'StatementOfCashFlowsTextBlock': ('CF', 'standalone'),
    'ConsolidatedStatementOfCashFlowsIFRSTextBlock': ('CF', 'consolidated'),
    'StatementOfCashFlowsIFRSTextBlock': ('CF', 'standalone'),
    'ConsolidatedBalanceSheetUSGAAPTextBlock': ('BS', 'consolidated'),
    'ConsolidatedStatementOfIncomeUSGAAPTextBlock': ('PL', 'consolidated'),
    'ConsolidatedStatementOfCashFlowsUSGAAPTextBlock': ('CF', 'consolidated'),
}


def _blocks(pages: list[Page]):
    found = []
    for page in pages:
        for block in _elements(page.root, 'nonnumeric'):
            local = block.get('name', '').rsplit(':', 1)[-1]
            if local in _STATEMENT_NAMES:
                statement, basis = _STATEMENT_NAMES[local]
                # Exclude pure references with no rendered statement table.
                if block.xpath('.//table'):
                    found.append((page, block, statement, basis))
    return found


def _basis_matches(ctx: Context, basis: str) -> bool:
    return ctx.basis is None or ctx.basis == basis


def _periods(contexts: dict[str, Context], blocks, basis: str, filing: Filing) -> list[Period]:
    periods: set[Period] = set()
    for _, block, statement, _ in blocks:
        for fact in _elements(block, 'nonfraction'):
            ctx = contexts.get(fact.get('contextref', ''))
            if ctx and not ctx.instant and ctx.start and not ctx.dimensions and _basis_matches(ctx, basis):
                periods.add(Period(ctx.start, ctx.end))
    # A normal annual filing's BS/PL/CF cover current and comparative periods.
    # Summary-table contexts never enter this set because summaries are not blocks.
    if not periods:
        # Explicit metadata is a safe fallback for BS-only/unsupported reports.
        if filing.start and filing.end:
            periods.add(Period(filing.start, filing.end))
        for ctx in contexts.values():
            if ctx.id in {'CurrentYearDuration', 'Prior1YearDuration', 'CurrentYearDuration_NonConsolidatedMember', 'Prior1YearDuration_NonConsolidatedMember'} and ctx.start and _basis_matches(ctx, basis):
                periods.add(Period(ctx.start, ctx.end))
    return sorted(periods)


def _cells(row: etree._Element) -> list[etree._Element]:
    return [c for c in row if isinstance(c.tag, str) and _local(c.tag) in {'td', 'th'}]


def _facts(element: etree._Element):
    return list(_elements(element, 'nonfraction'))


def _grid(rows) -> dict[etree._Element, list[tuple[int, etree._Element]]]:
    """Resolve physical HTML columns, including colspan and rowspan.

    EDINET's common twelve-column statements place indentation in blank cells
    and colspan the remaining label area. Raw td indexes are therefore *not*
    fiscal columns and must never be used for period assignment.
    """
    result = {}
    occupied: dict[int, int] = {}
    for tr in rows:
        positions = []
        col = 0
        new_spans = {}
        for cell in _cells(tr):
            while occupied.get(col, 0) > 0:
                col += 1
            try:
                colspan = max(1, min(1000, int(cell.get('colspan', '1'))))
                rowspan = max(1, min(1000, int(cell.get('rowspan', '1'))))
            except ValueError as exc:
                raise ParseError('不正なHTMLセル結合指定があります。') from exc
            positions.append((col, cell))
            if rowspan > 1:
                for covered in range(col, col+colspan):
                    new_spans[covered] = rowspan-1
            col += colspan
        result[tr] = positions
        occupied = {c: n-1 for c, n in occupied.items() if n > 1}
        occupied.update(new_spans)
    return result




def _table_rows(block: etree._Element):
    for table in block.xpath('.//table'):
        # Financial tables are normally flat. Skip outer layout tables containing
        # nested tables, otherwise a row may be counted more than once.
        if table.xpath('.//table'):
            continue
        yield table, [r for r in table.xpath('.//tr') if r.getparent() is table or r.getparent().getparent() is table]


def _column_map(rows, contexts: dict[str, Context], periods: list[Period], statement: str, basis: str, grid=None) -> dict[int, Period]:
    grid = grid or _grid(rows)
    votes: dict[int, Counter] = defaultdict(Counter)
    for tr in rows:
        for index, cell in grid[tr]:
            for fact in _facts(cell):
                ctx = contexts.get(fact.get('contextref', ''))
                if not ctx or ctx.dimensions or not _basis_matches(ctx, basis):
                    continue
                for period in periods:
                    if (not ctx.instant and ctx.start == period.start and ctx.end == period.end) or (statement == 'BS' and ctx.instant and ctx.end == period.end):
                        votes[index][period] += 1
    result = {}
    for index, counter in votes.items():
        choices = counter.most_common()
        if len(choices) > 1 and choices[0][1] == choices[1][1]:
            raise ParseError(f'年度列を確定できません: 列{index+1}')
        result[index] = choices[0][0]
    return result


def _opening_columns(rows, grid, contexts: dict[str, Context], periods: list[Period], column_periods: dict[int, Period], basis: str) -> dict[int, str]:
    """Identify *explicit* IFRS transition/opening BS columns outside annual ends.

    The displayed transition date must equal the actual earliest duration start,
    and all column facts must be instants for its preceding day. No annual start
    date is invented, and unrecognized extra fiscal columns still fail parsing.
    """
    earliest_start = min(p.start for p in periods)
    unknown: dict[int, list[Context]] = defaultdict(list)
    for tr in rows:
        for col, cell in grid[tr]:
            if col in column_periods:
                continue
            for fact in _facts(cell):
                ctx = contexts.get(fact.get('contextref', ''))
                if ctx:
                    unknown[col].append(ctx)
    excluded = {}
    for col, candidates in unknown.items():
        if not all(c.instant and c.end == earliest_start-timedelta(days=1) and not c.dimensions and _basis_matches(c,basis) for c in candidates):
            continue
        for tr in rows:
            for start, cell in grid[tr]:
                end = start + int(cell.get('colspan', '1'))
                if not start <= col < end or _facts(cell):
                    continue
                header = unicodedata.normalize('NFKC', _text(cell))
                if '移行日' not in header and '期首' not in header:
                    continue
                dates = re.findall(r'(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日', header)
                if any(date(int(y),int(m),int(d)) == earliest_start for y,m,d in dates):
                    excluded[col] = header
                    break
            if col in excluded:
                break
    return excluded


def _indent(cell: etree._Element) -> int:
    displacement = 0.0
    for element in cell.iter():
        styles = element.get('style', '')
        amount = 0.0
        for match in re.finditer(r'(?:margin-left|padding-left|text-indent)\s*:\s*(-?[\d.]+)\s*(px|pt|mm)', styles):
            n = float(match.group(1))
            if match.group(2) == 'pt':
                n *= 4 / 3
            elif match.group(2) == 'mm':
                n *= 3.77953
            amount += n
        displacement = max(displacement, amount)
    return max(0, min(12, int(round(displacement / 17))))


def _total(label: str, row: etree._Element) -> bool:
    if label.endswith(('合計', '総額')) or label in {'売上総利益', '営業利益', '営業損失（△）', '経常利益', '当期純利益', '税金等調整前当期純利益', '親会社株主に帰属する当期純利益', '営業活動によるキャッシュ・フロー', '投資活動によるキャッシュ・フロー', '財務活動によるキャッシュ・フロー'}:
        return True
    # Original source uses top/bottom numeric-cell rules for subtotals.
    numeric_cells = [c for c in _cells(row) if _facts(c)]
    return any(re.search(r'border-(?:top|bottom)\s*:\s*[1-9]', c.get('style', '')) for c in numeric_cells)


def _bs_side(label: str, current: str) -> str:
    compact = re.sub(r'\s+', '', label)
    if compact in {'資産の部', '資産', '資産合計'}:
        return 'BS_A'
    if compact in {'負債の部', '負債', '負債及び純資産の部', '負債及び資本', '負債及び資本の部', '資本の部', '資本', '純資産の部', '純資産'}:
        return 'BS_LE'
    return current


def parse_filing(filing: Filing, pages: list[tuple[str, str]], basis: str = 'auto') -> Dataset:
    """Read one annual filing, including the actual comparative fiscal period.

    The cover/resources page **must** be supplied along with statement chapters.
    No remote requests are made here. Unsupported/unlabelled numeric facts raise
    ParseError; the caller can report a failed filing instead of producing a
    plausible-looking incomplete workbook.
    """
    if basis not in {'auto', 'consolidated', 'standalone'}:
        raise ValueError('basis must be auto, consolidated, or standalone')
    parsed: list[Page] = []
    for filename, markup in pages:
        if isinstance(markup, bytes):
            markup = markup.decode('utf-8-sig')
        if not markup.strip():
            continue
        try:
            root = html.fromstring(markup.lstrip('\ufeff').encode('utf-8'), parser=html.HTMLParser(encoding='utf-8', no_network=True))
        except (etree.ParserError, ValueError) as exc:
            raise ParseError(f'HTMLを読めません: {filename}') from exc
        parsed.append(Page(filename, root, _namespaces(markup)))
    contexts = _contexts(parsed)
    if not contexts:
        raise ParseError('XBRLコンテキストがありません。表紙・resourcesを含む原文が必要です。')
    units = _units(parsed)
    blocks = _blocks(parsed)
    if not blocks:
        raise ParseError('対応するBS・PL・CFの本表TextBlockがありません。')
    if basis == 'auto':
        basis = 'consolidated' if any(b[3] == 'consolidated' for b in blocks) else 'standalone'
    selected = [b for b in blocks if b[3] == basis]
    if not selected:
        raise ParseError(f'{basis}の財務諸表がありません。')
    periods = _periods(contexts, selected, basis, filing)
    if not periods:
        raise ParseError('本表の事業年度を確定できません。')
    company = filing.company
    code = filing.code
    for page in parsed:
        for node in _elements(page.root, 'nonnumeric'):
            name = node.get('name', '').rsplit(':', 1)[-1]
            if name == 'CompanyNameCoverPage' and not company:
                company = _text(node)
            elif name == 'SecurityCodeDEI' and not code:
                raw = _compact(node)
                code = raw[:-1] if len(raw) == 5 and raw.endswith('0') else raw
    dataset = Dataset(code, company, basis, periods)
    standards = {'IFRS' if 'IFRS' in block.get('name','') else 'US-GAAP' if 'USGAAP' in block.get('name','') else 'J-GAAP' for _,block,_,_ in selected}
    if len(standards) != 1:
        raise ParseError('同じ連結区分の本表に複数の会計基準があります。自動統合しません。')
    dataset.accounting_standard = standards.pop()
    dataset.source_notes = []
    indexes = {s: {} for s in dataset.rows}
    seen_block_types: Counter = Counter()
    for page, block, statement, _ in selected:
        if block.get('continuedat'):
            raise ParseError(f'{page.filename}: 本表TextBlockの継続参照（continuedAt）は未対応です。分割された原文を省略しないため出力を停止します。')
        if any(f.get('continuedat') for f in _facts(block)):
            raise ParseError(f'{page.filename}: 数値ファクトの継続参照は未対応です。')
        seen_block_types[statement] += 1
        bs_side = 'BS_A'
        section_stack: list[tuple[int, str]] = []
        headings_seen: Counter = Counter()
        expected_facts = set(_facts(block))
        handled_facts: set[etree._Element] = set()
        excluded_facts: set[etree._Element] = set()
        for table, rows in _table_rows(block):
            grid = _grid(rows)
            column_periods = _column_map(rows, contexts, periods, statement, basis, grid)
            opening_columns = _opening_columns(rows, grid, contexts, periods, column_periods, basis) if statement == 'BS' else {}
            for tr in rows:
                for col, cell in grid[tr]:
                    if col in opening_columns:
                        excluded_facts.update(_facts(cell))
            for col, header in opening_columns.items():
                dataset.source_notes.append(f'{filing.doc_id} {page.filename}: {header}（物理列{col+1}）は年度末以外の明示的な期首・IFRS移行BS列のため、年度末比較から除外。原文キャッシュに保存。')
            if not column_periods:
                if any(_facts(tr) for tr in rows):
                    raise ParseError(f'{page.filename}: 財務諸表の年度列を確定できません。')
                for tr in rows:
                    plain_cells = _cells(tr)
                    if len(plain_cells) >= 2 and _text(plain_cells[0]) and any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?', unicodedata.normalize('NFKC', _compact(c))) for c in plain_cells[1:]):
                        raise ParseError(f'{page.filename}: XBRLタグのない数値行: {_text(plain_cells[0])}')
                continue
            for tr in rows:
                cells = _cells(tr)
                if not cells:
                    continue
                positions = grid[tr]
                cell_lookup = dict(positions)
                facts_by_col = {i: _facts(c) for i, c in positions if _facts(c) and i not in opening_columns}
                label_positions = [(i,c) for i,c in positions if i not in column_periods and i not in opening_columns and not _facts(c) and _text(c)]
                label_parts = [_text(c) for _,c in label_positions if not re.fullmatch(r'※?\s*[\d０-９]+(?:[,、・，\s]+[\d０-９]+)*', _text(c))]
                label = ' '.join(p for p in label_parts if p).strip()
                if not label:
                    if facts_by_col:
                        raise ParseError(f'{page.filename}: 科目名のない数値行があります。')
                    continue
                # A row caption may be split into preceding cells; remove only
                # standalone note markers, never alter original account wording.
                label = re.sub(r'^※\s*\d+(?:[,、・]\d+)*\s*', '', label).strip()
                if statement == 'BS':
                    bs_side = _bs_side(label, bs_side)
                target = bs_side if statement == 'BS' else statement
                label_col, label_cell = label_positions[0] if label_positions else (0,cells[0])
                indent = _indent(label_cell) + min(12, label_col)
                if not facts_by_col:
                    # Unit/date/header rows are not accounting headings.
                    compact = re.sub(r'\s+', '', label)
                    if any(token in compact for token in ['単位：', '単位:', '会計年度', '事業年度']) or re.search(r'\d{4}年\d', unicodedata.normalize('NFKC', compact)):
                        continue
                    monetary_tokens = [_compact(cell_lookup[i]) for i in column_periods if i in cell_lookup]
                    # Numeric untagged rows cannot be silently omitted. Dashes
                    # in an otherwise untagged row remain unidentifiable too.
                    if any(re.fullmatch(r'[△▲−\-+（(]?[\d,]+(?:\.\d+)?[）)]?', unicodedata.normalize('NFKC', t)) for t in monetary_tokens if t):
                        raise ParseError(f'{page.filename}: XBRLタグのない数値行: {label}')
                    if any(monetary_tokens) and all(t in {'', '-', '－', '—', '―', '–', '−', 'ー'} for t in monetary_tokens):
                        # A source account with only untagged dashes has no
                        # proven XBRL identity. Retain its original name/blanks,
                        # scoped to this filing so it can never be guessed into
                        # another year's concept.
                        blank_key = json.dumps(['untagged-blank', filing.doc_id, page.filename, target, label, len(dataset.rows[target]), basis], ensure_ascii=False)
                        row = Row(blank_key, label, target, tuple(s for _, s in section_stack), indent)
                        for col, period in column_periods.items():
                            raw = _compact(cell_lookup[col]) if col in cell_lookup else ''
                            source = Source(filing.doc_id, page.filename, f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}', filing.submitted, '', '', 'JPY', '', label, raw, 0, basis)
                            row.values[period.key] = Cell(None, source, note='XBRL識別子のない原文ダッシュ行。他年度と統合しない。')
                        dataset.rows[target].append(row)
                        indexes[target][blank_key] = row
                    elif not any(monetary_tokens):
                        while section_stack and section_stack[-1][0] >= indent:
                            section_stack.pop()
                        section_stack.append((indent, label))
                        section = tuple(s for _, s in section_stack)
                        heading_key = json.dumps(['heading', target, section], ensure_ascii=False)
                        headings_seen[heading_key] += 1
                        if headings_seen[heading_key] > 1:
                            heading_key += ':' + str(headings_seen[heading_key])
                        if heading_key not in indexes[target]:
                            row = Row(heading_key, label, target, section, indent, is_heading=True)
                            dataset.rows[target].append(row)
                            indexes[target][heading_key] = row
                    continue
                while section_stack and section_stack[-1][0] >= indent:
                    section_stack.pop()
                section = tuple(s for _, s in section_stack)
                row_keys: list[str] = []
                for col, facts in facts_by_col.items():
                    for fact in facts:
                        cid = fact.get('contextref', '')
                        ctx = contexts.get(cid)
                        if ctx is None:
                            raise ParseError(f'{page.filename}: 未定義コンテキスト: {cid}')
                        if not _basis_matches(ctx, basis):
                            raise ParseError(f'{page.filename}: 本表に連結と個別が混在しています: {cid}')
                        period = column_periods.get(col)
                        if not period:
                            raise ParseError(f'{page.filename}: 年度列外に財務数値があります: {label}')
                        if ctx.instant:
                            if ctx.end == period.end:
                                instant_role = 'end'
                            elif ctx.end == period.start - timedelta(days=1):
                                instant_role = 'begin'
                            else:
                                raise ParseError(f'{page.filename}: 年度と一致しない時点: {label} ({ctx.end})')
                        else:
                            if ctx.start != period.start or ctx.end != period.end:
                                raise ParseError(f'{page.filename}: 年度と一致しない期間: {label}')
                            instant_role = 'duration'
                        expanded = _expanded(fact.get('name', ''), page.namespaces)
                        identity = concept_identity(expanded)
                        # Section headings are presentation labels, not concept
                        # identifiers. Stable standard concept+dimensions+role is
                        # sufficient; repeated exact facts are checked below.
                        value, nil, raw = _number(fact)
                        unitref = fact.get('unitref', '')
                        unit = units.get(unitref)
                        if not unit:
                            raise ParseError(f'{page.filename}: 未定義単位: {unitref}')
                        key = json.dumps([target, identity, ctx.dimensions, instant_role, unit, basis], ensure_ascii=False)
                        source = Source(filing.doc_id, page.filename, f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{filing.doc_id}', filing.submitted, cid, expanded, unit, fact.get('decimals', ''), label, raw, int(fact.get('scale', '0')), basis)
                        row = indexes[target].get(key)
                        if row is None:
                            row = Row(key, label, target, section, indent, _total(label, tr), label_period=period.key)
                            dataset.rows[target].append(row)
                            indexes[target][key] = row
                        if period.key in row.values:
                            old = row.values[period.key]
                            if old.value != value or old.nil != nil:
                                raise ParseError(f'{page.filename}: 同一科目・年度の数値が重複して不一致: {label}')
                        else:
                            row.values[period.key] = Cell(value, source, nil)
                        if period.key >= row.label_period:
                            row.label = label
                            row.label_period = period.key
                        row_keys.append(key)
                        handled_facts.add(fact)
                # Untagged source dash in one year is explicitly retained as
                # empty, but cannot establish identity across changed concepts.
                unique_keys = set(row_keys)
                for col, period in column_periods.items():
                    if col not in cell_lookup or col in facts_by_col:
                        continue
                    raw = _compact(cell_lookup[col])
                    if raw not in {'', '-', '－', '—', '―', '–', '−', 'ー'}:
                        # Check every fiscal cell even if this source row uses
                        # different concepts in different years. Ambiguity must
                        # never cause an untagged numeric cell to disappear.
                        raise ParseError(f'{page.filename}: XBRLタグのない値: {label}: {raw}')
                    if len(unique_keys) == 1:
                        row = indexes[target][next(iter(unique_keys))]
                        if period.key in row.values:
                            continue
                        proto = next(iter(row.values.values())).source
                        source = Source(filing.doc_id, page.filename, proto.url, filing.submitted, '', proto.concept, proto.unit, '', label, raw, 0, basis)
                        row.values[period.key] = Cell(None, source, note='原文空欄・ダッシュ（ゼロに置換しない）')
        unexplained = expected_facts - handled_facts - excluded_facts
        if unexplained:
            first = next(iter(unexplained))
            raise ParseError(f'{page.filename}: 本表のXBRLファクト{len(unexplained)}件を科目行に対応付けられません（入れ子表等）: {first.get("name","")} / {first.get("contextref","")}')
    for statement in ['BS', 'PL', 'CF']:
        if not seen_block_types[statement]:
            dataset.warnings.append(f'{filing.doc_id}: {basis}の{statement}本表がありません。')
    # Do not include an empty comparative fiscal period inferred from unrelated
    # contexts. At least one selected main-statement fact must support each.
    dataset.periods = [p for p in periods if any(p.key in r.values for rs in dataset.rows.values() for r in rs)]
    dataset.period_bases = {p.key: basis for p in dataset.periods}
    dataset.period_standards = {p.key: dataset.accounting_standard for p in dataset.periods}
    dataset.source_notes = list(dict.fromkeys(dataset.source_notes))
    return dataset
