from copy import deepcopy
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
import gzip
import json
from pathlib import Path
import threading

import pytest
import requests

from zaimu10 import market
from zaimu10.market import MarketDataError

FIXTURES=Path(__file__).parent/'fixtures'/'market'
JST=timezone(timedelta(hours=9))


def timestamp(day):return int(datetime.fromisoformat(day+'T09:00:00+09:00').timestamp())


def response(symbol='6947.T',*,days=None,splits=None):
    days=days or [('2024-05-31',100,95),('2024-06-26',101,96),('2024-06-28',102,97),
                  ('2024-07-31',110,104)]
    return {'chart':{'error':None,'result':[dict(meta=dict(symbol=symbol,currency='JPY',
        instrumentType='INDEX' if symbol=='^N225' else 'EQUITY',exchangeTimezoneName='Asia/Tokyo'),
        timestamp=[timestamp(d[0]) for d in days],indicators=dict(quote=[dict(close=[d[1] for d in days],
            volume=[0 if symbol=='^N225' else 1000 for d in days])],
        adjclose=[dict(adjclose=[d[2] for d in days])]),events=dict(splits=splits or {}))]}}


@pytest.fixture(autouse=True)
def today(monkeypatch):
    monkeypatch.setattr(market,'_today',lambda:date(2026,11,20))


def fixture(name):return gzip.decompress((FIXTURES/name).read_bytes())


def test_real_stock_close_is_separate_from_dividend_adjusted_price_and_split_events():
    data=market.parse_yahoo_daily(fixture('7826_selected_daily.json.gz'),'7826.T')
    monthly=market.monthly_rows(data['daily_rows'],start_month='2024-05',end_month='2024-12')
    december=next(row for row in monthly if row['month']=='2024-12')
    assert december['date']=='2024-12-30' and Decimal(december['close'])==3625
    assert Decimal(december['adjclose'])!=Decimal(december['close'])
    assert [(e['date'],e['ratio']) for e in data['events']['splits']]==[
        ('2010-03-29','2:1'),('2024-06-27','3:1')]


def test_actual_last_trading_day_and_full_precision_match_original_reference_inputs():
    stock=market.parse_yahoo_daily(fixture('6947_selected_daily.json.gz'),'6947.T')
    index=market.parse_yahoo_daily(fixture('n225_selected_daily.json.gz'),'^N225')
    s=market.monthly_rows(stock['daily_rows'],start_month='2024-08',end_month='2024-08')[0]
    n=market.monthly_rows(index['daily_rows'],start_month='2024-08',end_month='2024-08')[0]
    assert s['date']==n['date']=='2024-08-30'  # 8/31 is Saturday, not invented.
    assert Decimal(s['close'])==3495 and int(Decimal(n['close']))==38647
    assert Decimal(n['close'])!=38647  # CAPM applies explicit TRUNC separately.


@pytest.mark.parametrize('change',['symbol','currency','timezone','instrument','length','negative','nan','split'])
def test_wrong_identity_or_invalid_price_or_action_is_explicit_failure(change):
    body=response();raw=body['chart']['result'][0]
    if change=='symbol':raw['meta']['symbol']='7826.T'
    elif change=='currency':raw['meta']['currency']='USD'
    elif change=='timezone':raw['meta']['exchangeTimezoneName']='America/New_York'
    elif change=='instrument':raw['meta']['instrumentType']='ETF'
    elif change=='length':raw['indicators']['quote'][0]['close'].pop()
    elif change=='negative':raw['indicators']['quote'][0]['close'][0]=-1
    elif change=='nan':raw['indicators']['quote'][0]['close'][0]=float('nan')
    else:raw['events']['splits']={'x':dict(date=timestamp('2024-06-27'),numerator=3,denominator=0)}
    with pytest.raises(MarketDataError):market.parse_yahoo_daily(body,'6947.T')


def test_null_daily_candles_do_not_become_zero_or_forward_filled_months():
    body=response(days=[('2024-05-31',100,95),('2024-06-28',None,None),('2024-07-31',110,104)])
    data=market.parse_yahoo_daily(body,'6947.T')
    rows=market.monthly_rows(data['daily_rows'],start_month='2024-05',end_month='2024-07')
    assert [r['month'] for r in rows]==['2024-05','2024-07']


def fake_japan(monkeypatch,daily_rows,quotes=None):
    def load(code,*,timeframe,start,end,**kwargs):
        rows=[]
        for item in daily_rows:
            nominal,adjusted=(quotes or {}).get(item['date'],(item['close'],item['close']))
            rows.append(dict(date=item['date'],month=item['date'][:7],close_nominal=str(nominal),
                             close_adjusted=str(adjusted),source_url='https://finance.yahoo.co.jp/quote/'+code+'.T/history',source_row=2))
        if timeframe=='m':
            groups={}
            for item in rows:groups[item['month']]=item
            rows=[item for month,item in sorted(groups.items())if start<=month<=end]
        else:rows=[row for row in rows if row['date']<=end]
        return dict(rows=rows,checked_at='2026-11-20T10:00:00+09:00',stale=False,warnings=[],
                    source=dict(provider='YahooJapan',source_url='https://finance.yahoo.co.jp/',sha256='public_fixture'))
    monkeypatch.setattr(market,'_load_japan',load)


def seed(monkeypatch,tmp_path,symbol='6947.T',*,days=None,splits=None,japan_quotes=None):
    body=response(symbol,days=days,splits=splits)
    monkeypatch.setattr(market,'_request',lambda *a,**k:json.dumps(body).encode())
    result=market._load_series(symbol,start_month='2024-05',cache_dir=tmp_path,offline=False,
        refresh=True,cancel=None,log=lambda _:None)
    fake_japan(monkeypatch,result['data']['daily_rows'],japan_quotes)
    return result


def test_offline_cache_is_verified_and_network_never_runs(monkeypatch,tmp_path):
    saved=seed(monkeypatch,tmp_path)
    def unexpected(*args,**kwargs):raise AssertionError('no network in offline mode')
    monkeypatch.setattr(market,'_request',unexpected)
    loaded=market._load_series('6947.T',start_month='2024-05',cache_dir=tmp_path,offline=True,
        refresh=False,cancel=None,log=lambda _:None)
    assert loaded['data']==saved['data'] and loaded['offline'] is True


def test_corrupt_cache_is_preserved_not_silently_reset(monkeypatch,tmp_path):
    seed(monkeypatch,tmp_path);path=market._cache_path(tmp_path,'6947.T')
    content=path.read_text();payload=json.loads(content)
    payload['data']['daily_rows'][0]['close']='9999';path.write_text(json.dumps(payload))
    before=path.read_bytes()
    with pytest.raises(MarketDataError,match='キャッシュ'):
        market._load_series('6947.T',start_month='2024-05',cache_dir=tmp_path,offline=True,
            refresh=False,cancel=None,log=lambda _:None)
    assert path.read_bytes()==before


def test_failed_refresh_preserves_verified_prices_raw_evidence_and_timestamp(monkeypatch,tmp_path):
    saved=seed(monkeypatch,tmp_path);path=market._cache_path(tmp_path,'6947.T');before=path.read_bytes()
    def fail(*args,**kwargs):raise MarketDataError('HTTP 503')
    monkeypatch.setattr(market,'_request',fail)
    result=market._load_series('6947.T',start_month='2024-05',cache_dir=tmp_path,offline=False,
        refresh=True,cancel=None,log=lambda _:None)
    assert result['stale'] and result['checked_at']==saved['checked_at']
    assert result['data']==saved['data'] and '更新失敗' in result['warnings'][0]
    assert path.read_bytes()==before


def test_monthly_api_excludes_current_partial_month_and_reports_missing_months(monkeypatch,tmp_path):
    def request(session,url,**kwargs):
        symbol='^N225' if '%5E' in url else '6947.T'
        return json.dumps(response(symbol,days=[('2026-09-30',100,95),('2026-10-30',110,104),
                                                ('2026-11-19',115,109)])).encode()
    monkeypatch.setattr(market,'_request',request)
    fake_japan(monkeypatch,[dict(date=d,close=str(c))for d,c in [('2026-09-30',100),('2026-10-30',110),('2026-11-19',115)]])
    result=market.load_capm_market('6947',start_month='2026-08',end_month='2026-10',cache_dir=tmp_path,log=lambda _:None)
    assert [r['month'] for r in result['stock_rows']]==['2026-09','2026-10']
    assert result['coverage']['missing_stock_months']==['2026-08']
    assert result['benchmark']=='^N225' and '日経' in result['benchmark_name']
    with pytest.raises(MarketDataError,match='完了した月'):
        market.load_capm_market('6947',start_month='2026-10',end_month='2026-11',cache_dir=tmp_path)


def test_domestic_nominal_fiscal_price_is_used_directly_without_global_price_reconstruction(monkeypatch,tmp_path):
    splits={'a':dict(date=timestamp('2024-06-27'),numerator=3,denominator=1,splitRatio='3:1')}
    seed(monkeypatch,tmp_path,splits=splits,japan_quotes={'2024-05-31':('300','100')})
    result=market.load_fiscal_prices('6947',[date(2024,5,31),'2024-06-30'],cache_dir=tmp_path,offline=True)
    before=result['prices']['2024-05-31'];after=result['prices']['2024-06-30']
    assert before['historical_close_jpy']=='300' and before['split_adjusted_close']=='100'
    assert after['historical_close_jpy']=='102' and after['trading_date']=='2024-06-28'
    assert before['split_factor_after_fiscal_date']=='3' and after['split_factor_after_fiscal_date']=='1'


def test_market_exrights_event_does_not_guess_legal_share_basis(monkeypatch,tmp_path):
    splits={'a':dict(date=timestamp('2024-06-29'),numerator=3,denominator=1,splitRatio='3:1')}
    seed(monkeypatch,tmp_path,splits=splits,japan_quotes={'2024-06-28':('306','102')})
    result=market.load_fiscal_prices('6947',['2024-06-30'],cache_dir=tmp_path,offline=True)
    item=result['prices']['2024-06-30']
    assert item['trading_date']=='2024-06-28'
    assert item['historical_close_jpy']=='306'
    assert item['share_basis_state']=='nominal_quote_at_trading_date'
    assert item['stock_split_events'][0]['date']=='2024-06-29'


def test_split_after_capm_end_is_still_kept_for_correct_historical_share_basis(monkeypatch,tmp_path):
    splits={'a':dict(date=timestamp('2025-09-29'),numerator=5,denominator=1,splitRatio='5:1')}
    seed(monkeypatch,tmp_path,splits=splits,japan_quotes={'2024-05-31':('500','100')})
    result=market.load_fiscal_prices('6947',['2024-05-31'],cache_dir=tmp_path,offline=True)
    assert result['prices']['2024-05-31']['historical_close_jpy']=='500'
    assert result['prices']['2024-05-31']['subsequent_splits'][0]['date']=='2025-09-29'


def test_stale_or_absent_trading_quote_never_fabricates_fiscal_price(monkeypatch,tmp_path):
    seed(monkeypatch,tmp_path)
    result=market.load_fiscal_prices('6947',['2024-08-31'],cache_dir=tmp_path,offline=True)
    assert result['prices']['2024-08-31']['available'] is False


def test_cancellation_prevents_network_or_cache_mutation(tmp_path):
    cancel=threading.Event();cancel.set()
    with pytest.raises(InterruptedError):
        market.load_capm_market('6947',start_month='2024-01',end_month='2024-12',cache_dir=tmp_path,cancel=cancel)
    assert not (tmp_path/'market').exists()


def test_http_retry_honors_long_retry_after_without_early_retry(monkeypatch):
    monkeypatch.setattr(market.edinet,'_pause',lambda *args:None)
    class Session:
        calls=0
        def get(self,*args,**kwargs):
            self.calls+=1
            assert kwargs['allow_redirects'] is False and kwargs['timeout']==(5,15)
            class Response:
                status_code=429;headers={'Retry-After':'60'}
            return Response()
    session=Session()
    with pytest.raises(MarketDataError,match='待機指定'):market._request(session,'https://query1.finance.yahoo.com/')
    assert session.calls==1


def test_real_domestic_prices_resolve_the_known_global_provider_conflict():
    daily=market.parse_yahoo_japan_history((FIXTURES/'6947_japan_d.html').read_bytes(),'6947',timeframe='d')
    monthly=market.parse_yahoo_japan_history((FIXTURES/'6947_japan_m.html').read_bytes(),'6947',timeframe='m')
    assert next(row for row in daily if row['date']=='2024-03-29')['close_nominal']=='4505'
    assert next(row for row in monthly if row['month']=='2024-03')['close_adjusted']=='4505'
    # Global historical feeds returned 4485 for that date. Do not silently
    # replace the domestic public closing print with that conflicting field.
    assert next(row for row in daily if row['date']=='2024-03-29')['close_nominal']!='4485'


def test_real_domestic_nominal_and_split_adjusted_prices_are_not_interchanged():
    daily=market.parse_yahoo_japan_history((FIXTURES/'7826_japan_d.html').read_bytes(),'7826',timeframe='d')
    before=next(row for row in daily if row['date']=='2024-06-26')
    after=next(row for row in daily if row['date']=='2024-06-28')
    assert before['close_nominal']=='13270' and before['close_adjusted']=='4423.33'
    assert after['close_nominal']==after['close_adjusted']=='4370'
    assert len(daily)==5  # Printed split announcement is not a price candle.


def test_domestic_history_rejects_wrong_company_and_unrecognized_table():
    raw=(FIXTURES/'6947_japan_m.html').read_bytes()
    with pytest.raises(MarketDataError):market.parse_yahoo_japan_history(raw,'7826',timeframe='m')
    with pytest.raises(MarketDataError):market.parse_yahoo_japan_history(b'<title>6947</title><table><tr><td>advertisement</td></tr></table>','6947',timeframe='m')


def domestic_html(months):
    headings=['日付','始値','高値','安値','終値','出来高','調整後 終値','PER','PBR']
    header='<tr>'+''.join('<th>'+value+'</th>' for value in headings)+'</tr>'
    rows=''.join('<tr><th>'+month.replace('-','/')+'</th>'+''.join('<td>'+v+'</td>' for v in ['100','101','99','100','10000','100','VIP','VIP'])+'</tr>' for month in months)
    return ('<html><title>図研 6947 Yahoo Japan</title><script>ANONYMOUS_TOKEN_SHOULD_NOT_BE_STORED</script>'
            '<input name="token" value="PRIVATE"><table>'+header+rows+'</table></html>').encode()


def test_domestic_pagination_and_cache_keep_public_prices_without_tokens_or_paid_fields(monkeypatch,tmp_path):
    months=list(reversed(market._months('2024-01','2025-11')));calls=[]
    def request(session,url,**kwargs):
        calls.append(url)
        return domestic_html(months[20:] if 'page=2' in url else months[:20])
    monkeypatch.setattr(market,'_request',request)
    saved=market._load_japan('6947',timeframe='m',start='2024-01',end='2025-11',cache_dir=tmp_path,
        offline=False,refresh=False,cancel=None,log=lambda _:None)
    assert len(saved['rows'])==23 and len(calls)==2
    raw=(tmp_path/'market'/saved['source']['raw_path']).read_text()
    assert 'TOKEN' not in raw and 'PRIVATE' not in raw and '<script' not in raw and 'VIP' not in raw
    monkeypatch.setattr(market,'_request',lambda *a,**k:(_ for _ in()).throw(AssertionError('offline network')))
    loaded=market._load_japan('6947',timeframe='m',start='2024-01',end='2025-11',cache_dir=tmp_path,
        offline=True,refresh=False,cancel=None,log=lambda _:None)
    assert loaded['rows']==saved['rows']


def test_domestic_stalled_pagination_is_failure_not_partial_success(monkeypatch,tmp_path):
    rows=list(reversed(market._months('2024-04','2025-11')))
    monkeypatch.setattr(market,'_request',lambda *a,**k:domestic_html(rows))
    with pytest.raises(MarketDataError,match='先へ進まない'):
        market._load_japan('6947',timeframe='m',start='2024-01',end='2025-11',cache_dir=tmp_path,
            offline=False,refresh=False,cancel=None,log=lambda _:None)
    assert not market._japan_cache(tmp_path,'6947','monthly').exists()


def test_legacy_global_cache_is_not_silently_used_as_domestic_price_source(monkeypatch,tmp_path):
    def request(session,url,**kwargs):
        symbol='^N225' if '%5E' in url else '6947.T'
        return json.dumps(response(symbol)).encode()
    monkeypatch.setattr(market,'_request',request)
    for symbol in ['6947.T','^N225']:
        market._load_series(symbol,start_month='2024-05',cache_dir=tmp_path,offline=False,
            refresh=True,cancel=None,log=lambda _:None)
    with pytest.raises(MarketDataError,match='保存されていません|保存データ'):
        market.load_capm_market('6947',start_month='2024-05',end_month='2024-07',cache_dir=tmp_path,offline=True)


def test_one_fiscal_quote_failure_preserves_other_years_and_cancellation_is_not_swallowed(monkeypatch,tmp_path):
    seed(monkeypatch,tmp_path);normal=market._load_japan
    def fail_one(code,**kwargs):
        if kwargs['end']=='2024-06-30':raise MarketDataError('その期末価格だけ取得失敗')
        return normal(code,**kwargs)
    monkeypatch.setattr(market,'_load_japan',fail_one)
    result=market.load_fiscal_prices('6947',['2024-05-31','2024-06-30','2024-07-31'],cache_dir=tmp_path,offline=True)
    assert result['prices']['2024-05-31']['available'] is True
    assert result['prices']['2024-06-30']['available'] is False
    assert result['prices']['2024-07-31']['available'] is True
    def cancelled(*args,**kwargs):raise InterruptedError('cancel')
    monkeypatch.setattr(market,'_load_japan',cancelled)
    with pytest.raises(InterruptedError):market.load_fiscal_prices('6947',['2024-05-31'],cache_dir=tmp_path,offline=True)


def test_domestic_close_wins_provider_conflict_with_both_sources_recorded(monkeypatch,tmp_path):
    def request(session,url,**kwargs):
        symbol='^N225' if '%5E' in url else '6947.T'
        return json.dumps(response(symbol,days=[('2024-03-29',4485,4132)])).encode()
    monkeypatch.setattr(market,'_request',request)
    fake_japan(monkeypatch,[dict(date='2024-03-29',close='4485')],{'2024-03-29':('4505','4505')})
    result=market.load_capm_market('6947',start_month='2024-03',end_month='2024-03',cache_dir=tmp_path,log=lambda _:None)
    assert result['stock_rows'][0]['close']=='4505'
    assert result['stock_rows'][0]['date']=='2024-03-29'
    assert result['source_provenance']['stock']['provider']=='YahooJapan'
    assert result['provider_conflicts'][0]['global_close']=='4485'
    assert result['provider_conflicts'][0]['difference_jpy']=='20'
    assert result['provider_conflicts'][0]['adopted']=='YahooJapan'


def test_domestic_invalid_cache_preserves_file_instead_of_falling_back_to_global(monkeypatch,tmp_path):
    monkeypatch.setattr(market,'_request',lambda *a,**k:domestic_html(['2024-05']))
    market._load_japan('6947',timeframe='m',start='2024-05',end='2024-05',cache_dir=tmp_path,
        offline=False,refresh=False,cancel=None,log=lambda _:None)
    path=market._japan_cache(tmp_path,'6947','monthly');payload=json.loads(path.read_text())
    payload['rows'][0]['close_nominal']='9999';path.write_text(json.dumps(payload))
    before=path.read_bytes()
    with pytest.raises(MarketDataError,match='国内株価キャッシュ'):
        market._load_japan('6947',timeframe='m',start='2024-05',end='2024-05',cache_dir=tmp_path,
            offline=True,refresh=False,cancel=None,log=lambda _:None)
    assert path.read_bytes()==before


def test_transient_http500_is_retried_with_bounded_attempts(monkeypatch):
    monkeypatch.setattr(market.edinet,'_pause',lambda *args:None)
    class Session:
        calls=0
        def get(self,*args,**kwargs):
            self.calls+=1
            class Response:
                status_code=500 if self.calls==1 else 200
                headers={};content=b'public price data'
            return Response()
    session=Session()
    assert market._request(session,'https://finance.yahoo.co.jp/')==b'public price data'
    assert session.calls==2


def test_equity_zero_volume_carry_days_are_preserved_as_exclusions_not_trading_dates():
    body=response(days=[('2018-12-28',100,95),('2018-12-31',100,95)])
    body['chart']['result'][0]['indicators']['quote'][0]['volume']=[1000,0]
    parsed=market.parse_yahoo_daily(body,'6947.T')
    rows=market.monthly_rows(parsed['daily_rows'],start_month='2018-12',end_month='2018-12')
    assert rows[0]['date']=='2018-12-28'
    assert parsed['excluded_nontrading_rows'][0]['date']=='2018-12-31'
    assert parsed['excluded_nontrading_rows'][0]['volume']=='0'


def test_index_zero_volume_is_a_valid_observation():
    data=market.parse_yahoo_daily(response('^N225',days=[('2018-12-28',20014,20014)]),'^N225')
    assert data['daily_rows'][0]['date']=='2018-12-28'
    assert data['daily_rows'][0]['volume']=='0'
    assert data['excluded_nontrading_rows']==[]


def test_legacy_calendar_is_migrated_from_verified_raw_sha_without_refetch(monkeypatch,tmp_path):
    body=response(days=[('2018-12-28',100,95),('2018-12-31',100,95)])
    body['chart']['result'][0]['indicators']['quote'][0]['volume']=[1000,0]
    monkeypatch.setattr(market,'_request',lambda *a,**k:json.dumps(body).encode())
    market._load_series('6947.T',start_month='2018-12',cache_dir=tmp_path,offline=False,refresh=True,cancel=None,log=lambda _:None)
    path=market._cache_path(tmp_path,'6947.T');saved=json.loads(path.read_text());sha=saved['source']['sha256']
    saved.pop('payload_sha256');saved['schema']=1
    saved['data']['daily_rows'].append(dict(date='2018-12-31',close='100',adjclose='95',source_timestamp=timestamp('2018-12-31')))
    saved['payload_sha256']=market._hash(saved);path.write_text(json.dumps(saved))
    monkeypatch.setattr(market,'_request',lambda *a,**k:(_ for _ in()).throw(AssertionError('migration must not fetch')))
    migrated=market._read(path,'6947.T')
    assert migrated['schema']==2 and migrated['source']['sha256']==sha
    assert [row['date'] for row in migrated['data']['daily_rows']]==['2018-12-28']
    assert json.loads(path.read_text())['schema']==2


def test_real_kabutan_published_monthly_prices_keep_advertised_precision_and_actual_dates():
    rows=market.parse_kabutan_monthly((FIXTURES/'4519_kabutan_selected.html').read_bytes(),'4519')
    by={row['month']:row for row in rows}
    assert by['2026-03']['date']=='2026-03-31' and by['2026-03']['close_adjusted']=='8611'
    assert by['2019-12']['close_adjusted']=='3359'  # Published provider value; not nominal/3.
    assert all(row['published_decimal_places']==0 for row in rows)


def test_real_96ut_nominal_daily_prices_and_split_announcement_are_separate():
    rows=market.parse_96ut_daily((FIXTURES/'4519_96ut_2020_selected.html').read_bytes(),'4519',2020)
    by={row['date']:row for row in rows}
    assert by['2020-12-30']['close_nominal']=='5503'
    assert len(rows)==3
    with pytest.raises(MarketDataError):market.parse_96ut_daily((FIXTURES/'4519_96ut_2020_selected.html').read_bytes(),'4519',2021)


def test_whole_beta_series_falls_back_to_one_disclosed_domestic_provider(monkeypatch,tmp_path):
    seed(monkeypatch,tmp_path)
    def unavailable(*args,**kwargs):raise MarketDataError('HTTP 500')
    monkeypatch.setattr(market,'_load_japan',unavailable)
    rows=[dict(month=m,date=d,close_adjusted=v,source_url='https://kabutan.jp/',source_row=2)
          for m,d,v in [('2024-05','2024-05-31','200'),('2024-06','2024-06-28','210'),('2024-07','2024-07-31','220')]]
    monkeypatch.setattr(market,'_load_kabutan_monthly',lambda *a,**k:dict(provider='Kabutan',rows=rows,
        checked_at='2026-11-20T10:00:00+09:00',warnings=[],stale=False,
        source=dict(provider='株探（Kabutan）',source_url='https://kabutan.jp/',sha256='public')))
    def request(session,url,**kwargs):return json.dumps(response('^N225' if '%5E' in url else '6947.T')).encode()
    monkeypatch.setattr(market,'_request',request)
    result=market.load_capm_market('6947',start_month='2024-05',end_month='2024-07',cache_dir=tmp_path,log=lambda _:None)
    assert [r['close'] for r in result['stock_rows']]==['200','210','220']
    assert {r['price_provider'] for r in result['stock_rows']}=={'株探（Kabutan）'}
    assert any('全月次系列' in warning for warning in result['warnings'])


def test_fiscal_domestic_fallback_preserves_nominal_prices_and_rejects_stale_last_day(monkeypatch,tmp_path):
    seed(monkeypatch,tmp_path)
    monkeypatch.setattr(market,'_load_japan',lambda *a,**k:(_ for _ in()).throw(MarketDataError('HTTP 500')))
    data=dict(provider='96UT',rows=[dict(date='2024-06-28',close_nominal='306',volume='100')],
              checked_at='2026-11-20T10:00:00+09:00',warnings=[],stale=False,
              source=dict(provider='96UT.com',source_url='https://96ut.com/',price_kind='nominal_unadjusted'))
    monkeypatch.setattr(market,'_load_96ut_year',lambda *a,**k:deepcopy(data))
    result=market.load_fiscal_prices('6947',['2024-06-30'],cache_dir=tmp_path,offline=True)
    assert result['prices']['2024-06-30']['historical_close_jpy']=='306'
    assert result['prices']['2024-06-30']['source']['provider']=='96UT.com'
    data['rows'][0]['date']='2024-06-26'
    result=market.load_fiscal_prices('6947',['2024-06-30'],cache_dir=tmp_path,offline=True)
    assert result['prices']['2024-06-30']['available'] is False
    assert '古い価格を代用しません' in result['prices']['2024-06-30']['reason']
