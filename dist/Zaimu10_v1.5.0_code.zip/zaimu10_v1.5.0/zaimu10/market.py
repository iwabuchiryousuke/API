"""Reproducible public market prices, separate from financial statements.

Domestic public history supplies nominal and split-adjusted Japanese prices.
Yahoo Global supplies Nikkei prices, daily calendar evidence and action events.
Their different definitions and conflicting values retain separate provenance.
CAPM rounding is explicit in the writer; this module preserves original numbers.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlencode, quote
import html as html_escape
import unicodedata

import requests
from bs4 import BeautifulSoup

from .discovery import normalize_code
from . import edinet

SCHEMA=2
_GLOBAL_SCHEMA=2
JST=timezone(timedelta(hours=9))
BENCHMARK='^N225'
_HOST='https://query1.finance.yahoo.com'
_MAX_BYTES=8*1024*1024


class MarketDataError(RuntimeError):
    """A verified market input is unavailable; financial statements stay usable."""


def _today():return datetime.now(JST).date()
def _now():return datetime.now(JST).isoformat(timespec='seconds')


def _month(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}',value):
        raise MarketDataError('株価の年月はYYYY-MMで指定してください。')
    try:return date.fromisoformat(value+'-01')
    except ValueError:raise MarketDataError('株価の対象年月が不正です。') from None


def _months(start,end):
    a,b=_month(start),_month(end)
    if a>b:raise MarketDataError('株価の開始年月と終了年月が逆転しています。')
    result=[]
    while a<=b:
        result.append(a.strftime('%Y-%m'))
        a=date(a.year+1,1,1) if a.month==12 else date(a.year,a.month+1,1)
    return result


def last_completed_month(today=None):
    value=today or _today()
    return (value.replace(day=1)-timedelta(days=1)).strftime('%Y-%m')


def _number(value,*,positive=False):
    if isinstance(value,bool) or value is None:raise ValueError
    try:result=Decimal(str(value))
    except (InvalidOperation,TypeError,ValueError):raise ValueError from None
    if not result.is_finite() or (positive and result<=0):raise ValueError
    return result


def _day(timestamp):
    if isinstance(timestamp,bool) or not isinstance(timestamp,(int,float)):
        raise ValueError
    return datetime.fromtimestamp(timestamp,JST).date().isoformat()


def _hash(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':')).encode('utf-8')).hexdigest()


def _atomic(path,content):
    path.parent.mkdir(parents=True,exist_ok=True);temporary=None
    try:
        with tempfile.NamedTemporaryFile('wb',dir=path.parent,suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name);stream.write(content)
        temporary.replace(path)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def parse_yahoo_daily(content, symbol, *, through=None):
    """Validate symbol/currency/timezone and preserve exact public numeric data."""
    try:
        body=json.loads(content) if isinstance(content,(bytes,str)) else deepcopy(content)
        chart=body['chart']
        if chart.get('error') or not isinstance(chart.get('result'),list) or len(chart['result'])!=1:
            raise ValueError
        raw=chart['result'][0];meta=raw['meta'];timestamps=raw['timestamp']
        expected_type='INDEX' if symbol==BENCHMARK else 'EQUITY'
        if (meta.get('symbol')!=symbol or meta.get('currency')!='JPY'
                or meta.get('instrumentType')!=expected_type
                or meta.get('exchangeTimezoneName')!='Asia/Tokyo'
                or not isinstance(timestamps,list) or not timestamps):raise ValueError
        quotes=raw['indicators']['quote']
        if len(quotes)!=1:raise ValueError
        closes=quotes[0]['close']
        if len(closes)!=len(timestamps):raise ValueError
        volumes=quotes[0].get('volume')
        if volumes is not None and len(volumes)!=len(timestamps):raise ValueError
        adjusted=raw['indicators'].get('adjclose') or []
        adjusted=adjusted[0]['adjclose'] if adjusted else [None]*len(timestamps)
        if len(adjusted)!=len(timestamps):raise ValueError
        days={};excluded=[];limit=(through or _today()).isoformat()
        for i,timestamp in enumerate(timestamps):
            day=_day(timestamp)
            if day>limit:continue
            if closes[i] is None:continue
            volume=_number(volumes[i]) if volumes is not None and volumes[i] is not None else None
            if volume is not None and volume<0:raise ValueError
            if expected_type=='EQUITY' and (volume is None or volume<=0):
                excluded.append(dict(date=day,close=str(closes[i]),volume=str(volume) if volume is not None else None,
                                     source_timestamp=timestamp,reason='positive_equity_trading_volume_not_confirmed'))
                continue
            close=_number(closes[i],positive=True)
            adj=_number(adjusted[i],positive=True) if adjusted[i] is not None else None
            row=dict(date=day,close=str(close),adjclose=str(adj) if adj is not None else None,
                     volume=str(volume) if volume is not None else None,source_timestamp=timestamp)
            if day in days and days[day]['close']!=row['close']:raise ValueError
            days[day]=row
        if not days:raise ValueError
        events={'splits':[],'dividends':[]}
        for kind in events:
            for item in (raw.get('events',{}).get(kind) or {}).values():
                day=_day(item['date'])
                if day>limit:continue
                if kind=='splits':
                    numerator=_number(item['numerator'],positive=True)
                    denominator=_number(item['denominator'],positive=True)
                    ratio=item.get('splitRatio')
                    if ratio:
                        a,b=ratio.split(':')
                        if _number(a,positive=True)/_number(b,positive=True)!=numerator/denominator:raise ValueError
                    events[kind].append(dict(date=day,numerator=str(numerator),denominator=str(denominator),
                        ratio=ratio or f'{numerator}:{denominator}',source_timestamp=item['date']))
                else:
                    amount=_number(item['amount'])
                    if amount<0:raise ValueError
                    events[kind].append(dict(date=day,amount=str(amount),currency='JPY',source_timestamp=item['date']))
            events[kind].sort(key=lambda row:row['date'])
        return dict(symbol=symbol,currency='JPY',timezone='Asia/Tokyo',
            instrument_type=expected_type,daily_rows=[days[k] for k in sorted(days)],events=events,
            excluded_nontrading_rows=excluded,
            calendar_policy='Equity dates require positive traded volume; index quotes retain zero-volume observations',
            provider_metadata={key:meta[key] for key in ('symbol','currency','exchangeName','fullExchangeName',
                'exchangeTimezoneName','instrumentType','firstTradeDate','regularMarketTime','longName','shortName') if key in meta},
            close_policy='Yahoo Finance close: 株式分割調整済み・配当再投資調整なし',
            adjclose_policy='Yahoo Finance adjclose: 分割・配当等調整済み（CAPM計算には使用しない）')
    except (KeyError,ValueError,TypeError,IndexError,OverflowError,OSError):
        raise MarketDataError(f'{symbol}: 公開株価の銘柄・通貨・日付・数値・企業行動を確認できません。') from None


def monthly_rows(daily_rows,*,start_month,end_month):
    wanted=set(_months(start_month,end_month));last={}
    for item in daily_rows:
        month=item['date'][:7]
        if month in wanted and (month not in last or item['date']>last[month]['date']):
            last[month]=item
    return [dict(month=month,date=last[month]['date'],last_trading_date=last[month]['date'],
                 close=last[month]['close'],adjclose=last[month].get('adjclose')) for month in sorted(last)]


def _request(session,url,*,cancel=None):
    for attempt in range(2):
        edinet._check_cancel(cancel)
        with edinet._request_lock:
            edinet._pause(max(0,edinet._MIN_INTERVAL-(time.monotonic()-edinet._last_request)),cancel)
            edinet._last_request=time.monotonic()
        try:response=session.get(url,timeout=(5,15),allow_redirects=False)
        except requests.RequestException:
            if attempt==1:raise MarketDataError('無料公開株価の取得先に接続できません。') from None
            edinet._pause(2,cancel);continue
        if response.status_code in (edinet._RETRY_STATUSES | {500}) and attempt==0:
            delay=edinet._retry_after(response.headers.get('Retry-After'))
            if delay is not None and delay>30:
                raise MarketDataError('株価取得先から長時間の待機指定がありました。時間を置いて再取得してください。')
            edinet._pause(max(delay or 0,2),cancel);continue
        if response.status_code!=200:
            raise MarketDataError(f'無料公開株価を取得できません（HTTP {response.status_code}）。')
        if len(response.content)>_MAX_BYTES:raise MarketDataError('公開株価の応答サイズが想定範囲を超えました。')
        edinet._check_cancel(cancel)
        return response.content
    raise MarketDataError('公開株価を取得できません。')


def _cache_path(cache_dir,symbol):
    safe='N225' if symbol==BENCHMARK else symbol.replace('.','_')
    return Path(cache_dir)/'market'/'series'/f'{safe}.json'


def _read(path,symbol):
    if not path.exists():return None
    try:
        body=json.loads(path.read_text(encoding='utf-8'));checksum=body.pop('payload_sha256')
        version=body.get('schema')
        if version not in {1,_GLOBAL_SCHEMA} or body.get('symbol')!=symbol or checksum!=_hash(body):raise ValueError
        proof=body['source'];relative=proof['raw_path']
        if not re.fullmatch(r'raw/[A-Za-z0-9_-]+-[a-f0-9]{64}\.json',relative):raise ValueError
        content=(path.parent.parent/relative).read_bytes()
        if hashlib.sha256(content).hexdigest()!=proof['sha256']:raise ValueError
        parsed=parse_yahoo_daily(content,symbol,through=date.fromisoformat(body['request_through']))
        if version==1:
            # Immutable raw-response SHA was verified first. Rebuild only the
            # derived calendar under the positive-volume policy; no refetch.
            body.update(schema=_GLOBAL_SCHEMA,data=parsed,normalization_policy='equity-positive-volume-v2',normalized_at=_now())
            record=deepcopy(body);record['payload_sha256']=_hash(record)
            _atomic(path,json.dumps(record,ensure_ascii=False,indent=2).encode('utf-8'))
        elif parsed!=body['data']:raise ValueError
        return body
    except (OSError,UnicodeError,ValueError,TypeError,KeyError,MarketDataError):
        raise MarketDataError(f'株価キャッシュが壊れているか対象が異なります。元ファイルは保持しています：{path.name}') from None


def _load_series(symbol,*,start_month,cache_dir,offline,refresh,cancel,log):
    edinet._check_cancel(cancel);_month(start_month)
    path=_cache_path(cache_dir,symbol);saved=_read(path,symbol)
    today=_today();warnings=[]
    if offline:
        if saved is None:raise MarketDataError(f'{symbol}: 保存済み株価がありません。オンラインでCAPMデータを取得してください。')
        result=deepcopy(saved);result['offline']=True
        if saved['start_month']>start_month:warnings.append('指定した開始年月より前の価格は保存されていません。')
        result['warnings']=warnings;return result
    if saved and not refresh and saved['start_month']<=start_month:
        try:
            age=datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at'])
            if age<timedelta(hours=12) and saved['request_through']>=today.isoformat():
                return deepcopy(saved)
        except ValueError:pass
    fetch_start=min(start_month,saved['start_month']) if saved else start_month
    start=_month(fetch_start)
    period1=int(datetime.combine(start,datetime.min.time(),JST).timestamp())
    period2=int(datetime.combine(today+timedelta(days=1),datetime.min.time(),JST).timestamp())
    # Always request corporate actions through retrieval day: historical closes
    # are adjusted even for splits after the requested CAPM observation end.
    url=_HOST+'/v8/finance/chart/'+quote(symbol,safe='')+'?'+urlencode(dict(
        period1=period1,period2=period2,interval='1d',events='div,splits'))
    try:
        log(f'{symbol}: 無料公開の日次株価・分割情報を確認しています。')
        with requests.Session() as session:
            session.headers.update({'User-Agent':'Mozilla/5.0 (Zaimu10 public market research)'})
            content=_request(session,url,cancel=cancel)
        data=parse_yahoo_daily(content,symbol,through=today)
        sha=hashlib.sha256(content).hexdigest();safe='N225' if symbol==BENCHMARK else symbol.replace('.','_')
        relative=f'raw/{safe}-{sha}.json';raw=path.parent.parent/relative
        if not raw.exists():_atomic(raw,content)
        source=dict(provider='Yahoo Finance',source_url=url,source_title=f'Yahoo Finance chart {symbol} daily',
                    sha256=sha,raw_path=relative,retrieved_at=_now(),
                    price_definition_url='https://help.yahoo.com/kb/SLN2311.html')
        body=dict(schema=_GLOBAL_SCHEMA,symbol=symbol,start_month=fetch_start,request_through=today.isoformat(),
                  checked_at=_now(),stale=False,warnings=[],source=source,data=data)
        record=deepcopy(body);record['payload_sha256']=_hash(record)
        _atomic(path,json.dumps(record,ensure_ascii=False,indent=2).encode('utf-8'))
        return body
    except InterruptedError:raise
    except (MarketDataError,OSError,ValueError) as exc:
        if saved is None:raise MarketDataError(f'{symbol}: 市場データの取得に失敗しました。{exc}') from None
        result=deepcopy(saved);result['stale']=True
        result['warnings']=list(saved.get('warnings',[]))+[f'更新失敗。{saved["checked_at"]}の確認済み市場データを使用。{exc}']
        return result


def _compact(value):return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(value or '')))


def _japan_price_tables(soup):
    result=[]
    for table in soup.find_all('table'):
        first=table.find('tr')
        headings=[_compact(cell.get_text(' ',strip=True)) for cell in first.find_all(['th','td'],recursive=False)] if first else []
        if headings[:7]==['日付','始値','高値','安値','終値','出来高','調整後終値']:
            result.append(table)
    return result


def parse_yahoo_japan_history(content,code,*,timeframe,source_url='',page=1):
    """Public price columns only: nominal close and split-adjusted close.

    Japan's 調整後終値 is NOT Yahoo Global dividend-adjusted ``adjclose``.
    Monthly table labels identify a calendar month, not an explicit trading day.
    """
    code=normalize_code(code)
    try:
        soup=BeautifulSoup(content,'html.parser')
        title=soup.title.get_text(' ',strip=True) if soup.title else ''
        if code not in title:raise ValueError
        tables=_japan_price_tables(soup)
        if not tables:
            text=soup.get_text(' ',strip=True)
            if any(term in text for term in ('指定した期間にデータはありません','指定された期間に情報はありません','該当するデータはありません')):
                return []
            raise ValueError
        rows={}
        for table in tables:
            owner=table.find_parent('section',attrs={'data-source-url':True})
            url=owner['data-source-url'] if owner else source_url
            page_number=int(owner.get('data-page',page)) if owner else page
            for row_number,tr in enumerate(table.find_all('tr')[1:],2):
                cells=tr.find_all(['th','td'],recursive=False)
                texts=[_compact(cell.get_text(' ',strip=True)) for cell in cells]
                if len(texts)<7 or '分割' in ''.join(texts):continue
                if timeframe=='m':
                    m=re.fullmatch(r'(\d{4})/(\d{1,2})',texts[0])
                    if not m:raise ValueError
                    label=f'{int(m[1]):04}-{int(m[2]):02}';_month(label)
                elif timeframe=='d':
                    m=re.fullmatch(r'(\d{4})/(\d{1,2})/(\d{1,2})',texts[0])
                    if not m:raise ValueError
                    label=date(*(int(x) for x in m.groups())).isoformat()
                else:raise ValueError
                if texts[4] in {'-','---','―','—'} or texts[6] in {'-','---','―','—'}:continue
                nominal=_number(texts[4].replace(',',''),positive=True)
                adjusted=_number(texts[6].replace(',',''),positive=True)
                item=dict(close_nominal=str(nominal),close_adjusted=str(adjusted),
                          source_url=url,source_page=page_number,source_row=row_number,
                          source_date_label=texts[0])
                item['month' if timeframe=='m' else 'date']=label
                if label in rows and any(rows[label][k]!=item[k] for k in ('close_nominal','close_adjusted')):
                    raise ValueError
                rows[label]=item
        return [rows[key] for key in sorted(rows)]
    except (ValueError,TypeError,KeyError,IndexError):
        raise MarketDataError(f'{code}: 国内公開株価の銘柄・年月日・終値・調整後終値を確認できません。') from None


def _public_japan_table(content,code,source_url,page):
    """Retain public facts, remove scripts/tokens, paid-column UI and inputs."""
    soup=BeautifulSoup(content,'html.parser')
    title=soup.title.get_text(' ',strip=True) if soup.title else ''
    out=BeautifulSoup('<section><table></table></section>','html.parser')
    section=out.section;section['data-source-url']=source_url;section['data-page']=str(page)
    target=section.table
    for table in _japan_price_tables(soup):
        for tr in table.find_all('tr'):
            line=out.new_tag('tr')
            for cell in tr.find_all(['th','td'],recursive=False)[:7]:
                copied=out.new_tag(cell.name)
                if cell.get('colspan') and str(cell['colspan']).isdigit():copied['colspan']=cell['colspan']
                copied.string=cell.get_text(' ',strip=True);line.append(copied)
            target.append(line)
    return title,str(section)


def _japan_cache(cache_dir,code,key):
    return Path(cache_dir)/'market'/'japan'/f'{code}_{key}.json'


def _read_japan(path,code,timeframe):
    if not path.exists():return None
    try:
        body=json.loads(path.read_text(encoding='utf-8'));checksum=body.pop('payload_sha256')
        if (body.get('schema')!=SCHEMA or body.get('provider')!='YahooJapan'
                or body.get('code')!=code or body.get('timeframe')!=timeframe or checksum!=_hash(body)):raise ValueError
        proof=body['source'];relative=proof['raw_path']
        if not re.fullmatch(r'japan/raw/[A-Za-z0-9_-]+-[a-f0-9]{64}\.html',relative):raise ValueError
        raw=(path.parent.parent/relative).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=proof['sha256']:raise ValueError
        rows=parse_yahoo_japan_history(raw,code,timeframe=timeframe)
        label='month' if timeframe=='m' else 'date'
        rows=[row for row in rows if body['start']<=row[label]<=body['end']]
        if rows!=body['rows']:raise ValueError
        return body
    except (OSError,ValueError,TypeError,KeyError,MarketDataError):
        raise MarketDataError(f'国内株価キャッシュが壊れているか対象が異なります。元ファイルは保持しています：{path.name}') from None


def _load_japan(code,*,timeframe,start,end,cache_dir,offline,refresh,cancel,log,query_to=None):
    edinet._check_cancel(cancel)
    key='monthly' if timeframe=='m' else 'fiscal_'+end.replace('-','')
    path=_japan_cache(cache_dir,code,key);saved=_read_japan(path,code,timeframe)
    if offline:
        if saved is None:raise MarketDataError(f'{code}: 国内株価の保存データがありません。オンライン取得が必要です。')
        result=deepcopy(saved);result['offline']=True;return result
    if saved and not refresh and saved['start']<=start and saved['end']>=end:
        try:
            if datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at'])<timedelta(hours=12):
                return deepcopy(saved)
        except ValueError:pass
    fetch_start=min(saved['start'],start) if saved and timeframe=='m' else start
    fetch_end=max(saved['end'],end) if saved and timeframe=='m' else end
    if timeframe=='m' and query_to and query_to[:7]!=fetch_end:
        # Refreshing a shorter historical request must not truncate a wider
        # verified cache while retaining its declared coverage.
        previous=saved.get('query_to') if saved else None
        query_to=previous if previous and previous[:7]==fetch_end else None
    first=_month(fetch_start) if timeframe=='m' else date.fromisoformat(fetch_start)
    if timeframe=='m':
        after=date(_month(fetch_end).year+1,1,1) if _month(fetch_end).month==12 else date(_month(fetch_end).year,_month(fetch_end).month+1,1)
        last=after-timedelta(days=1)
        max_pages=(len(_months(fetch_start,fetch_end))+19)//20+2
    else:last=date.fromisoformat(fetch_end);max_pages=3
    if query_to:
        actual=date.fromisoformat(query_to)
        if not first<=actual<=last:raise MarketDataError('国内株価の照会日が対象範囲外です。')
        last=actual
    sections=[];parts=[];all_rows={};title='';first_url=''
    try:
        with requests.Session() as session:
            session.headers.update({'User-Agent':'Mozilla/5.0 (Zaimu10 public market research)'})
            for page in range(1,max_pages+1):
                edinet._check_cancel(cancel)
                query=urlencode(dict(from_=first.strftime('%Y%m%d'))).replace('from_','from')
                query+='&'+urlencode(dict(to=last.strftime('%Y%m%d'),timeFrame=timeframe,page=page))
                url=f'https://finance.yahoo.co.jp/quote/{code}.T/history?'+query
                if not first_url:first_url=url
                log(f'{code}: 国内公開株価（{"月次" if timeframe=="m" else "期末終値"}）{page}ページを確認しています。')
                content=_request(session,url,cancel=cancel)
                rows=parse_yahoo_japan_history(content,code,timeframe=timeframe,source_url=url,page=page)
                title,section=_public_japan_table(content,code,url,page);sections.append(section)
                parts.append(dict(source_url=url,http_response_sha256=hashlib.sha256(content).hexdigest()))
                previous=set(all_rows)
                for item in rows:
                    label=item['month' if timeframe=='m' else 'date']
                    if label<fetch_start or label>fetch_end:continue
                    if label in all_rows and any(item[k]!=all_rows[label][k] for k in ('close_nominal','close_adjusted')):
                        raise MarketDataError('国内株価のページ間で同じ日付の値が一致しません。')
                    all_rows[label]=item
                if not rows or len(rows)<20 or rows[0]['month' if timeframe=='m' else 'date']<=fetch_start:
                    break
                if set(all_rows)==previous:
                    raise MarketDataError('国内株価のページが先へ進まないため取得を停止しました。')
            else:raise MarketDataError('国内株価のページ数が対象範囲と一致しません。')
        if not all_rows:raise MarketDataError('指定範囲の国内公開株価がありません。')
        raw=('<html><head><title>'+html_escape.escape(title)+'</title></head><body>'+''.join(sections)+'</body></html>').encode('utf-8')
        sha=hashlib.sha256(raw).hexdigest();relative=f'japan/raw/{code}_{key}-{sha}.html'
        raw_path=path.parent.parent/relative
        if not raw_path.exists():_atomic(raw_path,raw)
        body=dict(schema=SCHEMA,provider='YahooJapan',code=code,timeframe=timeframe,
                  start=fetch_start,end=fetch_end,query_to=last.isoformat(),rows=[all_rows[k] for k in sorted(all_rows)],
                  checked_at=_now(),stale=False,warnings=[],source=dict(
                    provider='Yahoo!ファイナンス（日本）',source_url=first_url,
                    source_title=f'{code} 国内株価時系列（公開価格欄）',sha256=sha,raw_path=relative,
                    format='sanitized_public_html',parts=parts,retrieved_at=_now(),
                    evidence_policy='公開された日付と価格7列だけ保存。実行スクリプト・入力欄・匿名トークン・有料指標欄は保存しない。',
                    price_definition_url='https://support.yahoo-net.jp/PccFinance/s/article/H000006678'))
        record=deepcopy(body);record['payload_sha256']=_hash(record)
        _atomic(path,json.dumps(record,ensure_ascii=False,indent=2).encode('utf-8'))
        return body
    except InterruptedError:raise
    except (MarketDataError,OSError,ValueError) as exc:
        if saved is None:raise MarketDataError(f'{code}: 国内公開株価を取得できません。{exc}') from None
        result=deepcopy(saved);result['stale']=True
        result['warnings']=list(saved.get('warnings',[]))+[f'国内株価の更新失敗。{saved["checked_at"]}の確認済み値を使用。{exc}']
        return result


def _snapshot_tables(content,tables,source_url,page=1):
    soup=BeautifulSoup(content,'html.parser');title=soup.title.get_text(' ',strip=True) if soup.title else ''
    clean=BeautifulSoup('<section></section>','html.parser');section=clean.section
    section['data-source-url']=source_url;section['data-page']=str(page)
    for table in tables:
        target=clean.new_tag('table');section.append(target)
        for tr in table.find_all('tr'):
            line=clean.new_tag('tr');target.append(line)
            for cell in tr.find_all(['th','td'],recursive=False):
                new=clean.new_tag(cell.name);new.string=cell.get_text(' ',strip=True)
                if cell.get('colspan') and str(cell['colspan']).isdigit():new['colspan']=cell['colspan']
                line.append(new)
    return title,str(section)


def _96ut_tables(soup):
    return [t for t in soup.find_all('table') if t.find('tr') and
            [_compact(c.get_text(' ',strip=True)) for c in t.find('tr').find_all(['th','td'],recursive=False)]
            ==['日付','始値','高値','安値','終値','出来高']]


def parse_96ut_daily(content,code,year):
    try:
        soup=BeautifulSoup(content,'html.parser')
        if not soup.title or code not in soup.title.get_text():raise ValueError
        tables=_96ut_tables(soup)
        if not tables:raise ValueError
        output={}
        for table in tables:
            for row_number,tr in enumerate(table.find_all('tr')[1:],2):
                texts=[_compact(c.get_text(' ',strip=True)) for c in tr.find_all(['th','td'],recursive=False)]
                if len(texts)<6:
                    if not texts or any('分割' in text for text in texts):continue
                    raise ValueError
                match=re.fullmatch(r'(\d{4})/(\d{1,2})/(\d{1,2})',texts[0])
                if not match:raise ValueError
                day=date(*(int(v) for v in match.groups()))
                if day.year!=year:raise ValueError
                if texts[4] in {'-','---','―'}:continue
                close=_number(texts[4].replace(',',''),positive=True)
                volume=_number(texts[5].replace(',',''))
                if volume<0:raise ValueError
                if not volume:continue
                item=dict(date=day.isoformat(),close_nominal=str(close),volume=str(volume),source_row=row_number)
                if day.isoformat() in output and output[day.isoformat()]['close_nominal']!=item['close_nominal']:raise ValueError
                output[day.isoformat()]=item
        if not output:raise ValueError
        return [output[key] for key in sorted(output)]
    except (ValueError,KeyError,TypeError,IndexError):
        raise MarketDataError(f'{code}/{year}: 国内代替の日次名目株価を確認できません。') from None


def _store_96ut_year(code,year,content,cache_dir,*,retrieved_at=None):
    rows=parse_96ut_daily(content,code,year)
    url=f'https://96ut.com/stock/jikei.php?code={code}&year={year}'
    soup=BeautifulSoup(content,'html.parser');title,section=_snapshot_tables(content,_96ut_tables(soup),url)
    raw=('<html><head><title>'+html_escape.escape(title)+'</title></head><body>'+section+'</body></html>').encode()
    sha=hashlib.sha256(raw).hexdigest();relative=f'domestic96ut/raw/{code}_{year}-{sha}.html'
    base=Path(cache_dir)/'market';path=base/'domestic96ut'/f'{code}_{year}.json'
    _atomic(base/relative,raw)
    body=dict(schema=SCHEMA,provider='96UT',code=code,year=year,rows=rows,checked_at=retrieved_at or _now(),
              stale=False,warnings=[],source=dict(provider='96UT.com',source_url=url,
              source_title=f'{code} {year}年 公開日次四本値',raw_path=relative,sha256=sha,
              http_response_sha256=hashlib.sha256(content).hexdigest(),format='sanitized_public_html',
              price_kind='nominal_unadjusted',currency='JPY',
              evidence_policy='銘柄タイトルと公開日次OHLC・出来高表だけ保存。スクリプト・広告等は除去。'))
    record=deepcopy(body);record['payload_sha256']=_hash(record)
    _atomic(path,json.dumps(record,ensure_ascii=False,indent=2).encode());return body


def _load_96ut_year(code,year,*,cache_dir,offline,refresh,cancel,log):
    edinet._check_cancel(cancel);path=Path(cache_dir)/'market'/'domestic96ut'/f'{code}_{year}.json';saved=None
    if path.exists():
        try:
            saved=json.loads(path.read_text());checksum=saved.pop('payload_sha256')
            if (saved.get('schema')!=SCHEMA or saved.get('provider')!='96UT' or saved.get('code')!=code
                    or saved.get('year')!=year or checksum!=_hash(saved)):raise ValueError
            relative=saved['source']['raw_path']
            if not re.fullmatch(r'domestic96ut/raw/[A-Za-z0-9_-]+-[a-f0-9]{64}\.html',relative):raise ValueError
            raw=(path.parent.parent/relative).read_bytes()
            if hashlib.sha256(raw).hexdigest()!=saved['source']['sha256'] or parse_96ut_daily(raw,code,year)!=saved['rows']:raise ValueError
        except (ValueError,KeyError,TypeError,OSError,MarketDataError):
            raise MarketDataError('国内代替株価キャッシュを確認できません。元ファイルは保持しています。') from None
    if saved:
        fresh=year<_today().year
        try:fresh=fresh or datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at'])<timedelta(hours=12)
        except ValueError:pass
        if offline or not refresh and fresh:return saved
    if offline:raise MarketDataError(f'{code}/{year}: 国内代替の日次株価が保存されていません。')
    try:
        log(f'{code}: 国内代替の公開日次株価（{year}年）を確認しています。')
        with requests.Session() as session:
            session.headers.update({'User-Agent':'Mozilla/5.0'})
            content=_request(session,f'https://96ut.com/stock/jikei.php?code={code}&year={year}',cancel=cancel)
        return _store_96ut_year(code,year,content,cache_dir)
    except InterruptedError:raise
    except (MarketDataError,OSError) as exc:
        if saved is None:raise
        result=deepcopy(saved);result['stale']=True;result['warnings']=[f'国内代替日次価格の更新失敗。保存済み値を使用。{exc}'];return result


def _kabutan_tables(soup):
    tables=[]
    for table in soup.find_all('table'):
        first=table.find('tr');heads=[_compact(c.get_text(' ',strip=True)) for c in first.find_all(['th','td'],recursive=False)] if first else []
        if heads[:5]==['日付','始値','高値','安値','終値'] and any('前月比' in head for head in heads):tables.append(table)
    return tables


def parse_kabutan_monthly(content,code,*,source_url='',page=1):
    try:
        soup=BeautifulSoup(content,'html.parser')
        if not soup.title or code not in soup.title.get_text():raise ValueError
        tables=_kabutan_tables(soup)
        if not tables:raise ValueError
        result={}
        for table in tables:
            owner=table.find_parent('section',attrs={'data-source-url':True})
            url=owner['data-source-url'] if owner else source_url;number=int(owner.get('data-page',page)) if owner else page
            for row_number,tr in enumerate(table.find_all('tr')[1:],2):
                texts=[_compact(c.get_text(' ',strip=True)) for c in tr.find_all(['th','td'],recursive=False)]
                if len(texts)<5:continue
                match=re.fullmatch(r'(\d{2,4})/(\d{1,2})(?:/(\d{1,2}))?',texts[0])
                if not match:raise ValueError
                year=int(match[1]);year=year if year>=100 else 2000+year if 2000+year<=_today().year+1 else 1900+year
                month=f'{year:04}-{int(match[2]):02}';_month(month)
                day=date(year,int(match[2]),int(match[3])).isoformat() if match[3] else None
                value=_number(texts[4].replace(',',''),positive=True)
                item=dict(month=month,date=day,close_adjusted=str(value),source_url=url,
                          source_page=number,source_row=row_number,source_date_label=texts[0],
                          published_decimal_places=max(0,-value.as_tuple().exponent))
                if month in result and result[month]['close_adjusted']!=item['close_adjusted']:raise ValueError
                result[month]=item
        if not result:raise ValueError
        return [result[key] for key in sorted(result)]
    except (ValueError,KeyError,TypeError,IndexError):
        raise MarketDataError(f'{code}: 国内代替の公開月次価格を確認できません。') from None


def _load_kabutan_monthly(code,*,start,end,cache_dir,offline,refresh,cancel,log):
    edinet._check_cancel(cancel);base=Path(cache_dir)/'market';path=base/'kabutan'/f'{code}_monthly.json';saved=None
    if path.exists():
        try:
            saved=json.loads(path.read_text());checksum=saved.pop('payload_sha256')
            if saved.get('schema')!=SCHEMA or saved.get('provider')!='Kabutan' or saved.get('code')!=code or checksum!=_hash(saved):raise ValueError
            relative=saved['source']['raw_path']
            if not re.fullmatch(r'kabutan/raw/[A-Za-z0-9_-]+-[a-f0-9]{64}\.html',relative):raise ValueError
            raw=(base/relative).read_bytes()
            if hashlib.sha256(raw).hexdigest()!=saved['source']['sha256']:raise ValueError
            rows=parse_kabutan_monthly(raw,code)
            rows=[row for row in rows if saved['start']<=row['month']<=saved['end']]
            if rows!=saved['rows']:raise ValueError
        except (ValueError,KeyError,TypeError,OSError,MarketDataError):
            raise MarketDataError('国内代替月次株価キャッシュが不正です。元ファイルは保持しています。') from None
    if saved and saved['start']<=start and saved['end']>=end:
        fresh=False
        try:fresh=datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at'])<timedelta(hours=12)
        except ValueError:pass
        if offline or not refresh and fresh:return saved
    if offline:raise MarketDataError(f'{code}: 国内代替の月次価格が保存されていません。')
    if saved:start=min(start,saved['start']);end=max(end,saved['end'])
    errors=[]
    for variant in ('desktop','mobile'):
        sections=[];parts=[];rows={};title=''
        try:
            with requests.Session() as session:
                session.headers.update({'User-Agent':'Mozilla/5.0'})
                for page in range(1,(len(_months(start,end))+28)//29+5):
                    edinet._check_cancel(cancel)
                    url=(f'https://kabutan.jp/stock/kabuka?code={code}&ashi=mon&page={page}' if variant=='desktop'
                         else f'https://s.kabutan.jp/stocks/{code}/historical_prices/monthly/?page={page}')
                    log(f'{code}: 国内代替の公開月次株価（{page}ページ）を確認しています。')
                    content=_request(session,url,cancel=cancel);parsed=parse_kabutan_monthly(content,code,source_url=url,page=page)
                    soup=BeautifulSoup(content,'html.parser');title,section=_snapshot_tables(content,_kabutan_tables(soup),url,page)
                    sections.append(section);parts.append(dict(source_url=url,http_response_sha256=hashlib.sha256(content).hexdigest()))
                    previous=set(rows)
                    for row in parsed:
                        if start<=row['month']<=end:
                            if row['month'] in rows and rows[row['month']]['close_adjusted']!=row['close_adjusted']:raise MarketDataError('国内代替月次ページの値が一致しません。')
                            rows[row['month']]=row
                    if parsed[0]['month']<=start:break
                    if set(rows)==previous:raise MarketDataError('国内代替月次ページが進みません。')
                else:raise MarketDataError('国内代替月次の対象範囲を確認できません。')
            if not rows:raise MarketDataError('国内代替月次に対象価格がありません。')
            raw=('<html><head><title>'+html_escape.escape(title)+'</title></head><body>'+''.join(sections)+'</body></html>').encode()
            sha=hashlib.sha256(raw).hexdigest();relative=f'kabutan/raw/{code}_monthly-{sha}.html';_atomic(base/relative,raw)
            body=dict(schema=SCHEMA,provider='Kabutan',code=code,start=start,end=end,rows=[rows[k] for k in sorted(rows)],
                checked_at=_now(),stale=False,warnings=[],source=dict(provider='株探（Kabutan）',source_url=parts[0]['source_url'],
                source_title=f'{code} 公開月次修正株価',raw_path=relative,sha256=sha,parts=parts,
                format='sanitized_public_html',price_kind='published_split_adjusted_monthly_close',
                precision_policy='公開表の表示精度をそのまま保持。失われた小数桁は推定しない。',currency='JPY',variant=variant))
            record=deepcopy(body);record['payload_sha256']=_hash(record);_atomic(path,json.dumps(record,ensure_ascii=False,indent=2).encode());return body
        except InterruptedError:raise
        except (MarketDataError,OSError) as exc:errors.append(str(exc))
    if saved:
        result=deepcopy(saved);result['stale']=True;result['warnings']=['国内代替月次の更新失敗。保存値を使用。'+' '.join(errors)];return result
    raise MarketDataError('国内代替月次を取得できません。'+' '.join(errors))


def load_capm_market(code,*,start_month,end_month,cache_dir,offline=False,refresh=False,cancel=None,log=print):
    """Chronological monthly stock/Nikkei closes plus reproducible daily facts.

    The endpoint may return a current partial month. It is never included in
    ``stock_rows``/``index_rows``; only requested completed months are selected.
    ``close`` and ``adjclose`` are unrounded decimal strings. The CAPM writer
    explicitly applies the reference workbook's integer TRUNC input policy.
    """
    code=normalize_code(code);wanted=_months(start_month,end_month)
    if end_month>last_completed_month():
        raise MarketDataError('CAPMは完了した月の終値で計算します。今月以降は指定できません。')
    stock=_load_series(code+'.T',start_month=start_month,cache_dir=cache_dir,offline=offline,
                       refresh=refresh,cancel=cancel,log=log)
    index=_load_series(BENCHMARK,start_month=start_month,cache_dir=cache_dir,offline=offline,
                       refresh=refresh,cancel=cancel,log=log)
    calendar_rows=monthly_rows(stock['data']['daily_rows'],start_month=start_month,end_month=end_month)
    calendar_by_month={row['month']:row for row in calendar_rows}
    end_calendar=calendar_by_month.get(end_month)
    fallback_reason=None
    try:
        japan=_load_japan(code,timeframe='m',start=start_month,end=end_month,cache_dir=cache_dir,
                           offline=offline,refresh=refresh,cancel=cancel,log=log,
                           query_to=end_calendar['date'] if end_calendar else None)
    except MarketDataError as exc:
        if 'キャッシュ' in str(exc):raise
        fallback_reason=str(exc)
        japan=_load_kabutan_monthly(code,start=start_month,end=end_month,cache_dir=cache_dir,
                                    offline=offline,refresh=refresh,cancel=cancel,log=log)
    a=[];conflicts=[]
    for row in japan['rows']:
        if not start_month<=row['month']<=end_month:continue
        calendar=calendar_by_month.get(row['month'])
        actual_date=row.get('date')
        if not actual_date and calendar is None:
            raise MarketDataError(f'{code}: {row["month"]}の取引日を別の日次資料で確認できません。')
        actual_date=actual_date or calendar['date']
        a.append(dict(month=row['month'],date=actual_date,last_trading_date=actual_date,
            close=row['close_adjusted'],adjclose=None,nominal_close=row.get('close_nominal'),
            price_source=row['source_url'],source_row=row['source_row'],
            price_provider=japan['source']['provider'],
            date_source=row['source_url'] if row.get('date') else stock['source']['source_url'],
            date_basis='国内公開表の実日付' if row.get('date') else '国内月次資料は年月表示。取引日は正の出来高を持つ同月日次観測を別途確認。'))
        difference=abs(_number(row['close_adjusted'])-_number(calendar['close'])) if calendar else Decimal(0)
        if difference:
            conflicts.append(dict(month=row['month'],domestic_close=row['close_adjusted'],
                global_close=calendar['close'],difference_jpy=str(difference),
                kind='display_rounding' if difference<=Decimal('0.01') else 'provider_price_difference',
                adopted=japan['source']['provider'],domestic_source=row['source_url'],global_source=stock['source']['source_url']))
    b=monthly_rows(index['data']['daily_rows'],start_month=start_month,end_month=end_month)
    am={row['month'] for row in a};bm={row['month'] for row in b}
    warnings=list(stock.get('warnings',[]))+list(index.get('warnings',[]))+list(japan.get('warnings',[]))
    if fallback_reason:warnings.append(f'国内標準配信を利用できず、全月次系列を{japan["source"]["provider"]}の公表精度で取得。{fallback_reason}')
    if any(row['kind']=='provider_price_difference' for row in conflicts):
        warnings.append('国内株価と海外配信値に差がある月は、国内公開時系列の調整後終値を採用。差額と両出典を記録しています。')
    if set(wanted)-am or set(wanted)-bm:
        warnings.append('指定範囲に公開価格のない月があります。必要な観測数を満たさない年度のβは未算出にしてください。')
    return dict(schema=SCHEMA,code=code,stock_symbol=code+'.T',benchmark=BENCHMARK,
        benchmark_name='日経平均株価',start_month=start_month,end_month=end_month,
        stock_rows=a,index_rows=b,stock_daily_rows=deepcopy(stock['data']['daily_rows']),
        stock_events=deepcopy(stock['data']['events']),index_events=deepcopy(index['data']['events']),
        source_provenance=dict(stock=deepcopy(japan['source']),index=deepcopy(index['source']),
                               stock_calendar_and_actions=deepcopy(stock['source'])),
        provider_conflicts=conflicts,
        price_policy=dict(stock_close=('Yahoo!ファイナンス（日本）公開月次の調整後終値：分割等調整済み・配当調整なし'
                           if japan.get('provider')=='YahooJapan' else '株探（Kabutan）公開月次の修正終値：公表された桁数のまま保持し、小数桁を推定しない'),
                          stock_adjclose='国内資料に配当調整後価格はないため未設定。海外adjcloseは元の日次原文に別途保持。',
                          benchmark='Nikkei 225 price index close（配当なし）',rounding='市場データには丸めを適用しない'),
        coverage=dict(requested_months=len(wanted),paired_months=len(am&bm),
            missing_stock_months=sorted(set(wanted)-am),missing_index_months=sorted(set(wanted)-bm)),
        checked_at=min(stock['checked_at'],index['checked_at'],japan['checked_at']),
        stale=bool(stock.get('stale') or index.get('stale') or japan.get('stale')),warnings=warnings)


def load_fiscal_prices(code,dates,*,cache_dir,offline=False,refresh=False,cancel=None,log=print):
    """Domestic nominal daily quotes, before separate legal-share-basis proof.

    Ex-rights dates in market feeds do not establish legal issuance dates. The
    share-basis reader must align the quote if fiscal close falls in that gap.
    This module never guesses the legal effective date from a price event.
    """
    code=normalize_code(code)
    try:
        requested=sorted({value.date() if isinstance(value,datetime) else value if isinstance(value,date)
                          else date.fromisoformat(str(value)) for value in dates})
    except (ValueError,TypeError):raise MarketDataError('時価総額の基準日が不正です。') from None
    if not requested:return dict(code=code,prices={},warnings=[],stale=False)
    if any(day>=_today() for day in requested):
        raise MarketDataError('時価総額には終値が確定した過去の決算期末を指定してください。')
    start=(requested[0]-timedelta(days=14)).strftime('%Y-%m')
    series=_load_series(code+'.T',start_month=start,cache_dir=cache_dir,offline=offline,
                        refresh=refresh,cancel=cancel,log=log)
    prices={};warnings=list(series.get('warnings',[]));data=series['data']
    price_sources=[];stale=bool(series.get('stale'));checked_at=series['checked_at']
    for fiscal in requested:
        edinet._check_cancel(cancel)
        calendar=[row for row in data['daily_rows'] if row['date']<=fiscal.isoformat()]
        query_to=calendar[-1]['date'] if calendar and (fiscal-date.fromisoformat(calendar[-1]['date'])).days<=10 else None
        try:
            japan=_load_japan(code,timeframe='d',start=(fiscal-timedelta(days=14)).isoformat(),end=fiscal.isoformat(),
                               cache_dir=cache_dir,offline=offline,refresh=refresh,cancel=cancel,log=log,query_to=query_to)
        except InterruptedError:raise
        except MarketDataError as exc:
            try:
                if 'キャッシュ' in str(exc):raise
                alternative=_load_96ut_year(code,fiscal.year,cache_dir=cache_dir,offline=offline,
                                            refresh=refresh,cancel=cancel,log=log)
                japan=alternative
                warnings.append(f'{fiscal.isoformat()}の名目終値は国内代替96UT.comを使用。{exc}')
            except InterruptedError:raise
            except MarketDataError as alternative_error:
                prices[fiscal.isoformat()]=dict(available=False,requested_date=fiscal.isoformat(),reason=str(alternative_error))
                warnings.append(f'{fiscal.isoformat()}の国内終値を取得できません。{alternative_error}')
                continue
        warnings.extend(japan.get('warnings',[]))
        price_sources.append(deepcopy(japan['source']));stale=stale or bool(japan.get('stale'))
        checked_at=min(checked_at,japan['checked_at'])
        eligible=[row for row in japan['rows'] if row['date']<=fiscal.isoformat()]
        if not eligible or (fiscal-date.fromisoformat(eligible[-1]['date'])).days>10:
            prices[fiscal.isoformat()]=dict(available=False,reason='期末直前の確定した公開終値を確認できません。')
            continue
        row=eligible[-1];factor=Decimal(1);actions=[]
        if japan.get('provider')=='96UT' and query_to and row['date']!=query_to:
            prices[fiscal.isoformat()]=dict(available=False,requested_date=fiscal.isoformat(),
                reason='国内代替資料の最終日が、別途確認した最終取引日と一致しません。古い価格を代用しません。')
            continue
        for event in data['events']['splits']:
            if event['date']>fiscal.isoformat():
                factor*=_number(event['numerator'],positive=True)/_number(event['denominator'],positive=True)
                actions.append(deepcopy(event))
        close=_number(row['close_nominal'],positive=True)
        informational=close
        for event in data['events']['splits']:
            if event['date']>row['date']:
                informational/=_number(event['numerator'],positive=True)/_number(event['denominator'],positive=True)
        prices[fiscal.isoformat()]=dict(available=True,requested_date=fiscal.isoformat(),
            date=row['date'],trading_date=row['date'],currency='JPY',
            nominal_close_jpy=str(close),split_adjusted_close=row.get('close_adjusted',str(informational)),adjclose=None,
            split_adjusted_close_is_derived='close_adjusted' not in row,
            split_factor_after_fiscal_date=str(factor),historical_close_jpy=str(close),
            subsequent_splits=actions,stock_split_events=deepcopy(data['events']['splits']),
            source=deepcopy(japan['source']),corporate_action_source=deepcopy(series['source']),
            price_provider='96UT.com' if japan.get('provider')=='96UT' else 'YahooJapan',share_basis_state='nominal_quote_at_trading_date',
            method='domestic daily nominal close; legal issued-share-basis alignment is a separate verified step',
            reconstruction_basis_date=row['date'],adjustment_through=japan['checked_at'])
    providers=sorted({item['provider'] for item in price_sources})
    return dict(schema=SCHEMA,code=code,prices=prices,
                source=dict(provider=providers[0] if len(providers)==1 else '各期の国内価格出典を参照',
                            providers=providers,price_sources=price_sources),
                corporate_action_source=deepcopy(series['source']),
                checked_at=checked_at,stale=stale,warnings=list(dict.fromkeys(warnings)))
