"""Current-year-only bond inset reader: real annual reports and hostile cases."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip
from hashlib import sha256
import json
from pathlib import Path

import pytest

from zaimu10.analysis import analyze_dataset,metric_terms
from zaimu10.debt_notes import extract_debt_notes,DebtNoteError
from zaimu10.models import Dataset,Period,Row,Cell,Source,Filing
from zaimu10.parser import parse_filing

F=Path(__file__).parent/'fixtures'/'jes_bonds'
NS='http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor'
P=Period(date(2024,4,1),date(2025,3,31))
O=Period(date(2023,4,1),date(2024,3,31))


def by_category(rows,name):return next(r for r in rows if r.key.split(':')[2]==name)
def evidence(cell):return json.loads(cell.note.split('debt_note_evidence:',1)[1])


def dataset():
    ds=Dataset('6544','検証会社','consolidated',[O,P],accounting_standard='J-GAAP')
    source=Source('S100TEST','main.xhtml','https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100TEST',
        concept='{http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor}BondsPayable',unit='JPY',basis='consolidated')
    ds.rows['BS_LE']=[Row('bond','社債','BS_LE',values={P.key:Cell(Decimal(400000),source)})]
    return ds


def body(*,end='400 (100)',total='400 (100)',detail=None,semantic=True,maturity='100',begin='999 (777)'):
    rows=detail or [('検証会社','第1回無担保社債','2021年3月1日',begin,end,'1.0','なし','2027年3月1日')]
    headers=['会社名','銘柄','発行年月日','当期首残高(千円)','当期末残高(千円)','利率(%)','担保','償還期限']
    table='<table><tr>'+''.join('<td>'+h+'</td>'for h in headers)+'</tr>'
    for row in rows:table+='<tr>'+''.join('<td>'+v+'</td>'for v in row)+'</tr>'
    table+='<tr><td>合計</td><td>－</td><td>－</td><td>'+begin+'</td><td>'+total+'</td><td>－</td><td>－</td><td>－</td></tr></table>'
    if semantic:table+='<p>（注）（　）内書は、１年以内の償還予定額であります。</p>'
    if maturity is not None:
        table+='<p>連結決算日後５年間の償還予定額は以下のとおりであります。</p><table><tr>'
        table+=''.join('<td>'+v+'(千円)</td>'for v in ['1年以内','1年超2年以内','2年超3年以内','3年超4年以内','4年超5年以内'])
        table+='</tr><tr>'+''.join('<td>'+v+'</td>'for v in [maturity,'－','－','－','－'])+'</tr></table>'
    return '<h6>【社債明細表】</h6>'+table


def extract(content=None,ds=None):
    content=content or body()
    markup='<html xmlns:ix="http://www.xbrl.org/2013/inlineXBRL" xmlns:xbrli="http://www.xbrl.org/2003/instance" xmlns:jpcrp_cor="'+NS+'"><body><ix:resources><xbrli:context id="CurrentYearDuration"><xbrli:entity><xbrli:identifier>E33034-000</xbrli:identifier></xbrli:entity><xbrli:period><xbrli:startDate>2024-04-01</xbrli:startDate><xbrli:endDate>2025-03-31</xbrli:endDate></xbrli:period></xbrli:context></ix:resources><ix:nonNumeric name="jpcrp_cor:AnnexedConsolidatedDetailedScheduleOfCorporateBondsTextBlock" contextRef="CurrentYearDuration">'+content+'</ix:nonNumeric></body></html>'
    return extract_debt_notes([('annex.xhtml',markup)],ds or dataset())


@pytest.mark.parametrize('doc,current,noncurrent',[
    ('S100ASMM','0','400000000'),('S100DFWJ','400000000','0'),('S100G9V9','0','0')])
def test_real_jes_closing_inset_uses_reported_current_period_only(doc,current,noncurrent):
    pages=json.loads(gzip.decompress((F/f'{doc}.json.gz').read_bytes()))
    ds=parse_filing(Filing(doc,code='6544'),pages);original=asdict(ds)
    rows=extract_debt_notes(pages,ds);period=ds.periods[-1]
    c=by_category(rows,'current_bonds').values[period.key]
    n=by_category(rows,'bonds').values[period.key]
    assert c.value==Decimal(current)and n.value==Decimal(noncurrent)
    assert set(by_category(rows,'bonds').values)=={period.key}
    assert set(by_category(rows,'current_bonds').values)=={period.key}
    proof=evidence(c)
    assert proof['scope']=='current_fiscal_year_end_only'
    assert proof['balance_column']=='end' and proof['physical_column']==5
    assert proof['unit_label']=='千円'and proof['scale']==3
    assert proof['parentheses_semantics']and proof['details']
    assert Decimal(proof['reported_total_jpy'])==c.value+n.value
    assert proof['noncurrent_formula']=='reported_total_jpy - reported_current_jpy'
    assert c.source.concept.endswith('}AnnexedConsolidatedDetailedScheduleOfCorporateBondsTextBlock')
    assert c.source.context_id=='CurrentYearDuration'and c.source.unit=='JPY'and c.source.basis=='consolidated'
    assert c.source.raw_value==proof['raw_value']
    coverage=by_category(rows,'bonds_coverage').values[period.key]
    assert coverage.value is None and coverage.operation=='bonds_schedule_complete'
    if doc!='S100G9V9':assert proof['redemption_crosscheck']
    assert asdict(ds)==original
    ds.analysis_inputs=rows
    analysis=analyze_dataset(ds)
    debt=analysis.metrics['interest_bearing_debt'].values[period.key]
    assert debt.value is not None
    # Notes complement the BS rather than add its identical bonds again.
    terms=metric_terms(debt)
    assert len([cell for _,_,cell in terms if cell.source.concept.endswith('}BondsPayable')])<=1


def test_reported_total_is_split_into_current_and_noncurrent_once():
    rows=extract()
    assert by_category(rows,'current_bonds').values[P.key].value==100000
    assert by_category(rows,'bonds').values[P.key].value==300000
    assert set(by_category(rows,'bonds').values)=={P.key}
    # An opening-year value is intentionally ignored, not copied into O.
    assert all(O.key not in r.values for r in rows)


def test_zero_current_is_proven_by_explicit_aggregate_not_missing_detail_parentheses():
    rows=extract(body(end='400',total='400 (－)',maturity='－'))
    c=by_category(rows,'current_bonds').values[P.key]
    assert c.value==0
    e=evidence(c)
    assert e['positive_details_without_inset']and e['current_zero_proven_by_reported_aggregate']


def test_explicit_total_dash_proves_no_bonds_without_an_inner_parenthesis():
    rows=extract(body(end='－',total='－',maturity=None))
    assert by_category(rows,'bonds').values[P.key].value==0
    assert by_category(rows,'current_bonds').values[P.key].value==0


@pytest.mark.parametrize('kwargs',[
    dict(semantic=False),dict(end='400',total='400',maturity=None),
    dict(end='400',total='400 (100)'),dict(end='400 (500)',total='400 (500)',maturity=None),
    dict(total='450 (100)'),dict(total='400 (200)'),dict(maturity='200'),
    dict(end='',total='400 (100)'),dict(end='nil'),dict(end='△400'),
])
def test_unsupported_or_contradictory_inner_amounts_are_not_summed(kwargs):
    with pytest.raises(DebtNoteError):extract(body(**kwargs))


@pytest.mark.parametrize('old,new',[
    ('当期末残高(千円)','当期末残高(米ドル)'),('会社名','通貨'),
    ('1年以内(千円)','1年以内(百万円)'),('連結決算日後５年間','次期以降'),
])
def test_units_columns_and_maturity_scope_must_be_positive_proof(old,new):
    with pytest.raises(DebtNoteError):extract(body().replace(old,new))


def test_duplicate_security_and_unclassified_additional_tables_fail_closed():
    row=('検証会社','第1回無担保社債','2021年3月1日','100','200 (50)','1.0','なし','2027年3月1日')
    with pytest.raises(DebtNoteError,match='重複'):extract(body(detail=[row,row],total='400 (100)'))
    with pytest.raises(DebtNoteError):extract(body()+'<table><tr><td>不明残高</td><td>999</td></tr></table>')


def test_unknown_blank_is_not_interpreted_as_monetary_dash():
    with pytest.raises(DebtNoteError):extract(body(end='400 ()',total='400 ()',maturity=None))


def test_named_company_scope_and_comparative_opening_are_not_silently_extended():
    ds=dataset();ds.basis='standalone'
    assert extract(ds=ds)==[]
    rows=extract(body(begin='未分類の期首金額'))
    assert all(set(r.values)=={P.key}for r in rows)


def test_duplicate_annex_does_not_duplicate_debt_category():
    content=body()
    # Two separate sections in the same standard note are ambiguous, not added.
    with pytest.raises(DebtNoteError):extract(content+content)


def test_real_fixtures_retain_public_source_hashes():
    for record in json.loads((F/'sources.json').read_text()):
        payload=(F/record['path']).read_bytes()
        assert sha256(payload).hexdigest()==record['sha256']
        pages=json.loads(gzip.decompress(payload))
        assert [dict(filename=n,sha256=sha256(t.encode()).hexdigest())for n,t in pages]==record['files']
