"""Historical DCF and financial ratios translated from the supplied workbooks.

This is the supplied historical model, not a forecast or a valuation.  All
financial inputs reference final visible cells in the four approved statements.
No source-company forecast, tax override, growth guess or share price is copied.
"""
from __future__ import annotations

from copy import copy
from decimal import Decimal
from importlib.resources import files
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter

from .models import Dataset, Period, Row
from .financial_refs import FinancialRefs

TEMPLATE_PATH = files('zaimu10').joinpath('assets').joinpath('supplementary_template.xlsx')
DCF_LABELS = {2:'売上高',3:'G R',4:'±',5:'売上原価',6:'/Sales',7:'売上総利益',8:'販管費',
    9:'/Sales',10:'営業利益',11:'G R',12:'/Sales',13:'実効税率',14:'ＮＯＰＡＴ',
    15:'非現金支出',16:'/Sales',17:'売上債権',18:'/Sales',19:'在庫',20:'/Sales',
    21:'支払債務',22:'/COGS',23:'運転資本',24:'±',25:'設備投資',26:'FCF',27:'GR'}
DCF_KEYS = {2:'revenue',3:'sales_growth',4:'sales_change',5:'cost_of_sales',6:'cost_ratio',
    7:'gross_profit',8:'sga',9:'sga_ratio',10:'model_operating_profit',11:'operating_growth',
    12:'operating_margin',13:'effective_tax_rate',14:'nopat',15:'noncash',16:'noncash_ratio',
    17:'trade_receivables',18:'receivables_ratio',19:'inventory',20:'inventory_ratio',
    21:'trade_payables',22:'payables_cost_ratio',23:'working_capital',24:'working_capital_change',
    25:'capex',26:'fcf',27:'fcf_growth'}
DCF_MONEY = {2,4,5,7,8,10,14,15,17,19,21,23,24,25,26}
FR_LABELS = {2:'ROIC',3:'投下資本回転率',4:'AROIC',5:'WACC(C)',6:'WACC(R)',7:'Spread',
    8:'投下資本',9:'EVA',10:'＜バリュードライバー＞',11:'税引前ROIC',12:'営業利益率',
    13:'売上高成長率',14:'EBITDAマージン',15:'原価率',16:'販管費率',17:'＜安全性指標＞',
    18:'手元流動性',19:'流動比率',20:'当座比率',21:'＜生産性指標＞',22:'有形固定資産回転率',
    23:'売上債権回転日数',24:'棚卸資産回転日数',25:'買入債務回転日数',26:'Cash Conversion Cycle'}
FR_KEYS = {2:'roic',3:'invested_capital_turnover',4:'aroic',5:'wacc_c',6:'wacc_r',7:'spread',
    8:'invested_capital',9:'eva',11:'pretax_roic',12:'operating_margin',13:'sales_growth',
    14:'ebitda_margin',15:'cost_ratio',16:'sga_ratio',18:'liquidity_months',19:'current_ratio',
    20:'quick_ratio',22:'ppe_turnover',23:'receivables_days',24:'inventory_days',25:'payables_days',26:'ccc'}
FR_MONEY = {8,9}
NONCASH_DEFINITION = '見本の非現金支出：CFの減価償却費・のれん償却・減損損失・引当金増減（原本CF4:7）。退職給付増減等へ推測で拡張しません。'
CAPEX_DEFINITION = '見本の設備投資：有形・無形固定資産の取得/売却及び関係会社株式の取得/売却。原文の符号を保持。投資有価証券の取得/売却は含めません。'


def _ref(sheet: str, address: str) -> str:
    return "'"+sheet.replace("'", "''")+"'!"+address


def _numeric(value) -> bool:
    return isinstance(value, Decimal) and value.is_finite()


def _sheet(writer, dataset: Dataset, name: str):
    if name in writer.book:
        writer.book.remove(writer.book[name])
    writer.cells[:]=[cell for cell in writer.cells if cell.get('sheet')!=name]
    for mapping in (writer.values, writer.cached):
        for key in list(mapping):
            if key[0]==name:del mapping[key]
    ws=writer.book.create_sheet(name)
    with TEMPLATE_PATH.open('rb') as stream:template=load_workbook(stream)
    src=template[name]
    last=27 if name=='DCF' else 26
    for key,dimension in src.column_dimensions.items():
        if dimension.min and dimension.min>len(writer.periods)+1:continue
        ws.column_dimensions[key]=copy(dimension)
    ws.sheet_format=copy(src.sheet_format)
    ws.sheet_view.showGridLines=src.sheet_view.showGridLines
    ws.freeze_panes='B2'
    ws.page_setup=copy(src.page_setup);ws.page_setup.id=None
    ws.page_setup.orientation='landscape';ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=1
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_margins=copy(src.page_margins)
    for number in range(1,last+1):
        source_row=(number if name=='DCF' or number<=5 else 5 if number==6 else number-1)
        ws.row_dimensions[number].height=src.row_dimensions[source_row].height
        ws.row_dimensions[number].hidden=False
        for column in range(1,len(writer.periods)+2):
            original=src.cell(source_row,min(column,16));target=ws.cell(number,column)
            # Individual properties are portable across workbooks; style IDs
            # are local to their original font/fill tables.
            target.font=copy(original.font);target.fill=copy(original.fill)
            target.border=copy(original.border);target.alignment=copy(original.alignment)
            target.number_format=original.number_format;target.protection=copy(original.protection)
            if column>1 and number>1:writer.fit_number(target)
    template.close()
    company=dataset.company.replace('株式会社','').strip()
    ws['A1']=f'{company} /{writer.unit_label}' if name=='DCF' else f'Financial Ratio\n単位：{writer.unit_label}'
    alignment=copy(ws['A1'].alignment);alignment.wrap_text=True;ws['A1'].alignment=alignment
    header_height=max(writer.book['PL'].row_dimensions[1].height or 30,43.5)
    ws.row_dimensions[1].height=header_height
    for column,period in enumerate(writer.periods,2):
        header=writer.book['PL'].cell(1,column)
        ws.cell(1,column).value=header.value
        if header.comment:ws.cell(1,column).comment=copy(header.comment)
    labels=DCF_LABELS if name=='DCF' else FR_LABELS
    for number,label in labels.items():ws.cell(number,1).value=label
    ws.print_area=f'A1:{get_column_letter(len(writer.periods)+1)}{last}'
    return ws


class _Model:
    def __init__(self,writer,dataset,refs,name):
        self.writer=writer;self.dataset=dataset;self.refs=refs;self.name=name
        self.ws=_sheet(writer,dataset,name)
        self.metadata={'sheet':name,'historical_only':True,'forecast_generated':False,
            'source_templates':['6947図研.xlsx','7826フルヤ金属.xlsx'],
            'rows':DCF_KEYS if name=='DCF' else FR_KEYS,'periods':{},'missing_inputs':[]}

    def value(self,row,column):
        return self.writer.values.get((self.name,f'{get_column_letter(column)}{row}'))

    def input(self,name,period):
        return self.refs.get(name,period)

    def reason(self,name,period):
        return self.refs.reason(name,period) or f'{name}の対応する可視財務入力を確認できません。'

    def emit(self,row,column,expression,value,*,note='',missing=(),assumptions=(),inputs=()):
        period=self.writer.periods[column-2]
        keys=DCF_KEYS if self.name=='DCF' else FR_KEYS
        key='supplement:'+self.name+':'+keys[row]
        monetary=row in (DCF_MONEY if self.name=='DCF' else FR_MONEY)
        address=f'{get_column_letter(column)}{row}'
        details={'address':address,'metric':keys[row],'formula':expression,
            'display_value':str(value) if value is not None else None,
            'missing':list(missing),'assumptions':list(assumptions),'note':note,'inputs':list(inputs)}
        self.metadata['periods'].setdefault(period.key,{})[keys[row]]=details
        if missing:self.metadata['missing_inputs'].append({'period':period.key,'metric':keys[row],'reasons':list(missing)})
        record=Row(key,(DCF_LABELS if self.name=='DCF' else FR_LABELS)[row],'PL')
        text='添付見本の実績モデル。将来予測・理論株価・終価の仮定は生成しません。\n'+note
        if assumptions:text+='\n見本の計算上の扱い: '+' '.join(assumptions)
        if missing:text+='\n未算出/入力不足: '+' '.join(missing)
        if expression is not None and value is not None:
            expected=value*self.writer.factor if monetary else value
            self.writer.formula(self.name,row,column,expression,expected,row=record,note=text,monetary=monetary)
            self.writer.cells[-1]['supplemental']=details
        else:
            self.ws.cell(row,column).value=None
            self.writer.values[(self.name,address)]=None
            self.ws.cell(row,column).comment=Comment(text+'\n対象期間: '+period.key,'Zaimu10')
            self.writer.cells.append({'sheet':self.name,'address':address,'row_key':key,'period':period.key,
                'formula':None,'display_value':None,'source':None,
                'unit':self.writer.unit if monetary else 'ratio_or_text','supplemental':details})

    def link(self,row,column,name,period,*,note=''):
        source=self.input(name,period)
        if source is None:
            self.emit(row,column,None,None,note=note,missing=[self.reason(name,period)])
        else:
            self.emit(row,column,'='+source.excel,source.value,note=note,
                      inputs=[{'sheet':ref.sheet,'address':ref.address}for ref in source.refs])

    def arithmetic(self,row,column,expression,operands,operation,*,note='',zero_blanks=False,assumptions=()):
        values=[self.value(source,column) for source in operands]
        missing=[f'{self.name}{source}入力が空欄です。'for source,value in zip(operands,values)if not _numeric(value)]
        if missing and not zero_blanks:
            self.emit(row,column,None,None,note=note,missing=missing);return
        result=operation([value if _numeric(value)else Decimal(0)for value in values])
        self.emit(row,column,expression,result,note=note,missing=missing if zero_blanks else (),
                  assumptions=assumptions,inputs=[{'sheet':self.name,'address':f'{get_column_letter(column)}{r}'}for r in operands])

    def ratio(self,row,column,numerator,denominator,*,note='',growth=False):
        letter=get_column_letter(column)
        previous=get_column_letter(column-1)
        n=self.value(numerator,column)
        d=self.value(denominator,column-1 if growth else column)
        if not _numeric(n)or not _numeric(d)or d==0:
            self.emit(row,column,None,None,note=note,missing=['初年度の比較値不足、対応入力の空欄、又は分母0。']);return
        dref=f'{previous if growth else letter}{denominator}'
        self.emit(row,column,f'={letter}{numerator}/{dref}'+('-1'if growth else ''),n/d-(1 if growth else 0),note=note)

    def finish(self):
        self.writer.layout_metadata[self.name]={'historical_only':True,'rows':self.metadata['rows'],
            'last_row':27 if self.name=='DCF' else 26,'periods':[p.key for p in self.writer.periods]}
        return self.metadata


def write_dcf(writer,dataset: Dataset,refs: FinancialRefs | None=None) -> dict:
    """Write reference-model historical DCF rows1–27, without forecasts."""
    refs=refs or FinancialRefs(writer,dataset);model=_Model(writer,dataset,refs,'DCF')
    for column,period in enumerate(writer.periods,2):
        letter=get_column_letter(column);previous=get_column_letter(column-1)
        for number,name,note in [(2,'revenue','売上高は承認済みPLの対応行。'),(5,'cost_of_sales','売上原価は承認済みPLの対応行。'),
            (8,'sga','販管費は承認済みPLの対応行。'),(13,'effective_tax_rate','全年度を承認済みPLの実効税率へ接続。見本の手入力3%等は引き継ぎません。'),
            (15,'noncash',NONCASH_DEFINITION),(17,'trade_receivables','売上債権。その他債権と未分離の広い残高を勝手に同一視しません。'),
            (19,'inventory','見本の棚卸資産の合計。計上された合計とその内訳は重ねて加算しません。'),
            (21,'trade_payables','仕入/支払債務。広いその他債務への推測置換は行いません。'),(25,'capex',CAPEX_DEFINITION)]:
            model.link(number,column,name,period,note=note)
        if column>2:
            model.ratio(3,column,2,2,growth=True)
            current=model.value(2,column);prior=model.value(2,column-1)
            model.emit(4,column,f'={letter}2-{previous}2' if _numeric(current)and _numeric(prior)else None,
                       current-prior if _numeric(current)and _numeric(prior)else None,
                       missing=()if _numeric(current)and _numeric(prior)else ['前期又は当期の売上高が空欄です。'])
        else:
            model.emit(3,column,None,None,missing=['初年度の比較対象をこの10期の表に表示していないため空欄。'])
            model.emit(4,column,None,None,missing=['初年度の比較対象をこの10期の表に表示していないため空欄。'])
        model.ratio(6,column,5,2)
        model.arithmetic(7,column,f'={letter}2-{letter}5',[2,5],lambda v:v[0]-v[1])
        model.ratio(9,column,8,2)
        model.arithmetic(10,column,f'={letter}7-{letter}8',[7,8],lambda v:v[0]-v[1],
                         note='見本どおり売上総利益－販管費で計算するモデル営業利益。PLの別途開示されたその他営業損益がある場合、PL営業利益と異なります。')
        reported=refs.get('operating_profit',period)
        calculated=model.value(10,column)
        if reported is not None and _numeric(calculated)and reported.value!=calculated:
            detail=model.metadata['periods'][period.key]['model_operating_profit']
            detail['reported_pl_operating_profit']=str(reported.value)
            detail['difference_from_pl']=str(calculated-reported.value)
            comment=model.ws.cell(10,column).comment
            comment.text+=f'\nPL営業利益: {reported.value}、モデルとの差: {calculated-reported.value}（表示単位）。見本の式を維持し、差額を補いません。'
        if column>2:model.ratio(11,column,10,10,growth=True)
        else:model.emit(11,column,None,None,missing=['初年度の比較営業利益がありません。'])
        model.ratio(12,column,10,2)
        model.arithmetic(14,column,f'={letter}10-{letter}10*{letter}13',[10,13],lambda v:v[0]-v[0]*v[1],note='見本のNOPAT＝モデル営業利益－モデル営業利益×実効税率。')
        model.ratio(16,column,15,2);model.ratio(18,column,17,2);model.ratio(20,column,19,2);model.ratio(22,column,21,5)
        model.arithmetic(23,column,f'={letter}17+{letter}19-{letter}21',[17,19,21],lambda v:v[0]+v[1]-v[2])
        current=model.value(23,column);prior=model.value(23,column-1)if column>2 else None
        if column>2 and _numeric(current)and _numeric(prior):model.emit(24,column,f'={letter}23-{previous}23',current-prior)
        else:model.emit(24,column,None,None,missing=['初年度、又は前期/当期の運転資本入力が空欄です。'])
        # The supplied workbook intentionally leaves the first delta blank;
        # preserve its explicit arithmetic and disclose Excel's blank-as-zero
        # treatment instead of introducing an IF/ERROR or a balancing value.
        assumptions=[]
        required=[14,15,25]+([24]if column>2 else [])
        missing=[f'{letter}{r}の入力が空欄です。'for r in required if not _numeric(model.value(r,column))]
        if missing:
            model.emit(26,column,None,None,
                note='FCFの必須入力が未開示/未算出のため、欠けたNOPAT・非現金支出・設備投資・期中運転資本増減を0とはみなしません。',missing=missing)
        else:
            if column==2:
                assumptions.append(f'見本どおり初年度の{letter}24は空欄のまま、Excelの通常の加減算により0として扱います。実在する運転資本増減0を取得したことは意味しません。')
            model.arithmetic(26,column,f'={letter}14+{letter}15-{letter}24+{letter}25',[14,15,24,25],lambda v:v[0]+v[1]-v[2]+v[3],
                note='見本のFCF＝NOPAT＋非現金支出－運転資本増減＋符号付き設備投資。会計上の営業CF－投資CFという定義への置換はしません。',
                zero_blanks=column==2,assumptions=assumptions)
        if column>2:model.ratio(27,column,26,26,growth=True)
        else:model.emit(27,column,None,None,missing=['初年度の比較FCFがありません。'])
    return model.finish()


def write_fr(writer,dataset: Dataset,refs: FinancialRefs | None=None) -> dict:
    """Write the historical FR union, retaining the two supplied definitions."""
    refs=refs or FinancialRefs(writer,dataset);model=_Model(writer,dataset,refs,'FR')
    def from_sheet(sheet,row,column):
        address=f'{get_column_letter(column)}{row}';value=writer.values.get((sheet,address))
        return _ref(sheet,address),value
    for column,period in enumerate(writer.periods,2):
        letter=get_column_letter(column)
        def optional_status(name):
            method=getattr(refs,'status',None)
            return method(name,period)if method else 'unresolved'
        def resolved(name):
            source=refs.get(name,period)
            return (source.excel,source.value)if source else (None,None)
        def calc(row,expression,values,operation,note='',missing=()):
            if any(not _numeric(value)for value in values):
                model.emit(row,column,None,None,note=note,missing=missing or ['定義に対応する入力が空欄です。']);return
            model.emit(row,column,expression,operation(values),note=note)
        def divide(row,numerator,denominator,note=''):
            ne,nv=numerator;de,dv=denominator
            if not _numeric(nv)or not _numeric(dv)or dv==0:
                model.emit(row,column,None,None,note=note,missing=['定義に対応する入力が空欄、又は分母0。']);return
            model.emit(row,column,f'=({ne})/({de})',nv/dv,note=note)
        revenue=resolved('revenue');cost=resolved('cost_of_sales');op=resolved('operating_profit')
        invested=resolved('invested_capital');nopat=from_sheet('DCF',14,column)
        divide(2,nopat,invested,'見本のROIC＝DCF NOPAT÷期末投下資本。平均投下資本への置換はしません。')
        divide(3,revenue,invested)
        calc(4,f'={letter}2*{letter}3',[model.value(2,column),model.value(3,column)],lambda v:v[0]*v[1],'見本のAROIC＝ROIC×投下資本回転率。')
        for row,capm_row in [(5,10),(6,13)]:
            expression,value=from_sheet('CAPM',capm_row,column)
            model.emit(row,column,'='+expression if _numeric(value)else None,value if _numeric(value)else None,
                note='CAPMシートの当該年度WACCを参照。別年度のβやWACCで補完しません。',
                missing=()if _numeric(value)else ['当該年度のCAPM WACCが未算出です。'])
        calc(7,f'={letter}2-{letter}5',[model.value(2,column),model.value(5,column)],lambda v:v[0]-v[1],'見本のSpread＝ROIC－WACC(C)。')
        model.link(8,column,'invested_capital',period)
        calc(9,f'={letter}7*{letter}8',[model.value(7,column),model.value(8,column)],lambda v:v[0]*v[1])
        divide(11,op,invested,'見本の税引前ROICはPL営業利益÷投下資本。税引前当期利益を代入しません。')
        divide(12,op,revenue)
        growth=resolved('sales_growth')
        model.emit(13,column,'='+growth[0]if _numeric(growth[1])else None,growth[1]if _numeric(growth[1])else None,
                   missing=()if _numeric(growth[1])else ['初年度の売上高成長率、又は対応入力が空欄です。'])
        noncash=resolved('noncash')
        divide(14,(f'({op[0]}+{noncash[0]})',op[1]+noncash[1] if _numeric(op[1])and _numeric(noncash[1])else None),revenue,
               '見本のEBITDAマージン＝（PL営業利益＋指定CF4科目の非現金支出）÷売上高。'+NONCASH_DEFINITION)
        divide(15,cost,revenue);divide(16,resolved('sga'),revenue)
        cash=resolved('cash');securities=resolved('current_securities')
        liquid_expr=f'({cash[0]}+{securities[0]})'if _numeric(securities[1])else cash[0]
        liquid_value=cash[1]+securities[1]if _numeric(cash[1])and _numeric(securities[1])else cash[1]
        securities_unknown=not _numeric(securities[1])and optional_status('current_securities')!='absent'
        if securities_unknown:liquid_value=None
        liquid_note='見本の手元流動性＝（現預金＋流動の有価証券）÷（売上高÷12）。有価証券の科目自体が存在しない場合は現預金のみ。明示nil・空欄・一意に解決できない有価証券は0扱いせず未算出。非流動の投資有価証券や未分離のその他金融資産は含めません。'
        divide(18,(liquid_expr,liquid_value),(f'({revenue[0]}/12)',revenue[1]/12 if _numeric(revenue[1])else None),liquid_note)
        liabilities=resolved('current_liabilities')
        divide(19,resolved('current_assets'),liabilities)
        receivables=resolved('trade_receivables')
        quick_value=liquid_value+receivables[1]if _numeric(liquid_value)and _numeric(receivables[1])else None
        divide(20,(f'({liquid_expr}+{receivables[0]})',quick_value),liabilities,
               '見本の当座比率＝（現預金＋売上債権＋流動の有価証券）÷流動負債。明示nilの有価証券は0扱いしません。')
        for target in [18,20]:
            model.metadata['periods'][period.key][FR_KEYS[target]]['optional_input_status']={
                'current_securities':'available'if _numeric(securities[1])else optional_status('current_securities')}
        ppe=resolved('ppe');construction=resolved('construction_in_progress')
        ppe_expr=f'({ppe[0]}-{construction[0]})'if _numeric(construction[1])else ppe[0]
        ppe_value=ppe[1]-construction[1]if _numeric(ppe[1])and _numeric(construction[1])else ppe[1]
        construction_unknown=not _numeric(construction[1])and optional_status('construction_in_progress')!='absent'
        if construction_unknown:ppe_value=None
        divide(22,revenue,(ppe_expr,ppe_value),'見本どおり有形固定資産から建設仮勘定を控除。科目自体が存在しない場合だけ追加控除なし。原文の明示的nil・空欄・一意に解決できない入力は0扱いせず未算出。')
        model.metadata['periods'][period.key]['ppe_turnover']['optional_input_status']={
            'construction_in_progress':'available'if _numeric(construction[1])else optional_status('construction_in_progress')}
        for row,numerator,denominator,definition in [(23,receivables,revenue,'売上債権÷売上高×365'),
                (24,resolved('inventory'),revenue,'棚卸資産÷売上高×365（見本どおり売上原価ではない）'),
                (25,resolved('trade_payables'),cost,'買入債務÷売上原価×365')]:
            ne,nv=numerator;de,dv=denominator
            if _numeric(nv)and _numeric(dv)and dv!=0:
                model.emit(row,column,f'=({ne})/({de})*365',nv/dv*365,note='見本の回転日数：'+definition+'。期間日数に置き換えず365を維持。')
            else:model.emit(row,column,None,None,missing=['回転日数の対応入力が空欄、又は分母0。'])
        calc(26,f'={letter}23+{letter}24-{letter}25',[model.value(23,column),model.value(24,column),model.value(25,column)],lambda v:v[0]+v[1]-v[2])
    return model.finish()


def write_supplemental(writer,dataset: Dataset,refs: FinancialRefs | None=None) -> dict:
    """Convenience without market access; callers normally insert CAPM between."""
    refs=refs or FinancialRefs(writer,dataset)
    return {'DCF':write_dcf(writer,dataset,refs),'FR':write_fr(writer,dataset,refs)}
