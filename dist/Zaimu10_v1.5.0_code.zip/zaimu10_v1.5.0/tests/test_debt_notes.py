"""Borrowing-note evidence, real hidden leases, and fail-closed table changes."""
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import gzip
import json
from pathlib import Path

import pytest
from lxml import html,etree
from bs4 import BeautifulSoup

from zaimu10.debt_notes import DebtNoteError, extract_debt_notes
from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source
from zaimu10.parser import parse_filing

F = Path(__file__).parent / 'fixtures'
P = Period(date(2024,4,1), date(2025,3,31))
O = Period(date(2023,4,1), date(2024,3,31))
NS = 'http://disclosure.edinet-fsa.go.jp/taxonomy/jpcrp/2024-11-01/jpcrp_cor'
BORROW = 'AnnexedConsolidatedDetailedScheduleOfBorrowingsTextBlock'
BONDS = 'AnnexedConsolidatedDetailedScheduleOfCorporateBondsNATextBlock'


def source_dataset(*, basis='consolidated', periods=None):
    periods = periods or [O,P]
    ds = Dataset('6947','図研',basis,periods,accounting_standard='J-GAAP')
    source = Source('S100TEST','main.xhtml','https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100TEST',
                    submitted='2025-06-20',basis=basis,
                    concept='{http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/2024-11-01/jppfs_cor}CurrentLiabilities')
    ds.rows['BS_LE'] = [Row('current','流動負債合計','BS_LE',values={p.key:Cell(Decimal(100),deepcopy(source))for p in periods})]
    return ds


def markup(body, *, block=BORROW, context='CurrentYearDuration', basis_member='',
           period_start='2024-04-01', period_end='2025-03-31', attrs='', namespace=NS):
    return '<html xmlns:ix="http://www.xbrl.org/2013/inlineXBRL" xmlns:xbrli="http://www.xbrl.org/2003/instance" '+\
           'xmlns:xbrldi="http://xbrl.org/2006/xbrldi" xmlns:jpcrp_cor="'+namespace+'"><body>'+\
           '<ix:resources><xbrli:context id="CurrentYearDuration"><xbrli:entity><xbrli:identifier>E01966-000</xbrli:identifier>'+\
           basis_member+'</xbrli:entity><xbrli:period><xbrli:startDate>'+period_start+'</xbrli:startDate>'+\
           '<xbrli:endDate>'+period_end+'</xbrli:endDate></xbrli:period></xbrli:context></ix:resources>'+\
           '<ix:nonNumeric name="jpcrp_cor:'+block+'" contextRef="'+context+'" '+attrs+'>'+body+'</ix:nonNumeric></body></html>'


def table(rows=None, *, unit='千円', begin='当期首残高', end='当期末残高', total=None):
    rows = rows or [('１年以内に返済予定のリース債務','10','20'),
                    ('リース債務（１年以内に返済予定のものを除く。）','30','40')]
    header=f'<tr><td>区分</td><td>{begin}（{unit}）</td><td>{end}（{unit}）</td><td>平均利率（％）</td><td>返済期限</td></tr>'
    body=''.join(f'<tr><td>{label}</td><td>{before}</td><td>{after}</td><td>1.0</td><td>2028年</td></tr>'for label,before,after in rows)
    if total is not None:
        body+=f'<tr><td>合計</td><td>{total[0]}</td><td>{total[1]}</td><td>－</td><td>－</td></tr>'
    return '<h6>【借入金等明細表】</h6><table>'+header+body+'</table>'


def extract(body=None, ds=None, **kwargs):
    return extract_debt_notes([('original.xhtml',markup(body or table(),**kwargs))],ds or source_dataset())


def by_category(rows, category):
    return next(r for r in rows if r.key.split(':')[2]==category)


def evidence(cell):
    return json.loads(cell.note.split('debt_note_evidence:',1)[1])


def test_real_zuken_has_hidden_current_and_noncurrent_leases_not_zero_debt():
    pages=json.load(gzip.open(F/'zuken_2025_ixbrl.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100W07I',code='6947',submitted='2025-06-20'),pages)
    before=asdict(ds)
    rows=extract_debt_notes(pages,ds)
    current,previous=ds.periods[-1],ds.periods[0]
    lease=by_category(rows,'current_lease');long=by_category(rows,'noncurrent_lease')
    assert lease.values[current.key].value==Decimal('56239000')
    assert long.values[current.key].value==Decimal('59539000')
    assert lease.values[previous.key].value==Decimal('38185000')
    assert long.values[previous.key].value==Decimal('60313000')
    assert lease.values[current.key].value+long.values[current.key].value==Decimal('115778000')
    assert not any('LeaseObligations'in c.source.concept for r in ds.rows['BS_LE']for c in r.values.values())
    assert not any(r.key.split(':')[2]in {'total','interest_bearing_debt'}for r in rows)
    c=lease.values[current.key];e=evidence(c)
    assert c.source.concept.endswith('}AnnexedConsolidatedDetailedScheduleOfBorrowingsTextBlock')
    assert c.source.context_id=='CurrentYearDuration' and c.source.raw_value=='56,239'
    assert c.source.unit=='JPY' and c.source.scale==3 and c.source.decimals=='-3'
    assert e['balance_column']=='end' and e['unit_label']=='千円' and e['physical_row']>1
    assert e['raw_value']=='56,239' and e['period_end']=='2025-03-31'
    coverage=by_category(rows,'borrowings_coverage').values[current.key]
    assert coverage.value is None and coverage.operation=='debt_schedule_complete'
    assert evidence(coverage)['reported_schedule_total_jpy']=='115778000'
    assert asdict(ds)==before


def test_real_furuya_schedule_omits_short_term_loan_and_must_not_generate_a_false_zero():
    pages=json.load(gzip.open(F/'furuya_2017_ixbrl.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100BDPD',code='7826'),pages)
    rows=extract_debt_notes(pages,ds);current=ds.periods[-1]
    main_short=next(c for r in ds.rows['BS_LE']for k,c in r.values.items()
                    if k==current.key and c.source.concept.endswith('}ShortTermLoansPayable'))
    assert main_short.value==Decimal('300000000')
    assert not any(r.key.split(':')[2]=='short_term_borrowings'for r in rows)
    assert sum(by_category(rows,n).values[current.key].value for n in
               ['current_long_term_borrowings','current_lease','long_term_borrowings','noncurrent_lease'])==Decimal('2189000000')
    assert main_short.value+Decimal('2189000000')==Decimal('2489000000')
    assert by_category(rows,'current_lease').values[current.key].source.context_id=='CurrentYearDuration'
    assert by_category(rows,'current_lease').values[current.key].source.basis=='standalone'


def test_actual_fresh_dawn_notes_explicitly_prove_zero_rather_than_infer_it_from_absent_bs_rows():
    pages=json.load(gzip.open(F/'dawn_2026_debt_notes.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100YXLE',code='2303',edinet_code='E05289'),pages)
    rows=extract_debt_notes(pages,ds);period=ds.periods[-1]
    for category in ['short_term_borrowings','current_long_term_borrowings','current_lease','long_term_borrowings','noncurrent_lease','bonds']:
        c=by_category(rows,category).values[period.key]
        assert c.value==0 and c.operation=='explicit_no_balance'
        assert '該当事項はありません' in c.source.raw_value
    assert by_category(rows,'borrowings_absent').values[period.key].operation=='explicit_no_borrowings'


def test_actual_fresh_furuya_note_monetary_dash_resolves_bs_nil_without_using_unknown_long_payables():
    pages=json.load(gzip.open(F/'furuya_2026_debt_notes.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100Z403',code='7826',edinet_code='E02485'),pages)
    rows=extract_debt_notes(pages,ds);period=ds.periods[-1]
    main=next(c for r in ds.rows['BS_LE']for key,c in r.values.items()if key==period.key and c.source.concept.endswith('}ShortTermLoansPayable'))
    assert main.value is None and main.nil
    short=by_category(rows,'short_term_borrowings').values[period.key]
    assert short.value==0 and short.operation=='explicit_no_balance' and short.source.raw_value in {'－','―','—','-'}
    total=sum(by_category(rows,c).values[period.key].value for c in ['short_term_borrowings','current_long_term_borrowings','current_lease','long_term_borrowings','noncurrent_lease'])
    assert total==Decimal('14263000000')
    assert not any('長期未払金'in c.source.original_label for r in rows for c in r.values.values())


def test_absence_of_note_is_not_a_zero_or_a_completeness_certificate():
    for name,code in [('dawn_2026','2303'),('furuya_2026','7826'),('nitori_2026','9843')]:
        pages=json.load(gzip.open(F/(name+'_ixbrl.json.gz'),'rt',encoding='utf8'))
        assert extract_debt_notes(pages,parse_filing(Filing('S100TEST',code=code),pages))==[]


@pytest.mark.parametrize('block,title,categories,status',[
    (BORROW,'借入金等明細表',{'short_term_borrowings','current_long_term_borrowings','current_lease','long_term_borrowings','noncurrent_lease'},'borrowings_absent'),
    (BONDS,'社債明細表',{'bonds','current_bonds'},'bonds_absent'),
])
def test_explicit_none_proves_covered_current_balances_only(block,title,categories,status):
    body='<h6>【'+title+'】</h6><p>該当事項はありません。</p>'
    rows=extract(body,block=block)
    assert {r.key.split(':')[2]for r in rows}==categories|{status}
    for r in rows:
        assert set(r.values)=={P.key}  # prose has no numerical prior-year column
        c=r.values[P.key]
        assert c.value==0 and '該当事項はありません'in c.source.raw_value
        assert evidence(c)['kind']=='explicit_none'
    for r in rows:
        if r.key.split(':')[2]in categories:assert r.values[P.key].operation=='explicit_no_balance'


def test_explicit_monetary_dash_is_zero_while_empty_or_nil_is_not():
    rows=extract(table([('短期借入金','－','0')]))
    row=by_category(rows,'short_term_borrowings')
    assert row.values[O.key].value==0 and row.values[O.key].operation=='explicit_no_balance'
    assert row.values[O.key].source.raw_value=='－'
    assert row.values[P.key].value==0 and row.values[P.key].operation==''
    for unknown in ['', '<ix:nonFraction xsi:nil="true"></ix:nonFraction>', '未定', '(10)', '△10']:
        with pytest.raises(DebtNoteError):extract(table([('短期借入金',unknown,'0')]))


def test_explicit_other_interest_bearing_deposit_caption_is_distinct_from_generic_deposit():
    body=table([('その他有利子負債 預り金','594','581')],unit='百万円').replace('<td>1.0</td>','<td>1.99</td>')
    rows=extract(body)
    c=by_category(rows,'other_interest_bearing_debt').values[P.key]
    assert c.value==Decimal('581000000') and c.source.original_label=='その他有利子負債 預り金'
    assert evidence(c)['interest_rate_raw']=='1.99'
    assert evidence(c)['interest_rate_positive_required']
    assert '平均利率'in evidence(c)['interest_rate_column_header']
    for rate in ['0','－']:
        with pytest.raises(DebtNoteError,match='正の平均利率'):
            extract(body.replace('<td>1.99</td>','<td>'+rate+'</td>'))
    with pytest.raises(DebtNoteError,match='未識別'):
        extract(table([('預り金','594','581')],unit='百万円'))


def test_note_dimensions_and_mismatched_basis_are_not_silently_read_as_company_totals():
    ds=source_dataset(basis='standalone')
    assert extract(ds=ds)==[]  # consolidated appendix is outside requested basis
    member='<xbrli:segment><xbrldi:explicitMember dimension="jpcrp_cor:ConsolidatedOrNonConsolidatedAxis">jpcrp_cor:NonConsolidatedMember</xbrldi:explicitMember></xbrli:segment>'
    with pytest.raises(DebtNoteError,match='連結区分'):extract(basis_member=member)
    dimension='<xbrli:segment><xbrldi:explicitMember dimension="jpcrp_cor:BusinessSegmentsAxis">jpcrp_cor:OneBusinessMember</xbrldi:explicitMember></xbrli:segment>'
    with pytest.raises(DebtNoteError,match='次元'):extract(basis_member=dimension)


@pytest.mark.parametrize('kwargs',[
    {'context':'missing'}, {'period_start':'2024-07-01'}, {'period_end':'2025-06-30'},
    {'attrs':'continuedAt="another"'}, {'attrs':'xsi:nil="true"'},
    {'namespace':'https://unverified.example/jpcrp_cor'},
])
def test_context_period_continuation_nil_and_taxonomy_guards(kwargs):
    with pytest.raises(DebtNoteError):extract(**kwargs)


def test_period_error_exposes_affected_periods_for_nonblocking_analysis_failure():
    with pytest.raises(DebtNoteError)as err:extract(period_end='2026-03-31')
    assert err.value.periods==[O.key,P.key]


@pytest.mark.parametrize('unit',['', '米ドル', '千円・百万円'])
def test_unknown_or_mixed_currency_scale_cannot_be_guessed(unit):
    with pytest.raises(DebtNoteError,match='単位'):extract(table(unit=unit))


def test_explicit_column_dates_must_equal_context_start_minus_one_and_end():
    rows=extract(table(begin='当期首残高2024年3月31日',end='当期末残高令和7年3月31日'))
    assert by_category(rows,'current_lease').values[P.key].value==20000
    with pytest.raises(DebtNoteError,match='日付'):
        extract(table(begin='当期首残高2024年3月30日'))


def test_comparative_uses_actual_previous_period_end_even_after_changed_year_length():
    shortened=Period(date(2023,7,1),date(2024,3,31))
    rows=extract(ds=source_dataset(periods=[shortened,P]))
    assert set(by_category(rows,'current_lease').values)=={shortened.key,P.key}


@pytest.mark.parametrize('body',[
    table([('その他','10','20')]),
    table([('短期借入金','10','20'),('短期借入金','10','20')]),
    table().replace('平均利率','期中増加額'),
    table().replace('当期首残高','期末残高'),
    table().replace('【借入金等明細表】','【別の表】'),
])
def test_unknown_rows_duplicate_categories_and_changed_headers_fail_closed(body):
    with pytest.raises(DebtNoteError):extract(body)


def test_reported_total_is_only_a_crosscheck_and_rounding_never_changes_component_amounts():
    rows=extract(table(total=('41','61')))
    assert by_category(rows,'current_lease').values[P.key].value==20000
    assert by_category(rows,'noncurrent_lease').values[P.key].value==40000
    cov=by_category(rows,'borrowings_coverage').values[P.key]
    assert evidence(cov)['reported_schedule_total_jpy']=='61000'
    assert evidence(cov)['component_sum_jpy']=='60000'
    with pytest.raises(DebtNoteError,match='内訳と合計'):
        extract(table(total=('400','600')))


def test_numeric_bond_schedule_with_unverified_current_portion_schema_is_not_misread_as_absence():
    body=table().replace('借入金等明細表','社債明細表')
    with pytest.raises(DebtNoteError,match='社債明細表'):
        extract(body,block=BONDS)


def test_duplicate_full_note_and_mixed_document_inputs_cannot_double_count():
    page=markup(table())
    with pytest.raises(DebtNoteError,match='複数'):
        extract_debt_notes([('one.xhtml',page),('two.xhtml',page)],source_dataset())
    ds=source_dataset();ds.rows['BS_LE'][0].values[O.key].source.doc_id='S100ELSE'
    with pytest.raises(DebtNoteError,match='元書類'):
        extract(ds=ds)
    ds.basis='mixed'
    with pytest.raises(DebtNoteError,match='単一原本'):
        extract(ds=ds)


def test_note_cannot_borrow_another_issuers_same_dates_and_context_id():
    ds=source_dataset()
    for c in ds.rows['BS_LE'][0].values.values():
        c.source.filename='0105010_E01966-000_2025-03-31_ixbrl.htm'
    page=markup(table()).replace('E01966-000','E00932-000')
    with pytest.raises(DebtNoteError,match='提出者'):
        extract_debt_notes([('0105010_E00932-000_2025-03-31_ixbrl.htm',page)],ds)


def test_qualifying_prose_after_none_statement_does_not_turn_into_automatic_zero():
    with pytest.raises(DebtNoteError):
        extract('<h6>【借入金等明細表】</h6><p>該当事項はありません。ただし子会社借入は除きます。</p>')


def chugai():
    pages=json.load(gzip.open(F/'chugai_2025_debt_notes.json.gz','rt',encoding='utf8'))
    ds=parse_filing(Filing('S100XTBJ',code='4519',submitted='2026-03-25'),pages)
    return pages,ds


def mutate_chugai(pages,local,callback):
    result=deepcopy(pages)
    for i,(filename,markup_)in enumerate(result):
        root=html.fromstring(markup_.encode('utf8'),parser=html.HTMLParser(encoding='utf8'))
        target=next((n for n in root.iter()if isinstance(n.tag,str)and n.get('name','').rsplit(':',1)[-1]==local),None)
        if target is not None:
            callback(target)
            result[i]=[filename,etree.tostring(root,encoding='unicode')]
            return result
    raise AssertionError('test target missing: '+local)


CUR='NotesOtherCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock'
NCL='NotesOtherNonCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock'
RISK='NotesRiskManagementConsolidatedFinancialStatementsIFRSTextBlock'
LEASE='NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock'


def replace_text(node,before,after):
    for n in node.iter():
        if n.text and before in n.text:
            n.text=n.text.replace(before,after)
            return
    raise AssertionError('target original text missing: '+before)


def test_actual_ifrs_lease_liability_classification_and_narrow_nonlease_absence():
    pages,ds=chugai();rows=extract_debt_notes(pages,ds);before,current=ds.periods
    assert by_category(rows,'current_lease').values[current.key].value==Decimal('7773000000')
    assert by_category(rows,'noncurrent_lease').values[current.key].value==Decimal('17937000000')
    assert by_category(rows,'current_lease').values[before.key].value==Decimal('6365000000')
    assert by_category(rows,'noncurrent_lease').values[before.key].value==Decimal('4532000000')
    assert sum(by_category(rows,c).values[current.key].value for c in ['current_lease','noncurrent_lease'])==Decimal('25710000000')
    # 25,711m is the separately rounded total carrying amount; use the two
    # classified balances, not the 8,194m undiscounted one-year cash flow.
    assert by_category(rows,'current_lease').values[current.key].value!=Decimal('8194000000')
    status=by_category(rows,'nonlease_debt_absent')
    assert set(status.values)=={current.key}
    assert status.values[current.key].operation=='explicit_no_nonlease_debt'
    assert 'リース負債は'in status.values[current.key].source.raw_value
    assert status.values[current.key].source.concept.endswith('}'+RISK)
    for category in ['short_term_borrowings','current_long_term_borrowings','long_term_borrowings','bonds','current_bonds','commercial_paper']:
        c=by_category(rows,category).values[current.key]
        assert c.value==0 and c.operation=='explicit_no_balance'
    for category in ['current_lease_coverage','noncurrent_lease_coverage']:
        c=by_category(rows,category).values[current.key]
        assert c.value is None and c.operation=='lease_note_complete'


def test_ifrs_source_evidence_points_to_the_actual_physical_cell_including_spacer_columns():
    pages,ds=chugai();row=by_category(extract_debt_notes(pages,ds),'current_lease');c=row.values[ds.periods[-1].key]
    e=evidence(c);markup_=next(h for f,h in pages if f==c.source.filename)
    soup=BeautifulSoup(markup_,'html.parser');tb=soup.find_all('table')[e['page_table_index']-1]
    tr=tb.find_all('tr')[e['physical_row']-1];td=tr.find_all(['td','th'],recursive=False)[e['physical_column']-1]
    assert ''.join(td.stripped_strings)=='7,773'==c.source.raw_value
    assert e['parent_local']=='OtherCurrentLiabilitiesCLIFRS'


def test_undiscounted_lease_maturity_and_total_carrying_amount_never_substitute_for_classified_balances():
    pages,ds=chugai();original=extract_debt_notes(pages,ds)
    mutated=mutate_chugai(pages,LEASE,lambda n:replace_text(n,'8,194','999,999'))
    mutated=mutate_chugai(mutated,LEASE,lambda n:replace_text(n,'25,711','888,888'))
    assert [asdict(r)for r in extract_debt_notes(mutated,ds)]==[asdict(r)for r in original]


@pytest.mark.parametrize('before,after',[
    ('当社グループが保有する有利子負債','当社グループが保有する固定金利の有利子負債'),
    ('当社グループが保有する有利子負債','当社が保有する有利子負債'),
    ('当社グループが保有する有利子負債','前連結会計年度において当社グループが保有する有利子負債'),
    ('金利リスク','固定金利リスク'),
    ('リース負債はリース契約','リース負債は一部の借入金を除き、リース契約'),
])
def test_partial_scope_or_previous_period_prose_never_asserts_zero_for_all_group_nonlease_debt(before,after):
    pages,ds=chugai();mutated=mutate_chugai(pages,RISK,lambda n:replace_text(n,before,after))
    rows=extract_debt_notes(mutated,ds)
    assert not any(r.key.split(':')[2]=='nonlease_debt_absent'for r in rows)
    assert by_category(rows,'current_lease').values[ds.periods[-1].key].value==Decimal('7773000000')


def test_identical_risk_wording_from_another_issuer_is_not_a_generic_zero_rule():
    pages,ds=chugai()
    mutated=[]
    for filename,text in pages:
        if '0105110_'in filename:
            text=text.replace('/E00932-000/2025-12-31/01/2026-03-25','/E00001-000/2025-12-31/01/2026-03-25')
        mutated.append([filename,text])
    rows=extract_debt_notes(mutated,ds)
    assert not any(r.key.split(':')[2]=='nonlease_debt_absent'for r in rows)


def test_ifrs_note_wrong_balance_or_parent_scope_is_a_real_conflict_not_a_fallback():
    pages,ds=chugai()
    bad=mutate_chugai(pages,CUR,lambda n:replace_text(n,'7,773','99,999'))
    with pytest.raises(DebtNoteError,match='内訳と合計'):extract_debt_notes(bad,ds)
    for row in ds.rows['BS_LE']:
        for c in row.values.values():
            if c.source.concept.endswith('}OtherCurrentLiabilitiesCLIFRS'):c.value+=Decimal('100000000')
    with pytest.raises(DebtNoteError,match='本表'):extract_debt_notes(pages,ds)


def test_ifrs_changed_currency_date_or_nonempty_spacer_is_not_silently_ignored():
    pages,ds=chugai()
    for before,after in [('百万円','米ドル'),('2025年12月31日','2025年12月30日')]:
        bad=mutate_chugai(pages,CUR,lambda n:replace_text(n,before,after))
        with pytest.raises(DebtNoteError):extract_debt_notes(bad,ds)
    def spacer(n):
        table_=next(x for x in n.iter()if isinstance(x.tag,str)and x.tag=='table')
        trs=list(table_.iter('tr'));list(trs[3])[1].text='1'
    bad=mutate_chugai(pages,CUR,spacer)
    with pytest.raises(DebtNoteError):extract_debt_notes(bad,ds)


NITORI_BORROW='NotesBorrowingsConsolidatedFinancialStatementsIFRSTextBlock'
NITORI_FIN='NotesOtherFinancialLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock'


def nitori(transition=False):
    stem='nitori_2025_transition_debt_notes'if transition else'nitori_2026_debt_notes'
    doc='S100W5DK'if transition else'S100YIMF'
    pages=json.load(gzip.open(F/(stem+'.json.gz'),'rt',encoding='utf8'))
    ds=parse_filing(Filing(doc,code='9843',edinet_code='E03144'),pages)
    return pages,ds


def test_actual_nitori_ifrs_loan_and_lease_components_reconcile_without_using_generic_financial_other():
    pages,ds=nitori();rows=extract_debt_notes(pages,ds);period=ds.periods[-1]
    expected={'short_term_borrowings':'140000000000','current_long_term_borrowings':'10000000000',
              'long_term_borrowings':'10000000000','current_lease':'32923000000','noncurrent_lease':'211078000000'}
    for category,amount in expected.items():assert by_category(rows,category).values[period.key].value==Decimal(amount)
    assert sum(Decimal(v)for v in expected.values())==Decimal('404001000000')
    assert len(rows)==7 and not any('annex'in r.key or':borrowings_coverage:'in r.key for r in rows)
    coverage=by_category(rows,'financial_liabilities_coverage').values[period.key]
    proof=evidence(coverage)
    assert coverage.operation=='financial_liabilities_complete'
    assert proof['scope']=='classified_financial_liabilities_only'
    exclusions={r['label']:r for r in proof['excluded_rows']}
    assert exclusions['その他']['value_jpy']=='1001000000'
    assert exclusions['預り敷金及び保証金']['value_jpy']in {'177000000','9613000000'}
    assert all('not_inferred'in r['reason']for r in proof['excluded_rows'])
    assert {r['section']for r in proof['main_reconciliation']}=={'current','noncurrent'}
    assert all(r['note_total_jpy']==r['main_value_jpy']for r in proof['main_reconciliation'])
    assert by_category(rows,'ifrs_borrowings_coverage').values[period.key].operation=='ifrs_borrowings_complete'


def test_actual_ifrs_transition_opening_column_is_explicitly_excluded_from_all_annual_inputs():
    pages,ds=nitori(True);rows=extract_debt_notes(pages,ds);prior,current=ds.periods
    assert [p.end.isoformat()for p in ds.periods]==['2024-03-31','2025-03-31']
    assert all(set(r.values)=={prior.key,current.key}for r in rows)
    assert by_category(rows,'short_term_borrowings').values[prior.key].value==Decimal('80227000000')
    assert by_category(rows,'current_lease').values[prior.key].value==Decimal('34380000000')
    assert by_category(rows,'noncurrent_lease').values[current.key].value==Decimal('210721000000')
    for r in rows:
        for c in r.values.values():
            excluded=evidence(c)['excluded_columns']
            assert len(excluded)==1 and excluded[0]['date']=='2023-04-01'
            assert '移行日'in excluded[0]['column_header']
            assert excluded[0]['reason']=='explicit_ifrs_transition_opening_not_an_annual_period'


def test_transition_opening_amounts_cannot_contaminate_annual_debt_but_unmarked_extra_date_is_rejected():
    pages,ds=nitori(True);original=extract_debt_notes(pages,ds)
    changed=mutate_chugai(pages,NITORI_BORROW,lambda n:replace_text(n,'40,000','9,999,999'))
    changed=mutate_chugai(changed,NITORI_FIN,lambda n:replace_text(n,'35,438','8,888,888'))
    actual=extract_debt_notes(changed,ds)
    monetary=lambda rs:{r.key:{p:c.value for p,c in r.values.items()}for r in rs}
    assert monetary(actual)==monetary(original)
    bad=mutate_chugai(pages,NITORI_FIN,lambda n:replace_text(n,'移行日','参考日'))
    with pytest.raises(DebtNoteError,match='日付'):extract_debt_notes(bad,ds)


def test_nitori_ifrs_date_namespace_and_main_loan_conflicts_are_not_covered_by_a_scope_marker():
    pages,ds=nitori()
    bad=mutate_chugai(pages,NITORI_BORROW,lambda n:replace_text(n,'2026年３月31日','2027年３月31日'))
    with pytest.raises(DebtNoteError,match='日付|残高列'):extract_debt_notes(bad,ds)
    # The exact note filename varies by company; modify the standard URI in
    # whichever chapter actually carries the notes, without touching BS input.
    wrong_ns=[[f,h.replace('/jpigp_cor','/unknown_cor')]if NITORI_BORROW in h else[f,h]for f,h in pages]
    with pytest.raises(DebtNoteError,match='タクソノミ'):extract_debt_notes(wrong_ns,ds)
    for r in ds.rows['BS_LE']:
        for c in r.values.values():
            if c.source.concept.endswith('}BorrowingsCLIFRS'):c.value+=Decimal('1000000000')
    with pytest.raises(DebtNoteError,match='本表'):extract_debt_notes(pages,ds)


def test_nitori_financial_other_is_not_silently_reclassified_if_caption_changes_to_unknown_loan():
    pages,ds=nitori()
    def unknown_loan(node):
        td=next(td for td in node.iter('td')if ''.join(td.itertext()).strip()=='その他')
        replace_text(td,'その他','未識別借入金')
    bad=mutate_chugai(pages,NITORI_FIN,unknown_loan)
    with pytest.raises(DebtNoteError):extract_debt_notes(bad,ds)
    bad=mutate_chugai(pages,NITORI_BORROW,lambda n:replace_text(n,'１年内長期借入金','長期借入金'))
    with pytest.raises(DebtNoteError,match='区分外'):extract_debt_notes(bad,ds)


def test_nitori_ifrs_note_subtotal_mismatch_fails_even_when_main_balance_was_originally_valid():
    pages,ds=nitori()
    bad=mutate_chugai(pages,NITORI_BORROW,lambda n:replace_text(n,'150,000','160,000'))
    with pytest.raises(DebtNoteError,match='明細と区分合計'):extract_debt_notes(bad,ds)
