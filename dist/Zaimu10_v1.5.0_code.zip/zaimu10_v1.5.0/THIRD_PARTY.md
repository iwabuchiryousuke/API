# データ・ライブラリの出典

## 財務データ

金融庁EDINETの公式公開情報を使用します。

- [EDINETトップページ](https://disclosure2.edinet-fsa.go.jp/)
- [公式の書類検索画面](https://disclosure2.edinet-fsa.go.jp/WEEE0030.aspx)
- [EDINETコードリスト](https://disclosure2dl.edinet-fsa.go.jp/searchdocument/codelist/Edinetcode.zip)
- 原文閲覧URL：`https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?書類ID`

銘柄コードと提出者の対応には、公式EDINETコードリストのCSVを使用します。**財務数値は各有価証券報告書の公開原文から取得します。** 通常は勘定別inline XBRL、借入金等の補足は原文TextBlock内の明細表を読みます。勘定別の数値タグがない古いIFRS本表は、明示的な年度列・単位・物理セル位置を検証して取得し、合成した表示上の役割と実在のXBRL QNameを区別します。有料データ、バフェットコードAPI、EDINET APIキーは使用していません。

開示資料の作成者は各提出会社です。本プログラムが生成するExcel・監査JSONには元書類を追跡できる識別子とURLを記録します。財務資料やEDINETの画面素材に本プログラムのライセンスを適用するものではありません。

回帰テストには、図研、ドーン、トリケミカル研究所、ニトリホールディングス、フルヤ金属、中外製薬の公開原文や訂正報告書を使用しています。図研の代表例は有価証券報告書第49期（提出日2025年6月20日、書類ID **S100W07I**）です。

- [図研 S100W07I の原文閲覧](https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?S100W07I)
- 各フィクスチャの書類ID・対象期間・保存形式・照合目的：[tests/fixtures/README.md](tests/fixtures/README.md)

同梱の原文フィクスチャは取得・解析・訂正分類・表示整理の回帰検証用です。公開閲覧のセッション状態・Cookie・トークンを含めず、原文の名前空間やQNameを保持しています。

## 決算発表日・発表予定

- [JPX上場会社情報サービス](https://www2.jpx.co.jp/tseHpFront/JJK010010Action.do?Show=Show)：個社の適時開示情報にある本決算短信のタイトル・発表日・PDFリンク。
- [JPX決算発表予定日](https://www.jpx.co.jp/listing/event-schedules/financial-announcement/index.html)：公表済みの予定一覧。本決算・四半期の種別と対象期を確認します。
- 各社公式IRカレンダー：会社が明示した発表予定。取り込んだイベントごとに実際のURL・タイトルを保存します。

有価証券報告書の提出日を決算発表日に流用しません。第三者の推測日を公式予定として取り込みません。日付のキャッシュと登録履歴にも出典・取得日時を残します。

## 書式テンプレート

`zaimu10/assets/financial_template.xlsx`は、ユーザー提供のフルヤ金属の見本Excelから書式とラベルを抽出して作成した表示用テンプレートです。列幅・行高・罫線・色・フォント等を参照します。元の金額・数式・コメント・外部リンク・定義名は含めていません。

財務数値の取得元はEDINET原文です。見本の金額や手作業集計を対象企業の値として転用しません。出力する計算式は、原文から取得した数値と明示した項目対応に基づいてプログラムが生成します。原資料や書式の権利を、下記のPythonライブラリのライセンスへ変更するものではありません。

## Pythonライブラリ

ライブラリ本体は初回セットアップで通常のPythonパッケージとしてインストールします。各ライブラリにはそれぞれのライセンスが適用されます。正確な版はインストールされた環境で`python -m pip freeze`により確認できます。

|ライブラリ|用途|公開元・ライセンス|
|---|---|---|
|requests|HTTPS通信|[プロジェクト](https://github.com/psf/requests)・Apache-2.0|
|lxml|HTML／XML／inline XBRLの解析|[プロジェクト](https://lxml.de/)・BSD系。詳細は配布物のLICENSESを参照|
|cryptography|公式閲覧画面の応答処理|[プロジェクト](https://cryptography.io/)・Apache-2.0／BSD-3-Clause|
|openpyxl|Excel生成|[プロジェクト](https://openpyxl.readthedocs.io/)・MIT|
|Beautiful Soup 4|公開検索結果のHTML解析|[プロジェクト](https://www.crummy.com/software/BeautifulSoup/)・MIT|
|pytest（テスト用）|回帰テスト|[プロジェクト](https://pytest.org/)・MIT|

Python標準ライブラリとTkinterも使用します。Python・Tcl/Tkのライセンスは、それぞれの公式配布物を参照してください。


## v1.5.0で追加した市場データ

- Yahoo!ファイナンス（日本）公開株価時系列: `https://finance.yahoo.co.jp/quote/6947.T/history`。月次の調整後終値（分割等調整）をCAPM、日次の名目終値を期末時価総額に使用。国内株の時系列は同サイトがNRI提供と説明。表・年月日・項目・単位・取得URL・SHAを保持し、HTML内のスクリプトやトークンはキャッシュしない。
- Yahoo Finance公開Chart: `https://query1.finance.yahoo.com/v8/finance/chart/6947.T`（銘柄部分を置換）、日経平均 `^N225`。日経平均、実取引日、権利落ち日・分割等の補助確認と国内配信値との照合。原応答をハッシュと取得時刻付きで保存。海外配信の国内株価と国内時系列が相違する場合、国内価格を採用し、差額と両出典を記録。公開データにAPIキー不要。
- EDINET「株式等の状況」の事業年度末発行済株式数。提出日現在の株式数やEPSの期中平均を代用しない。原本の数値タグ、古い年度は実在するTextBlock内の年月日・株単位・普通株式行・合計行を照合して取得。
- CAPMのRf1.03%・ERP5.63%は利用者提供見本の固定仮定。市場サイトから現在値として取得した値ではない。
- 追加テンプレートは利用者提供2ファイルから書式・ラベル・明示仮定のみを抽出。会社別の過去価格・財務数値・予測値・式の外部リンクは含めない。

公式のデータ説明: [調整後終値](https://support.yahoo-net.jp/PccFinance/s/article/H000006678)、[四本値](https://support.yahoo-net.jp/PccFinance/s/article/H000006682)、[時系列データの提供元](https://support.yahoo-net.jp/PccFinance/s/article/H000006667)。

### 国内履歴取得失敗時の代替

- [株探（Kabutan）の公開月足](https://kabutan.jp/stock/kabuka?code=4519&ashi=mon)：公開された修正株価を元資料の表示精度で採用。同一銘柄のβ用系列全体を同じ資料にそろえる。
- [96UT公開株価履歴](https://96ut.com/)：会社コード・年度・日付が明示された日足から期末の名目終値を取得。現在の分割換算後株価を当時の名目終値と混同しない。具体的な取得URLは各CAPMセルと監査JSONに記録。
- 金融庁有報の株式数・分割注記と組み合わせて期末の株式基準を照合。中外製薬の2020年分割は[会社公式発表](https://www.chugai-pharm.co.jp/news/detail/20200121170000_931.html)でも確認。

各資料の公表精度・分割調整方法は同一ではない。未掲載日や異なる価格を無条件に同じ資料として合成せず、採用した方式と切替理由を記録する。
