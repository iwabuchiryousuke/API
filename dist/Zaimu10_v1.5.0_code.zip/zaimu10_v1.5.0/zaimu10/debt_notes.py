"""Read specifically identified EDINET borrowing schedules as audit inputs.

These rows supplement balance-sheet disclosures; they are not new BS totals.
In particular a borrowing-schedule total must never replace interest-bearing
debt: some published schedules omit a short-term balance shown in the BS.
Every extracted amount retains its real TextBlock, context and physical cell.
"""
from __future__ import annotations

from datetime import timedelta
from decimal import Decimal, InvalidOperation
import json
import re
import unicodedata

from lxml import etree, html

from .models import Cell, Dataset, Row, Source
from .parser import Page, ParseError, _contexts, _expanded, _local, _namespaces, _text


class DebtNoteError(ValueError):
    """Recognized debt evidence is malformed, ambiguous, or unsupported."""

    def __init__(self, message: str, *, periods: list[str] | None = None):
        super().__init__(message)
        self.periods = periods


_BORROWING_CATEGORIES = (
    'short_term_borrowings', 'current_long_term_borrowings', 'current_lease',
    'long_term_borrowings', 'noncurrent_lease',
)
_LABELS = {
    'short_term_borrowings': '短期借入金',
    'current_long_term_borrowings': '1年内返済予定の長期借入金',
    'current_lease': '1年内返済予定のリース債務',
    'long_term_borrowings': '長期借入金', 'noncurrent_lease': 'リース債務（非流動）',
    'bonds': '社債', 'current_bonds': '1年内償還予定の社債',
    'commercial_paper': 'コマーシャル・ペーパー',
    'other_interest_bearing_debt': 'その他の有利子負債',
    'borrowings_coverage': '借入金等明細表（検証済み対象範囲）',
    'borrowings_absent': '借入金等明細表（該当事項なし）',
    'bonds_absent': '社債明細表（該当事項なし）',
    'current_lease_coverage': 'その他の流動負債注記（検証済み対象範囲）',
    'noncurrent_lease_coverage': 'その他の非流動負債注記（検証済み対象範囲）',
    'nonlease_debt_absent': '非リース有利子負債（残高なしの明示）',
    'ifrs_borrowings_coverage': 'IFRS借入金注記（借入範囲の検証）',
    'financial_liabilities_coverage': 'IFRSその他金融負債注記（分類残高の検証）',
}
_DASHES = {'-', '−', '－', '―', '—', '–', 'ー', '─'}
_INTEREST_DEPOSIT_CAPTIONS = {'その他有利子負債預り金', 'その他の有利子負債預り金'}
_STANDARD_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpcrp/\d{4}-\d{2}-\d{2}/jpcrp_cor\Z')
_BLOCK_NAME = re.compile(
    r'Annexed(?P<consolidated>Consolidated)?DetailedScheduleOf'
    r'(?P<kind>Borrowings|CorporateBonds)(?:FinancialStatements)?(?:NA)?TextBlock\Z')
_IFRS_LIABILITY_NOTES = {
    'NotesOtherCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('current_lease','その他の流動負債','OtherCurrentLiabilitiesCLIFRS'),
    'NotesOtherNonCurrentLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('noncurrent_lease','その他の非流動負債','OtherNonCurrentLiabilitiesNCLIFRS'),
}
_IFRS_SECTION_NOTES = {
    'NotesBorrowingsConsolidatedFinancialStatementsIFRSTextBlock':
        ('ifrs_borrowings','借入金','ifrs_borrowings_coverage','ifrs_borrowings_complete'),
    'NotesOtherFinancialLiabilitiesConsolidatedFinancialStatementsIFRSTextBlock':
        ('ifrs_financial_liabilities','その他の金融負債','financial_liabilities_coverage','financial_liabilities_complete'),
}
_IFRS_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/taxonomy/jpigp/\d{4}-\d{2}-\d{2}/jpigp_cor\Z')
_RISK_LOCAL = 'NotesRiskManagementConsolidatedFinancialStatementsIFRSTextBlock'
_CHUGAI_URI = re.compile(r'https?://disclosure\.edinet-fsa\.go\.jp/jpcrp030000/asr/001/E00932-000/\d{4}-\d{2}-\d{2}/\d+/\d{4}-\d{2}-\d{2}\Z')
_NONLEASE_OPENING = '当社グループが保有する有利子負債及び貸付金の残高はなく、リース負債は'
_NONLEASE_STATEMENT = _NONLEASE_OPENING + 'リース契約の規模及び現在の低金利の経済状況を鑑みると当社グループにおける金利リスクは軽微です。'


def _compact(value: str) -> str:
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or ''))


def _visible(element) -> bool:
    for ancestor in [element, *element.iterancestors()]:
        style = _compact(ancestor.get('style', '')).lower()
        if ancestor.get('hidden') is not None or 'display:none' in style or 'visibility:hidden' in style:
            return False
    return True


def _own_rows(table):
    def owner(node, name):
        return next((a for a in node.iterancestors() if _local(a.tag) == name), None)
    return [node for node in table.iter() if isinstance(node.tag, str)
            and _local(node.tag) == 'tr' and owner(node, 'table') is table]


def _grid(table):
    rows = _own_rows(table)
    grid, remaining = [], {}
    physical = {}
    for ri, tr in enumerate(rows, 1):
        cells = [node for node in tr if isinstance(node.tag, str) and _local(node.tag) in {'td', 'th'}]
        current, next_remaining = {}, {}
        for col, (cell, count) in remaining.items():
            current[col] = cell
            if count > 1:
                next_remaining[col] = (cell, count - 1)
        column = 0
        for ci, cell in enumerate(cells, 1):
            physical[cell] = (ri, ci)
            while column in current:
                column += 1
            try:
                colspan = int(cell.get('colspan', '1'))
                rowspan = int(cell.get('rowspan', '1'))
            except (TypeError, ValueError):
                raise DebtNoteError('借入金等明細表のセル結合を読めません。') from None
            if not (1 <= colspan <= 30 and 1 <= rowspan <= 100):
                raise DebtNoteError('借入金等明細表のセル結合が対応範囲外です。')
            for offset in range(colspan):
                if column + offset in current:
                    raise DebtNoteError('借入金等明細表のセル範囲が重複しています。')
                current[column + offset] = cell
                if rowspan > 1:
                    next_remaining[column + offset] = (cell, rowspan - 1)
            column += colspan
        grid.append(current)
        remaining = next_remaining
    if remaining:
        raise DebtNoteError('借入金等明細表の結合セルが表の外へ続いています。')
    return rows, grid, physical


def _category(label: str) -> str | None:
    label = _compact(label)
    label = re.sub(r'[（(]注\d*[)）]$', '', label)
    if label in {'短期借入金', '短期借入れ', '短期借入'}:
        return 'short_term_borrowings'
    if label in {'1年内長期借入金','1年以内長期借入金'}:
        return 'current_long_term_borrowings'
    current = bool(re.search(r'1年(?:以)?内(?:に)?(?:返済|償還)予定', label))
    excludes = '除く' in label
    if '長期借入金' in label:
        if current and not excludes:
            return 'current_long_term_borrowings'
        if label.startswith('長期借入金') and (label == '長期借入金' or excludes):
            return 'long_term_borrowings'
    if 'リース債務' in label or 'リース負債' in label:
        if current and not excludes:
            return 'current_lease'
        if re.search(r'[（(]流動(?:負債)?[)）]', label):
            return 'current_lease'
        if excludes or re.search(r'[（(](?:非流動|固定)(?:負債)?[)）]', label):
            return 'noncurrent_lease'
    if label in {'コマーシャル・ペーパー', 'コマーシャルペーパー', 'CP'}:
        return 'commercial_paper'
    if label in {'その他の有利子負債', 'その他有利子負債',
                 'その他有利子負債預り金', 'その他の有利子負債預り金'}:
        return 'other_interest_bearing_debt'
    return None


def _amount(raw: str) -> tuple[Decimal, str]:
    value = _compact(raw)
    if value in _DASHES:
        return Decimal(0), 'explicit_no_balance'
    if not re.fullmatch(r'\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?', value):
        raise DebtNoteError(f'借入金等明細表の残高を確定できません: {raw!r}')
    try:
        parsed = Decimal(value.replace(',', ''))
    except InvalidOperation:
        raise DebtNoteError(f'借入金等明細表の残高が数値ではありません: {raw!r}') from None
    if not parsed.is_finite() or parsed < 0:
        raise DebtNoteError('借入金等明細表の残高が非有限値または負数です。')
    return parsed, ''


def _dates(value: str):
    from datetime import date
    value = _compact(value)
    result = []
    for year, month, day in re.findall(r'(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})日?', value):
        try:
            result.append(date(int(year), int(month), int(day)))
        except ValueError:
            raise DebtNoteError('借入金等明細表の列見出しの日付が不正です。') from None
    for era, year, month, day in re.findall(r'(令和|平成|昭和)(元|\d+)年(\d{1,2})月(\d{1,2})日', value):
        try:
            number = 1 if year == '元' else int(year)
            result.append(date({'令和':2018, '平成':1988, '昭和':1925}[era] + number,
                               int(month), int(day)))
        except ValueError:
            raise DebtNoteError('借入金等明細表の和暦日付が不正です。') from None
    return result


def _unit(headers: list[str], block, table) -> tuple[str, int]:
    known = {'千円':3, '百万円':6, '円':0}
    def found(text):
        return set(re.findall(r'百万円|千円|(?<![万千])円', _compact(text)))
    units = found(' '.join(headers))
    if not units:
        prefix = []
        for node in block.iter():
            if node is table:
                break
            if node.text:
                prefix.append(node.text)
            if node is not block and node.tail:
                prefix.append(node.tail)
        units = found(' '.join(prefix))
    if len(units) != 1:
        raise DebtNoteError('借入金等明細表の円・千円・百万円の単位を一意に確認できません。')
    name = next(iter(units))
    return name, known[name]


def _source(base: Source, filename: str, qname: str, context: str, label: str,
            raw: str, basis: str, scale: int) -> Source:
    return Source(base.doc_id, filename, base.url, submitted=base.submitted,
                  context_id=context, concept=qname, unit='JPY', decimals=str(-scale),
                  original_label=label, raw_value=raw, scale=scale, basis=basis)


def _note(evidence: dict, message: str) -> str:
    return message + '\ndebt_note_evidence:' + json.dumps(evidence, ensure_ascii=False, separators=(',', ':'))


def _ifrs_liability_note(block, page_tables, dataset, current, previous, context,
                         specification, put):
    """Read carrying amounts, never undiscounted lease maturity cash flows."""
    category,title,parent_local=specification
    scoped=[p.key for p in previous+current]
    tables=[n for n in block.iter() if isinstance(n.tag,str) and _local(n.tag)=='table' and _visible(n)]
    candidates=[]
    expected_dates={context.end,context.start-timedelta(days=1)}
    for ti,table in enumerate(tables,1):
        rows,grid,physical=_grid(table)
        for hi,cells in enumerate(grid):
            dates={col:_dates(_text(cell)) for col,cell in cells.items()}
            dated={col:values[0] for col,values in dates.items() if len(values)==1}
            if not dated:
                continue
            if len(dated)!=2 or set(dated.values())!=expected_dates:
                raise DebtNoteError('その他負債注記の年度列が本表と一致しないか、既知の3列形式ではありません。',periods=scoped)
            # EDINET often inserts physically blank spacer columns. They are
            # not financial columns, and every later value in them is checked.
            label_cols={col for col in set(cells)-set(dated)
                        if any(_compact(_text(row[col]))for row in grid[hi+1:]if col in row)}
            if len(label_cols)!=1:
                raise DebtNoteError('その他負債注記の項目列を一意に識別できません。',periods=scoped)
            candidates.append((ti,table,grid,physical,hi,label_cols.pop(),dated))
    if len(candidates)!=1:
        raise DebtNoteError('その他負債注記の残高表を一意に識別できません。',periods=scoped)
    ti,table,grid,physical,hi,label_col,dated=candidates[0]
    header_texts=[_text(c) for row in grid[:hi+1] for c in set(row.values())]
    unit_name,scale=_unit(header_texts,block,table)
    proof=[];sums={col:Decimal(0) for col in dated};totals={};lease_seen=False
    for ri in range(hi+1,len(grid)):
        cells=grid[ri]
        if not any(_compact(_text(c)) for c in set(cells.values())):
            continue
        semantic_columns={label_col,*dated}
        if not semantic_columns<=set(cells) or any(_compact(_text(cell))for col,cell in cells.items()if col not in semantic_columns):
            raise DebtNoteError('その他負債注記の明細列が欠けています。',periods=scoped)
        label=_text(cells[label_col]);name=_compact(label)
        total=name in {'合計','計','総合計'}
        lease=name in {'リース負債','リース債務'}
        if lease and lease_seen:
            raise DebtNoteError('その他負債注記に同じリース残高が複数行あります。',periods=scoped)
        if lease:lease_seen=True
        if not lease and not total and any(t in name for t in ['借入','社債','リース','有利子']):
            raise DebtNoteError('その他負債注記に未識別の有利子残高があります: '+label,periods=scoped)
        row_proof={'label':label,'physical_row':ri+1,'values':{}}
        for col,end in dated.items():
            cell=cells[col]
            if any(n.get('xsi:nil','').lower() in {'true','1'}or n.get('continuedat')for n in cell.iter()):
                raise DebtNoteError('その他負債注記の残高にnil・継続参照があります。',periods=scoped)
            raw=_text(cell);amount,operation=_amount(raw);amount*=Decimal(10)**scale
            row_proof['values'][end.isoformat()]={'raw':raw,'value_jpy':str(amount)}
            if total:
                if col in totals:raise DebtNoteError('その他負債注記に複数の合計があります。',periods=scoped)
                totals[col]=amount
            else:sums[col]+=amount
            if lease:
                pri=[p for p in previous+current if p.end==end]
                physical_row,physical_col=physical[cell]
                for period in pri:
                    put(category,period,amount,raw,operation,
                        {'kind':'ifrs_other_liabilities','table_index':ti,
                         'page_table_index':page_tables.index(table)+1,
                         'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                         'balance_column':'closing','column_header':_text(grid[hi][col]),
                         'unit_label':unit_name,'scale':scale,'raw_value':raw,'parent_local':parent_local},label,scale)
        proof.append(row_proof)
    if set(totals)!=set(dated):
        raise DebtNoteError('その他負債注記の各年度の合計を確認できません。',periods=scoped)
    tolerance=Decimal(10)**scale*Decimal(len(proof)+1)
    for col,reported in totals.items():
        if abs(sums[col]-reported)>tolerance:
            raise DebtNoteError('その他負債注記の内訳と合計が丸め許容差を超えています。',periods=scoped)
        for period in [p for p in previous+current if p.end==dated[col]]:
            parents=[c for row in dataset.rows['BS_LE'] for key,c in row.values.items()
                     if key==period.key and c.source.concept.rsplit('}',1)[-1]==parent_local]
            if any(c.value is not None and not c.nil and abs(c.value-reported)>tolerance for c in parents):
                raise DebtNoteError('その他負債注記の合計と本表の同区分残高が一致しません。',periods=[period.key])
            put(category+'_coverage',period,None,_text(table),'lease_note_complete',
                {'kind':'ifrs_other_liabilities_coverage','table_index':ti,
                 'page_table_index':page_tables.index(table)+1,'unit_label':unit_name,'scale':scale,
                 'rows':proof,'parent_local':parent_local,'lease_row_present':lease_seen,
                 'reported_note_total_jpy':str(reported),'component_sum_jpy':str(sums[col]),
                 'rounding_tolerance_jpy':str(tolerance)},scale=scale)


def _chugai_nonlease_absence(block, current, put):
    """A narrow issuer-specific explicit claim, not a fuzzy no-debt search."""
    paragraphs=[n for n in block.iter() if isinstance(n.tag,str) and _local(n.tag)=='p']
    statements=[]
    for pi,node in enumerate(paragraphs,1):
        text=_text(node);normalized=_compact(text)
        if not normalized.startswith(_NONLEASE_OPENING):continue
        previous=node.getprevious()
        while previous is not None and not _compact(_text(previous)):
            previous=previous.getprevious()
        if previous is None or _compact(_text(previous))!='金利リスク':continue
        if normalized==_NONLEASE_STATEMENT:
            statements.append((pi,text))
    if not statements:return
    if len(statements)!=1:
        raise DebtNoteError('非リース有利子負債なしの限定文が複数あります。',periods=[p.key for p in current])
    pi,text=statements[0]
    ev={'kind':'explicit_nonlease_absence','statement':text,'paragraph_index':pi,
        'scope':'nonlease_only','table_index':None,'physical_row':None,'physical_column':None,
        'balance_column':'end'}
    for period in current:
        put('nonlease_debt_absent',period,Decimal(0),text,'explicit_no_nonlease_debt',ev)
        for category in ['short_term_borrowings','current_long_term_borrowings','long_term_borrowings',
                         'bonds','current_bonds','commercial_paper']:
            put(category,period,Decimal(0),text,'explicit_no_balance',ev)


def _ifrs_sectioned_note(block,page_tables,dataset,current,previous,context,specification,evidence_source,put):
    """Classified loan/lease balances with explicit current/noncurrent groups.

    Other financial lines are fully reconciled but never reclassified as debt.
    A transition opening column is excluded only when it says 移行日 and has a
    dated balance earlier than the prior annual closing balance.
    """
    kind,_,status,operation=specification
    scoped=[p.key for p in previous+current]
    expected_dates={context.end,context.start-timedelta(days=1)}
    tables=[n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='table'and _visible(n)]
    candidates=[]
    for ti,table in enumerate(tables,1):
        _,grid,physical=_grid(table)
        for hi,cells in enumerate(grid):
            raw_dates={col:_dates(_text(cell))for col,cell in cells.items()}
            if not any(raw_dates.values()):continue
            annual={};excluded=[]
            for col,dates in raw_dates.items():
                if not dates:continue
                if len(dates)!=1:
                    raise DebtNoteError('IFRS負債注記の残高列に複数の日付があります。',periods=scoped)
                day=dates[0];header=_text(cells[col])
                if day in expected_dates:
                    if '移行日'in _compact(header):
                        raise DebtNoteError('IFRS移行日を年次残高列として扱いません。',periods=scoped)
                    annual[col]=day
                elif '移行日'in _compact(header)and day<min(expected_dates):
                    ri,ci=physical[cells[col]]
                    excluded.append({'expanded_column':col+1,'physical_row':ri,'physical_column':ci,
                                     'date':day.isoformat(),'column_header':header,
                                     'reason':'explicit_ifrs_transition_opening_not_an_annual_period'})
                else:
                    raise DebtNoteError('IFRS負債注記に対象外又は未識別の日付列があります。',periods=scoped)
            if len(annual)!=2 or set(annual.values())!=expected_dates or len(excluded)>1:
                raise DebtNoteError('IFRS負債注記の2年次残高列を一意に識別できません。',periods=scoped)
            rates=[col for col,c in cells.items()if '平均利率'in _compact(_text(c))]
            dues=[col for col,c in cells.items()if _compact(_text(c))=='返済期限']
            if kind=='ifrs_borrowings'and(len(rates)!=1 or len(dues)!=1):
                raise DebtNoteError('IFRS借入金注記の利率・期限列を確認できません。',periods=scoped)
            if kind!='ifrs_borrowings'and(rates or dues):
                raise DebtNoteError('IFRSその他金融負債注記に未知の追加列があります。',periods=scoped)
            dated=set(annual)|{e['expanded_column']-1 for e in excluded}
            other=set(rates+dues)
            labels={col for col in set(cells)-dated-other
                    if any(_compact(_text(row[col]))for row in grid[hi+1:]if col in row)}
            if len(labels)!=1:
                raise DebtNoteError('IFRS負債注記の項目列を一意に識別できません。',periods=scoped)
            candidates.append((ti,table,grid,physical,hi,labels.pop(),annual,excluded,other))
    if len(candidates)!=1:
        raise DebtNoteError('IFRS負債注記の残高表を一意に識別できません。',periods=scoped)
    ti,table,grid,physical,hi,label_col,annual,excluded,other=candidates[0]
    unit_name,scale=_unit([_text(c)for row in grid[:hi+1]for c in set(row.values())],block,table)
    excluded_cols={e['expanded_column']-1 for e in excluded}
    semantic={label_col,*annual,*excluded_cols,*other}
    headers=({'流動負債':'current','非流動負債':'noncurrent'}if kind=='ifrs_borrowings'else
             {'その他の金融負債(流動)':'current','その他の金融負債(非流動)':'noncurrent'})
    parent_names=({'current':'BorrowingsCLIFRS','noncurrent':'BorrowingsNCLIFRS'}if kind=='ifrs_borrowings'else
                  {'current':'OtherFinancialLiabilitiesCLIFRS','noncurrent':'OtherFinancialLiabilitiesNCLIFRS'})
    group=None;seen_groups=set();totals={};sums={};proof=[];excluded_rows={p.key:[]for p in previous+current};seen_categories=set()
    for ri in range(hi+1,len(grid)):
        cells=grid[ri]
        if not any(_compact(_text(c))for c in set(cells.values())):continue
        if not semantic<=set(cells)or any(_compact(_text(c))for col,c in cells.items()if col not in semantic):
            raise DebtNoteError('IFRS負債注記の明細列が欠けるか、スペーサーに未知の値があります。',periods=scoped)
        label=_text(cells[label_col]);name=_compact(label).rstrip(':：')
        if name in headers:
            group=headers[name]
            if group in seen_groups or any(_compact(_text(cells[c]))and cells[c]is not cells[label_col]for c in annual):
                raise DebtNoteError('IFRS負債注記の流動・非流動見出しが重複するか残高と混在しています。',periods=scoped)
            seen_groups.add(group);continue
        if kind!='ifrs_borrowings'and name=='償却原価で測定される金融負債':
            if any(_compact(_text(cells[c]))for c in annual):
                raise DebtNoteError('金融負債の分類見出しに未識別の残高があります。',periods=scoped)
            continue
        if group is None:
            raise DebtNoteError('IFRS負債注記の残高行の流動・非流動区分が不明です。',periods=scoped)
        total=name in {'合計','計','総合計'}
        stripped=re.sub(r'\(注\d*\)$','',name)
        if kind=='ifrs_borrowings':
            category=_category(label)
            allowed={'short_term_borrowings','current_long_term_borrowings'}if group=='current'else{'long_term_borrowings'}
            if category not in allowed and not total:
                raise DebtNoteError('IFRS借入金注記に未識別又は区分外の借入残高があります: '+label,periods=scoped)
        else:
            category=('current_lease'if group=='current'else'noncurrent_lease')if stripped in {'リース負債','リース債務'}else None
            if not category and not total and any(t in name for t in ['借入','社債','リース','有利子']):
                raise DebtNoteError('IFRSその他金融負債注記に未識別の有利子項目があります: '+label,periods=scoped)
        if category:
            if category in seen_categories:
                raise DebtNoteError('IFRS負債注記の同一カテゴリが重複しています: '+label,periods=scoped)
            seen_categories.add(category)
        rowproof={'label':label,'section':group,'category':category,'physical_row':ri+1,'values':{}}
        for col,day in annual.items():
            cell=cells[col]
            if any(n.get('xsi:nil','').lower()in{'true','1'}or n.get('continuedat')for n in cell.iter()):
                raise DebtNoteError('IFRS負債注記の残高にnil・継続参照があります。',periods=scoped)
            raw=_text(cell);amount,zero_operation=_amount(raw);amount*=Decimal(10)**scale
            rowproof['values'][day.isoformat()]={'raw':raw,'value_jpy':str(amount)}
            pair=group,col
            if total:
                if pair in totals:raise DebtNoteError('IFRS負債注記の同一区分合計が重複しています。',periods=scoped)
                totals[pair]=amount
            else:sums[pair]=sums.get(pair,Decimal(0))+amount
            for period in [p for p in previous+current if p.end==day]:
                physical_row,physical_col=physical[cell]
                ev={'kind':kind,'table_index':ti,'page_table_index':page_tables.index(table)+1,
                    'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                    'balance_column':'closing','column_header':_text(grid[hi][col]),'section':group,
                    'unit_label':unit_name,'scale':scale,'raw_value':raw,'excluded_columns':excluded,
                    'parent_local':parent_names[group]}
                if category:
                    put(category,period,amount,raw,zero_operation,ev,label,scale)
                elif not total:
                    excluded_rows[period.key].append({'label':label,'value_jpy':str(amount),'raw_value':raw,
                        'section':group,'physical_row':physical_row,'physical_column':physical_col,'expanded_column':col+1,
                        'source':evidence_source,'unit_label':unit_name,'scale':scale,
                        'reason':'outside_reference_core_and_not_explicitly_interest_bearing; interest_nature_not_inferred'})
        proof.append(rowproof)
    required={(group,col)for group in ['current','noncurrent']for col in annual}
    if seen_groups!={'current','noncurrent'}or set(totals)!=required:
        raise DebtNoteError('IFRS負債注記の流動・非流動の両合計を確認できません。',periods=scoped)
    tolerance=Decimal(10)**scale*Decimal(len(proof)+1)
    reconciled={p.key:[]for p in previous+current}
    for (group,col),reported in totals.items():
        if abs(sums.get((group,col),Decimal(0))-reported)>tolerance:
            raise DebtNoteError('IFRS負債注記の明細と区分合計が一致しません。',periods=scoped)
        for period in [p for p in previous+current if p.end==annual[col]]:
            parents=[c for row in dataset.rows['BS_LE']for key,c in row.values.items()
                     if key==period.key and c.source.concept.rsplit('}',1)[-1]==parent_names[group]]
            if len(parents)!=1 or parents[0].value is None or parents[0].nil:
                raise DebtNoteError('IFRS負債注記に対応する本表の区分残高を一意に確認できません。',periods=[period.key])
            if abs(parents[0].value-reported)>tolerance:
                raise DebtNoteError('IFRS負債注記の区分合計と本表の残高が一致しません。',periods=[period.key])
            reconciled[period.key].append({'section':group,'parent_local':parent_names[group],
                'note_total_jpy':str(reported),'component_sum_jpy':str(sums[group,col]),
                'main_value_jpy':str(parents[0].value),'main_source_concept':parents[0].source.concept})
    for period in previous+current:
        put(status,period,None,_text(table),operation,
            {'kind':status,'scope':'loans_only'if kind=='ifrs_borrowings'else'classified_financial_liabilities_only',
             'table_index':ti,'page_table_index':page_tables.index(table)+1,'unit_label':unit_name,'scale':scale,
             'rows':proof,'excluded_columns':excluded,'excluded_rows':excluded_rows[period.key],
             'main_reconciliation':reconciled[period.key],'rounding_tolerance_jpy':str(tolerance)},scale=scale)


def extract_debt_notes(pages: list[tuple[str, str]], parsed_dataset: Dataset) -> list[Row]:
    """Return source-evidenced categories and coverage/status audit rows.

    Only known EDINET appendix TextBlocks are interpreted. Unknown notes are
    never mined by loose wording. Absence of a category row creates no zero.
    An explicitly printed dash, or an explicit applicable-none statement, can
    establish zero while retaining that exact original evidence.
    """
    dataset = parsed_dataset
    if dataset.basis not in {'consolidated', 'standalone'}:
        raise DebtNoteError('借入注記は年度・連結区分を選択した単一原本から取得してください。')
    parsed = []
    context_entities = {}
    try:
        for filename, markup in pages:
            if isinstance(markup, bytes):
                markup = markup.decode('utf-8-sig')
            if markup.strip():
                root = html.fromstring(markup.lstrip('\ufeff').encode('utf-8'),
                                       parser=html.HTMLParser(encoding='utf-8', no_network=True))
                parsed.append(Page(filename, root, _namespaces(markup)))
        contexts = _contexts(parsed)
        for page in parsed:
            for node in page.root.iter():
                if isinstance(node.tag,str) and _local(node.tag)=='context':
                    identifiers={_text(e) for e in node.iter() if isinstance(e.tag,str)
                                 and _local(e.tag)=='identifier' and _text(e)}
                    context_entities.setdefault(node.get('id',''),set()).update(identifiers)
    except (ValueError, etree.ParserError, ParseError) as exc:
        raise DebtNoteError(f'借入注記のXBRLコンテキストを読めません: {exc}') from exc
    source_candidates = [cell.source for rows in dataset.rows.values() for row in rows
                         for period, cell in row.values.items() if period in {p.key for p in dataset.periods}
                         and cell.source.basis == dataset.basis]
    output = {}
    for page in parsed:
        blocks = [node for node in page.root.iter() if isinstance(node.tag, str)
                  and _local(node.tag) == 'nonnumeric' and _visible(node)]
        page_tables = [node for node in page.root.iter() if isinstance(node.tag, str) and _local(node.tag) == 'table']
        for block_index, block in enumerate(blocks, 1):
            raw_qname = block.get('name', '')
            local = raw_qname.rsplit(':', 1)[-1]
            match = _BLOCK_NAME.fullmatch(local)
            ifrs_note=_IFRS_LIABILITY_NOTES.get(local)
            section_note=_IFRS_SECTION_NOTES.get(local)
            risk=local==_RISK_LOCAL
            if not match and not ifrs_note and not section_note and not risk:
                continue
            basis = 'consolidated' if ifrs_note or section_note or risk or match.group('consolidated') else 'standalone'
            if basis != dataset.basis:
                continue
            try:
                qname = _expanded(raw_qname, page.namespaces)
            except ParseError as exc:
                raise DebtNoteError(str(exc)) from exc
            uri = qname[1:].split('}', 1)[0]
            if risk and not _CHUGAI_URI.fullmatch(uri):
                continue
            if ((ifrs_note or section_note) and not _IFRS_URI.fullmatch(uri)) or (match and not _STANDARD_URI.fullmatch(uri)):
                raise DebtNoteError('借入注記の標準タクソノミを確認できません。')
            context_id = block.get('contextref', '')
            context = contexts.get(context_id)
            if context is None or context.instant or context.start is None or context.dimensions:
                raise DebtNoteError('借入注記の年度・次元コンテキストを確認できません。')
            if context.basis is not None and context.basis != basis:
                raise DebtNoteError('借入注記の見出しと連結区分が一致しません。')
            current = [p for p in dataset.periods if p.start == context.start and p.end == context.end]
            previous = [p for p in dataset.periods if p.end == context.start - timedelta(days=1)]
            if len(current) != 1:
                raise DebtNoteError('借入注記の年度が本表の対象年度と一致しません。', periods=[p.key for p in dataset.periods])
            scoped_periods = [p.key for p in previous + current]
            if block.get('continuedat') or block.get('xsi:nil', '').lower() in {'true', '1'}:
                raise DebtNoteError('継続参照・nilの借入注記から残高を確定できません。', periods=scoped_periods)
            if len({s.doc_id for s in source_candidates}) != 1:
                raise DebtNoteError('借入注記の元書類を一意に確認できません。', periods=scoped_periods)
            base = source_candidates[0]
            issuers=context_entities.get(context_id,set())
            if len(issuers)!=1:
                raise DebtNoteError('借入注記の提出者コンテキストを一意に確認できません。',periods=scoped_periods)
            original_issuer=re.search(r'E\d{5}-\d{3}',base.filename)
            note_issuer=re.search(r'E\d{5}-\d{3}',page.filename)
            if original_issuer and (next(iter(issuers))!=original_issuer.group()
                                    or note_issuer and note_issuer.group()!=original_issuer.group()):
                raise DebtNoteError('借入注記と本表の提出者が一致しません。',periods=scoped_periods)
            text = _text(block)
            title = ifrs_note[1] if ifrs_note else section_note[1]if section_note else 'リスクマネジメント' if risk else '借入金等明細表' if match.group('kind') == 'Borrowings' else '社債明細表'
            if title not in _compact(text):
                raise DebtNoteError('借入注記の標準要素と実際の見出しが一致しません。', periods=scoped_periods)
            evidence_base = {'filename':page.filename, 'block_qname':qname, 'block_context':context_id,
                             'block_index':block_index, 'basis':basis, 'document_id':base.doc_id,
                             'context_period_start':context.start.isoformat(), 'context_period_end':context.end.isoformat()}
            statement = _compact(text).replace('【' + title + '】', '').replace(title, '').strip('。．.')
            no_items = statement in {'該当事項はありません', '該当事項がありません', '該当する事項はありません',
                                     '該当事項はございません', '該当事項なし'}
            def put(category, period, amount, raw, operation, evidence, label=None, scale=0):
                key = f'notes:debt:{category}:{basis}'
                row = output.setdefault(key, Row(key, _LABELS[category], 'BS_LE', section=('借入金等明細表',)))
                if period.key in row.values:
                    raise DebtNoteError('同じ年度の借入注記カテゴリが複数あります: ' + category, periods=[period.key])
                source = _source(base, page.filename, qname, context_id, label or _LABELS[category], raw, basis, scale)
                row.values[period.key] = Cell(amount, source, operation=operation,
                    note=_note({**evidence_base, **evidence, 'category':category,
                                'period_start':period.start.isoformat(), 'period_end':period.end.isoformat()},
                               '原文注記の独立した残高。BS本表の同じ対象残高と重ねて加算しない。'))
            if ifrs_note:
                _ifrs_liability_note(block,page_tables,dataset,current,previous,context,ifrs_note,put)
                continue
            if section_note:
                _ifrs_sectioned_note(block,page_tables,dataset,current,previous,context,section_note,evidence_base,put)
                continue
            if risk:
                _chugai_nonlease_absence(block,current,put)
                continue
            if no_items:
                kind = 'borrowings' if match.group('kind') == 'Borrowings' else 'bonds'
                category = kind + '_absent'
                operation = 'explicit_no_borrowings' if kind == 'borrowings' else 'explicit_no_bonds'
                ev = {'kind':'explicit_none', 'statement':text, 'table_index':None,
                      'physical_row':None, 'physical_column':None, 'balance_column':'end'}
                # A prose-only current-year statement does not silently prove
                # the prior comparative year's closing balances were zero.
                put(category, current[0], Decimal(0), text, operation, ev)
                for covered in _BORROWING_CATEGORIES if kind == 'borrowings' else ('bonds', 'current_bonds'):
                    put(covered, current[0], Decimal(0), text, 'explicit_no_balance', ev)
                continue
            if match.group('kind') != 'Borrowings':
                raise DebtNoteError('社債明細表の内数・償還区分を未確認のため、自動で残高を合算しません。', periods=scoped_periods)
            tables = [node for node in block.iter() if isinstance(node.tag, str) and _local(node.tag) == 'table' and _visible(node)]
            candidates = []
            for table_index, table in enumerate(tables, 1):
                rows, grid, physical = _grid(table)
                for header_index, cells in enumerate(grid):
                    texts = {col:_compact(_text(cell)) for col,cell in cells.items()}
                    beginnings = [col for col,t in texts.items() if any(s in t for s in ['当期首残高','前期末残高','前連結会計年度末残高','前事業年度末残高'])]
                    endings = [col for col,t in texts.items() if any(s in t for s in ['当期末残高','当連結会計年度末残高','当事業年度末残高'])]
                    if beginnings or endings:
                        if len(beginnings) != 1 or len(endings) != 1:
                            raise DebtNoteError('借入金等明細表の期首・期末列が一意ではありません。', periods=scoped_periods)
                        labels = [col for col,t in texts.items() if t == '区分']
                        rates = [col for col,t in texts.items() if '平均利率' in t]
                        dues = [col for col,t in texts.items() if t == '返済期限']
                        if len(labels) != 1 or len(rates) != 1 or len(dues) != 1 or len(set(texts)) != 5:
                            raise DebtNoteError('借入金等明細表の区分・残高・利率・期限の列形式が未対応です。', periods=scoped_periods)
                        columns = labels[0], beginnings[0], endings[0], rates[0], dues[0]
                        if len(set(columns)) != 5:
                            raise DebtNoteError('借入金等明細表の列区分が重複しています。', periods=scoped_periods)
                        candidates.append((table_index,table,rows,grid,physical,header_index,columns))
            if len(candidates) != 1:
                raise DebtNoteError('借入金等明細表の残高表を一意に確認できません。', periods=scoped_periods)
            table_index,table,rows,grid,physical,header_index,columns = candidates[0]
            label_col,begin_col,end_col,rate_col,_ = columns
            header_texts = [_text(grid[header_index][col]) for col in columns]
            unit_name,scale = _unit(header_texts,block,table)
            for col, expected in [(begin_col,context.start-timedelta(days=1)),(end_col,context.end)]:
                if any(day != expected for day in _dates(_text(grid[header_index][col]))):
                    raise DebtNoteError('借入金等明細表の列の日付とXBRL年度が一致しません。', periods=scoped_periods)
            amounts, totals, categories = {'begin':[],'end':[]}, {}, set()
            proof_rows=[]
            for row_index in range(header_index+1,len(grid)):
                cells=grid[row_index]
                if not any(_compact(_text(cell)) for cell in set(cells.values())):
                    continue
                if any(col not in cells for col in columns):
                    raise DebtNoteError('借入金等明細表の明細列が欠けています。', periods=scoped_periods)
                label=_text(cells[label_col]);normalized=_compact(label)
                total = normalized in {'合計','計','総合計'}
                category = _category(label)
                if not total and category is None:
                    raise DebtNoteError('借入金等明細表に未識別の残高行があります: '+label, periods=scoped_periods)
                if normalized in _INTEREST_DEPOSIT_CAPTIONS:
                    rate_raw=_text(cells[rate_col])
                    try:
                        rate,_=_amount(rate_raw.rstrip('%％').strip())
                    except DebtNoteError:
                        raise DebtNoteError('その他有利子負債の預り金について正の平均利率を確認できません。',periods=scoped_periods) from None
                    if rate<=0:
                        raise DebtNoteError('その他有利子負債の預り金について正の平均利率を確認できません。',periods=scoped_periods)
                if category is not None and category in categories:
                    raise DebtNoteError('借入金等明細表に同一カテゴリの複数行があります: '+label, periods=scoped_periods)
                if category is not None:
                    categories.add(category)
                proof_row={'label':label,'category':category,'physical_row':row_index+1,'values':{}}
                for balance,col,period_list in [('begin',begin_col,previous),('end',end_col,current)]:
                    value_cell=cells[col]
                    if any(node.get('xsi:nil','').lower() in {'true','1'} or node.get('continuedat') for node in value_cell.iter()):
                        raise DebtNoteError('借入金等明細表の残高にnil・継続参照があります。', periods=scoped_periods)
                    raw=_text(value_cell);amount,operation=_amount(raw);amount*=Decimal(10)**scale
                    proof_row['values'][balance]={'raw':raw,'value_jpy':str(amount)}
                    ri,ci=physical[value_cell]
                    rate_row,rate_column=physical[cells[rate_col]]
                    ev={'kind':'borrowings_schedule','table_index':table_index,
                        'page_table_index':page_tables.index(table)+1,'physical_row':ri,'physical_column':ci,
                        'expanded_column':col+1,'balance_column':balance,'column_header':_text(grid[header_index][col]),
                        'unit_label':unit_name,'scale':scale,'raw_value':raw,
                        'interest_rate_raw':_text(cells[rate_col]),
                        'interest_rate_column_header':_text(grid[header_index][rate_col]),
                        'interest_rate_physical_row':rate_row,'interest_rate_physical_column':rate_column,
                        'interest_rate_expanded_column':rate_col+1,
                        'interest_rate_positive_required':normalized in _INTEREST_DEPOSIT_CAPTIONS}
                    if total:
                        if balance in totals:
                            raise DebtNoteError('借入金等明細表に複数の合計行があります。', periods=scoped_periods)
                        totals[balance]=amount
                    else:
                        amounts[balance].append(amount)
                        for period in period_list:
                            put(category,period,amount,raw,operation,ev,label,scale)
                proof_rows.append(proof_row)
            if not categories:
                raise DebtNoteError('借入金等明細表の独立した残高行がありません。', periods=scoped_periods)
            tolerance=Decimal(10)**scale*Decimal(len(categories)+1)
            for balance,reported in totals.items():
                calculated=sum(amounts[balance],Decimal(0))
                if abs(calculated-reported)>tolerance:
                    raise DebtNoteError('借入金等明細表の内訳と合計が丸め許容差を超えて一致しません。', periods=scoped_periods)
            for period,balance in [(p,'begin')for p in previous]+[(p,'end')for p in current]:
                put('borrowings_coverage',period,None,text,'debt_schedule_complete',
                    {'kind':'borrowings_schedule_coverage','table_index':table_index,
                     'page_table_index':page_tables.index(table)+1,'balance_column':balance,
                     'unit_label':unit_name,'scale':scale,'rows':proof_rows,
                     'reported_schedule_total_jpy':str(totals[balance])if balance in totals else None,
                     'component_sum_jpy':str(sum(amounts[balance],Decimal(0))),
                     'rounding_tolerance_jpy':str(tolerance)},scale=scale)
    return list(output.values())
