"""Native desktop UI. Network work never runs on the Tk event loop."""
from __future__ import annotations

from datetime import date, datetime, timezone, timedelta
from dataclasses import dataclass, field
from pathlib import Path
import os
import calendar
import webbrowser
from urllib.parse import urlparse
import re
import queue
import subprocess
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

from . import __version__
from .discovery import discover_filings, search_companies, display_company_name
from .registry import CompanyRegistry, RegistryError
from .service import Options, Result, run, validate_code
from .charts import FinancialCharts
from .calendar_projection import (project_annual_estimates,with_estimated_next_date,
                                  centered_calendar_start)

APP_DIR = Path(__file__).resolve().parent.parent
UNIT_OPTIONS = {'自動（取得元の表示単位）': 'auto', '千円': 'thousand', '百万円': 'million', '円': 'yen'}
BASIS_OPTIONS = {'自動（連結を優先）': 'auto', '連結': 'consolidated', '個別': 'standalone'}


def initial_window_size(screen_width: int, screen_height: int) -> tuple[int, int]:
    """Fit ordinary laptop screens while retaining a resizable working area."""
    return max(640, min(screen_width-80, 1040)), max(480, min(screen_height-100, 820))


def scheduled_announcement_text(record: dict) -> str:
    """Official dates take priority; a separate display projection is explicit."""
    announced=record.get('next_announcement_date')
    status=record.get('next_announcement_status') or 'not_fetched'
    if announced:
        text=str(announced)
        if record.get('next_announcement_stale') or status=='stale_schedule':
            text+='（要更新）'
        period=record.get('next_announcement_fiscal_period')
        if period and '対象期の詳細は出典を参照' in period:period='通期（対象期は出典参照）'
        return text+('\n'+str(period)if period else'')
    if record.get('display_next_announcement_date'):
        return record['display_next_announcement_date']+'\n'+str(record.get('display_next_announcement_fiscal_period') or '公式予定')
    if record.get('estimated_next_announcement_date'):
        return record['estimated_next_announcement_date']+'（予想日）\n'+str(record.get('estimated_next_announcement_fiscal_period') or '')
    return {'past_unconfirmed':'日程経過・未確認',
            'partial_fetch_failure':'取得未完了',
            'stale_no_schedule':'要更新・予定未確認',
            'not_in_checked_sources':'未確認'}.get(status,'未取得')


def calendar_values(record: dict) -> tuple[str, ...]:
    """Keep actual dates separate from official upcoming annual schedules."""
    return (str(record.get('code') or ''),
            str(record.get('display_name') or display_company_name(record.get('company') or '')),
            str(record.get('latest_period_end') or record.get('latest_period_label') or '未取得'),
            str(record.get('announcement_date') or '未取得'),
            scheduled_announcement_text(record))


def japan_today() -> date:
    # Windows Python need not have an IANA timezone database installed.
    return datetime.now(timezone(timedelta(hours=9))).date()


def month_dates(year: int, month: int) -> list[date]:
    weeks=calendar.Calendar(firstweekday=6).monthdatescalendar(year,month)
    days=[day for week in weeks for day in week]
    from datetime import timedelta
    while len(days)<42:days.append(days[-1]+timedelta(days=1))
    return days


def calendar_event_view(events: list[dict], *, scope: str, today: date,
                        year: int, month: int, selected_date: date | None = None) -> list[dict]:
    result=[]
    for event in events:
        try:day=date.fromisoformat(event.get('date',''))
        except (ValueError,TypeError):continue
        kind=event.get('kind')
        if kind not in {'actual','scheduled','estimated'}:continue
        if selected_date is not None:
            if day!=selected_date:continue
        elif scope=='今後の予定':
            if kind not in {'scheduled','estimated'} or day<today:continue
        elif scope=='過去の発表':
            if kind!='actual' or day>today:continue
        elif scope=='表示中の月' and (day.year!=year or day.month!=month):continue
        result.append(event)
    return sorted(result,key=lambda e:(e['date'],e.get('time')or'',e.get('code')or''),reverse=scope=='過去の発表')


def combined_calendar_events(registered: list[dict], market: list[dict]) -> list[dict]:
    """Reconcile providers without collapsing different known fiscal periods."""
    def period_month(event):
        month=event.get('fiscal_month') or (event.get('fiscal_end') or '')[:7]
        if not month:
            match=re.search(r'(\d{4})年\s*(\d{1,2})月期',event.get('fiscal_period') or '')
            if match:month=f'{int(match[1]):04}-{int(match[2]):02}'
        return month
    all_events=registered+market
    actual={}
    for event in all_events:
        if event.get('kind')=='actual':
            actual.setdefault((event.get('code'),event.get('date')),set()).add(period_month(event))
    groups={}
    for event in all_events:
        actual_periods=actual.get((event.get('code'),event.get('date')),set())
        month=period_month(event)
        if event.get('kind')=='scheduled' and actual_periods and (
                not month or month in actual_periods or '' in actual_periods):continue
        key=(event.get('code'),event.get('date'),event.get('kind'))
        groups.setdefault(key,[]).append(event)
    result=[]
    for events in groups.values():
        known={};unknown=[]
        for event in events:
            month=period_month(event)
            if not month:unknown.append(event);continue
            previous=known.get(month)
            if previous is None or (event.get('fiscal_end') and not previous.get('fiscal_end')):
                known[month]=event
        result.extend(known.values() if known else unknown[:1])
    return result


@dataclass
class GuiJob:
    """One independently cancellable worker. Only the UI changes busy state.

    Every run owns a fresh cancellation event and generation. Logs and terminal
    values go to this job's private queue, so late messages cannot finish a
    different job or a later run. Worker callbacks never call Tk.
    """
    name: str
    busy: bool = False
    generation: int = 0
    cancel_event: threading.Event = field(default_factory=threading.Event)
    events: queue.Queue = field(default_factory=queue.Queue)
    thread: threading.Thread | None = None
    message: str = ''

    def start(self, call, done_kind: str) -> bool:
        if self.busy:
            return False
        self.generation += 1
        generation = self.generation
        cancel = threading.Event()
        self.cancel_event = cancel
        self.busy = True

        def emit(kind, value):
            self.events.put((generation, kind, value))

        def work():
            try:
                value = call(cancel, lambda text: emit('log', text))
                emit(done_kind, value)
            except InterruptedError as exc:
                emit('cancelled', str(exc))
            except Exception as exc:
                emit('error', str(exc))
                emit('trace', traceback.format_exc())

        self.thread = threading.Thread(target=work, name='zaimu10-'+self.name,
                                       daemon=True)
        self.thread.start()
        return True

    def pending(self, limit: int = 100):
        for _ in range(limit):
            try:
                generation, kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if generation == self.generation:
                yield kind, value

    def finish(self):
        self.busy = False

    def cancel(self):
        self.cancel_event.set()


class App:
    def __init__(self, root: tk.Tk, initial_code: str = '6947', *,
                 data_dir: Path | None = None, cache_dir: Path | None = None):
        self.root = root
        self.root.title('企業評価')
        width, height = initial_window_size(root.winfo_screenwidth(), root.winfo_screenheight())
        self.root.geometry(f'{width}x{height}')
        self.root.minsize(min(860, width), min(620, height))
        self.root.configure(bg='#f5f7fa')
        self.cache_dir = Path(cache_dir) if cache_dir is not None else APP_DIR/'.cache'/'zaimu10'
        self.registry = CompanyRegistry((Path(data_dir) if data_dir is not None else APP_DIR/'data')/'companies.json')
        self.jobs = {name: GuiJob(name) for name in ('financial', 'earnings', 'search')}
        self.closing = False
        self.result: Result | None = None
        self.selected_company: dict | None = None
        self.search_results: dict[str, dict] = {}
        self.registered: dict[str, dict] = {}
        self.market_events: list[dict] = []
        self.calendar_events: list[dict] = []
        self.calendar_event_rows: dict[str,dict] = {}
        today=japan_today()
        self.calendar_year,self.calendar_month=today.year,today.month
        self.calendar_list_year,self.calendar_list_month=today.year,today.month
        self.calendar_selected_date: date | None = None
        self.calendar_list_expanded=False
        self._calendar_positioned=False
        self._calendar_render_generation=0
        self._idle_callbacks=set()
        self._refreshing_registry=False
        self.show_logs=tk.BooleanVar(value=False)
        self.calendar_days: list[date] = []
        self.pending_search_action = 'show'
        self.loading_company = False
        self.code = tk.StringVar(value=initial_code)
        self.years = tk.IntVar(value=10)
        self.basis = tk.StringVar(value=next(iter(BASIS_OPTIONS)))
        self.unit = tk.StringVar(value=next(iter(UNIT_OPTIONS)))
        self.output = tk.StringVar(value=str(APP_DIR/'results'))
        self.until = tk.StringVar()
        self.partial = tk.BooleanVar(value=False)
        self.offline = tk.BooleanVar(value=False)
        self.show_advanced = tk.BooleanVar(value=False)
        self.selected_text = tk.StringVar(value='銘柄コード、または会社名を入力してください。')
        self.registry_text = tk.StringVar(value='登録した企業の最新決算期末と本決算発表日を表示します。')
        self.calendar_scope=tk.StringVar(value='すべて')
        self.calendar_month_text=tk.StringVar()
        self.calendar_note=tk.StringVar(value='企業を登録して「発表日を更新」を押してください。')
        self.calendar_detail=tk.StringVar(value='発表済みと、公式に公表された今後の予定を表示します。')
        self.market_schedule=tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='会社を検索するか、銘柄コードを入力して「Excelを作成」を押してください。')
        self.financial_state=tk.StringVar(value='待機中')
        self.search_state=tk.StringVar(value='待機中')
        self.earnings_state=tk.StringVar(value='待機中')
        self.result_notice=tk.StringVar(value='')
        self._styles()
        self._build()
        self.code.trace_add('write', self._query_changed)
        self._refresh_registry()
        self._sync_controls()
        self.root.protocol('WM_DELETE_WINDOW', self._close)
        self.root.bind('<Destroy>',self._root_destroyed,add='+')
        self._poll_after_id=self.root.after(100,self._poll)

    def _styles(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=('Yu Gothic UI', 10), background='#f5f7fa', foreground='#203047')
        style.configure('TFrame', background='#f5f7fa')
        style.configure('Card.TFrame', background='#ffffff')
        style.configure('Card.TLabel', background='#ffffff')
        style.configure('Title.TLabel', font=('Yu Gothic UI', 21, 'bold'), foreground='#172c48')
        style.configure('Sub.TLabel', foreground='#526276', font=('Yu Gothic UI', 9))
        style.configure('TButton', padding=(12, 7), font=('Yu Gothic UI', 10))
        style.configure('Small.TButton',padding=(8,4),font=('Yu Gothic UI',9))
        style.configure('Primary.TButton', background='#174a7b', foreground='white', font=('Yu Gothic UI', 10, 'bold'))
        style.map('Primary.TButton', background=[('active', '#246296'), ('disabled', '#b4c2d0')])
        style.configure('TEntry', padding=5)
        style.configure('TCombobox', padding=5)
        style.configure('TLabelframe', padding=10, background='white')
        style.configure('TLabelframe.Label', background='#f5f7fa', font=('Yu Gothic UI', 10, 'bold'))
        style.configure('TCheckbutton', background='white')
        style.configure('Treeview', background='white', fieldbackground='white', rowheight=27, font=('Yu Gothic UI', 9))
        style.configure('Treeview.Heading', font=('Yu Gothic UI', 9, 'bold'))
        style.configure('Registry.Treeview', rowheight=34)
        style.configure('TNotebook.Tab', padding=(14, 7))
        style.configure('Compact.Horizontal.TProgressbar',thickness=6)

    @staticmethod
    def _tree(parent, columns, headings, widths, height):
        frame = ttk.Frame(parent)
        tree = ttk.Treeview(frame, columns=columns, show='headings', selectmode='browse', height=height)
        for key, label, width in zip(columns, headings, widths):
            tree.heading(key, text=label)
            tree.column(key, width=width, minwidth=65, stretch=key == 'company')
        scroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.grid(row=0, column=0, sticky='nsew')
        scroll.grid(row=0, column=1, sticky='ns')
        horizontal = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(xscrollcommand=horizontal.set)
        horizontal.grid(row=1, column=0, sticky='ew')
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return frame, tree

    def _build(self):
        main=ttk.Frame(self.root,padding=(20,12));main.pack(fill='both',expand=True)
        heading=ttk.Frame(main);heading.pack(fill='x',pady=(0,9))
        ttk.Label(heading,text='企業評価',style='Title.TLabel').pack(side='left')
        ttk.Label(heading,text='10期の財務データを、8シートのExcelとグラフへ。',style='Sub.TLabel').pack(side='left',padx=(18,0))
        footer=ttk.Frame(main);footer.pack(side='bottom',fill='x',pady=(7,0))
        activity=ttk.Frame(footer);activity.pack(fill='x')
        self.progress=ttk.Progressbar(activity,mode='indeterminate',style='Compact.Horizontal.TProgressbar')
        self.earnings_progress=ttk.Progressbar(activity,mode='indeterminate',style='Compact.Horizontal.TProgressbar')
        self.search_progress=ttk.Progressbar(activity,mode='indeterminate',style='Compact.Horizontal.TProgressbar')
        for group,(label,bar,state) in enumerate((('Excel',self.progress,self.financial_state),
                ('発表日',self.earnings_progress,self.earnings_state),('検索',self.search_progress,self.search_state))):
            column=group*3;activity.columnconfigure(column+1,weight=1)
            ttk.Label(activity,text=label,style='Sub.TLabel').grid(row=0,column=column,padx=(10 if group else 0,5))
            bar.grid(row=0,column=column+1,sticky='ew')
            ttk.Label(activity,textvariable=state,style='Sub.TLabel',width=11).grid(row=0,column=column+2,padx=(5,0))
        statusline=ttk.Frame(footer);statusline.pack(fill='x',pady=(3,0));statusline.columnconfigure(0,weight=1)
        ttk.Label(statusline,textvariable=self.status,style='Sub.TLabel',wraplength=800).grid(row=0,column=0,sticky='w')
        self.log_toggle=ttk.Button(statusline,text='取得ログを表示',command=self._toggle_logs)
        self.log_toggle.grid(row=0,column=1,padx=(8,0),sticky='ne')
        ttk.Label(footer,textvariable=self.result_notice,style='Sub.TLabel',wraplength=950).pack(anchor='w')
        self.log_frame=ttk.Frame(footer)
        self.logs=ScrolledText(self.log_frame,height=4,wrap='word',font=('Yu Gothic UI',9),bg='white',fg='#28384d',relief='flat',padx=8,pady=5,state='disabled')
        self.logs.pack(fill='x',expand=False)
        self.notebook=ttk.Notebook(main);self.notebook.pack(fill='both',expand=True)
        self.create_tab=ttk.Frame(self.notebook,padding=(10,9))
        self.registry_tab=self.create_tab  # One workspace, preserving caller aliases.
        self.calendar_tab=ttk.Frame(self.notebook,padding=(10,8))
        self.charts_tab=ttk.Frame(self.notebook,padding=(10,8))
        self.notebook.add(self.create_tab,text='企業・Excel作成')
        self.notebook.add(self.charts_tab,text='財務グラフ')
        self.notebook.add(self.calendar_tab,text='決算カレンダー')
        self._build_create_tab();self._build_registry_tab();self._build_calendar_tab()
        self.financial_charts=FinancialCharts(self.charts_tab,open_callback=self._open_saved_chart,source_callback=self._open_url)
        self.financial_charts.pack(fill='both',expand=True)
        self.root.bind('<Control-Return>',lambda _:self._start())
        self.code_entry.focus_set()

    def _toggle_logs(self):
        opened=not self.show_logs.get();self.show_logs.set(opened)
        if opened:self.log_frame.pack(fill='x',pady=(5,0));self.log_toggle.configure(text='取得ログを閉じる')
        else:self.log_frame.pack_forget();self.log_toggle.configure(text='取得ログを表示')

    def _after_idle(self, callback):
        """Own idle callbacks so closing a window leaves no Tcl callbacks."""
        if not hasattr(self,'_idle_callbacks'):self._idle_callbacks=set()
        ticket={}
        def ready():
            self._idle_callbacks.discard(ticket.get('id'))
            if not self.closing:callback()
        ticket['id']=self.root.after_idle(ready)
        self._idle_callbacks.add(ticket['id'])

    def _build_create_tab(self):
        main=self.create_tab;main.columnconfigure(0,minsize=320);main.columnconfigure(1,weight=1,minsize=440);main.rowconfigure(0,weight=1)
        left=ttk.Frame(main);left.grid(row=0,column=0,sticky='nsew',padx=(0,12));left.columnconfigure(0,weight=1);left.rowconfigure(0,weight=1)
        canvas=tk.Canvas(left,highlightthickness=0,bg='#ffffff',width=320)
        canvas.grid(row=0,column=0,sticky='nsew')
        scroll=ttk.Scrollbar(left,orient='vertical',command=canvas.yview);scroll.grid(row=0,column=1,sticky='ns')
        canvas.configure(yscrollcommand=scroll.set)
        content=ttk.Frame(canvas,style='Card.TFrame',padding=10)
        window=canvas.create_window((0,0),window=content,anchor='nw')
        self.controls_canvas=canvas
        def resized(_=None):
            canvas.configure(scrollregion=canvas.bbox('all'))
            if content.winfo_reqheight()>canvas.winfo_height():scroll.grid()
            else:scroll.grid_remove()
        content.bind('<Configure>',resized)
        canvas.bind('<Configure>',lambda event:(canvas.itemconfigure(window,width=event.width),resized()))
        content.columnconfigure(0,weight=1)
        ttk.Label(content,text='作成する企業',style='Card.TLabel',font=('Yu Gothic UI',12,'bold')).grid(row=0,column=0,sticky='w',pady=(0,7))
        search=ttk.Frame(content,style='Card.TFrame');search.grid(row=1,column=0,sticky='ew');search.columnconfigure(0,weight=1)
        self.code_entry=ttk.Entry(search,textvariable=self.code,font=('Yu Gothic UI',12),width=16)
        self.code_entry.grid(row=0,column=0,sticky='ew');self.code_entry.bind('<Return>',lambda _:self._search())
        self.search_button=ttk.Button(search,text='検索',command=self._search_button_clicked,width=6)
        self.search_button.grid(row=0,column=1,padx=(6,0))
        ttk.Label(content,textvariable=self.selected_text,style='Card.TLabel',wraplength=292).grid(row=3,column=0,sticky='w',pady=(7,0))
        self.register_button=ttk.Button(content,text='この企業を登録',command=self._register_company)
        self.register_button.grid(row=4,column=0,sticky='w',pady=(8,10))
        opts=ttk.Frame(content,style='Card.TFrame');opts.grid(row=5,column=0,sticky='ew');opts.columnconfigure(1,weight=1)
        ttk.Label(opts,text='対象',style='Card.TLabel').grid(row=0,column=0,sticky='w',padx=(0,6))
        self.basis_box=ttk.Combobox(opts,textvariable=self.basis,values=list(BASIS_OPTIONS),state='readonly',width=20)
        self.basis_box.grid(row=0,column=1,sticky='ew')
        ttk.Label(opts,text='期数',style='Card.TLabel').grid(row=1,column=0,sticky='w',pady=(7,0))
        self.years_box=ttk.Combobox(opts,textvariable=self.years,values=list(range(1,11)),width=4,state='readonly')
        self.years_box.grid(row=1,column=1,sticky='w',pady=(7,0))
        ttk.Label(opts,text='単位',style='Card.TLabel').grid(row=2,column=0,sticky='w',pady=(7,0))
        self.unit_box=ttk.Combobox(opts,textvariable=self.unit,values=list(UNIT_OPTIONS),state='readonly',width=20)
        self.unit_box.grid(row=2,column=1,sticky='ew',pady=(7,0))
        ttk.Label(content,text='出力先',style='Card.TLabel').grid(row=6,column=0,sticky='w',pady=(10,3))
        destination=ttk.Frame(content,style='Card.TFrame');destination.grid(row=7,column=0,sticky='ew');destination.columnconfigure(0,weight=1)
        self.output_entry=ttk.Entry(destination,textvariable=self.output,width=17)
        self.output_entry.grid(row=0,column=0,sticky='ew')
        self.folder_button=ttk.Button(destination,text='選択',command=self._choose_folder,width=5)
        self.folder_button.grid(row=0,column=1,padx=(5,0))
        self.advanced_check=ttk.Checkbutton(content,text='詳細設定',variable=self.show_advanced,command=self._toggle_advanced)
        self.advanced_check.grid(row=8,column=0,sticky='w',pady=(8,0))
        self.advanced_frame=ttk.Frame(content,style='Card.TFrame');self.advanced_frame.grid(row=9,column=0,sticky='ew',pady=(6,0));self.advanced_frame.columnconfigure(0,weight=1)
        ttk.Label(self.advanced_frame,text='最終決算日（空欄＝最新）',style='Card.TLabel').grid(row=0,column=0,sticky='w')
        self.until_entry=ttk.Entry(self.advanced_frame,textvariable=self.until,width=16)
        self.until_entry.grid(row=1,column=0,sticky='ew',pady=(3,5))
        self.offline_check=ttk.Checkbutton(self.advanced_frame,text='取得済みデータのみ使用',variable=self.offline)
        self.offline_check.grid(row=2,column=0,sticky='w')
        self.partial_check=ttk.Checkbutton(self.advanced_frame,text='不足・警告があっても要確認で出力',variable=self.partial)
        self.partial_check.grid(row=3,column=0,sticky='w',pady=(4,0));self.advanced_frame.grid_remove()
        actions=ttk.Frame(left);actions.grid(row=1,column=0,columnspan=2,sticky='ew',pady=(8,0));actions.columnconfigure(0,weight=1)
        self.start_button=ttk.Button(actions,text='Excelを作成',style='Primary.TButton',command=self._start)
        self.start_button.grid(row=0,column=0,sticky='ew')
        self.cancel_button=ttk.Button(actions,text='中止',command=self._cancel_financial,state='disabled',width=5)
        self.cancel_button.grid(row=0,column=1,padx=(6,0))
        opened=ttk.Frame(left);opened.grid(row=2,column=0,columnspan=2,sticky='ew',pady=(5,0))
        self.open_button=ttk.Button(opened,text='Excelを開く',command=self._open_file,state='disabled')
        self.open_button.pack(side='left')
        self.open_folder_button=ttk.Button(opened,text='出力先を開く',command=self._open_folder)
        self.open_folder_button.pack(side='left',padx=(5,0))
        self.registry_panel=ttk.Frame(main);self.registry_panel.grid(row=0,column=1,sticky='nsew')
        self.inputs=[self.code_entry,self.search_button,self.register_button,self.years_box,self.basis_box,self.unit_box,self.output_entry,self.folder_button,self.until_entry,self.offline_check,self.partial_check,self.advanced_check]
        self._build_search_dialog();self.inputs.append(self.use_search_button)

    def _build_search_dialog(self):
        # Ambiguous matches use their own selection window. A results table
        # embedded above the options would hide logs on small laptop screens.
        self.search_dialog = tk.Toplevel(self.root)
        self.search_dialog.withdraw()
        self.search_dialog.title('検索結果から企業を選択')
        self.search_dialog.transient(self.root)
        self.search_dialog.minsize(620, 300)
        self.search_dialog.geometry(f'{min(900,self.root.winfo_screenwidth()-100)}x{min(470,self.root.winfo_screenheight()-130)}')
        self.search_dialog.protocol('WM_DELETE_WINDOW', self._dismiss_search)
        self.search_dialog.bind('<Escape>', lambda _: self._dismiss_search())
        dialog_main = ttk.Frame(self.search_dialog, padding=16)
        dialog_main.pack(fill='both', expand=True)
        self.search_caption = tk.StringVar(value='対象の企業を選んでください。')
        ttk.Label(dialog_main, textvariable=self.search_caption, wraplength=820).pack(anchor='w', pady=(0, 10))
        self.search_frame, self.search_tree = self._tree(dialog_main,
            ('code', 'company'), ('銘柄コード', '会社名'),
            (100, 660), 10)
        self.search_frame.pack(fill='both', expand=True)
        self.search_tree.bind('<Double-1>', lambda _: self._use_search_result())
        self.search_tree.bind('<Return>', lambda _: self._use_search_result())
        dialog_actions = ttk.Frame(dialog_main)
        dialog_actions.pack(fill='x', pady=(12, 0))
        self.use_search_button = ttk.Button(dialog_actions, text='選択した企業を入力', command=self._use_search_result, style='Primary.TButton')
        self.use_search_button.pack(side='left')
        ttk.Button(dialog_actions, text='閉じる', command=self._dismiss_search).pack(side='right')


    def _build_registry_tab(self):
        main=self.registry_panel;main.columnconfigure(0,weight=1);main.rowconfigure(1,weight=1)
        heading=ttk.Frame(main);heading.grid(row=0,column=0,sticky='ew',pady=(0,7));heading.columnconfigure(0,weight=1)
        ttk.Label(heading,text='登録企業',font=('Yu Gothic UI',12,'bold')).grid(row=0,column=0,sticky='w')
        self.remove_registered_button=ttk.Button(heading,text='登録を解除',command=self._remove_registered)
        self.remove_registered_button.grid(row=0,column=1,sticky='e')
        frame,self.registry_tree=self._tree(main,('code','company','period','announcement','scheduled'),
            ('コード','会社名','最新決算期末 ▼','発表日（実績）','次回発表（公式／予想）'),(55,140,110,105,165),7)
        self.registry_tree.configure(style='Registry.Treeview');frame.grid(row=1,column=0,sticky='nsew')
        self.registry_tree.bind('<<TreeviewSelect>>',lambda _:self._registry_selection_changed())
        self.registry_tree.bind('<Double-1>',lambda _:self._use_registered());self.registry_tree.bind('<Return>',lambda _:self._use_registered())
        actions=ttk.Frame(main);actions.grid(row=2,column=0,sticky='ew',pady=(7,4))
        self.use_registered_button=ttk.Button(actions,text='企業を入力',command=self._use_registered)
        self.use_registered_button.pack(side='left')
        self.calendar_button=ttk.Button(actions,text='選択の発表日を更新',command=self._update_calendar)
        self.calendar_button.pack(side='left',padx=(5,0))
        self.all_calendar_button=ttk.Button(actions,text='全社を更新',command=self._update_all_calendars)
        self.all_calendar_button.pack(side='left',padx=(5,0))
        self.calendar_cancel_button=ttk.Button(actions,text='中止',command=self._cancel_earnings,state='disabled',width=4)
        self.calendar_cancel_button.pack(side='left',padx=(5,0))
        ttk.Label(main,textvariable=self.registry_text,style='Sub.TLabel',wraplength=585).grid(row=3,column=0,sticky='w',pady=(3,0))
        ttk.Label(main,text='企業を選ぶと左に入力します。予想日は前年実績の1年後で、公式予定とは区別します。',style='Sub.TLabel',wraplength=585).grid(row=4,column=0,sticky='w',pady=(5,0))
        self.inputs.extend([self.use_registered_button,self.calendar_button,self.all_calendar_button,self.remove_registered_button])

    def _registry_selection_changed(self):
        if not getattr(self,'_refreshing_registry',False):self._use_registered(focus=False)

    def _build_calendar_tab(self):
        main=self.calendar_tab
        main.columnconfigure(0,weight=1)
        main.rowconfigure(2,weight=1,minsize=150);main.rowconfigure(4,weight=3,minsize=145)
        controls=ttk.Frame(main);controls.grid(row=0,column=0,sticky='ew',pady=(0,5));controls.columnconfigure(3,weight=1)
        ttk.Button(controls,text='‹ 前月',style='Small.TButton',width=7,command=lambda:self._move_calendar(-1)).grid(row=0,column=0)
        ttk.Label(controls,textvariable=self.calendar_month_text,font=('Yu Gothic UI',14,'bold'),width=13,anchor='center').grid(row=0,column=1,padx=8)
        ttk.Button(controls,text='翌月 ›',style='Small.TButton',width=7,command=lambda:self._move_calendar(1)).grid(row=0,column=2)
        ttk.Button(controls,text='今月',style='Small.TButton',width=7,command=self._calendar_today).grid(row=0,column=3,sticky='w',padx=8)
        self.calendar_refresh_button=ttk.Button(controls,text='発表日を更新',style='Small.TButton',command=self._update_earnings)
        self.calendar_refresh_button.grid(row=0,column=4,padx=(4,6))
        self.calendar_stop_button=ttk.Button(controls,text='中止',style='Small.TButton',command=self._cancel_earnings,state='disabled',width=5)
        self.calendar_stop_button.grid(row=0,column=5)
        options=ttk.Frame(main);options.grid(row=1,column=0,sticky='ew',pady=(0,5));options.columnconfigure(0,weight=1)
        self.market_check=ttk.Checkbutton(options,text='公開予定も表示（全銘柄・JPX公式）',variable=self.market_schedule,command=self._market_changed)
        self.market_check.grid(row=0,column=0,sticky='w')
        self.calendar_scope_box=ttk.Combobox(options,textvariable=self.calendar_scope,values=['表示中の月','今後の予定','過去の発表','すべて'],state='readonly',width=14)
        legend=ttk.Frame(options);legend.grid(row=0,column=1,padx=(4,12))
        ttk.Label(legend,text='● 発表済み',foreground='#16816a',font=('Yu Gothic UI',8)).pack(side='left',padx=(0,8))
        ttk.Label(legend,text='● 公式予定',foreground='#4467a2',font=('Yu Gothic UI',8)).pack(side='left',padx=(0,8))
        ttk.Label(legend,text='● 予想日',foreground='#a36b1a',font=('Yu Gothic UI',8)).pack(side='left')
        self.calendar_scope_box.grid(row=0,column=2,sticky='e');self.calendar_scope_box.bind('<<ComboboxSelected>>',lambda _:self._calendar_filter_changed())
        self.month_canvas=tk.Canvas(main,bg='white',highlightthickness=0,height=150)
        self.month_canvas.grid(row=2,column=0,sticky='nsew')
        self.month_canvas.bind('<Configure>',lambda _:self._draw_calendar())
        self.month_canvas.bind('<Button-1>',self._calendar_click)
        self.month_canvas.bind('<Motion>',self._calendar_hover)
        self.month_canvas.bind('<Leave>',lambda _:self.month_canvas.delete('calendar_hover'))
        list_header=ttk.Frame(main);list_header.grid(row=3,column=0,sticky='ew',pady=(5,4));list_header.columnconfigure(0,weight=1)
        ttk.Label(list_header,textvariable=self.calendar_note,style='Sub.TLabel',wraplength=460).grid(row=0,column=0,sticky='w')
        self.apply_month_button=ttk.Button(list_header,text='この月の一覧',style='Small.TButton',command=self._apply_calendar_month)
        self.apply_month_button.grid(row=0,column=1,sticky='e',padx=(8,0))
        self.clear_calendar_date_button=ttk.Button(list_header,text='日付解除',style='Small.TButton',command=self._clear_calendar_date,state='disabled')
        self.clear_calendar_date_button.grid(row=0,column=2,sticky='e',padx=(8,0))
        self.list_expand_button=ttk.Button(list_header,text='一覧を広く表示',style='Small.TButton',command=self._toggle_calendar_list)
        self.list_expand_button.grid(row=0,column=3,sticky='e',padx=(8,0))
        self.center_calendar_button=ttk.Button(list_header,text='今日の前後',style='Small.TButton',command=self._calendar_near_today)
        self.center_calendar_button.grid(row=0,column=4,sticky='e',padx=(8,0))
        frame,self.events_tree=self._tree(main,('date','kind','code','company','period'),
            ('決算発表日','区分','コード','会社名','対象決算期'),(120,95,75,310,220),3)
        frame.grid(row=4,column=0,sticky='nsew')
        self.events_tree.tag_configure('estimated',foreground='#9a621c',background='#fff9ec')
        self.events_tree.tag_configure('scheduled',foreground='#375c95')
        self.events_tree.bind('<<TreeviewSelect>>',lambda _:self._calendar_event_selected())
        self.events_tree.bind('<Configure>',lambda _:self._calendar_viewport_resized())
        self.events_tree.bind('<Double-1>',lambda _:self._open_event_source())
        footer=ttk.Frame(main);footer.grid(row=5,column=0,sticky='ew',pady=(6,0));footer.columnconfigure(0,weight=1)
        ttk.Label(footer,textvariable=self.calendar_detail,style='Sub.TLabel',wraplength=735).grid(row=0,column=0,sticky='w')
        self.event_source_button=ttk.Button(footer,text='出典を開く',style='Small.TButton',command=self._open_event_source,state='disabled')
        self.event_source_button.grid(row=0,column=1,sticky='e')
        self.inputs.extend([self.calendar_refresh_button,self.market_check])
        self._render_calendar()

    def _toggle_calendar_list(self):
        self.calendar_list_expanded=not self.calendar_list_expanded
        if self.calendar_list_expanded:
            self.month_canvas.grid_remove()
            self.calendar_tab.rowconfigure(2,weight=0,minsize=0)
            self.calendar_tab.rowconfigure(4,weight=1,minsize=180)
            self.list_expand_button.configure(text='月表示に戻す')
        else:
            self.month_canvas.grid()
            self.calendar_tab.rowconfigure(2,weight=1,minsize=150)
            self.calendar_tab.rowconfigure(4,weight=3,minsize=145)
            self.list_expand_button.configure(text='一覧を広く表示')

    def _refresh_calendar_grid(self):
        self.calendar_month_text.set(f'{self.calendar_year}年 {self.calendar_month}月')
        self._draw_calendar()

    def _move_calendar(self,amount):
        month=self.calendar_year*12+self.calendar_month-1+amount
        self.calendar_year,self.calendar_month=month//12,month%12+1
        # Top-month navigation never changes the lower list's condition, date
        # filter, selected source row or scroll position.
        self._refresh_calendar_grid()

    def _calendar_today(self):
        today=japan_today();self.calendar_year,self.calendar_month=today.year,today.month
        self._refresh_calendar_grid()

    def _calendar_filter_changed(self):
        self.calendar_selected_date=None
        if self.calendar_scope.get()=='表示中の月':
            self.calendar_list_year,self.calendar_list_month=self.calendar_year,self.calendar_month
        self._render_calendar()

    def _apply_calendar_month(self):
        self.calendar_scope.set('表示中の月')
        self.calendar_list_year,self.calendar_list_month=self.calendar_year,self.calendar_month
        self.calendar_selected_date=None
        self._render_calendar()

    def _clear_calendar_date(self):
        self.calendar_selected_date=None
        self._render_calendar()

    def _calendar_near_today(self):
        self.calendar_scope.set('すべて');self.calendar_selected_date=None
        self._calendar_positioned=False
        self._render_calendar(center=True)

    def _market_changed(self):
        self._render_calendar()
        if self.market_schedule.get() and not self.market_events and not self._job_busy('earnings'):
            self._update_earnings(market_only=True)

    def _render_calendar(self, *, center=False):
        registered=[event for record in self.registered.values()for event in record.get('earnings_events',[])]
        market=[event for event in self.market_events if self.market_schedule.get() or event.get('code') in self.registered]
        officials=combined_calendar_events(registered,market)
        self.calendar_events=project_annual_estimates(list(self.registered.values()),officials,today=japan_today())
        self.calendar_month_text.set(f'{self.calendar_year}年 {self.calendar_month}月')
        if not hasattr(self,'events_tree'):return
        selected=self.events_tree.selection()
        previous=self.calendar_event_rows.get(selected[0])if selected else None
        def identity(event):
            return (event.get('code'),event.get('date'),event.get('kind'),event.get('fiscal_month')or event.get('fiscal_period'))
        previous_key=identity(previous)if previous else None
        context=(self.calendar_scope.get(),self.calendar_selected_date,self.calendar_list_year,self.calendar_list_month)
        same_context=context==getattr(self,'_calendar_view_context',None)
        old_children=self.events_tree.get_children();top_key=None
        if old_children and hasattr(self.events_tree,'yview') and not center and same_context and not getattr(self,'_calendar_center_pending',False):
            view=self.events_tree.yview()
            if isinstance(view,(tuple,list)) and len(view)==2:
                index=max(0,min(len(old_children)-1,round(float(view[0])*len(old_children))))
                top=self.calendar_event_rows.get(old_children[index])
                if top:top_key=identity(top)
        events=calendar_event_view(self.calendar_events,scope=self.calendar_scope.get(),today=japan_today(),
            year=self.calendar_list_year,month=self.calendar_list_month,selected_date=self.calendar_selected_date)
        self.events_tree.delete(*self.events_tree.get_children());self.calendar_event_rows={}
        restore=None;top_restore=None
        for i,event in enumerate(events):
            key=str(i);self.calendar_event_rows[key]=event
            values=(event['date']+(' '+event['time'] if event.get('time')else''),
                {'actual':'発表済み','scheduled':'公式予定','estimated':'予想日'}[event['kind']],event.get('code',''),
                display_company_name(event.get('company','')),event.get('fiscal_period')or'')
            self.events_tree.insert('','end',iid=key,values=values)
            if hasattr(self.events_tree,'item'):self.events_tree.item(key,tags=(event['kind'],))
            if previous_key is not None and identity(event)==previous_key:restore=key
            if top_key is not None and identity(event)==top_key:top_restore=i
        if self.calendar_selected_date:
            label=self.calendar_selected_date.isoformat()+'（日付指定）'
        elif self.calendar_scope.get()=='表示中の月':
            label=f'{self.calendar_list_year}年{self.calendar_list_month}月の一覧'
        else:label=self.calendar_scope.get()
        actual=sum(e['kind']=='actual'for e in events);planned=sum(e['kind']=='scheduled'for e in events);estimated=sum(e['kind']=='estimated'for e in events)
        self.calendar_note.set(f'{label}：実績 {actual} ／ 公式 {planned} ／ 予想 {estimated}')
        self.calendar_detail.set('予想日は前年の本決算発表実績の1年後です。公式予定ではありません。月送りと一覧の条件は独立しています。')
        if hasattr(self,'clear_calendar_date_button'):
            self.clear_calendar_date_button.configure(state='normal'if self.calendar_selected_date else'disabled')
        if hasattr(self,'event_source_button'):self.event_source_button.configure(state='disabled')
        if restore is not None:
            self.events_tree.selection_set(restore)
            self._calendar_event_selected()
        self._calendar_render_generation=getattr(self,'_calendar_render_generation',0)+1
        generation=self._calendar_render_generation
        self._calendar_view_context=context
        if top_restore is not None and hasattr(self.events_tree,'yview_moveto'):
            self.events_tree.yview_moveto(top_restore/max(len(events),1))
        elif events and (center or not same_context or not getattr(self,'_calendar_positioned',False) or getattr(self,'_calendar_center_pending',False)):
            self._center_calendar_events(events,generation)
            if hasattr(self.root,'after_idle'):
                self._after_idle(lambda:self._center_calendar_events(events,generation))
        self._calendar_positioned=bool(events)
        self._draw_calendar()

    def _center_calendar_events(self, events, generation):
        if generation!=getattr(self,'_calendar_render_generation',None) or self.closing:return
        if not hasattr(self.events_tree,'yview_moveto'):return
        height=self.events_tree.winfo_height() if hasattr(self.events_tree,'winfo_height') else 0
        visible=max(1,(int(height)-27)//27) if isinstance(height,(int,float)) and height>27 else 5
        self._calendar_center_pending=not (isinstance(height,(int,float)) and height>54)
        start=centered_calendar_start(events,japan_today(),visible)
        self.events_tree.yview_moveto(start/max(len(events),1))

    def _calendar_viewport_resized(self):
        if getattr(self,'_calendar_center_pending',False):
            self._center_calendar_events(list(self.calendar_event_rows.values()),self._calendar_render_generation)

    def _draw_calendar(self):
        if not hasattr(self,'month_canvas'):return
        canvas=self.month_canvas;canvas.delete('all')
        width,height=max(100,canvas.winfo_width()),max(150,canvas.winfo_height())
        header=23;cw=width/7;ch=(height-header)/6
        self.calendar_days=month_dates(self.calendar_year,self.calendar_month)
        grouped={}
        for event in self.calendar_events:
            grouped.setdefault(event.get('date'),[]).append(event)
        weekdays=('日','月','火','水','木','金','土')
        for i,label in enumerate(weekdays):
            canvas.create_text((i+.5)*cw,11,text=label,fill='#b56262'if i==0 else'#5c78a0'if i==6 else'#64748b',font=('Yu Gothic UI',9,'bold'))
        today=japan_today()
        for i,day in enumerate(self.calendar_days):
            col,row=i%7,i//7;x0,y0=col*cw,header+row*ch;x1,y1=x0+cw,y0+ch
            other=day.month!=self.calendar_month
            color='#f4f6f9'if other else'#ffffff'
            if day==today:color='#edf4fd'
            selected=day==self.calendar_selected_date
            canvas.create_rectangle(x0,y0,x1,y1,fill=color,outline='#6a91c5'if selected else'#e1e7ef',width=2 if selected else 1)
            canvas.create_text(x0+7,y0+3,text=str(day.day),anchor='nw',fill='#b4bdc8'if other else'#b56262'if col==0 else'#5c78a0'if col==6 else'#263b56',font=('Yu Gothic UI',9,'bold'if day==today else'normal'))
            items=grouped.get(day.isoformat(),[])
            if items:
                canvas.create_text(x1-5,y0+3,text=f'{len(items)}件',anchor='ne',fill='#667b92',font=('Yu Gothic UI',8))
                room=max(0,int((ch-15)/11))
                if room==0:
                    event=items[0];label=('予 'if event['kind']=='estimated'else'')+event.get('code','')
                    canvas.create_text(x0+27,y0+4,text=label,anchor='nw',fill={'actual':'#16816a','scheduled':'#4467a2','estimated':'#a36b1a'}[event['kind']],font=('Yu Gothic UI',8))
                for j,event in enumerate(items[:room]):
                    name=display_company_name(event.get('company',''))
                    label=f"{event.get('code','')} {name}"
                    maximum=max(4,int((cw-12)/10));label=label if len(label)<=maximum else label[:maximum-1]+'…'
                    canvas.create_text(x0+6,y0+15+j*11,text=label,anchor='nw',fill={'actual':'#16816a','scheduled':'#4467a2','estimated':'#a36b1a'}[event['kind']],font=('Yu Gothic UI',8))

    def _calendar_day_at(self,event):
        width=max(1,self.month_canvas.winfo_width());height=max(150,self.month_canvas.winfo_height())
        if event.y<23:return None
        col=int(event.x/(width/7));row=int((event.y-23)/((height-23)/6))
        index=row*7+col
        return self.calendar_days[index]if 0<=col<7 and 0<=row<6 and index<len(self.calendar_days)else None

    def _calendar_click(self,event):
        day=self._calendar_day_at(event)
        if day is None:return
        self.calendar_year,self.calendar_month=day.year,day.month
        self.calendar_selected_date=day;self._render_calendar()

    def _calendar_hover(self,event):
        canvas=self.month_canvas;canvas.delete('calendar_hover')
        day=self._calendar_day_at(event)
        if day is None:return
        items=[e for e in self.calendar_events if e.get('date')==day.isoformat()]
        if not items:return
        lines=[day.isoformat()]
        for item in items[:7]:
            status={'actual':'発表済み','scheduled':'公式予定','estimated':'予想日'}[item['kind']]
            lines.append(f"{status}　{item.get('code','')} {display_company_name(item.get('company',''))}")
        if len(items)>7:lines.append(f'ほか{len(items)-7}件。クリックして一覧を表示。')
        text=canvas.create_text(0,0,text='\n'.join(lines),anchor='nw',font=('Yu Gothic UI',9),fill='#263b56',tags='calendar_hover')
        box=canvas.bbox(text);bw,bh=box[2]-box[0]+18,box[3]-box[1]+14
        x=min(max(4,event.x+12),max(4,canvas.winfo_width()-bw-4));y=min(max(4,event.y+12),max(4,canvas.winfo_height()-bh-4))
        canvas.coords(text,x+9,y+7);rect=canvas.create_rectangle(x,y,x+bw,y+bh,fill='#f4f8fd',outline='#bbcbdc',tags='calendar_hover');canvas.tag_raise(text,rect)

    def _calendar_event_selected(self):
        selection=self.events_tree.selection()
        event=self.calendar_event_rows.get(selection[0])if selection else None
        if event:
            self.event_source_button.configure(text='予想の根拠を開く'if event['kind']=='estimated'else'出典を開く')
            if event['kind']=='estimated':self.calendar_detail.set(event['estimation_note'])
            else:self.calendar_detail.set(f"{event.get('title','')}　／　{event.get('source_title')or event.get('publisher')or'公式開示'}　／　確認：{(event.get('verified_at')or'')[:10]}")
        else:self.event_source_button.configure(text='出典を開く')
        self.event_source_button.configure(state='normal'if event and event.get('source_url')else'disabled')

    def _open_event_source(self):
        selection=self.events_tree.selection()
        event=self.calendar_event_rows.get(selection[0])if selection else None
        if event and event.get('source_url'):self._open_url(event['source_url'])

    def _open_url(self,url):
        parsed=urlparse(url)
        if parsed.scheme in {'https','http'} and parsed.hostname:webbrowser.open(url)

    def _open_saved_chart(self):
        if self.closing:return
        path=filedialog.askopenfilename(title='保存済みの財務データを開く',initialdir=self.output.get()if Path(self.output.get()).is_dir()else str(APP_DIR),filetypes=[('Zaimu10の監査データ','*.audit.json'),('JSON','*.json')])
        if not path:return
        try:
            from .audit import load_result
            result=load_result(Path(path))
            self.financial_charts.set_dataset(result.dataset)
            self.result=result
            self.notebook.select(self.charts_tab)
            self.open_button.configure(state='normal'if result.workbook.is_file()else'disabled')
            self.status.set(f'{result.dataset.code} {result.dataset.company} の保存済みグラフを表示しています。')
        except (ValueError,OSError,KeyError)as exc:messagebox.showerror('データを開けませんでした',str(exc),parent=self.root)

    def _toggle_advanced(self):
        if self.show_advanced.get():
            self.advanced_frame.grid()
        else:
            self.advanced_frame.grid_remove()

    def _show_search_results(self, count: int):
        if count > 1:
            self.search_caption.set(f'「{self.code.get()}」に一致する企業は{count}件です。対象企業を選んで入力してください。')
            self.search_dialog.deiconify()
            self.search_dialog.lift()
            self.search_dialog.grab_set()
        else:
            if self.search_dialog.grab_current() is self.search_dialog:
                self.search_dialog.grab_release()
            self.search_dialog.withdraw()

    def _dismiss_search(self):
        self.pending_search_action = 'show'
        self._show_search_results(0)
        self.status.set('企業選択を閉じました。検索語を変えて再検索できます。')

    def _query_changed(self, *_):
        if not self.loading_company:
            self.selected_company = None
            self.pending_search_action = 'show'
            self._show_search_results(0)
            self.search_tree.delete(*self.search_tree.get_children())
            self.search_results = {}
            self.selected_text.set('銘柄コード、会社名のどちらでも検索できます。')

    def _set_company(self, company: dict):
        self.loading_company = True
        try:
            self.code.set(company['code'])
        finally:
            self.loading_company = False
        self.selected_company = dict(company)
        self.selected_text.set(f"{company['code']}　{company.get('display_name') or display_company_name(company.get('company',''))}")
        if hasattr(self,'register_button'):
            self.register_button.configure(text='登録済み（更新）'if company['code'] in self.registered else'この企業を登録')

    def _choose_folder(self):
        path = filedialog.askdirectory(title='Excelの出力先を選択', initialdir=self.output.get() if Path(self.output.get()).is_dir() else str(APP_DIR))
        if path:
            self.output.set(path)

    def _append(self, text: str):
        self.logs.configure(state='normal')
        self.logs.insert('end', text+'\n')
        self.logs.see('end')
        self.logs.configure(state='disabled')

    @property
    def busy(self):
        """Aggregate observation for callers waiting for all activity to finish."""
        return any(job.busy for job in self.jobs.values())

    def _job_busy(self, name):
        return self.jobs[name].busy

    def _sync_controls(self):
        financial=self._job_busy('financial');earnings=self._job_busy('earnings');search=self._job_busy('search')
        closing=self.closing
        # Settings are snapshots when a worker starts. Editing another company
        # or preparing the next export cannot change an active export's options.
        for widget in self.inputs:
            widget.configure(state='disabled'if closing else('readonly'if isinstance(widget,ttk.Combobox)else'normal'))
        self.code_entry.configure(state='disabled'if search or closing else'normal')
        self.register_button.configure(state='disabled'if search or closing else'normal')
        self.use_search_button.configure(state='disabled'if search or closing else'normal')
        self.use_registered_button.configure(state='disabled'if search or closing else'normal')
        self.search_button.configure(text='検索中止'if search else'検索',state='disabled'if closing else'normal')
        self.start_button.configure(state='disabled'if financial or search or closing else'normal')
        for button in (self.calendar_button,self.all_calendar_button,self.calendar_refresh_button,self.market_check):
            button.configure(state='disabled'if earnings or closing else'normal')
        self.cancel_button.configure(state='normal'if financial and not self.jobs['financial'].cancel_event.is_set()and not closing else'disabled')
        for button in (self.calendar_cancel_button,self.calendar_stop_button):
            button.configure(state='normal'if earnings and not self.jobs['earnings'].cancel_event.is_set()and not closing else'disabled')
        self.open_button.configure(state='normal'if self.result and not closing else'disabled')
        for name,bar in (('financial',self.progress),('earnings',self.earnings_progress)):
            if self._job_busy(name):bar.start(12)
            else:bar.stop()
        if hasattr(self,'search_progress'):
            if search:self.search_progress.start(12)
            else:self.search_progress.stop()
            self.search_state.set('検索中'if search else'待機中')

    def _job_status(self, name, text, state=None):
        self.jobs[name].message=text
        if state is not None:
            if name=='financial':self.financial_state.set(state)
            elif name=='earnings':self.earnings_state.set(state)
        labels={'financial':'Excel','earnings':'決算発表日','search':'企業検索'}
        active=[key for key in ('financial','earnings')if self._job_busy(key)]
        if name not in active:active.append(name)
        def summary(text):
            text=' '.join(str(text).split())
            return text if len(text)<=64 else text[:63]+'…'
        self.status.set('\n'.join(labels[key]+'：'+summary(self.jobs[key].message) for key in active if self.jobs[key].message))

    def _worker(self, name: str, call, done_kind: str):
        expected={'financial':'done','earnings':'earnings_done','search':'search_done'}
        if name not in expected or done_kind!=expected[name]:
            raise ValueError('バックグラウンド処理の結果種別が一致しません。')
        if self.closing:return False
        started=self.jobs[name].start(call,done_kind)
        if started:
            if name=='financial':self.financial_state.set('取得中')
            elif name=='earnings':self.earnings_state.set('更新中')
            self._sync_controls()
        return started

    def _search_button_clicked(self):
        if self._job_busy('search'):self._cancel_search()
        else:self._search()

    def _search(self, purpose: str = 'show'):
        if self._job_busy('search') or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showinfo('企業の検索', '銘柄コード、または会社名を入力してください。', parent=self.root)
            return
        self.pending_search_action = purpose
        offline = self.offline.get()
        self._job_status('search',f'「{query}」に一致する企業を検索しています。')
        self._worker('search', lambda cancel,log: (search_companies(query, cache_dir=self.cache_dir,
            offline=offline, cancel=cancel, log=log), purpose), 'search_done')

    def _search_done(self, results: list[dict], purpose: str):
        self.search_tree.delete(*self.search_tree.get_children())
        self.search_results = {}
        for i, company in enumerate(results):
            item = str(i)
            self.search_results[item] = dict(company)
            self.search_tree.insert('', 'end', iid=item, values=(company['code'], company.get('display_name') or display_company_name(company.get('company',''))))
        self.pending_search_action = purpose
        self._show_search_results(len(results))
        if not results:
            self.selected_company = None
            self.selected_text.set('一致する企業がありません。会社名の一部、または4文字の銘柄コードで再検索してください。')
            self.status.set('企業が見つかりませんでした。')
        elif len(results) == 1:
            self.search_tree.selection_set('0')
            self._set_company(results[0])
            self.status.set(f"{results[0]['code']} の企業情報を入力しました。")
            self._complete_search_action(purpose)
        else:
            self.selected_company = None
            self.selected_text.set(f'{len(results)}件見つかりました。検索結果をダブルクリックするか「選択した企業を入力」を押してください。')
            self.status.set('同じ名前を含む企業が複数あります。対象企業を選んでください。')
            self.search_tree.focus_set()

    def _complete_search_action(self, purpose):
        self.pending_search_action = 'show'
        if purpose == 'register':
            self._register_company()
        elif purpose == 'start':
            self._start()

    def _use_search_result(self):
        if self._job_busy('search') or self.closing:
            return
        selected = self.search_tree.selection()
        if not selected:
            self.status.set('検索結果から企業を選択してください。')
            return
        company = self.search_results[selected[0]]
        purpose = self.pending_search_action
        self._set_company(company)
        self._show_search_results(0)
        self.status.set(f"{company['code']} の企業情報を入力しました。")
        self._complete_search_action(purpose)

    def _register_company(self):
        if self._job_busy('search') or self.closing:
            return
        if self.selected_company is None:
            self._search('register')
            return
        try:
            company = self.registry.register(self.selected_company)
            self._refresh_registry()
            self.status.set(f"{company['code']} {display_company_name(company.get('company',''))} を登録しました。")
            self.registry_text.set('登録しました。「発表日を更新」で最新決算期末と本決算発表日を確認できます。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録できませんでした', str(exc), parent=self.root)

    def _refresh_registry(self):
        try:
            records = self.registry.calendar_rows()
        except (RegistryError, OSError, ValueError) as exc:
            self.registry_text.set(f'登録情報を読み込めませんでした：{exc}')
            self._append(f'登録情報：{exc}')
            return
        selected = self.registry_tree.selection()
        self._refreshing_registry=True
        self.registry_tree.delete(*self.registry_tree.get_children())
        self.registered = {record['code']: record for record in records}
        if self.selected_company is not None and self.code.get()==self.selected_company.get('code'):
            self._set_company(self.selected_company)
        elif self.code.get() in self.registered:
            self._set_company(self.registered[self.code.get()])
        official=[e for record in records for e in record.get('earnings_events',[])]
        official=combined_calendar_events(official,[e for e in getattr(self,'market_events',[]) if e.get('code') in self.registered])
        display_events=project_annual_estimates(records,official,today=japan_today())
        for record in records:
            display=with_estimated_next_date(record,display_events,today=japan_today())
            self.registry_tree.insert('', 'end', iid=record['code'], values=calendar_values(display))
        if selected and selected[0] in self.registered:
            self.registry_tree.selection_set(selected[0])
        elif self.code.get() in self.registered:
            self.registry_tree.selection_set(self.code.get())
        elif records:
            self.registry_tree.selection_set(records[0]['code'])
        if hasattr(self.root,'after_idle'):
            self._after_idle(lambda:setattr(self,'_refreshing_registry',False))
        else:self._refreshing_registry=False
        self.registry_text.set(f'登録企業：{len(records)}社。最新決算期末の新しい順（未取得は下段）。')
        if hasattr(self,'month_canvas'):self._render_calendar()

    def _use_registered(self, *, focus=True):
        if self._job_busy('search') or self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('登録企業から対象を選択してください。')
            return
        self._set_company(self.registered[selected[0]])
        if focus:self.notebook.select(self.create_tab)
        self.status.set('登録企業を入力しました。「Excelを作成」で取得できます。')
        if focus:self.code_entry.focus_set()

    def _remove_registered(self):
        if self.closing:
            return
        selected = self.registry_tree.selection()
        if not selected:
            self.status.set('解除する登録企業を選択してください。')
            return
        code = selected[0]
        try:
            self.registry.remove(code)
            self._refresh_registry()
            self.status.set(f'{code} の登録を解除しました。')
        except (RegistryError, OSError, ValueError) as exc:
            messagebox.showerror('登録を解除できませんでした', str(exc), parent=self.root)

    def _update_calendar(self):
        if self._job_busy('earnings') or self.closing:return
        selected=self.registry_tree.selection()
        if not selected:self.status.set('発表日を更新する登録企業を選択してください。');return
        self._update_earnings(codes=[selected[0]])

    def _update_all_calendars(self):
        if self._job_busy('earnings') or self.closing:return
        codes=list(self.registered)
        if not codes:
            self.status.set('登録企業がありません。企業を登録してから全社更新を実行してください。')
            return
        self._update_earnings(codes=codes)

    def _update_earnings(self,codes=None,market_only=False):
        if self._job_busy('earnings') or self.closing:return
        chosen=[]if market_only else(list(self.registered)if codes is None else list(codes))
        include_market=self.market_schedule.get()
        if not chosen and not include_market:
            self.status.set('企業を登録するか「公開予定も表示」を選んでください。');return
        offline=self.offline.get()
        self._job_status('earnings',(f'登録企業{len(chosen)}社の'if chosen else'公開予定の')+'本決算発表日・公式予定を確認しています。')
        def work(cancel,log):
            from .earnings import load_calendar,load_market_schedule
            warnings=[];count=0;market=None
            for code in chosen:
                if cancel.is_set():raise InterruptedError('発表日の更新を中止しました。')
                try:
                    calendar=load_calendar(code,cache_dir=self.cache_dir,offline=offline,refresh=not offline,cancel=cancel,log=log)
                    self.registry.update_earnings(code,calendar);count+=len(calendar.get('events',[]));warnings.extend(calendar.get('warnings',[]))
                except InterruptedError:raise
                except Exception as exc:warnings.append(f'{code}：{exc}')
            if include_market:
                try:
                    market=load_market_schedule(cache_dir=self.cache_dir,offline=offline,refresh=not offline,cancel=cancel,log=log)
                    warnings.extend(market.get('warnings',[]));count+=len(market.get('events',[]))
                except InterruptedError:raise
                except Exception as exc:warnings.append(f'公開予定：{exc}')
            if cancel.is_set():raise InterruptedError('発表日の更新を中止しました。')
            return {'market':market,'count':count,'warnings':warnings}
        self._worker('earnings',work,'earnings_done')

    def _make_options(self, code: str) -> Options:
        until = date.fromisoformat(self.until.get().strip()) if self.until.get().strip() else None
        years = int(self.years.get())
        if not 1 <= years <= 10:
            raise ValueError('取得期数は1～10を指定してください。')
        if not self.output.get().strip():
            raise ValueError('出力先を指定してください。')
        return Options(code=code, output_dir=Path(self.output.get()), cache_dir=self.cache_dir,
            years=years, basis=BASIS_OPTIONS[self.basis.get()], unit=UNIT_OPTIONS[self.unit.get()],
            until=until, offline=self.offline.get(), allow_partial=self.partial.get())

    def _start(self):
        if self._job_busy('financial') or self._job_busy('search') or self.closing:
            return
        query = self.code.get().strip()
        if not query:
            messagebox.showerror('入力を確認してください', '会社名、または銘柄コードを入力してください。', parent=self.root)
            return
        try:
            opts = self._make_options(query)
        except (ValueError, KeyError, tk.TclError) as exc:
            messagebox.showerror('入力を確認してください', str(exc), parent=self.root)
            return
        try:
            opts.code = validate_code(query)
        except ValueError:
            self._search('start')
            return
        code = opts.code
        self.result = None
        self.logs.configure(state='normal')
        self.logs.delete('1.0', 'end')
        self.logs.configure(state='disabled')
        self.result_notice.set('出典・未算出の理由は、Excelと同名の監査JSONに保存します。')
        self._job_status('financial',f'{code} の財務諸表を取得しています。初回は数分かかる場合があります。')
        self._worker('financial',lambda cancel,log:run(opts,log=log,cancel=cancel),'done')

    def _handle_event(self, kind, value, *, job_name=None):
        name=job_name or {'earnings_done':'earnings','search_done':'search'}.get(kind,'financial')
        expected={'financial':'done','earnings':'earnings_done','search':'search_done'}
        if name not in expected or kind not in {'log','error','cancelled','trace',expected[name]}:
            return
        job=self.jobs[name]
        prefix={'financial':'Excel','earnings':'決算発表日','search':'企業検索'}[name]
        if kind=='log':
            self._append(f'[{prefix}] {value}')
            self._job_status(name,value)
            return
        if kind=='trace':return
        # Finishing one slot never changes another slot's busy/cancel state.
        job.finish()
        self._sync_controls()
        if kind=='search_done':
            if job.cancel_event.is_set()or self.closing:
                self.pending_search_action='show'
                self._job_status(name,'企業の検索を中止しました。')
            else:
                results,purpose=value
                self._search_done(results,purpose)
        elif kind=='earnings_done':
            if value.get('market')is not None:self.market_events=value['market'].get('events',[])
            self._refresh_registry()
            for warning in value.get('warnings',[]):self._append(f'[決算発表日] {warning}')
            self._job_status(name,f"本決算発表日・公式予定を{value.get('count',0)}件確認しました。"+
                (' 一部の予定は未公表・取得できません。詳細はログをご確認ください。'if value.get('warnings')else''),'完了')
        elif kind=='done':
            self.result=value
            try:self.financial_charts.set_dataset(value.dataset)
            except Exception as exc:self._append(f'[Excel] Excelは作成済みです。グラフを表示できませんでした：{exc}')
            notice=getattr(value,'basis_notice','')or''
            capm=getattr(value.dataset,'export_metadata',{}).get('supplemental',{}).get('CAPM',{})
            missing=set(period for period,details in capm.get('periods',{}).items()
                        if details.get('missing_inputs'))
            missing.update(item.get('period') for item in capm.get('calibrations',[])
                           if not item.get('complete'))
            market_notice=(f'CAPM：{len(missing)}期に未算出の指標があります。理由は同名の監査JSONに保存しています。'
                           if missing else '')
            tag='要確認の出力'if value.dataset.warnings else'作成完了'
            if notice or market_notice:
                self.result_notice.set(' '.join(text for text in (notice,market_notice) if text))
                self._append('[Excel] '+self.result_notice.get())
            summary='完了（個別CF未掲載のため取得区分を切替）'if notice else tag
            self._job_status(name,f'{summary}：{value.workbook.name}',
                             '完了・区分切替'if notice else'完了・CAPM一部未算出'if market_notice else'完了')
            self._append(f'[Excel] Excel：{value.workbook}\n監査記録：{value.audit}')
            try:
                record=self.registry.update_result(value.dataset)
                if record is not None:self._refresh_registry()
            except (RegistryError,OSError,ValueError)as exc:
                self._append(f'[Excel] Excelは作成済みです。登録情報の更新に失敗しました：{exc}')
            self._sync_controls()
        elif kind=='error':
            if name=='earnings':self._refresh_registry()
            self._append(f'[{prefix}] {value}')
            self._job_status(name,'処理を完了できませんでした。詳細はログをご確認ください。','エラー')
        elif kind=='cancelled':
            if name=='earnings':self._refresh_registry()
            self._append(f'[{prefix}] {value}')
            self._job_status(name,str(value),'中止')

    def _drain_jobs(self):
        # A chatty financial worker cannot starve an earnings completion event.
        for name,job in self.jobs.items():
            for kind,value in job.pending():
                self._handle_event(kind,value,job_name=name)

    def _poll(self):
        self._poll_after_id=None
        self._drain_jobs()
        if self.closing and all(job.thread is None or not job.thread.is_alive()for job in self.jobs.values()):
            self._stop_ui_poll()
            self.root.destroy()
            return
        self._poll_after_id=self.root.after(100,self._poll)

    def _stop_ui_poll(self):
        timer=getattr(self,'_poll_after_id',None)
        if timer is not None:
            self.root.after_cancel(timer)
            self._poll_after_id=None
        for timer in list(getattr(self,'_idle_callbacks',set())):
            self.root.after_cancel(timer)
        if hasattr(self,'_idle_callbacks'):self._idle_callbacks.clear()

    def _root_destroyed(self,event):
        if event.widget is self.root:
            self.closing=True
            for job in self.jobs.values():job.cancel()
            self._stop_ui_poll()

    def _cancel_job(self,name):
        job=self.jobs[name]
        if not job.busy:return
        job.cancel()
        self._job_status(name,'中止しています。実行中の通信が終了するまでお待ちください。','中止中')
        self._sync_controls()

    def _cancel_financial(self):self._cancel_job('financial')
    def _cancel_earnings(self):self._cancel_job('earnings')
    def _cancel_search(self):self._cancel_job('search')

    def _cancel(self):
        """Compatibility for the financial cancel action; never cancels earnings."""
        self._cancel_financial()

    def _close(self):
        if self.busy:
            self.closing=True
            for name in self.jobs:self._cancel_job(name)
            self._sync_controls()
        else:
            self._stop_ui_poll()
            self.root.destroy()

    def _open_path(self, path: Path):
        try:
            if sys.platform == 'win32':
                os.startfile(str(path))
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', str(path)])
            else:
                subprocess.Popen(['xdg-open', str(path)])
        except OSError as exc:
            messagebox.showerror('開けませんでした', str(exc), parent=self.root)

    def _open_file(self):
        if self.result:
            self._open_path(self.result.workbook)

    def _open_folder(self):
        path = Path(self.output.get()).expanduser()
        if path.is_dir():
            self._open_path(path)
        else:
            messagebox.showinfo('出力先', 'Excelの作成後にフォルダーを開けます。', parent=self.root)


def launch(initial_code: str = '6947'):
    root = tk.Tk()
    App(root, initial_code)
    root.mainloop()
