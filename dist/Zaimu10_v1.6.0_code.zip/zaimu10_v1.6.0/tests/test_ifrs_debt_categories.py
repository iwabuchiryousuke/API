"""IFRS current portions keep their individual debt scopes and issuer IDs."""
from dataclasses import replace
from datetime import date
from decimal import Decimal
import json

import pytest

from zaimu10.analysis import debt_category,_narrow_ifrs_current_loan
from zaimu10.models import Row,Cell,Source,Period

P=Period(date(2019,4,1),date(2020,3,31))
STANDARD='http://disclosure.edinet-fsa.go.jp/taxonomy/jpigp/2019-11-01/jpigp_cor'
ISSUER='http://disclosure.edinet-fsa.go.jp/jpcrp030000/asr/001/E00436-000/2020-03-31/01/2020-06-24'

def account(local,*,namespace=STANDARD,label='',section=('負債の部','流動負債')):
    source=Source('S100LN4K','original.xhtml','https://disclosure2.edinet-fsa.go.jp/',
        concept='{'+namespace+'}'+local,basis='consolidated',unit='JPY',original_label=label,
        context_id='CurrentYearInstant',decimals='-6')
    key=json.dumps(['BS_LE',local,[],'end','JPY','consolidated'])
    return Row(key,label or local,'BS_LE',section=section,
        values={P.key:Cell(Decimal('1000000'),source,source_section=section)})

@pytest.mark.parametrize('local,category',[
    ('CurrentPortionOfLongTermBorrowingsCLIFRS','current_long_term_borrowings'),
    ('CurrentPortionOfBondsCLIFRS','current_bonds'),
    ('BorrowingsNCLIFRS','long_term_borrowings'),
    ('LongTermAccountsPayableOther',None),
])
def test_disclosed_standard_current_portions_are_not_dropped_or_renamed(local,category):
    row=account(local);before=row.values[P.key].source.concept
    assert debt_category(row)==category
    assert row.values[P.key].source.concept==before


@pytest.mark.parametrize('local',['CurrentPortionOfLongTermBorrowingsCLIFRS','CurrentPortionOfBondsCLIFRS'])
def test_new_standard_element_spelling_does_not_certify_unknown_extension(local):
    row=account(local,namespace=ISSUER)
    assert debt_category(row) is None

def test_verified_issuer_typo_retains_original_identity():
    row=account('CurrentPortionOfBondsCLIFRSIFRS',namespace=ISSUER,label='１年内償還予定の社債')
    assert debt_category(row)=='current_bonds'
    assert row.values[P.key].source.concept.endswith('}CurrentPortionOfBondsCLIFRSIFRS')

@pytest.mark.parametrize('change',['issuer','caption','section','standard'])
def test_issuer_typo_proof_is_not_generalized_by_spelling(change):
    row=account('CurrentPortionOfBondsCLIFRSIFRS',namespace=ISSUER,label='１年内償還予定の社債')
    cell=row.values[P.key]
    if change=='issuer':cell.source=replace(cell.source,concept=cell.source.concept.replace('E00436','E01966'))
    elif change=='caption':cell.source=replace(cell.source,original_label='その他')
    elif change=='section':cell.source_section=('負債の部','非流動負債')
    else:cell.source=replace(cell.source,concept='{'+STANDARD+'}CurrentPortionOfBondsCLIFRSIFRS')
    assert debt_category(row) is None


def test_qualified_commercial_paper_is_debt_but_similar_unknown_issuer_is_not():
    row=account('CommercialPapersCLIFRS',namespace=ISSUER,label='コマーシャル・ペーパー')
    assert debt_category(row)=='commercial_paper'
    row.values[P.key].source=replace(row.values[P.key].source,
        concept=row.values[P.key].source.concept.replace('E00436','E01966'))
    assert debt_category(row) is None


def loan_proof_inputs():
    short=account('BorrowingsCLIFRS',label='短期借入金')
    portion=account('CurrentPortionOfLongTermBorrowingsCLIFRS',label='１年内返済予定の長期借入金')
    short.values[P.key].value=Decimal('6350000000')
    portion.values[P.key].value=Decimal('4095000000')
    a,b=short.values[P.key],portion.values[P.key]
    note_short=Cell(a.value,replace(a.source,filename='notes.xhtml',context_id='CurrentYearDuration'))
    note_portion=Cell(b.value,replace(b.source,filename='notes.xhtml',context_id='CurrentYearDuration'))
    main={'current_borrowings':[(short,a)],'current_long_term_borrowings':[(portion,b)]}
    notes={'short_term_borrowings':[(short,note_short)],'current_long_term_borrowings':[(portion,note_portion)]}
    status={'ifrs_borrowings_coverage':[Cell(None,note_short.source)]}
    return main,notes,status


def test_same_original_separate_ifrs_short_and_current_long_term_are_both_countable():
    main,notes,status=loan_proof_inputs()
    proof=_narrow_ifrs_current_loan(main,notes,status,P)
    assert proof and proof['short_term_jpy']=='6350000000'
    assert proof['current_long_term_jpy']=='4095000000'
    assert 'current_borrowings'not in main and 'short_term_borrowings'in main
    assert main['short_term_borrowings'][0][1].source.concept.endswith('}BorrowingsCLIFRS')


def test_generic_total_hint_does_not_override_explicit_separate_source_scope():
    main,notes,status=loan_proof_inputs()
    main['current_borrowings'][0][0].is_total=True
    main['current_long_term_borrowings'][0][0].is_total=True
    assert _narrow_ifrs_current_loan(main,notes,status,P)


@pytest.mark.parametrize('mutation',['other_document','inconsistent_short','inconsistent_portion',
    'no_coverage','no_separate_portion','unclear_caption','different_main_context','nested_main',
    'nil','zero_portion','rounding_ambiguous'])
def test_narrow_scope_is_never_guessed_without_all_proofs(mutation):
    main,notes,status=loan_proof_inputs()
    short=main['current_borrowings'][0][1]
    note=notes['short_term_borrowings'][0][1]
    if mutation=='other_document':note.source=replace(note.source,doc_id='S100OTHER')
    elif mutation=='inconsistent_short':note.value+=Decimal('100000000')
    elif mutation=='inconsistent_portion':notes['current_long_term_borrowings'][0][1].value+=Decimal('100000000')
    elif mutation=='no_coverage':status={}
    elif mutation=='no_separate_portion':main.pop('current_long_term_borrowings')
    elif mutation=='unclear_caption':short.source=replace(short.source,original_label='借入金')
    elif mutation=='different_main_context':short.source=replace(short.source,context_id='OtherPeriodInstant')
    elif mutation=='nested_main':main['current_long_term_borrowings'][0][0].indent+=1
    elif mutation=='nil':note.value=None;note.nil=True
    elif mutation=='zero_portion':main['current_long_term_borrowings'][0][1].value=Decimal(0)
    else:
        main['current_long_term_borrowings'][0][1].value=Decimal('1000000')
        notes['current_long_term_borrowings'][0][1].value=Decimal('1000000')
    assert _narrow_ifrs_current_loan(main,notes,status,P) is None
    assert 'current_borrowings'in main
