"""Desktop distribution: isolation, honest startup status, and local entry paths.

No test downloads packages or opens a GUI. Installer process boundaries are
substituted, while actual app/CLI self-check entry points also run in subprocesses
from a directory containing spaces and Japanese characters.
"""
from __future__ import annotations

import builtins
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest

PROJECT = Path(__file__).resolve().parents[1]


def load_entry(filename, monkeypatch):
    monkeypatch.syspath_prepend(str(PROJECT))
    spec = importlib.util.spec_from_file_location('desktop_test_' + filename.removesuffix('.py'), PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def app(monkeypatch):
    return load_entry('app.py', monkeypatch)


@pytest.fixture
def setup(monkeypatch):
    return load_entry('setup_app.py', monkeypatch)


def environment_tree(setup, base):
    executable = setup.environment_python(base)
    executable.parent.mkdir(parents=True, exist_ok=True)
    executable.write_text('test interpreter placeholder', encoding='utf-8')
    (base/'.venv'/'pyvenv.cfg').write_text(
        f'home = {Path(sys.executable).parent}\ninclude-system-site-packages = false\nversion = 3.12.0\n',
        encoding='utf-8')
    return executable


def installer_processes(monkeypatch, setup, base, *, prefix=None, base_prefix=None,
                        pip_status=0, ready_status=0, version_status=0,
                        pip_version_status=0, ensurepip_status=0, version=(3,12,0)):
    """Return interpreter metadata without ever executing placeholder binaries."""
    calls = {'run': [], 'pip': []}
    metadata = {'prefix': str(prefix or base/'.venv'),
                'base_prefix': str(base_prefix or Path(sys.base_prefix)),
                'executable': str(setup.environment_python(base)),
                'version': list(version), 'version_info': list(version),
                'paths': {'purelib':str(base/'.venv'/'lib'/'site-packages'),
                          'platlib':str(base/'.venv'/'lib'/'site-packages'),
                          'scripts':str(setup.environment_python(base).parent),
                          'data':str(base/'.venv')}}
    def runner(argv, **kwargs):
        calls['run'].append((list(argv), kwargs))
        if '--self-check' in argv:
            return subprocess.CompletedProcess(argv, ready_status,
                stdout=json.dumps({'ready': ready_status==0, 'problems': []}), stderr='')
        if '-c' in argv:
            return subprocess.CompletedProcess(argv, version_status,
                                               stdout=json.dumps(metadata), stderr='')
        if argv[1:4]==['-m','pip','--version']:
            return subprocess.CompletedProcess(argv,pip_version_status,stdout='pip test',stderr='')
        if argv[1:3]==['-m','ensurepip']:
            if ensurepip_status and kwargs.get('check'):
                raise subprocess.CalledProcessError(ensurepip_status,argv)
            return subprocess.CompletedProcess(argv,ensurepip_status,stdout='',stderr='')
        raise AssertionError(f'unexpected process {argv}')
    class PipProcess:
        def __init__(self, argv, **kwargs):
            calls['pip'].append((list(argv), kwargs))
            self.stdout = iter(['test package install output\n'])
            self.returncode = pip_status
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def wait(self): return pip_status
    monkeypatch.setattr(setup.subprocess, 'run', runner)
    monkeypatch.setattr(setup.subprocess, 'Popen', PipProcess)
    return calls


def test_environment_python_uses_app_local_platform_location(setup, monkeypatch, tmp_path):
    base=tmp_path/'日本語 app folder'
    monkeypatch.setattr(setup.sys, 'platform', 'win32')
    assert setup.environment_python(base)==base/'.venv'/'Scripts'/'python.exe'
    monkeypatch.setattr(setup.sys, 'platform', 'linux')
    assert setup.environment_python(base)==base/'.venv'/'bin'/'python'


@pytest.mark.parametrize('platform, expected_symlinks',
                         [('linux',True),('darwin',True),('win32',False)])
def test_first_setup_creates_own_environment_and_keeps_user_files(
        setup, monkeypatch, tmp_path, platform, expected_symlinks):
    monkeypatch.setattr(setup.sys,'platform',platform)
    base=tmp_path/'日本語 app folder';base.mkdir()
    for folder, filename in [('results','edited.xlsx'),('.cache','source.json')]:
        target=base/folder/filename;target.parent.mkdir();target.write_bytes(b'preserve user data')
    created=[]
    class Builder:
        def __init__(self, **kwargs):
            assert kwargs.get('with_pip') is True
            assert not kwargs.get('clear', False)
            # POSIX standalone Python needs its binary symlinked so bundled
            # Tcl/Tk libraries remain discoverable. Windows uses its ordinary
            # venv redirector/copy behavior instead.
            assert kwargs.get('symlinks') is expected_symlinks
        def create(self, path):
            created.append(Path(path))
            environment_tree(setup, base)
    monkeypatch.setattr(setup.venv, 'EnvBuilder', Builder)
    calls=installer_processes(monkeypatch, setup, base)
    assert setup.install(base)==0
    assert created==[base/'.venv']
    [pip]=calls['pip'];argv, kwargs=pip
    assert Path(argv[0])==setup.environment_python(base)
    assert argv[1:3]==['-m','pip']
    assert argv[argv.index('-r')+1]==str(base/'requirements.txt')
    assert Path(kwargs['cwd'])==base
    assert (base/'results'/'edited.xlsx').read_bytes()==b'preserve user data'
    assert (base/'.cache'/'source.json').read_bytes()==b'preserve user data'
    assert '準備ができました' in (base/'logs'/'setup.log').read_text(encoding='utf-8')


def test_existing_valid_environment_is_reused_without_recreating_or_erasing(setup, monkeypatch, tmp_path):
    base=tmp_path/'existing app';base.mkdir();environment_tree(setup,base)
    sentinel=base/'.venv'/'user-marker.txt';sentinel.write_text('keep',encoding='utf-8')
    def forbidden(*args, **kwargs):raise AssertionError('must not recreate an existing valid environment')
    monkeypatch.setattr(setup.venv,'EnvBuilder',forbidden)
    calls=installer_processes(monkeypatch,setup,base)
    assert setup.install(base)==0
    assert sentinel.read_text()=='keep'
    assert len(calls['pip'])==1


def test_existing_system_interpreter_cannot_run_pip(setup, monkeypatch, tmp_path):
    base=tmp_path/'suspicious app';base.mkdir();environment_tree(setup,base)
    # A copied system interpreter, even at a path named .venv/bin/python, must
    # never authorize package installation into the system prefix.
    shared=tmp_path/'system prefix'
    calls=installer_processes(monkeypatch,setup,base,prefix=shared,base_prefix=shared)
    assert setup.install(base)==1
    assert calls['pip']==[]
    assert setup.environment_python(base).read_text()=='test interpreter placeholder'


def test_external_environment_cannot_be_modified(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    calls=installer_processes(monkeypatch,setup,base,prefix=tmp_path/'other environment')
    assert setup.install(base)==1
    assert calls['pip']==[]


def test_nested_package_directory_link_cannot_write_outside_app(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    outside=tmp_path/'shared packages';outside.mkdir()
    sentinel=outside/'preserve.txt';sentinel.write_text('outside must remain unchanged')
    package_dir=base/'.venv'/'lib'/'site-packages'
    package_dir.parent.mkdir()
    try:
        package_dir.symlink_to(outside,target_is_directory=True)
    except (OSError,NotImplementedError):
        pytest.skip('this test host cannot create directory symlinks')
    calls=installer_processes(monkeypatch,setup,base)
    assert setup.install(base)==1
    assert calls['pip']==[]
    assert sentinel.read_text()=='outside must remain unchanged'


def test_environment_directory_link_is_refused_before_processes(setup, monkeypatch, tmp_path):
    external_base=tmp_path/'external';external_base.mkdir();environment_tree(setup,external_base)
    base=tmp_path/'app';base.mkdir()
    try:
        (base/'.venv').symlink_to(external_base/'.venv',target_is_directory=True)
    except (OSError,NotImplementedError):
        pytest.skip('this test host cannot create directory symlinks')
    calls=installer_processes(monkeypatch,setup,base)
    assert setup.install(base)==1
    assert calls['run']==[] and calls['pip']==[]


def test_old_environment_python_is_refused_without_erasing_it(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();executable=environment_tree(setup,base)
    calls=installer_processes(monkeypatch,setup,base,version=(3,9,19))
    assert setup.install(base)==1
    assert calls['pip']==[]
    assert executable.read_text()=='test interpreter placeholder'


def test_pip_target_configuration_cannot_escape_app_environment(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    monkeypatch.setenv('PIP_TARGET', str(tmp_path/'outside target'))
    monkeypatch.setenv('PIP_PREFIX', str(tmp_path/'outside prefix'))
    monkeypatch.setenv('PIP_USER', 'true')
    monkeypatch.setenv('HTTP_PROXY','http://proxy.example:8080')
    calls=installer_processes(monkeypatch,setup,base)
    assert setup.install(base)==0
    [pip]=calls['pip'];argv,kwargs=pip
    env=kwargs.get('env',{})
    assert '--isolated' in argv or (
        not env.get('PIP_TARGET') and not env.get('PIP_PREFIX')
        and env.get('PIP_USER','').lower() not in {'1','true','yes'}
        and env.get('PIP_CONFIG_FILE')==os.devnull)
    assert env.get('HTTP_PROXY')=='http://proxy.example:8080'
    assert not (tmp_path/'outside target').exists()
    assert not (tmp_path/'outside prefix').exists()


def test_failed_pip_never_reports_ready_or_starts_application(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    calls=installer_processes(monkeypatch,setup,base,pip_status=7)
    assert setup.install(base)==1
    assert not any('--self-check' in argv for argv,_ in calls['run'])
    log=(base/'logs'/'setup.log').read_text(encoding='utf-8')
    assert 'インストールに失敗' in log
    assert '準備ができました' not in log


def test_failed_final_self_check_never_reports_setup_success(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    installer_processes(monkeypatch,setup,base,ready_status=1)
    assert setup.install(base)==1
    log=(base/'logs'/'setup.log').read_text(encoding='utf-8')
    assert '起動準備の確認に失敗' in log
    assert '準備ができました' not in log


def test_missing_pip_is_repaired_only_by_verified_environment_python(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    calls=installer_processes(monkeypatch,setup,base,pip_version_status=1)
    assert setup.install(base)==0
    repairs=[argv for argv,_ in calls['run'] if argv[1:3]==['-m','ensurepip']]
    assert repairs==[[str(setup.environment_python(base)),'-m','ensurepip','--upgrade']]
    assert len(calls['pip'])==1


def test_failed_pip_repair_stops_before_dependency_install(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    calls=installer_processes(monkeypatch,setup,base,pip_version_status=1,ensurepip_status=3)
    assert setup.install(base)==1
    assert calls['pip']==[]


def test_check_missing_environment_is_read_only(setup, monkeypatch, tmp_path):
    def forbidden(*args, **kwargs):raise AssertionError('check must not run installer')
    monkeypatch.setattr(setup.subprocess,'run',forbidden)
    assert setup.check_environment(tmp_path/'not installed')!=0
    assert list(tmp_path.iterdir())==[]


def test_check_process_timeout_returns_failure_without_repair(setup, monkeypatch, tmp_path):
    base=tmp_path/'app';base.mkdir();environment_tree(setup,base)
    def timeout(argv, **kwargs):raise subprocess.TimeoutExpired(argv,kwargs['timeout'])
    monkeypatch.setattr(setup.subprocess,'run',timeout)
    assert setup.check_environment(base)!=0
    assert not (base/'logs').exists()


def test_missing_tkinter_does_not_create_environment_or_install(setup, monkeypatch, tmp_path):
    actual_import=builtins.__import__
    def import_without_tk(name,*args,**kwargs):
        if name=='tkinter':raise ImportError('tk unavailable')
        return actual_import(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',import_without_tk)
    assert setup.install(tmp_path/'app')==1
    assert list(tmp_path.iterdir())==[]


def test_missing_financial_backend_is_not_reported_ready(app, monkeypatch):
    actual=app.importlib.import_module
    def import_missing(name):
        if name=='zaimu10.edinet':raise ModuleNotFoundError('missing EDINET reader')
        return actual(name)
    monkeypatch.setattr(app.importlib,'import_module',import_missing)
    state=app.self_check()
    assert state['ready'] is False
    assert any('EDINET' in item or 'edinet' in item for item in state['problems'])


def test_unexpected_import_failure_becomes_failed_self_check_json(app, monkeypatch, capsys):
    actual=app.importlib.import_module
    def broken_import(name):
        if name=='requests':raise RuntimeError('library initialization failed')
        return actual(name)
    monkeypatch.setattr(app.importlib,'import_module',broken_import)
    assert app.main(['--self-check'])==1
    state=json.loads(capsys.readouterr().out)
    assert state['ready'] is False
    assert any('initialization failed' in problem for problem in state['problems'])


def test_explicit_cli_does_not_run_desktop_check_or_launch(app, monkeypatch):
    import zaimu10.__main__ as cli
    def forbidden():raise AssertionError('CLI must not self-check or open the GUI')
    monkeypatch.setattr(app,'self_check',forbidden)
    captured=[]
    monkeypatch.setattr(cli,'main',lambda argv: captured.append(argv) or 17)
    assert app.main(['6947','--years','2'])==17
    assert captured==[['6947','--years','2']]


def test_not_ready_desktop_returns_failure_and_never_launches(app, monkeypatch):
    import zaimu10.gui as gui
    monkeypatch.setattr(app,'self_check',lambda:{'ready':False,'problems':['missing dependency']})
    def forbidden():raise AssertionError('must not launch before readiness')
    monkeypatch.setattr(gui,'launch',forbidden)
    messages=[];monkeypatch.setattr(app,'_error',messages.append)
    assert app.main([])==1
    assert messages and 'missing dependency' in messages[0]


def test_unexpected_gui_error_is_logged_inside_app_and_returns_failure(app, monkeypatch, tmp_path):
    import zaimu10.gui as gui
    base=tmp_path/'日本語 app folder';base.mkdir()
    monkeypatch.setattr(app,'BASE',base)
    monkeypatch.setattr(app,'self_check',lambda:{'ready':True,'problems':[]})
    def failure():raise RuntimeError('explicit GUI failure')
    monkeypatch.setattr(gui,'launch',failure)
    messages=[];monkeypatch.setattr(app,'_error',messages.append)
    assert app.main([])==1
    log=base/'logs'/'startup_error.log'
    assert 'explicit GUI failure' in log.read_text(encoding='utf-8')
    assert str(log) in messages[0]
    assert sorted(p.name for p in tmp_path.iterdir())==['日本語 app folder']


@pytest.fixture
def copied_app(tmp_path):
    target=tmp_path/'展開先 with spaces';target.mkdir()
    shutil.copy2(PROJECT/'app.py',target/'app.py')
    shutil.copy2(PROJECT/'setup_app.py',target/'setup_app.py')
    shutil.copytree(PROJECT/'zaimu10',target/'zaimu10',ignore=shutil.ignore_patterns('__pycache__'))
    return target


def command(script, *args, cwd):
    env=os.environ.copy();env.pop('PYTHONPATH',None)
    env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
    return subprocess.run([sys.executable,str(script),*args],cwd=cwd,env=env,
                          capture_output=True,text=True,encoding='utf-8',timeout=30,check=False)


def test_actual_app_self_check_from_other_cwd_and_unicode_space_path(copied_app,tmp_path):
    proc=command(copied_app/'app.py','--self-check',cwd=tmp_path)
    assert proc.returncode==0,proc.stdout+proc.stderr
    state=json.loads(proc.stdout)
    assert state['application']=='Zaimu10' and state['ready'] is True
    assert state['problems']==[] and state['version']
    assert not (copied_app/'logs').exists()


def test_actual_cli_help_never_opens_window_or_installs(copied_app,tmp_path):
    proc=command(copied_app/'app.py','--help',cwd=tmp_path)
    assert proc.returncode==0,proc.stdout+proc.stderr
    assert '--years' in proc.stdout and '--output' in proc.stdout
    assert not (copied_app/'.venv').exists()
    assert not (copied_app/'logs').exists()


def test_actual_invalid_code_fails_before_any_acquisition(copied_app,tmp_path):
    proc=command(copied_app/'app.py','BAD-CODE',cwd=tmp_path)
    assert proc.returncode!=0
    assert '銘柄コード' in proc.stderr
    assert not (tmp_path/'results').exists()
    assert not (tmp_path/'.cache').exists()


def test_actual_setup_check_is_read_only_when_not_installed(copied_app,tmp_path):
    proc=command(copied_app/'setup_app.py','--check',cwd=tmp_path)
    assert proc.returncode!=0
    assert not (copied_app/'.venv').exists()
    assert not (copied_app/'logs').exists()
