"""v1.1 orchestration contracts with original-source boundaries substituted.

The real company resolver, merge, verification, presentation and audit writer
run here. A small exporter spy checks the resolved unit and leaves layout tests
to the workbook suite; no test needs to contact EDINET.
"""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import csv
import io
import json
import zipfile

import pytest

from zaimu10.models import Cell, Dataset, Filing, Period, Row, Source, SHEETS
from zaimu10.service import Options, run
from zaimu10.discovery import DiscoveryError


OLD = Period(date(2023,4,1),date(2024,3,31))
NEW = Period(date(2024,4,1),date(2025,3,31))
OLD_ID, NEW_ID = 'S100AAAA', 'S100BBBB'
OFFICIAL = '株式会社　検証会社'


def _cache_directory(cache):
    path=cache/'discovery';path.mkdir(parents=True)
    output=io.StringIO(newline='');writer=csv.writer(output)
    writer.writerow(['ダウンロード実行日','2026年11月18日現在'])
    writer.writerow(['ＥＤＩＮＥＴコード','提出者名','証券コード','連結の有無','決算日'])
    writer.writerow(['E01966',OFFICIAL,'69470','有','3月31日'])
    writer.writerow(['E00001','検証工業株式会社','10000','有','3月31日'])
    with zipfile.ZipFile(path/'Edinetcode.zip','w') as archive:
        archive.writestr('EdinetcodeDlInfo.csv',output.getvalue().encode('cp932'))


def _filing(doc_id,period):
    return Filing(doc_id,company=OFFICIAL,code='6947',edinet_code='E01966',
                  start=period.start,end=period.end,
                  submitted=f'{period.end.year}-06-20 14:00',description='有価証券報告書')


def _original_dataset(doc_id,periods,*,scale=6,namespace_date='2024-11-01'):
    dataset=Dataset('6947',OFFICIAL,'consolidated',periods,
                    accounting_standard='J-GAAP')
    namespace=f'http://disclosure.edinet-fsa.go.jp/taxonomy/jppfs/{namespace_date}/jppfs_cor'
    concepts={'PL':'NetSales','BS_A':'Assets','BS_LE':'LiabilitiesAndNetAssets',
              'CF':'NetCashProvidedByUsedInOperatingActivities'}
    for statement,local in concepts.items():
        qname=f'{{{namespace}}}{local}'
        row=Row(json.dumps([statement,qname,[],'duration' if statement in {'PL','CF'} else 'end','JPY','consolidated']),
                local,statement)
        for period in periods:
            source=Source(doc_id,'financial.xhtml',
                f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{doc_id}',
                submitted=f'{2025 if doc_id==NEW_ID else 2024}-06-20 14:00',
                concept=qname,unit='JPY',decimals=str(-scale),scale=scale,
                raw_value='1000',basis='consolidated',original_label=local)
            row.values[period.key]=Cell(Decimal('1000000000'),source)
        dataset.rows[statement].append(row)
    return dataset


def _sources(monkeypatch,*,latest_scale=6):
    monkeypatch.setattr('zaimu10.service._prepare_capm_market', lambda *a, **k: {})
    import zaimu10.discovery as discovery
    import zaimu10.edinet as edinet
    import zaimu10.parser as parser
    import zaimu10.excel as excel
    calls={'discover':[],'export':[]}
    originals={NEW_ID:_original_dataset(NEW_ID,[OLD,NEW],scale=latest_scale),
               OLD_ID:_original_dataset(OLD_ID,[OLD],scale=3,namespace_date='2023-11-01')}
    def discover(code,**kwargs):
        calls['discover'].append(code)
        return [_filing(NEW_ID,NEW),_filing(OLD_ID,OLD)]
    def export(dataset,path,unit):
        calls['export'].append((deepcopy(dataset),path,unit))
        path.write_bytes(b'service-test-export')
    monkeypatch.setattr(discovery,'discover_filings',discover)
    monkeypatch.setattr(edinet,'fetch_filing',lambda *args,**kwargs:[('financial.xhtml','original')])
    monkeypatch.setattr(parser,'parse_filing',lambda filing,*args,**kwargs:deepcopy(originals[filing.doc_id]))
    monkeypatch.setattr(excel,'export_workbook',export)
    return calls,originals


@pytest.mark.parametrize('scale,unit',[(3,'thousand'),(6,'million')])
def test_auto_unit_follows_latest_disclosure_and_name_filename_uses_latest_actual_end(monkeypatch,tmp_path,scale,unit):
    calls,_=_sources(monkeypatch,latest_scale=scale)
    cache=tmp_path/'cache';_cache_directory(cache)
    options=Options('株式会社 検証会社',tmp_path/'results',cache_dir=cache,years=2,offline=True)
    result=run(options,log=lambda _:None)
    assert options.code=='6947'
    assert calls['discover']==['6947']
    assert calls['export'][0][2]==unit
    assert result.workbook.name=='6947_検証会社_2025-03-31.xlsx'
    assert result.dataset.company=='検証会社'
    assert not result.dataset.warnings
    assert result.workbook.stem==result.audit.name.removesuffix('.audit.json')


def test_ambiguous_name_stops_before_any_financial_acquisition_or_output(monkeypatch,tmp_path):
    calls,_=_sources(monkeypatch)
    cache=tmp_path/'cache';_cache_directory(cache)
    with pytest.raises(DiscoveryError,match='複数の企業'):
        run(Options('検証',tmp_path/'results',cache_dir=cache,offline=True),log=lambda _:None)
    assert calls['discover']==[] and calls['export']==[]
    assert not (tmp_path/'results').exists()


def test_audit_v2_retains_official_name_authoritative_raw_periods_and_source_values(monkeypatch,tmp_path):
    calls,originals=_sources(monkeypatch)
    result=run(Options('6947',tmp_path/'results',cache_dir=tmp_path/'cache',years=2),log=lambda _:None)
    audit=json.loads(result.audit.read_text(encoding='utf-8'))
    assert audit['format_version']==2
    assert audit['raw_dataset']['company']==OFFICIAL
    assert audit['dataset']['company']=='検証会社'
    raw_rows=audit['raw_dataset']['rows']['PL']
    assert len(raw_rows)==1
    raw_sources=[cell['source'] for row in raw_rows for cell in row['values'].values()]
    assert {s['doc_id'] for s in raw_sources}=={NEW_ID}
    assert all('/2024-11-01/' in s['concept'] for s in raw_sources)
    assert audit['raw_dataset']['period_sources']=={OLD.key:NEW_ID,NEW.key:NEW_ID}
    assert audit['dataset']['period_sources']=={OLD.key:NEW_ID,NEW.key:NEW_ID}
    # The raw record preserves the complete selected QName; presentation uses
    # a separate semantic key. Older original lines cannot fill a gap in the
    # authoritative comparative representation and duplicate reclassifications.
    assert '/2024-11-01/' in raw_rows[0]['key']
    assert raw_rows[0]['key']!=audit['dataset']['rows']['PL'][0]['key']
    assert all(cell['value']=='1000000000' for row in raw_rows for cell in row['values'].values())
    assert len(result.dataset.rows['PL'])==1
    assert result.dataset.rows['PL'][0].values[OLD.key].source.doc_id==NEW_ID
    # The original parser-returned datasets were never changed by presentation.
    assert originals[NEW_ID].company==OFFICIAL
    assert originals[OLD_ID].rows['PL'][0].values[OLD.key].source.doc_id==OLD_ID


def test_manual_unit_override_and_repeat_export_preserve_existing_user_files(monkeypatch,tmp_path):
    calls,_=_sources(monkeypatch,latest_scale=6)
    options=lambda:Options('6947',tmp_path/'results',cache_dir=tmp_path/'cache',years=2,unit='yen')
    first=run(options(),log=lambda _:None)
    first.workbook.write_bytes(b'user-edited-workbook')
    audit_before=first.audit.read_bytes()
    second=run(options(),log=lambda _:None)
    assert [call[2] for call in calls['export']]==['yen','yen']
    assert second.workbook.name=='6947_検証会社_2025-03-31_2.xlsx'
    assert first.workbook.read_bytes()==b'user-edited-workbook'
    assert first.audit.read_bytes()==audit_before


def test_reclassified_old_component_is_not_added_to_complete_newer_comparative(monkeypatch,tmp_path):
    _,originals=_sources(monkeypatch)
    base=originals[OLD_ID].rows['BS_A'][0].values[OLD.key]
    retired=deepcopy(base);retired.value=Decimal('520386000')
    retired.source.concept=retired.source.concept.replace('Assets','DeferredTaxAssetsCA')
    retired.source.original_label='繰延税金資産'
    originals[OLD_ID].rows['BS_A'].append(Row('retired-ca','繰延税金資産','BS_A',values={OLD.key:retired}))
    result=run(Options('6947',tmp_path/'results',cache_dir=tmp_path/'cache',years=2),log=lambda _:None)
    assert not any(row.label=='繰延税金資産' for row in result.dataset.rows['BS_A'])
    audit=json.loads(result.audit.read_text(encoding='utf-8'))
    assert audit['raw_dataset']['period_sources'][OLD.key]==NEW_ID
    assert not any(row['key']=='retired-ca' for row in audit['raw_dataset']['rows']['BS_A'])
    assert originals[OLD_ID].rows['BS_A'][-1].values[OLD.key].value==Decimal('520386000')


def test_post_export_formula_mismatch_stops_strict_output_but_preserves_audit(monkeypatch,tmp_path):
    _sources(monkeypatch)
    import zaimu10.excel as excel
    def disagree(dataset,path,unit):
        path.write_bytes(b'generated-output')
        dataset.checks.append({'check':'presentation_total','ok':False,'difference_jpy':'1000000'})
    monkeypatch.setattr(excel,'export_workbook',disagree)
    with pytest.raises(Exception,match='計算式の検証'):
        run(Options('6947',tmp_path/'results',cache_dir=tmp_path/'cache',years=2),log=lambda _:None)
    assert not list((tmp_path/'results').glob('*.xlsx'))
    [audit]=list((tmp_path/'results').glob('*.audit.json'))
    data=json.loads(audit.read_text(encoding='utf-8'))['dataset']
    assert data['warnings'] and any(c.get('ok') is False for c in data['checks'])
