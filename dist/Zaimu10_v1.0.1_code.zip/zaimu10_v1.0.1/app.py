"""Zaimu10 desktop entry point. Run with `python app.py`."""
from __future__ import annotations

import importlib
import json
from pathlib import Path
import sys
import traceback

BASE = Path(__file__).resolve().parent
RUNTIME_MODULES = ('tkinter', 'requests', 'lxml.html', 'bs4',
                   'cryptography.hazmat.primitives.ciphers', 'openpyxl')
APPLICATION_MODULES = ('zaimu10.gui', 'zaimu10.parser', 'zaimu10.excel',
                       'zaimu10.service', 'zaimu10.discovery', 'zaimu10.edinet',
                       'zaimu10.amendment', 'zaimu10.__main__')


def self_check():
    problems = []
    if sys.version_info < (3, 10):
        problems.append('Python 3.10以上が必要です。')
    for name in RUNTIME_MODULES:
        try:
            importlib.import_module(name)
        except Exception as exc:
            problems.append(f'{name}: {type(exc).__name__}: {exc}')
    if not problems:
        for name in APPLICATION_MODULES:
            try:
                importlib.import_module(name)
            except Exception as exc:
                problems.append(f'{name}: {type(exc).__name__}: {exc}')
    try:
        from zaimu10 import __version__
    except Exception:
        __version__ = '不明'
        if not problems:
            problems.append('zaimu10のバージョンを確認できません。ZIPをすべて展開してください。')
    return {'application': 'Zaimu10', 'version': __version__,
            'python': sys.version.split()[0], 'ready': not problems,
            'problems': problems}


def _error(message):
    print(message, file=sys.stderr)
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('Zaimu10を起動できませんでした', message, parent=root)
        root.destroy()
    except Exception:
        pass


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    # CLI remains available and never opens a GUI when used explicitly.
    if args and args != ['--self-check']:
        from zaimu10.__main__ import main as cli_main
        return cli_main(args)
    state = self_check()
    if args == ['--self-check']:
        print(json.dumps(state, ensure_ascii=False, indent=2))
        return 0 if state['ready'] else 1
    if not state['ready']:
        _error('起動の準備ができていません。setup_windows.bat を実行してください。\n'
               'macOS/Linuxでは python3 setup_app.py を実行します。\n\n' +
               '\n'.join(state['problems']))
        return 1
    try:
        from zaimu10.gui import launch
        launch()
        return 0
    except Exception as exc:
        try:
            log = BASE / 'logs' / 'startup_error.log'
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(traceback.format_exc(), encoding='utf-8')
            details = f'\n詳細：{log}'
        except OSError:
            details = ''
        _error(f'アプリ画面を開けませんでした。\n{exc}{details}\n'
               'python.orgの公式Python（Tcl/Tk付き）と、画面を表示できる環境をご確認ください。')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
