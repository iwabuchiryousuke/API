@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" || exit /b 1
where py >nul 2>&1
if errorlevel 1 goto python
py -3 setup_app.py
goto done
:python
python setup_app.py
:done
set "ZAIMU_SETUP_RESULT=%errorlevel%"
if not "%ZAIMU_SETUP_RESULT%"=="0" echo セットアップに失敗しました。Python 3.10以上とインターネット接続をご確認ください。
if /I not "%~1"=="--no-pause" pause
popd
exit /b %ZAIMU_SETUP_RESULT%
