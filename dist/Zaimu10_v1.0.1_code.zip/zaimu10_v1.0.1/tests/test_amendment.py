from pathlib import Path
from copy import deepcopy

import pytest
from bs4 import BeautifulSoup

from zaimu10.amendment import inspect_amendment

FIXTURES = Path(__file__).parent / 'fixtures' / 'amendments'


def pages(doc='S100EPJ6'):
    files = sorted((FIXTURES / doc).glob('*.html'))
    return [('0000000_header.htm' if i == 0 else '0101000_body.htm', f.read_text(encoding='utf-8'))
            for i, f in enumerate(files)]


def edited_financial(edit):
    original = pages()
    soup = BeautifulSoup(original[1][1], 'html.parser')
    edit(soup, soup.find_all('table')[0], soup.find_all('table')[1])
    return [original[0], (original[1][0], str(soup))]


def safe_status(result):
    return result['status'] in {'nonfinancial_only', 'unchanged_financial_values'}


@pytest.mark.parametrize('doc,status', [('S100EPJ6', 'unchanged_financial_values'),
                                       ('S100JNL0', 'nonfinancial_only'),
                                       ('S100C56P', 'nonfinancial_only')])
def test_verified_real_correction_scopes(doc, status):
    result = inspect_amendment(pages(doc))
    assert result['status'] == status
    assert result['declared_scope']
    assert result['actual_headings']
    assert all(len(item['sha256']) == 64 for item in result['evidence'])
    if status == 'unchanged_financial_values':
        assert result['invariant']['rows_per_table'] == [30]
        assert result['invariant']['presentation_order_changed'] is True


@pytest.mark.parametrize('old,new', [('114,084', '114,085'), ('△991', '991'),
                                    ('千円', '百万円'), ('平成30年５月31日', '平成30年５月30日')])
def test_value_sign_unit_date_changes_never_skipped(old, new):
    def edit(soup, before, after):
        found = after.find(string=lambda s: s is not None and old in s)
        assert found is not None, old
        found.replace_with(str(found).replace(old, new, 1))
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_extra_unpaired_table_never_skipped():
    def edit(soup, before, after):
        after.insert_after(deepcopy(after))
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_numeric_footnote_outside_tables_never_skipped():
    def edit(soup, before, after):
        note = soup.new_tag('p')
        note.string = '注記: 適用税率30%' 
        after.insert_after(note)
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_numeric_change_before_paired_range_never_skipped():
    def edit(soup, before, after):
        note = soup.new_tag('p')
        note.string = '訂正した売上高は100です。'
        marker = soup.find('p', string=lambda s: s is not None and '（訂正前）' in s)
        marker.insert_before(note)
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_column_span_change_never_skipped():
    def edit(soup, before, after):
        after.find('td')['colspan'] = '9'
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_unhandled_rowspan_never_skipped():
    def edit(soup, before, after):
        for table in [before, after]:
            table.find('td')['rowspan'] = '2'
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_duplicate_numeric_account_labels_never_skipped():
    def edit(soup, before, after):
        for table in [before, after]:
            row = next(r for r in table.find_all('tr') if '製品売上高' in r.get_text())
            row.insert_after(deepcopy(row))
    assert not safe_status(inspect_amendment(edited_financial(edit)))


def test_nonfinancial_declaration_with_actual_financial_heading_is_unknown():
    original = pages('S100JNL0')
    original[1] = (original[1][0], original[1][1].replace('【事業の状況】', '【経理の状況】', 1))
    assert not safe_status(inspect_amendment(original))


def test_missing_explicit_after_marker_is_unknown():
    original = pages('S100JNL0')
    original[1] = (original[1][0], original[1][1].replace('（訂正後）', '追加情報', 1))
    assert inspect_amendment(original)['status'] == 'unknown'


def test_extra_untagged_chapter_is_unknown():
    original = pages()
    original.append(('0102000_other.htm', '<html><body><p>修正値999</p></body></html>'))
    assert inspect_amendment(original)['status'] == 'unknown'


def test_tagged_main_statement_requests_normal_parser():
    original = pages()
    original[1] = (original[1][0], '<html><body><ix:nonNumeric name="jpcrp_cor:StatementOfIncomeTextBlock">本表</ix:nonNumeric></body></html>')
    assert inspect_amendment(original)['status'] == 'financial'


def test_nonfinancial_scope_with_numeric_xbrl_never_skipped():
    original = pages('S100JNL0')
    original[1] = (original[1][0], original[1][1].replace('</body>', '<ix:nonFraction name="jppfs_cor:Assets" contextRef="CurrentYearInstant">999</ix:nonFraction></body>'))
    assert not safe_status(inspect_amendment(original))


def test_no_correction_cover_is_unknown():
    assert inspect_amendment([('file.htm', '<p>通常の報告書</p>')])['status'] == 'unknown'


def test_verified_shareholders_notices_attachment_only():
    result = inspect_amendment(pages('S100COBD'))
    assert result['status'] == 'nonfinancial_only'
    assert result['attachment_only'] is True
    assert '未添付' in result['declared_scope'][0]
    assert result['actual_scope'][0].endswith('の添付')


@pytest.mark.parametrize('old,new', [('ご通知」の添付', 'ご通知」の差し替え'),
                                    ('第111期定時株主総会決議ご通知', '第112期定時株主総会決議ご通知')])
def test_attachment_only_rejects_scope_change(old, new):
    original = pages('S100COBD')
    assert old in original[1][1]
    original[1] = (original[1][0], original[1][1].replace(old, new))
    assert not safe_status(inspect_amendment(original))


def test_attachment_only_rejects_extra_financial_description():
    original = pages('S100COBD')
    original[1] = (original[1][0], original[1][1].replace('</body>', '<p>【損益計算書】売上高100に訂正</p></body>'))
    assert not safe_status(inspect_amendment(original))


def test_verified_nitori_equipment_narrative_correction():
    result = inspect_amendment(pages('S100D357'))
    assert result['status'] == 'nonfinancial_only'
    assert '第３ 設備の状況' in result['declared_scope']


def test_numeric_xbrl_attributes_never_ignored_by_visible_text_invariant():
    def edit(soup, before, after):
        for table, scale in [(before, '0'), (after, '3')]:
            text = table.find(string=lambda s: s is not None and '114,084' in s)
            fact = soup.new_tag('ix:nonFraction', attrs={'name': 'extension:Profit', 'scale': scale})
            fact.string = str(text)
            text.replace_with(fact)
    result = inspect_amendment(edited_financial(edit))
    assert result['status'] == 'financial'
    assert result['numeric_xbrl_fact_count'] == 2


@pytest.mark.parametrize('extra', [
    '<div>【経理の状況】売上高を100に訂正</div>',
    '<table><tr><td>【損益計算書】</td><td>売上高999</td></tr></table>',
    '<table><tr><td>売上高</td><td>999</td></tr></table>',
    '<div>未分類の追記999</div>',
    '<span>【損益計算書】売上高を100に訂正</span>',
])
def test_nonfinancial_scope_inspects_every_visible_tag_and_table(extra):
    original = pages('S100JNL0')
    original[1] = (original[1][0], original[1][1].replace('</body>', extra + '</body>'))
    assert not safe_status(inspect_amendment(original))


def test_nonfinancial_equipment_narrative_rejects_new_financial_table():
    original = pages('S100D357')
    original[1] = (original[1][0], original[1][1].replace('</body>', '<table><tr><td>売上高</td><td>999</td></tr></table></body>'))
    assert not safe_status(inspect_amendment(original))


def test_same_row_values_moving_to_different_financial_section_never_skipped():
    def edit(soup, before, after):
        rows = after.find_all('tr')
        interest = next(r for r in rows if r.get_text(' ', strip=True).startswith('受取利息'))
        loss_heading = next(r for r in rows if r.get_text(' ', strip=True) == '特別損失')
        loss_heading.insert_after(interest.extract())
    result = inspect_amendment(edited_financial(edit))
    assert not safe_status(result)
    assert '節' in result['reason']


def test_equal_indent_numeric_rows_keep_preceding_explicit_section_boundary():
    def edit(soup, before, after):
        for table in [before, after]:
            for row in table.find_all('tr'):
                cells = row.find_all(['td', 'th'], recursive=False)
                while cells and not cells[0].get_text(' ', strip=True):
                    cells.pop(0).decompose()
        rows = after.find_all('tr')
        interest = next(r for r in rows if r.get_text(' ', strip=True).startswith('受取利息'))
        loss_heading = next(r for r in rows if r.get_text(' ', strip=True) == '特別損失')
        loss_heading.insert_after(interest.extract())
    assert not safe_status(inspect_amendment(edited_financial(edit)))
