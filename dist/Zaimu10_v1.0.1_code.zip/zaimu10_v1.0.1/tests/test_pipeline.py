"""Pipeline failure and selection tests, using deterministic disclosure sources.

Network discovery, retrieval and parsing are substituted, while the real merge,
validation, audit writer and Excel writer are exercised together.
"""
from copy import deepcopy
from datetime import date
from decimal import Decimal
import json
import threading

from openpyxl import load_workbook
import pytest

from zaimu10.models import Cell, Dataset, Filing, Period, Row, SHEETS, Source
from zaimu10.service import AcquisitionError, Options, run

OLD = Period(date(2023, 4, 1), date(2024, 3, 31))
NEW = Period(date(2024, 4, 1), date(2025, 3, 31))
OLD_ID, NEW_ID, AMEND_ID = 'S100AAAA', 'S100BBBB', 'S100CCCC'


def filing(doc_id, period, *, submitted=None, amended=False):
    return Filing(doc_id, company='検証会社', code='6947', edinet_code='E01966',
                  start=period.start, end=period.end,
                  submitted=submitted or f'{period.end.year}-06-20 14:00',
                  description='訂正有価証券報告書' if amended else '有価証券報告書',
                  amended=amended)


def complete(doc_id, periods, *, basis='consolidated', standard='J-GAAP', amount=1000000000):
    ds = Dataset('6947', '検証会社', basis, list(periods), accounting_standard=standard)
    ds.period_bases = {p.key: basis for p in periods}
    ds.period_standards = {p.key: standard for p in periods}
    family = 'jpigp' if standard == 'IFRS' else 'jppfs'
    namespace = f'http://disclosure.edinet-fsa.go.jp/taxonomy/{family}/2024-11-01/{family}_cor'
    concepts = ({'PL':'RevenueIFRS','BS_A':'AssetsIFRS',
                 'BS_LE':'LiabilitiesAndEquityIFRS',
                 'CF':'NetCashProvidedByUsedInOperatingActivitiesIFRS'} if standard == 'IFRS'
                else {'PL':'NetSales','BS_A':'Assets','BS_LE':'LiabilitiesAndNetAssets',
                      'CF':'NetCashProvidedByUsedInOperatingActivities'})
    for statement in SHEETS:
        local = concepts[statement]
        row = Row(f'{statement}:{standard}:{basis}', local, statement)
        for period in periods:
            source = Source(doc_id, 'statements.xhtml',
                            f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{doc_id}',
                            concept=f'{{{namespace}}}{local}', unit='JPY',
                            decimals='-3', basis=basis, original_label=local)
            row.values[period.key] = Cell(Decimal(amount), source)
        ds.rows[statement] = [row]
    return ds


def sources(monkeypatch, filings, datasets, *, fetch_hook=None, decisions=None):
    import zaimu10.discovery as discovery
    import zaimu10.edinet as edinet
    import zaimu10.parser as parser
    import zaimu10.amendment as amendment
    calls = {'fetch': [], 'parse': [], 'inspect': []}
    monkeypatch.setattr(discovery, 'discover_filings', lambda *args, **kwargs: deepcopy(filings))
    def fetch(doc_id, **kwargs):
        calls['fetch'].append(doc_id)
        if fetch_hook:
            fetch_hook(doc_id, kwargs)
        return [('original.xhtml', doc_id)]
    def parse(f, pages, basis='auto'):
        calls['parse'].append((f.doc_id, basis))
        ds = datasets[f.doc_id]
        if isinstance(ds, Exception):
            raise ds
        return deepcopy(ds)
    def inspect(pages):
        doc_id = pages[0][1]
        calls['inspect'].append(doc_id)
        return deepcopy((decisions or {})[doc_id])
    monkeypatch.setattr(edinet, 'fetch_filing', fetch)
    monkeypatch.setattr(parser, 'parse_filing', parse)
    monkeypatch.setattr(amendment, 'inspect_amendment', inspect)
    return calls


def options(tmp_path, **kwargs):
    return Options('6947', tmp_path/'results', cache_dir=tmp_path/'cache', years=2, **kwargs)


def test_success_writes_four_sheets_matching_audit_and_all_period_checks(monkeypatch, tmp_path):
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD])})
    result = run(options(tmp_path), log=lambda _: None)
    assert not result.dataset.warnings
    audit = json.loads(result.audit.read_text(encoding='utf-8'))
    assert len(audit['dataset']['periods']) == 2
    coverage = [c for c in audit['dataset']['checks'] if c['check']=='statement_coverage']
    assert len(coverage) == 8 and all(c['ok'] for c in coverage)
    assert all(c['ok'] is True for c in audit['dataset']['checks']
               if c['check'] not in {'cash_flow_components', 'cash_balance_rollforward'})
    cf_checks = [c for c in audit['dataset']['checks']
                 if c['check'] in {'cash_flow_components', 'cash_balance_rollforward'}]
    assert len(cf_checks)==4 and all(c['ok'] is None and c['reason'] for c in cf_checks)
    assert result.workbook.stem == result.audit.name.removesuffix('.audit.json')
    wb = load_workbook(result.workbook)
    assert wb.sheetnames == list(SHEETS.values())
    assert all(sheet['B7'].value == 1000000 for sheet in wb)
    wb.close()


def test_strict_missing_statement_stops_excel_and_keeps_honest_audit(monkeypatch, tmp_path):
    older = complete(OLD_ID, [OLD])
    older.rows['CF'] = []
    newer = complete(NEW_ID, [NEW])
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newer, OLD_ID: older})
    opts = options(tmp_path)
    with pytest.raises(AcquisitionError, match='完全な結果として出力できない'):
        run(opts, log=lambda _: None)
    assert not list(opts.output_dir.glob('*.xlsx'))
    [audit_path] = opts.output_dir.glob('*.audit.json')
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    failed = [c for c in audit['dataset']['checks'] if c['ok'] is False]
    assert any(c['statement']=='CF' and c['period']==OLD.key for c in failed)
    assert any('キャッシュフロー' in warning for warning in audit['dataset']['warnings'])


def test_verification_only_partial_failure_is_visible_in_ui_data_and_workbook(monkeypatch, tmp_path):
    ds = complete(NEW_ID, [OLD, NEW])
    ds.rows['BS_LE'][0].values[OLD.key].value += Decimal('1000000')
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: ds, OLD_ID: complete(OLD_ID, [OLD])})
    result = run(options(tmp_path, allow_partial=True), log=lambda _: None)
    assert '_要確認' in result.workbook.name
    assert any('BS左右合計' in warning for warning in result.dataset.warnings)
    assert any(c['check']=='balance_sheet_equation' and c['ok'] is False
               for c in result.dataset.checks)
    wb = load_workbook(result.workbook)
    assert any('BS左右合計' in str(cell.value) for sheet in wb for row in sheet for cell in row)
    wb.close()


def test_auto_keeps_one_complete_basis_and_standard_per_year(monkeypatch, tmp_path):
    newest = complete(NEW_ID, [NEW], standard='IFRS')
    # Opening/comparative BS alone must not replace an earlier complete solo set.
    for statement in ['BS_A', 'BS_LE']:
        newest.rows[statement][0].values[OLD.key] = deepcopy(newest.rows[statement][0].values[NEW.key])
        newest.rows[statement][0].values[OLD.key].value = Decimal('999000000000')
    older = complete(OLD_ID, [OLD], basis='standalone', amount=2000000000)
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newest, OLD_ID: older})
    result = run(options(tmp_path), log=lambda _: None)
    assert result.dataset.basis == 'mixed'
    assert result.dataset.period_bases == {OLD.key:'standalone', NEW.key:'consolidated'}
    assert result.dataset.period_standards == {OLD.key:'J-GAAP', NEW.key:'IFRS'}
    for rows in result.dataset.rows.values():
        for row in rows:
            for period_key, cell in row.values.items():
                assert cell.source.basis == result.dataset.period_bases[period_key]
                assert cell.value != Decimal('999000000000')
    assert result.dataset.complete
    assert not result.dataset.warnings


def test_restated_ifrs_comparative_excludes_old_jgaap_same_year(monkeypatch, tmp_path):
    newer = complete(NEW_ID, [OLD, NEW], standard='IFRS', amount=3000000000)
    older = complete(OLD_ID, [OLD], amount=1000000000)
    sources(monkeypatch, [filing(NEW_ID, NEW), filing(OLD_ID, OLD)],
            {NEW_ID: newer, OLD_ID: older})
    result = run(options(tmp_path), log=lambda _: None)
    assert result.dataset.period_standards == {OLD.key:'IFRS', NEW.key:'IFRS'}
    assert result.dataset.accounting_standard == 'IFRS'
    assert all(cell.source.doc_id==NEW_ID for rows in result.dataset.rows.values()
               for row in rows for cell in row.values.values())
    assert all(cell.value==Decimal('3000000000') for rows in result.dataset.rows.values()
               for row in rows for cell in row.values.values())


@pytest.mark.parametrize('safe_status', ['nonfinancial_only', 'unchanged_financial_values'])
def test_proven_irrelevant_amendment_is_logged_and_not_used_as_financial_fact(monkeypatch, tmp_path, safe_status):
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD])},
                    decisions={AMEND_ID: {'status':safe_status,'reason':'原文照合済み','evidence':['exact original scope']}})
    result = run(options(tmp_path), log=lambda _: None)
    assert calls['inspect'] == [AMEND_ID]
    assert all(doc_id!=AMEND_ID for doc_id, _ in calls['parse'])
    assert any(AMEND_ID in note for note in result.dataset.source_notes)
    [review] = [c for c in result.dataset.checks if c['check']=='amendment_scope']
    assert review['ok'] is True and review['status']==safe_status
    assert not result.dataset.warnings


def test_unknown_unparseable_amendment_never_becomes_a_complete_result(monkeypatch, tmp_path):
    from zaimu10.parser import ParseError
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [OLD, NEW]), OLD_ID: complete(OLD_ID, [OLD]),
                     AMEND_ID: ParseError('訂正前後の数値を確定できません。')},
                    decisions={AMEND_ID: {'status':'unknown','reason':'scope ambiguous','evidence':[]}})
    with pytest.raises(AcquisitionError, match='完全な結果として出力できない'):
        run(options(tmp_path), log=lambda _: None)
    assert AMEND_ID in calls['inspect']
    assert (AMEND_ID, 'auto') in calls['parse']
    assert not list((tmp_path/'results').glob('*.xlsx'))
    [audit_path] = (tmp_path/'results').glob('*.audit.json')
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    assert any(AMEND_ID in warning for warning in audit['dataset']['warnings'])


def test_tagged_financial_amendment_replaces_original_with_new_provenance(monkeypatch, tmp_path):
    amended = filing(AMEND_ID, OLD, submitted='2025-07-01 09:00', amended=True)
    calls = sources(monkeypatch, [filing(NEW_ID, NEW), amended, filing(OLD_ID, OLD)],
                    {NEW_ID: complete(NEW_ID, [NEW]), OLD_ID: complete(OLD_ID, [OLD]),
                     AMEND_ID: complete(AMEND_ID, [OLD], amount=4000000000)},
                    decisions={AMEND_ID: {'status':'financial','reason':'full tagged corrected statements','evidence':[]}})
    result = run(options(tmp_path), log=lambda _: None)
    assert (AMEND_ID,'auto') in calls['parse']
    assert all(row.values[OLD.key].source.doc_id==AMEND_ID for rows in result.dataset.rows.values() for row in rows)
    assert all(row.values[OLD.key].value==Decimal('4000000000') for rows in result.dataset.rows.values() for row in rows)
    assert any(c['check']=='amendment_scope' and c['ok'] is True for c in result.dataset.checks)


def test_cancelled_before_start_never_calls_discovery_or_writes_output(monkeypatch, tmp_path):
    import zaimu10.discovery as discovery
    event=threading.Event();event.set()
    def unexpected(*args, **kwargs):raise AssertionError('discovery must not run after cancellation')
    monkeypatch.setattr(discovery,'discover_filings',unexpected)
    with pytest.raises(InterruptedError):run(options(tmp_path),log=lambda _:None,cancel=event)
    assert not (tmp_path/'results').exists()


def test_cancellation_during_fetch_propagates_without_partial_audit(monkeypatch, tmp_path):
    event=threading.Event()
    def interrupt(doc_id, kwargs):
        event.set()
        raise InterruptedError('user cancelled')
    calls=sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
                  {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])},fetch_hook=interrupt)
    with pytest.raises(InterruptedError):run(options(tmp_path),log=lambda _:None,cancel=event)
    assert calls['parse']==[]
    assert not (tmp_path/'results').exists()


def test_repeated_run_preserves_edited_workbook_and_matching_original_audit(monkeypatch, tmp_path):
    sources(monkeypatch,[filing(NEW_ID,NEW),filing(OLD_ID,OLD)],
            {NEW_ID:complete(NEW_ID,[OLD,NEW]),OLD_ID:complete(OLD_ID,[OLD])})
    first=run(options(tmp_path),log=lambda _:None)
    edited=first.workbook.read_bytes()+b'\nuser edits must remain\n'
    first.workbook.write_bytes(edited)
    original_audit=first.audit.read_bytes()
    second=run(options(tmp_path),log=lambda _:None)
    assert first.workbook.read_bytes()==edited
    assert first.audit.read_bytes()==original_audit
    assert second.workbook.stem==first.workbook.stem+'_2'
    assert second.audit.stem==first.workbook.stem+'_2.audit'
    assert second.workbook.is_file() and second.audit.is_file()
