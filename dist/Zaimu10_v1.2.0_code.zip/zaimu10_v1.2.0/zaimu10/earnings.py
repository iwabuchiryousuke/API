"""Free, source-backed full-year earnings announcement calendars.

Actual dates come from JPX's public TDnet disclosure rows, not EDINET annual
report submission dates. Future dates remain schedules until an original
full-year results disclosure confirms them. Cached schedules never become
actual merely because their date has passed.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import tempfile
import time
import unicodedata
from zipfile import BadZipFile
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook

from . import edinet
from .discovery import normalize_code, display_company_name

JPX_SEARCH = 'https://www2.jpx.co.jp/tseHpFront/StockSearch.do'
JPX_SCHEDULE = 'https://www.jpx.co.jp/listing/event-schedules/financial-announcement/'
JPX_SCHEDULE_RULES = 'https://www.jpx.co.jp/listing/co-search/01.html'
SCHEMA = 1
_ALLOWED_HOSTS = {'www2.jpx.co.jp', 'www.jpx.co.jp', 'jpx.co.jp',
                  'www.dawn-corp.co.jp', 'www.xj-storage.jp'}
_MAX_BYTES = 12 * 1024 * 1024
_QUARTER = re.compile(r'四半期|半期|中間|quarter|\b[1-4]Q\b|\bQ[1-4]\b', re.I)
_NON_ORIGINAL = re.compile(r'訂正|修正|補足|補充|説明|配当|予想|お知らせ|追加|ダイジェスト')
_DATE = re.compile(r'(?<!\d)(20\d{2}|19\d{2})\s*[年/.-]\s*(\d{1,2})\s*[月/.-]\s*(\d{1,2})\s*日?')
_PERIOD = re.compile(r'(?:(20\d{2}|19\d{2})|平成(元|\d{1,2})|令和(元|\d{1,2}))年\s*(\d{1,2})月期')


class EarningsError(RuntimeError):
    pass


def _now() -> str:
    return datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds')


def _today() -> date:
    return datetime.now(timezone(timedelta(hours=9))).date()


def _compact(text) -> str:
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(text or ''))).strip()


def _plain(node) -> str:
    return _compact(node.get_text(' ', strip=True)) if node is not None else ''


def _dates(text: str) -> list[str]:
    result = []
    for parts in _DATE.findall(unicodedata.normalize('NFKC', text)):
        try:
            result.append(date(*(int(part) for part in parts)).isoformat())
        except ValueError:
            continue
    return list(dict.fromkeys(result))


def _period(title: str) -> tuple[str, str | None]:
    match = _PERIOD.search(unicodedata.normalize('NFKC', title))
    if not match:
        return '通期本決算（対象期の詳細は出典を参照）', None
    year, heisei, reiwa, month = match.groups()
    if year:
        year = int(year)
    else:
        era_year = heisei or reiwa
        year = (1988 if heisei else 2018) + (1 if era_year == '元' else int(era_year))
    month = int(month)
    if not 1 <= month <= 12:
        raise EarningsError('決算短信の対象月を確認できません。')
    return f'{year}年{month}月期', f'{year:04}-{month:02}'


def _annual_title(title: str) -> bool:
    value = _compact(title)
    return bool('決算短信' in value and not _QUARTER.search(value)
                and not _NON_ORIGINAL.search(value) and _PERIOD.search(value))


def _url_allowed(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == 'https' and parsed.hostname in _ALLOWED_HOSTS


def _request(session, method: str, url: str, *, cancel=None, **kwargs):
    if not _url_allowed(url):
        raise EarningsError('決算発表日の取得先が確認済みの公開ソースではありません。')
    for attempt in range(2):
        edinet._check_cancel(cancel)
        remaining=getattr(session,'_zaimu_earnings_deadline',time.monotonic()+45)-time.monotonic()
        if remaining<=0:
            raise EarningsError('決算発表日の更新時間が上限に達しました。保存済みデータを確認してください。')
        with edinet._request_lock:
            edinet._pause(max(0, edinet._MIN_INTERVAL -
                              (time.monotonic() - edinet._last_request)), cancel)
            edinet._last_request = time.monotonic()
        try:
            response = session.request(method, url, timeout=(min(5,max(.5,remaining)),min(18,max(.5,remaining))),
                                       allow_redirects=False, **kwargs)
        except requests.RequestException:
            if attempt == 1:
                raise EarningsError('決算発表日の公式ソースへ接続できません。') from None
            edinet._pause(2 ** (attempt+1), cancel)
            continue
        if response.status_code in edinet._RETRY_STATUSES:
            delay = edinet._retry_after(response.headers.get('Retry-After'))
            if delay is not None and delay > 30:
                raise EarningsError(f'公式ソースから{delay:.0f}秒の待機指定があります。時間を置いて更新してください。')
            if attempt < 1:
                if max(delay or 0,2 ** (attempt+1))>=remaining:
                    raise EarningsError('公式ソースの待機指定が更新時間の上限を超えました。時間を置いて更新してください。')
                edinet._pause(max(delay or 0, 2 ** (attempt+1)), cancel)
                continue
        if response.status_code != 200:
            raise EarningsError(f'決算発表日の公式ソースが利用できません（HTTP {response.status_code}）。')
        if len(response.content) > _MAX_BYTES:
            raise EarningsError('公式カレンダーの応答が想定サイズを超えたため停止しました。')
        edinet._check_cancel(cancel)
        return response
    raise EarningsError('決算発表日を取得できませんでした。')


def _digest(payload) -> str:
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = deepcopy(payload)
    body.pop('payload_sha256', None)
    body['payload_sha256'] = _digest(body)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent,
                                         suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(body, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _atomic_bytes(path: Path, content: bytes) -> None:
    temporary=None
    try:
        with tempfile.NamedTemporaryFile('wb',dir=path.parent,suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name);stream.write(content)
        temporary.replace(path)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def _validate_event(event: dict, code: str | None = None) -> dict:
    if not isinstance(event, dict):
        raise EarningsError('保存済み決算発表日の形式が不正です。')
    try:
        result = deepcopy(event)
        result['code'] = normalize_code(event['code'])
        date.fromisoformat(event['date'])
        if code is not None and result['code'] != code:
            raise ValueError
        if event['kind'] not in {'actual', 'scheduled'} or event.get('period_type') != 'annual':
            raise ValueError
        if event.get('is_annual') is not True:
            raise ValueError
        url = urlparse(event['source_url'])
        if not _url_allowed(event['source_url']) or not event.get('title') or not event.get('fiscal_period'):
            raise ValueError
        if not result.get('fiscal_month'):
            _,month=_period(event['fiscal_period'])
            if month:result['fiscal_month']=month
        if event.get('fiscal_end'):
            date.fromisoformat(event['fiscal_end'])
            if result.get('fiscal_month') and result['fiscal_month']!=event['fiscal_end'][:7]:
                raise ValueError
            if event['date']<event['fiscal_end']:
                raise ValueError
        if not event.get('publisher') or not event.get('source_title'):
            raise ValueError
        datetime.fromisoformat(event['verified_at'])
        if event['kind'] == 'actual' and date.fromisoformat(event['date']) > _today():
            raise ValueError
        return result
    except (KeyError, TypeError, ValueError):
        raise EarningsError('保存済み決算発表日の識別子・日付・出典を確認できません。') from None


def _read_cache(path: Path, code: str | None) -> dict | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
        checksum = payload.pop('payload_sha256')
        if payload.get('schema') != SCHEMA or payload.get('code') != code or checksum != _digest(payload):
            raise ValueError
        if not isinstance(payload.get('events'), list) or not isinstance(payload.get('history'), list):
            raise ValueError
        for event in payload['events'] + payload['history']:
            _validate_event(event, code)
        for item in payload.get('evidence', []):
            relative = item['path']
            if not re.fullmatch(r'evidence/[A-Za-z0-9_-]+-[a-f0-9]{64}\.(?:html|xlsx)', relative):
                raise ValueError
            content = (path.parent/relative).read_bytes()
            if hashlib.sha256(content).hexdigest() != item['sha256']:
                raise ValueError
        return payload
    except (OSError, ValueError, TypeError, KeyError):
        raise EarningsError(f'決算発表日の保存データが壊れているか別の対象です。元ファイルは保持しています：{path.name}') from None


def _event(code: str, company: str, when: str, title: str, source_url: str, *,
           kind='actual', publisher='日本取引所グループ（TDnet）',
           source_title='東証上場会社情報サービス・適時開示情報',
           evidence_url='', evidence_text='', fiscal_end=None, fiscal_period=None,
           observed_at=None, **extra) -> dict:
    label, month = _period(title)
    result = dict(code=code, company=display_company_name(company), date=when,
                  kind=kind, period_type='annual', is_annual=True,
                  fiscal_period=fiscal_period or label, fiscal_month=month,
                  fiscal_end=fiscal_end, title=_compact(title), source_url=source_url,
                  source_title=source_title, publisher=publisher,
                  evidence_url=evidence_url or source_url,
                  evidence_text=_compact(evidence_text or title),
                  verified_at=observed_at or _now(), **extra)
    return _validate_event(result, code)


def _jpx_detail(session, code: str, *, cancel=None) -> tuple[BeautifulSoup, str]:
    url = f'{JPX_SEARCH}?method=topsearch&topSearchStr={code}'
    result = _request(session, 'GET', url, cancel=cancel)
    soup = BeautifulSoup(result.content, 'html.parser')
    form = soup.find('form', attrs={'name': 'JJK010030Form'})
    if form is None:
        raise EarningsError('JPXの会社検索画面を確認できません。')
    # Disabled dispatch flags must not be submitted: the public browser enables
    # only BaseJh when the user clicks the selected company's basic information.
    fields = {node['name']: node.get('value', '') for node in form.select('input[name]')
              if not node.has_attr('disabled') and node.get('type') not in {'button', 'submit'}}
    candidates = [node for node in form.select('input[name]')
                  if node.get('name', '').endswith('.eqMgrCd') and node.get('value') == code+'0']
    if len(candidates) != 1:
        raise EarningsError(f'JPXで銘柄コード{code}の対象会社を一意に確認できません。')
    fields.update(mgrCd=code+'0', jjHisiFlg='1', BaseJh='BaseJh')
    action = urljoin(url, form.get('action', ''))
    result = _request(session, 'POST', action, data=fields, cancel=cancel)
    soup = BeautifulSoup(result.content, 'html.parser')
    if (not soup.find('h3') or not any(_plain(td) == code+'0' for td in soup.select('td'))
            or '上場会社詳細' not in (soup.title.get_text() if soup.title else '')):
        raise EarningsError('JPXの会社詳細が対象銘柄と一致しません。')
    return soup, url


def parse_jpx_detail(html, code: str, *, source_url: str | None = None,
                     observed_at: str | None = None) -> list[dict]:
    """Parse exact dated original annual-result rows; exclude amendments/Qs."""
    code = normalize_code(code)
    soup = html if isinstance(html, BeautifulSoup) else BeautifulSoup(html, 'html.parser')
    company = _plain(soup.find('h3')) if soup.find('h3') else code
    source_url = source_url or f'{JPX_SEARCH}?method=topsearch&topSearchStr={code}'
    result = []
    for anchor in soup.select('a[href]'):
        title = _plain(anchor)
        if not _annual_title(title):
            continue
        document_url = urljoin('https://www2.jpx.co.jp', anchor['href'])
        if not re.fullmatch(r'/disc/'+re.escape(code+'0')+r'/[^/?]+\.pdf', urlparse(document_url).path):
            continue
        row = anchor.find_parent('tr')
        cells = row.find_all('td', recursive=False) if row else []
        dates = _dates(_plain(cells[0])) if cells else []
        if len(dates) != 1:
            continue
        when = dates[0]
        if date.fromisoformat(when) > _today():
            # Future entries in a disclosure list are not actual announcements.
            continue
        result.append(_event(code, company, when, title, document_url,
                             evidence_url=source_url, evidence_text=_plain(row),
                             observed_at=observed_at))
        ixbrl = next((urljoin('https://www2.jpx.co.jp',a['href'])
                      for a in row.select('a[href]') if a['href'].endswith('ixbrl.htm')),None)
        if ixbrl:
            result[-1]['financial_html_url'] = ixbrl
    # The first schedule column is explicitly full-year; its date remains a
    # schedule. JPX deliberately withholds some future dates until 20 business
    # days before fiscal close; an empty cell is not an extraction failure.
    for header in soup.select('th'):
        if _plain(header) != '決算発表(予定)':
            continue
        data_row = header.find_parent('tr').find_next_sibling('tr')
        cells = data_row.find_all('td', recursive=False) if data_row else []
        dates = _dates(_plain(cells[0])) if cells else []
        if len(dates) == 1 and date.fromisoformat(dates[0]) >= _today():
            result.append(_event(code, company, dates[0], '通期本決算発表予定（JPX会社登録）',
                                 source_url, kind='scheduled', publisher='日本取引所グループ',
                                 source_title='東証上場会社情報サービス・決算発表予定',
                                 evidence_text=_plain(data_row), observed_at=observed_at))
    return result


def _sanitize_html(soup: BeautifulSoup) -> str:
    clean = BeautifulSoup(str(soup), 'html.parser')
    for node in clean.select('script,input,textarea'):
        node.decompose()
    for form in clean.select('form'):
        form.unwrap()
    for node in clean.find_all(True):
        for key in list(node.attrs):
            if key.lower().startswith('on'):
                del node.attrs[key]
            elif key in {'href', 'src', 'action'} and isinstance(node.attrs[key], str):
                node.attrs[key] = re.sub(r';jsessionid=[^?&#/]+', '', node.attrs[key], flags=re.I)
    return str(clean)


def _save_evidence(cache_dir: Path, code: str, soup: BeautifulSoup) -> dict:
    content = _sanitize_html(soup).encode('utf-8')
    digest = hashlib.sha256(content).hexdigest()
    directory = Path(cache_dir)/'earnings'/'evidence'
    directory.mkdir(parents=True, exist_ok=True)
    path = directory/f'{code}-{digest}.html'
    if not path.exists():
        _atomic_bytes(path,content)
    return {'path': f'evidence/{path.name}', 'sha256': digest,
            'note': '公開HTMLからセッション値・スクリプト・入力欄を除いて保存。'}


def parse_company_schedule(html, code: str, *, source_url: str, company: str,
                           observed_at: str | None = None) -> list[dict]:
    """Explicit dated full-year company calendar rows, including XJ text HTML."""
    soup = BeautifulSoup(html, 'html.parser')
    result = []
    for row in soup.select('tr'):
        cells = row.find_all(['th', 'td'], recursive=False)
        if len(cells) < 2:
            continue
        title = _plain(cells[-1])
        if (_QUARTER.search(title) or not _PERIOD.search(title)
                or not re.search(r'決算発表|本決算', title) or _NON_ORIGINAL.search(title.replace('予定',''))):
            continue
        dates = _dates(_plain(cells[0]))
        if len(dates) != 1 or date.fromisoformat(dates[0]) < _today():
            continue
        # A company calendar alone is a schedule even when its original text
        # omits 予定. Only a TDnet results disclosure can prove actual release.
        result.append(_event(code, company, dates[0], title, source_url,
                             kind='scheduled', publisher='発行会社公式IR',
                             source_title='発行会社公式IRカレンダー',
                             evidence_text=_plain(row), observed_at=observed_at))
    return result


def _company_schedules(session, code, company, *, cache_dir: Path, cancel=None) -> tuple[list[dict], list[dict]]:
    # Additional public company sources enrich the generic JPX service. No
    # dates are hard-coded; the official page must link the provider script.
    if code != '2303':
        return [], []
    url = 'https://www.dawn-corp.co.jp/ir/'
    response = _request(session, 'GET', url, cancel=cancel)
    soup = BeautifulSoup(response.content, 'html.parser')
    scope = soup.select_one('.ir-calendar')
    if scope is None:
        raise EarningsError('ドーン公式IRカレンダーの形式を確認できません。')
    events = parse_company_schedule(str(scope), code, source_url=url, company=company)
    evidence = []
    for script in scope.select('script[src]'):
        source = urljoin(url, script['src'])
        parsed = urlparse(source)
        if parsed.hostname != 'www.xj-storage.jp' or not parsed.path.startswith('/public-text/text/23030/'):
            continue
        response = _request(session, 'GET', source, cancel=cancel)
        # No JavaScript evaluation: the referenced public text file embeds a
        # literal HTML table; BeautifulSoup reads only those table elements.
        parsed_events = parse_company_schedule(response.content, code, source_url=url, company=company)
        proof = _save_evidence(cache_dir,code+'-schedule',BeautifulSoup(response.content,'html.parser'))
        proof.update(source_url=source,source_title='ドーン公式IRが参照する公開カレンダー本文')
        evidence.append(proof)
        for event in parsed_events:
            event['provider_url'] = source
            event['evidence_path'] = proof['path']
            event['source_sha256'] = proof['sha256']
        events.extend(parsed_events)
    return events, evidence


def _fiscal_key(event: dict) -> tuple:
    if event.get('fiscal_month'):
        return event['code'], event['fiscal_month']
    if event.get('fiscal_end'):
        return event['code'], event['fiscal_end'][:7]
    return event['code'], event['fiscal_period']


def merge_events(previous: list[dict], fresh: list[dict], *, today: date | None = None) -> tuple[list[dict], list[dict]]:
    """Keep first actual releases; fresh schedules replace older schedules."""
    today = today or _today()
    history = {}
    for event in previous + fresh:
        event = _validate_event(event)
        identity = (event['code'], event['date'], event['kind'], event['fiscal_period'],
                    event['source_url'], event['title'])
        if identity in history:
            # JPX repeats a PDF in multiple sections; a secondary rendering can
            # omit the iXBRL link. Retain the richer evidence for the SAME event.
            history[identity].update({k:v for k,v in event.items() if v is not None})
        else:
            history[identity] = event
    actuals = {}
    for event in history.values():
        if event['kind'] == 'actual':
            actuals.setdefault(_fiscal_key(event), []).append(event)
    active = []
    for group in actuals.values():
        chosen = deepcopy(min(group, key=lambda e: (e['date'], e['source_url'])))
        chosen['sources'] = [dict(date=e['date'], title=e['title'], source_url=e['source_url'],
                                  publisher=e['publisher']) for e in sorted(group,key=lambda e:e['date'])]
        active.append(chosen)
    schedules = {}
    actual_days={(event['code'],event['date']) for group in actuals.values() for event in group}
    for event in fresh:
        if (event['kind'] == 'scheduled' and date.fromisoformat(event['date']) >= today
                and _fiscal_key(event) not in actuals and (event['code'],event['date']) not in actual_days):
            schedules.setdefault(_fiscal_key(event), []).append(event)
    for group in schedules.values():
        # Workbook links can overlap. Download order is not publication order:
        # prefer the explicitly dated official snapshot before fetch time.
        chosen = deepcopy(max(group, key=lambda e: (
            e.get('source_as_of') or e.get('verified_at','')[:10],
            e.get('verified_at',''), e['source_url'])))
        chosen['sources'] = [dict(date=e['date'], title=e['title'], source_url=e['source_url'],
                                  publisher=e['publisher']) for e in group]
        active.append(chosen)
    active.sort(key=lambda e: (e['date'], e['code'], e['kind']), reverse=True)
    return active, sorted(history.values(),key=lambda e:(e['date'],e['code'],e['kind']),reverse=True)


def _cached_periods(events: list[dict], code: str, cache_dir: Path) -> None:
    """Optional exact fiscal ends from cached official reports, never dates of release."""
    try:
        from .discovery import discover_filings
        filings = discover_filings(code,cache_dir=cache_dir,offline=True,log=lambda _:None)
    except Exception:
        return
    for event in events:
        if event.get('fiscal_end') or not event.get('fiscal_month'):
            continue
        matches = [f for f in filings if f.end and f.end.strftime('%Y-%m') == event['fiscal_month']]
        ends = {f.end for f in matches}
        if len(ends) == 1:
            event['fiscal_end'] = next(iter(ends)).isoformat()
            event['fiscal_end_source'] = f'https://disclosure2.edinet-fsa.go.jp/WZEK0040.aspx?{matches[0].doc_id}'


def parse_disclosure_fiscal_end(html, code: str, *, fiscal_month: str) -> str | None:
    """Exact TSE disclosure metadata; never assume an end-of-month day."""
    soup = BeautifulSoup(html,'html.parser')
    codes = []
    ends = []
    for node in soup.find_all(attrs={'name':True}):
        local = node['name'].rsplit(':',1)[-1]
        if local in {'SecuritiesCode','SecurityCodeDEI'}:
            try:codes.append(normalize_code(re.sub(r'\s+','',node.get_text('',strip=True))))
            except ValueError:raise EarningsError('決算短信の企業コードを確認できません。') from None
        elif local in {'FiscalYearEnd','CurrentFiscalYearEndDateDEI'}:
            try:ends.append(date.fromisoformat(_plain(node)).isoformat())
            except ValueError:continue
    if not codes or set(codes)!={normalize_code(code)}:
        raise EarningsError('決算短信の企業コードが対象と一致しません。')
    ends = {end for end in ends if end[:7]==fiscal_month}
    return next(iter(ends)) if len(ends)==1 else None


def _latest_exact_period(events: list[dict], session, code: str, *, cache_dir: Path,
                         cancel=None) -> list[dict]:
    candidates = [e for e in events if e['kind']=='actual' and e.get('fiscal_month')]
    if not candidates:return []
    month = max(e['fiscal_month'] for e in candidates)
    # An IFRS republication later in the same year is not the initial annual
    # announcement; read the metadata paired with the first original release.
    latest = min((e for e in candidates if e['fiscal_month']==month),key=lambda e:e['date'])
    if latest.get('fiscal_end') or not latest.get('financial_html_url'):
        return []
    url = latest['financial_html_url']
    if not re.fullmatch(r'/disc/'+re.escape(code+'0')+r'/[^/?]+ixbrl\.htm',urlparse(url).path):
        raise EarningsError('決算短信の対象HTMLが対象銘柄と一致しません。')
    response = _request(session,'GET',url,cancel=cancel)
    exact = parse_disclosure_fiscal_end(response.content,code,fiscal_month=month)
    if not exact:return []
    latest['fiscal_end']=exact;latest['fiscal_end_source']=url
    evidence=_save_evidence(cache_dir,code+'-fiscal',BeautifulSoup(response.content,'html.parser'))
    evidence.update(source_url=url,source_title='通期決算短信の企業コード・正確な決算期末')
    return [evidence]


def load_calendar(code: str, *, cache_dir: Path, offline=False, refresh=False,
                  cancel=None, log=print) -> dict:
    """Return {code,events,history,checked_at,stale,warnings,evidence}.

    Events are annual only. ``date`` is the announcement date, never fiscal end
    or annual-report submission. Cached history is retained. Network failures
    return an explicitly stale previously verified result; a missing/corrupt
    cache cannot silently turn into an empty 'unpublished' calendar.
    """
    code = normalize_code(code)
    edinet._check_cancel(cancel)
    cache_dir = Path(cache_dir)
    path = cache_dir/'earnings'/f'{code}.json'
    saved = _read_cache(path, code)
    edinet._check_cancel(cancel)
    if offline:
        if saved is None:
            raise EarningsError(f'{code}: 決算発表日の保存データがありません。オンラインで「発表日を更新」してください。')
        saved['offline'] = True
        return saved
    if saved and not refresh:
        try:
            age = datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at'])
        except (ValueError, KeyError):
            age = timedelta(days=1)
        if age < timedelta(hours=6):
            return saved
    warnings = []
    try:
        with requests.Session() as session:
            session._zaimu_earnings_deadline=time.monotonic()+45
            session.headers.update({'User-Agent':'Zaimu10/1.2 (public earnings calendar)'})
            log(f'{code}: JPXの公式決算発表履歴を確認しています。')
            soup, source_url = _jpx_detail(session, code, cancel=cancel)
            events = parse_jpx_detail(soup, code, source_url=source_url)
            company = _plain(soup.find('h3'))
            evidence = list(saved.get('evidence',[])) if saved else []
            proof = _save_evidence(cache_dir, code, soup)
            proof.update(source_url=source_url,source_title='JPX公式会社詳細（公開部分）')
            evidence.append(proof)
            try:
                schedules, source_evidence = _company_schedules(session, code, company,
                                                               cache_dir=cache_dir,cancel=cancel)
                events.extend(schedules);evidence.extend(source_evidence)
            except InterruptedError:
                raise
            except EarningsError as exc:
                warnings.append(str(exc)+' 通期予定の確認が一部完了していません。')
            _cached_periods(events, code, cache_dir)
            try:
                evidence.extend(_latest_exact_period(events,session,code,cache_dir=cache_dir,cancel=cancel))
            except InterruptedError:
                raise
            except EarningsError as exc:
                warnings.append(str(exc)+' 発表日は確認済みですが、正確な決算期末日は未確認のままです。')
            active, history = merge_events(saved.get('history',[]) if saved else [], events)
        if not any(event['kind']=='actual' for event in events):
            warnings.append('JPX公開履歴から通期決算短信の発表実績を確認できませんでした。取得対象の範囲を出典で確認してください。')
        if not any(event['kind']=='scheduled' for event in active) and not any('通期予定の確認が一部' in warning for warning in warnings):
            warnings.append('確認した公式ソースに将来の通期決算発表予定はありません。JPXは期末20営業日前まで本決算予定を表示しない場合があります。')
        payload = dict(schema=SCHEMA, code=code, company=company, events=active,
                       history=history, checked_at=_now(), stale=False,
                       warnings=warnings, evidence=list({e['path']:e for e in evidence}.values()),
                       schedule_status='partial_fetch_failure' if any('通期予定の確認が一部' in w for w in warnings)
                           else 'verified_schedules' if any(e['kind']=='scheduled' for e in active) else 'not_in_checked_sources',
                       schedule_rules_url=JPX_SCHEDULE_RULES)
        _write_json(path, payload)
        return payload
    except InterruptedError:
        raise
    except (requests.RequestException, EarningsError, OSError, ValueError) as exc:
        if saved is None:
            raise EarningsError(f'{code}: 決算発表日の取得に失敗しました。{exc}') from None
        result = deepcopy(saved)
        result['stale'] = True
        result['warnings'] = list(result.get('warnings', [])) + [f'更新失敗。{saved.get("checked_at", "以前")}に確認した保存済み発表日を表示しています。{exc}']
        return result


def list_events(codes, *, cache_dir: Path, offline=False, refresh=False,
                cancel=None, log=print) -> list[dict]:
    events = []
    for code in dict.fromkeys(normalize_code(value) for value in codes):
        calendar = load_calendar(code,cache_dir=cache_dir,offline=offline,
                                 refresh=refresh,cancel=cancel,log=log)
        for event in calendar['events']:
            item = deepcopy(event)
            item['stale'] = bool(calendar.get('stale'))
            item['checked_at'] = calendar['checked_at']
            events.append(item)
    return sorted(events,key=lambda e:(e['date'],e['code']),reverse=True)


def parse_market_workbook(content: bytes, *, source_url: str,
                          observed_at: str | None = None) -> list[dict]:
    """JPX public XLSX: exact 本決算 classification, never Q4 as annual."""
    try:
        book = load_workbook(io.BytesIO(content),read_only=True,data_only=True)
    except (BadZipFile,OSError,ValueError,KeyError) as exc:
        raise EarningsError('JPX予定一覧のExcelファイルを読み取れません。') from None
    events = []
    recognized=0
    try:
        for sheet in book:
            rows = list(sheet.iter_rows(values_only=True))
            header_index = next((i for i,row in enumerate(rows[:25])
                                 if any(_compact(v).startswith('コード') for v in row)
                                 and any('決算' in _compact(v) for v in row)),None)
            if header_index is None:
                continue
            recognized+=1
            headings = [_compact(v) for v in rows[header_index]]
            def locate(*terms):
                return next((i for i,h in enumerate(headings) if h in terms),None)
            # Current bilingual workbook layout is identified by its headers,
            # not by fixed column positions alone.
            code_index = next((i for i,h in enumerate(headings) if h.startswith('コード')),None)
            date_index = next((i for i,h in enumerate(headings) if '発表予定' in h),None)
            company_index = locate('会社名','銘柄名')
            fiscal_index = next((i for i,h in enumerate(headings) if '決算期' in h),None)
            kind_index = locate('種別','決算種別')
            if any(i is None for i in (code_index,date_index,company_index,fiscal_index,kind_index)):
                raise EarningsError('JPX予定一覧の列見出しが既知の形式ではありません。')
            snapshots = [d for row in rows[:header_index] for cell in row
                         for d in _dates(_compact(cell))]
            snapshot = snapshots[0] if snapshots else None
            for row_number,row in enumerate(rows[header_index+1:],header_index+2):
                if len(row)<=max(code_index,date_index,company_index,fiscal_index,kind_index):
                    continue
                if _compact(row[kind_index])!='本決算':
                    continue
                raw_code = row[code_index]
                try:
                    code = normalize_code(str(int(raw_code)) if isinstance(raw_code,(int,float)) else str(raw_code))
                except (ValueError,TypeError,OverflowError):
                    continue
                when, end = row[date_index], row[fiscal_index]
                if isinstance(when,datetime):when=when.date()
                if isinstance(end,datetime):end=end.date()
                if not isinstance(when,date) or not isinstance(end,date):
                    continue  # 未定 is not a date and must not be guessed.
                events.append(_event(code,_compact(row[company_index]),when.isoformat(),
                                      f'{end.year}年{end.month}月期 本決算発表予定',source_url,
                                      kind='scheduled',publisher='日本取引所グループ',
                                      source_title='JPX 決算発表予定会社一覧',
                                      fiscal_end=end.isoformat(),observed_at=observed_at,
                                      evidence_text=' | '.join(_compact(v) for v in row),
                                      source_sheet=sheet.title,source_row=row_number,
                                      source_as_of=snapshot))
    finally:
        book.close()
    if not recognized:
        raise EarningsError('JPX予定一覧の表形式を確認できません。')
    return events


def load_market_schedule(*, cache_dir: Path, offline=False, refresh=False,
                          cancel=None, log=print) -> dict:
    """Public JPX scheduled full-year announcements across all listed codes."""
    cache_dir = Path(cache_dir)
    edinet._check_cancel(cancel)
    path = cache_dir/'earnings'/'market_schedule.json'
    saved = _read_cache(path, None)
    if offline:
        if saved is None:
            raise EarningsError('JPX公開予定の保存データがありません。オンラインで更新してください。')
        saved['offline'] = True
        return saved
    if saved and not refresh:
        try:
            if datetime.now(timezone.utc)-datetime.fromisoformat(saved['checked_at']) < timedelta(hours=6):
                return saved
        except (ValueError,KeyError):
            pass
    try:
        with requests.Session() as session:
            session._zaimu_earnings_deadline=time.monotonic()+45
            session.headers.update({'User-Agent':'Zaimu10/1.2 (public earnings calendar)'})
            response = _request(session,'GET',JPX_SCHEDULE,cancel=cancel)
            soup = BeautifulSoup(response.content,'html.parser')
            urls = list(dict.fromkeys(urljoin(JPX_SCHEDULE,a['href']) for a in soup.select('a[href]')
                                     if re.search(r'/kessan[^/?]*\.xlsx(?:\?.*)?$',a['href'],re.I)))
            if not urls:
                raise EarningsError('JPX公開予定一覧のExcelリンクを確認できません。')
            events = []; evidence = list(saved.get('evidence',[])) if saved else []
            for url in urls:
                log('JPX公開予定一覧を取得しています。')
                result = _request(session,'GET',url,cancel=cancel)
                events.extend(parse_market_workbook(result.content,source_url=url))
                digest = hashlib.sha256(result.content).hexdigest()
                directory=cache_dir/'earnings'/'evidence';directory.mkdir(parents=True,exist_ok=True)
                relative=f'evidence/market-{digest}.xlsx'
                evidence_path=cache_dir/'earnings'/relative
                if not evidence_path.exists():_atomic_bytes(evidence_path,result.content)
                evidence.append(dict(path=relative,sha256=digest,source_url=url,
                                     source_title='JPX公式決算発表予定会社一覧'))
        active, history = merge_events(saved.get('history',[]) if saved else [],events)
        payload = dict(schema=SCHEMA,code=None,events=active,history=history,
                       checked_at=_now(),stale=False,warnings=[],source_url=JPX_SCHEDULE,
                       evidence=list({e['path']:e for e in evidence}.values()))
        _write_json(path,payload)
        return payload
    except InterruptedError:
        raise
    except (requests.RequestException,EarningsError,OSError,ValueError) as exc:
        if saved is None:
            raise EarningsError(f'JPX公開予定の取得に失敗しました。{exc}') from None
        result = deepcopy(saved);result['stale']=True
        result['warnings']=list(saved.get('warnings',[]))+[f'更新失敗。{saved.get("checked_at","")}の保存済み公式予定を表示。{exc}']
        return result
