"""Japanese desktop app and command line entry point."""
from __future__ import annotations
import argparse
from datetime import date
from pathlib import Path
import sys

from . import __version__
from .service import Options, run


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description='EDINET原文から過去10期の詳細財務諸表を4シートのExcelへ出力します。')
    p.add_argument('code', nargs='?', help='銘柄コード（例：6947、285A）。省略するとアプリを開きます。')
    p.add_argument('--gui', action='store_true', help='デスクトップアプリを開く')
    p.add_argument('--years', type=int, default=10, help='取得期数（1～10、既定10）')
    p.add_argument('--basis', choices=['auto','consolidated','standalone'],default='auto',help='auto：連結優先、非連結企業は個別')
    p.add_argument('--unit',choices=['yen','thousand','million'],default='thousand',help='表示単位（既定：thousand＝千円）')
    p.add_argument('--output',type=Path,default=Path('results'),help='出力先フォルダー')
    p.add_argument('--cache',type=Path,default=Path('.cache/zaimu10'),help='取得原文のキャッシュ保存先')
    p.add_argument('--until',type=date.fromisoformat,help='この決算日以前の最新N期（YYYY-MM-DD）')
    p.add_argument('--offline',action='store_true',help='取得済みキャッシュのみを使う')
    p.add_argument('--refresh',action='store_true',help='原文キャッシュを更新する')
    p.add_argument('--allow-partial',action='store_true',help='不足・警告がある場合も「要確認」のExcelを明示的に出力')
    p.add_argument('--version',action='version',version=f'Zaimu10 {__version__}')
    p.add_argument('--debug',action='store_true',help='エラー時に詳細を表示')
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.gui or not args.code:
        try:
            from .gui import launch
            launch(initial_code=args.code or '6947')
            return 0
        except ImportError as exc:
            print('アプリ画面に必要なTkinterがありません。公式Python（Tcl/Tkを含む）をインストールするか、銘柄コードを指定してCLIをお使いください。',file=sys.stderr)
            if args.debug:
                raise
            return 2
    try:
        opts=Options(code=args.code,output_dir=args.output,cache_dir=args.cache,
                     years=args.years,basis=args.basis,unit=args.unit,until=args.until,
                     offline=args.offline,refresh=args.refresh,allow_partial=args.allow_partial)
        result=run(opts)
        print(f'Excel: {result.workbook}\n監査記録: {result.audit}')
        if result.dataset.warnings:
            print('要確認：監査記録とExcel内の注記を確認してください。')
        return 0
    except KeyboardInterrupt:
        print('\n中止しました。取得済み原文はキャッシュに残ります。',file=sys.stderr)
        return 130
    except Exception as exc:
        print(f'出力できませんでした。\n{exc}',file=sys.stderr)
        if args.debug:
            raise
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
