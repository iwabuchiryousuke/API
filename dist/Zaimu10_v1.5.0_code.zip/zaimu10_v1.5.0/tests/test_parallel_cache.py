"""Separate GUI jobs may update the shared public directory cache together."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from zaimu10.discovery import _write_json


def test_parallel_directory_cache_writes_are_complete_and_do_not_share_temporary_files(tmp_path):
    target=tmp_path/'directory.json'
    def write(index):
        data={'index':index,'values':[str(index)]*4000}
        _write_json(target,data)
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(write,range(40)))
    value=json.loads(target.read_text())
    assert value['values']==[str(value['index'])]*4000
    assert not list(tmp_path.glob('*.tmp'))
