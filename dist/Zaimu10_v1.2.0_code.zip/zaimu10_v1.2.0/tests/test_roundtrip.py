"""The same saved result drives Excel and the desktop charts."""
import gzip
import json
from copy import deepcopy
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook

from zaimu10.analysis import chart_data
from zaimu10.audit import load_result
from zaimu10.excel import export_workbook
from zaimu10.models import Filing
from zaimu10.parser import parse_filing
from zaimu10.presentation import annotate_filing, prepare_dataset
from zaimu10.service import Options, save_audit


def test_real_saved_result_reopens_with_the_same_final_excel_values(tmp_path):
    fixture = Path(__file__).parent/'fixtures'/'furuya_2026_ixbrl.json.gz'
    pages = json.load(gzip.open(fixture, 'rt', encoding='utf-8'))
    raw = annotate_filing(parse_filing(Filing('S100Z403', code='7826', company='フルヤ金属'), pages))
    ds = prepare_dataset(deepcopy(raw))
    workbook = tmp_path/'7826_フルヤ金属.xlsx'
    export_workbook(ds, workbook, 'million')
    audit = workbook.with_suffix('.audit.json')
    save_audit(ds, audit, Options('7826',tmp_path), raw)
    reopened = load_result(audit)
    model = chart_data(reopened.dataset, 'auto')
    book = load_workbook(workbook, data_only=True)
    for name,row in [('revenue',2),('gross_profit',5),('operating_profit',9),('net_profit',19)]:
        for column,value in enumerate(model['PL'][name]['values'],2):
            actual = book['PL'].cell(row,column).value
            assert value is None if actual is None else value == Decimal(str(actual))
    for name,concept,sheet in [('assets','Assets','BS-A'),('liabilities','Liabilities','BS-L,E'),
                               ('equity','NetAssets','BS-L,E')]:
        for index,period in enumerate(sorted(ds.periods)):
            row = next(r for r in reopened.dataset.rows['BS_A' if sheet=='BS-A' else 'BS_LE']
                       if period.key in r.values and r.values[period.key].source.concept.endswith('}'+concept))
            address = ds.export_metadata['source_addresses'][row.key][period.key]['address']
            assert model['BS'][name]['values'][index] == Decimal(str(book[sheet][address].value))
    roles = ds.export_metadata['layout']['CF']['roles']
    for name,slot in [('operating','40'),('investing','54'),('financing','64'),('cash','68')]:
        for column,value in enumerate(model['CF'][name]['values'],2):
            actual = book['CF'].cell(roles[slot],column).value
            assert value is None if actual is None else value == Decimal(str(actual))
    assert not reopened.dataset.warnings
    assert not any(c.get('ok') is False for c in reopened.dataset.checks)
