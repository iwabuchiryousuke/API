"""Chart the saved model values; never execute formula strings in an audit."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation

MODEL_VIEWS = {
    'ROIC': ('FR', (
        ('roic', 'ROIC', 'ratio'), ('wacc_c', 'WACC', 'ratio'),
        ('spread', 'Spread', 'ratio'), ('ebitda_margin', 'EBITDAマージン', 'ratio'))),
    'バリュードライバー': ('FR', (
        ('pretax_roic', '税引前ROIC', 'ratio'), ('operating_margin', '営業利益率', 'ratio'),
        ('invested_capital_turnover', '投下資本回転率', 'multiple'),
        ('sales_growth', '売上高成長率', 'ratio'), ('cost_ratio', '原価率', 'ratio'),
        ('sga_ratio', '販管費率', 'ratio'))),
    '安全指標': ('FR', (
        ('liquidity_months', '手元流動性', 'months'), ('current_ratio', '流動比率', 'ratio'),
        ('quick_ratio', '当座比率', 'ratio'))),
    '生産指標': ('FR', (
        ('ppe_turnover', '有形固定資産回転率', 'multiple'),
        ('receivables_days', '売上債権回転日数', 'days'),
        ('inventory_days', '棚卸資産回転日数', 'days'),
        ('payables_days', '買入債務回転日数', 'days'), ('ccc', 'Cash Conversion Cycle', 'days'))),
    'FCF': ('DCF', (
        ('nopat', 'NOPAT', 'money'), ('noncash', '非現金支出', 'money'),
        ('trade_receivables', '売上債権', 'money'), ('inventory', '在庫', 'money'),
        ('trade_payables', '支払債務', 'money'), ('working_capital_change', '⊿運転資本', 'money'),
        ('capex', '設備投資額', 'money'), ('fcf', 'FCF', 'money'))),
}


def append_model_series(dataset, output, factor: Decimal):
    """Align saved display-unit values with the requested graph-unit scale."""
    metadata = dataset.export_metadata or {}
    models = metadata.get('supplemental', {})
    current_definition = metadata.get('format_version') == 6
    factors = {'yen': Decimal(1), 'thousand': Decimal(1000), 'million': Decimal(1000000)}
    source_factor = factors.get(metadata.get('unit'))
    for view, (sheet, definitions) in MODEL_VIEWS.items():
        # Earlier releases used different noncash and FR definitions. Their
        # same-named values must not silently acquire the new chart labels.
        annual = models.get(sheet, {}).get('periods', {}) if current_definition else {}
        output[view] = {}
        for key, label, kind in definitions:
            values, reasons = [], []
            for period in output['periods']:
                record = annual.get(period['key'], {}).get(key, {})
                raw = record.get('display_value')
                reason = record.get('missing', [])
                if raw is None or raw == '':
                    values.append(None)
                    reasons.append(reason or (['旧版の分析定義です。新版でExcelを再作成してください。']
                        if models and not current_definition else ['対応するモデルの数値が保存されていません。']))
                    continue
                try:
                    value = Decimal(str(raw))
                except InvalidOperation as exc:
                    raise ValueError(f'{sheet}の{label}に不正なグラフ値があります。') from exc
                if not value.is_finite():
                    raise ValueError(f'{sheet}の{label}に有限値以外のグラフ値があります。')
                if kind == 'money':
                    if source_factor is None:
                        raise ValueError('保存済みモデルの表示単位を確認できません。')
                    value = value * source_factor / factor
                values.append(value)
                reasons.append(reason)
            output[view][key] = {'label': label, 'kind': kind, 'values': values,
                                 'cells': [], 'reasons': reasons, 'model_sheet': sheet}
    return output
