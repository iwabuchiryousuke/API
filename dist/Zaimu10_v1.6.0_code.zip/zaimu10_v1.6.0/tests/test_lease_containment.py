"""Optional BS display parents require the exact original inclusion sentence."""
from copy import deepcopy
from datetime import date
import gzip
import json
from pathlib import Path
from types import SimpleNamespace

from lxml import html
import pytest

from zaimu10.debt_notes import (_ifrs_lease_containment_proof,extract_debt_notes,
    _local,_text,_compact)
from zaimu10.models import Filing,Period
from zaimu10.parser import parse_filing

F=Path(__file__).parent/'fixtures'/'ajinomoto_debt'


def pages(doc):return json.loads(gzip.decompress((F/f'{doc}.json.gz').read_bytes()))
def proof(c):return json.loads(c.note.split('debt_note_evidence:',1)[1])


def case(doc='S100Y992'):
    for name,markup in pages(doc):
        root=html.fromstring(markup.encode('utf8'),parser=html.HTMLParser(encoding='utf8'))
        blocks=[n for n in root.iter()if isinstance(n.tag,str)and
                n.get('name','').rsplit(':',1)[-1]=='NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock']
        if not blocks:continue
        assert len(blocks)==1;block=blocks[0]
        table=next(t for t in block.iter()if isinstance(t.tag,str)and _local(t.tag)=='table'
                   and '支払期日が1年以内'in _compact(_text(t)))
        paragraph=next(n for n in block.iter()if isinstance(n.tag,str)and _local(n.tag)=='p'
                       and _compact(_text(n)).startswith('リース負債は'))
        return block,table,paragraph
    raise AssertionError('missing real source')


def test_actual_dual_period_sentence_records_real_paragraph_and_scope():
    b,t,p=case();context=SimpleNamespace(start=date(2025,4,1),end=date(2026,3,31))
    for end in [date(2025,3,31),date(2026,3,31)]:
        e=_ifrs_lease_containment_proof(b,t,context,Period(date(end.year-1,4,1),end))
        assert e and e['statement']==_text(p)
        assert e['applies_to']=='current_and_prior_annual_closing'
        assert e['target_period_end']==end.isoformat()
        assert e['paragraph_xpath']==p.getroottree().getpath(p)
        assert e['paragraph_index']>0 and e['block_node_index']<e['source_table_node_index']
        assert e['source_context']=='CurrentYearDuration'
        assert e['source_raw_qname']=='jpigp_cor:NotesLeasesConsolidatedFinancialStatementsIFRSTextBlock'


def test_actual_single_current_sentence_does_not_assert_prior_containment():
    b,t,_=case('S100IY1B');context=SimpleNamespace(start=date(2019,4,1),end=date(2020,3,31))
    assert _ifrs_lease_containment_proof(b,t,context,Period(date(2019,4,1),date(2020,3,31)))
    assert _ifrs_lease_containment_proof(b,t,context,Period(date(2018,4,1),date(2019,3,31)))is None


@pytest.mark.parametrize('change',['deleted','one_side','reversed','ambiguous','extra','duplicate'])
def test_missing_ambiguous_or_reversed_inclusion_never_assigns_a_parent(change):
    b,t,p=case();text=_compact(_text(p))
    if change=='deleted':p.getparent().remove(p)
    elif change=='duplicate':p.addprevious(deepcopy(p))
    else:
        if change=='one_side':text=text.replace('その他の金融負債(非流動負債)','他の項目')
        elif change=='reversed':
            text=text.replace('その他の金融負債(流動負債)','<TEMP>').replace('その他の金融負債(非流動負債)','その他の金融負債(流動負債)').replace('<TEMP>','その他の金融負債(非流動負債)')
        elif change=='ambiguous':text=text.replace('その他の金融負債(流動負債)','その他の金融負債(流動負債又は非流動負債)')
        else:text+='別の負債にも含まれます。'
        p.clear();p.text=text
    context=SimpleNamespace(start=date(2025,4,1),end=date(2026,3,31))
    assert _ifrs_lease_containment_proof(b,t,context,Period(date(2025,4,1),date(2026,3,31)))is None


def test_wrong_annual_period_does_not_borrow_the_inclusion_statement():
    b,t,_=case();context=SimpleNamespace(start=date(2025,4,1),end=date(2026,3,31))
    assert _ifrs_lease_containment_proof(b,t,context,Period(date(2026,4,1),date(2027,3,31)))is None


@pytest.mark.parametrize('doc,expected',[
    ('S100Y992',{'2025-03-31','2026-03-31'}),('S100IY1B',{'2020-03-31'}),
    ('S100G6V9',set()),('S100DDYF',set()),
])
def test_metadata_only_maps_modern_carried_lease_rows_and_keeps_old_memo(doc,expected):
    ps=pages(doc);ds=parse_filing(Filing(doc,code='2802',edinet_code='E00436'),ps)
    rows=extract_debt_notes(ps,ds)
    count=0
    for row in rows:
        category=row.key.split(':')[2]
        if category not in {'current_lease','noncurrent_lease'}:continue
        for key,c in row.values.items():
            e=proof(c);end=key.rsplit('/',1)[1]
            if end in expected:
                assert e['parent_local']==('OtherFinancialLiabilitiesCLIFRS'if category=='current_lease'else'OtherFinancialLiabilitiesNCLIFRS')
                assert e['parent_containment']['selected_scope']==('current'if category=='current_lease'else'noncurrent')
                assert e['parent_containment']['target_period_end']==end
                assert '含まれております' in e['parent_containment']['statement']
                assert e['measurement']=='carrying_amount'
                count+=1
            else:
                assert 'parent_local'not in e and 'parent_containment'not in e
    assert count==2*len(expected)
